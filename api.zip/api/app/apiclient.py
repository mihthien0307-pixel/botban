import random
import websocket
import struct
import requests, json

from ..util import utilzone

from ..models import *
from ..util.pack import *
from . import appstate
from ..util.logging import Logging
from urllib.parse import urlencode, urlparse
from concurrent.futures import ThreadPoolExecutor, Future
import os, math
from ..methods.util import utilsApi
from ..methods.upload import AttachmentsAPi
from ..methods.fetch import FetchAPi
from ..methods.get import GetAPi
from ..methods.account import AccAPi
from ..methods.threadgroup import GroupAPi
from ..methods.user import ActionAPi
from ..methods.send import SendAPi

import asyncio
import aiohttp
import re
import queue
import aiofiles
import time
pool = ThreadPoolExecutor(max_workers=9999)
logger = Logging(theme="catppuccin-mocha", log_text_color="black")
ApisMethod = (AttachmentsAPi, utilsApi,
               FetchAPi, GetAPi, AccAPi, GroupAPi,
                 ActionAPi, SendAPi)
class ZaloAPI(*ApisMethod):
    def __init__(self, phone, password, imei, session_cookies=None, user_agent=None, auto_login=True):
        self._state = appstate.State()
        self._condition = threading.Event()
        self._listening = False
        self._start_fix = False
        self.typeLogin = "PC"
        self.apiLogintype = 24
        self._upload_callbacks = {}
        self._upload_callbacks_async = {}
        self.bools = ThreadPoolExecutor()
        if auto_login:
            if (
                not session_cookies 
                or not self.setSession(session_cookies) 
                or not self.isLoggedIn()
            ):
                self.login(phone, password, imei, user_agent)
        
    def uid(self):
        return self.uid

    def setTyping(self, threadId, type):
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "imei": self._imei
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-chat1-wpa.chat.zalo.me/api/message/typing"
            payload["params"]["toid"] = str(threadId)
            payload["params"]["destType"] = 3
        elif type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/typing"
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            return True
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def markAsDelivered(
        self,
        msgId,
        cliMsgId,
        senderId,
        threadId,
        type,
        seen=0,
        method="webchat"
    ):
        destination_id = "0" if type == ThreadType.USER else threadId
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "msgInfos": {
                    "seen": 0,
                    "data": [{
                        "cmi": str(cliMsgId),
                        "gmi": str(msgId),
                        "si": str(senderId),
                        "di": str(destination_id),
                        "mt": method,
                        "st": 3,
                        "at": 0,
                        "ts": str(utilzone.now())
                    }]
                }
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-chat3-wpa.chat.zalo.me/api/message/deliveredv2"
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 501
        else:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/deliveredv2"
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 521
            payload["params"]["msgInfos"]["grid"] = str(destination_id)
            payload["params"]["imei"] = self._imei
        
        payload["params"]["msgInfos"] = json.dumps(payload["params"]["msgInfos"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            self.onMessageDelivered(msgId, threadId, type, utilzone.now())
            return True
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def markAsRead(
        self,
        msgId,
        cliMsgId,
        senderId,
        threadId,
        type,
        method="webchat"
    ):
        destination_id = "0" if type == ThreadType.USER else threadId
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "msgInfos": {
                    "data": [{
                        "cmi": str(cliMsgId),
                        "gmi": str(msgId),
                        "si": str(senderId),
                        "di": str(destination_id),
                        "mt": method,
                        "st": 3,
                        "ts": str(utilzone.now())
                    }]
                },
                "imei": self._imei
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-chat1-wpa.chat.zalo.me/api/message/seenv2"
            payload["params"]["msgInfos"]["data"][0]["at"] = 7
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 501
            payload["params"]["senderId"] = str(destination_id)
        elif type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/seenv2"
            payload["params"]["msgInfos"]["data"][0]["at"] = 0
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 511
            payload["params"]["grid"] = str(destination_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"]["msgInfos"] = json.dumps(payload["params"]["msgInfos"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            self.onMarkedSeen(msgId, threadId, type, utilzone.now())
            return True
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    LOGIN METHODS
    """
    
    def isLoggedIn(self):
        return self._state.is_logged_in()
        
    def getSession(self):
        return self._state.get_cookies()
        
    def setSession(self, session_cookies):
        try:
            if not isinstance(session_cookies, dict):
                return False
            self._state.set_cookies(session_cookies)
            self.uid = self._state.user_id
        except Exception as e:
            print("Failed loading session")
            return False
        return True
    
    def getSecretKey(self):
        return self._state.get_secret_key()
        
    def setSecretKey(self, secret_key):
        try:
            self._state.set_secret_key(secret_key)
            return True
        except:
            return False
    
    def login(self, phone, password, imei, user_agent=None):
        if not (phone and password):
            raise ZaloUserError("Phone and password not set")
        
        self.onLoggingIn()
        
        self._state.login(
            phone,
            password,
            imei,
            user_agent=user_agent
        )
        try:
            self._imei = self._state.user_imei
            self.uid = self.fetchAccountInfo().profile.get("userId", self._state.user_id)
        except:
            self._imei = None
            self.uid = self._state.user_id
        
        self.onLoggedIn(self._state._config.get("phone_number"))
    
    """
    END LOGIN
    """

    """
    LISTEN METHODS
    """
    
    def stop_listening(self):
        self._should_reconnect = False
        
        if hasattr(self, "ping_interval") and self.ping_interval:
            self.ping_interval.cancel()
            logger.info("WebSocket ping scheduler has been canceled.")

        if hasattr(self, "ws") and self.ws:
            self.ws.close()
            self.bools.shutdown(wait=False)
            logger.info("WebSocket connection has been closed manually.")
        else:
            logger.warning("WebSocket is not running or already closed.")

        self.listening = False
        return
    
    def _listen(self, thread=False, reconnect=5):
        self._condition.clear()
        params = {"zpw_ver": 647, "zpw_type": self.apiLogintype, "t": utilzone.now()}
        url = self._state._config["zpw_ws"][0] + "?" + urlencode(params)
        user_agent = self._state._headers.get("User-Agent") or utilzone.HEADERS["User-Agent"]
        raw_cookies = utilzone.dict_to_raw_cookies(self._state.get_cookies())
        if not raw_cookies:
            raise ZaloUserError("Unable to load cookies! Probably due to incorrect cookie format (cookies must be dict)")
        headers = {
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Connection": "Upgrade",
            "Host": urlparse(url).netloc,
            "Origin": "https://chat.zalo.me",
            "Pragma": "no-cache",
            "Sec-WebSocket-Extensions": "permessage-deflate; client_max_window_bits",
            "Sec-WebSocket-Version": "13",
            "Upgrade": "websocket",
            "User-Agent": user_agent,
            "Cookie": raw_cookies,
        }

        def on_open(ws):
            self.listening = True
            self._should_reconnect = True
            self.onListening()
        def on_close(ws, status_code, msg):
            logger.info(f"WebSocket connection closed: {status_code} - {msg}")
            self.listening = False
        def on_error(ws, error):
            if isinstance(error, KeyboardInterrupt):
                ws.close()
                logger.warning("Stop Listen Because KeyboardInterrupt Exception!")
                pid = os.getpid()
                os.kill(pid, signal.SIGTERM)
            self.onErrorCallBack(error)
            
        def on_message(ws, data):
            if not isinstance(data, bytes):
                return
            try:
                encodedHeader = data[:4]
                version, cmd, subCmd = utilzone.getHeader(encodedHeader)
                
                dataToDecode = data[4:]
                decodedData = dataToDecode.decode("utf-8")
                if not decodedData or "eventId" in decodedData:
                    return
                
                if not isinstance(decodedData, dict):
                    parsed = json.loads(decodedData)
                
                parsed = json.loads(decodedData)
                
                if version == 1 and cmd == 1 and subCmd == 1 and "key" in parsed:
                    self.ws_key = parsed["key"]
                
                    if hasattr(self, "ping_interval") and self.ping_interval:
                        self.ping_interval.cancel()
                    
                    self.ws_ping_scheduler()
                    return
                
                if not hasattr(self, "ws_key"):
                    return logger.error("Unable to decrypt data because key not found")
                
                parsedData = utilzone.zws_decode(parsed, self.ws_key)
                if version == 1 and cmd == 3000 and subCmd == 0:
                    logger.warning("Another connection is opened, closing this one")
                    self._should_reconnect = True
                    ws.close()
                
                elif version == 1 and cmd == 501 and subCmd == 0:
                    parsedData = utilzone.zws_decode(parsed, self.ws_key)
                    userMsgs = parsedData["data"]["msgs"]
                    
                    for message in userMsgs:
                        msgObj = MessageObject.fromDict(message, None)
                        [
                            self.bools.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                            if self.thread else
                            self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                        ]
                
                elif version == 1 and cmd == 521 and subCmd == 0:
                    groupMsgs = parsedData["data"]["groupMsgs"]
                    try:
                        for message in groupMsgs:
                            # messages = self.getRecentGroup(message["idTo"])["groupMsgs"]
                            # message = next((msg for msg in messages if msg["msgId"] == message["msgId"]), message)

                            msgObj = MessageObject.fromDict(message, None)
                            [
                                self.bools.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                                if self.thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                            ]
                    except Exception as e:
                        pass
                
                elif version == 1 and cmd == 601 and subCmd == 0:
                    controls = parsedData["data"].get("controls", [])
                    for control in controls:
                        if control["content"]["act_type"] == "group":
                            
                            if control["content"]["act"] == "join_reject":
                                continue
                            
                            groupEventData = json.loads(control["content"]["data"]) if isinstance(control["content"]["data"], str) else control["content"]["data"]
                            groupEventType = utilzone.getGroupEventType(control["content"]["act"])
                            EventData = EventObject.fromDict(groupEventData)
                            EventType = groupEventType
                            [
                                self.bools.submit(self.onEvent, EventData, EventType)
                                if self.thread else
                                self.onEvent(EventData, EventType)
                            ]
                        elif control["content"]["act_type"] == "file_done":
                            file_data = {
                                "fileUrl": control["content"]["data"]["url"],
                                "fileId": control["content"]["fileId"]
                            }
                            if str(control["content"]["fileId"]) in self._upload_callbacks:
                                callback = self._upload_callbacks.get(str(control["content"]["fileId"]))
                                if callback:
                                    callback(file_data)
                                    del self._upload_callbacks[str(control["content"]["fileId"])]
                            elif str(control["content"]["fileId"]) in self._upload_callbacks_async:
                                callback = self._upload_callbacks_async.get(str(control["content"]["fileId"]))
                                if callback:
                                    asyncio.run(callback(file_data))
                                    del self._upload_callbacks_async[str(control["content"]["fileId"])]
                                
                        elif control["content"]["act_type"] == "voice_aac_success":
                            file_data = {
                                "fileUrl": control["content"]["data"].get("5") or control["content"]["data"].get("6"),
                                "fileId": control["content"]["fileId"]
                            }
                            if str(control["content"]["fileId"]) in self._upload_callbacks:
                                callback = self._upload_callbacks.get(str(control["content"]["fileId"]))
                                if callback:
                                    callback(file_data)
                                    del self._upload_callbacks[str(control["content"]["fileId"])]
                            elif str(control["content"]["fileId"]) in self._upload_callbacks_async:
                                callback = self._upload_callbacks_async.get(str(control["content"]["fileId"]))
                                if callback:
                                    asyncio.run(callback(file_data))
                                    del self._upload_callbacks_async[str(control["content"]["fileId"])]
                        continue

                elif cmd == 612:
                    reacts = parsedData["data"].get("reacts", [])
                    reactGroups = parsedData["data"].get("reactGroups", [])
                    
                    for react in reacts:
                        react["content"] = json.loads(react["content"])
                        msgObj = MessageObject.fromDict(react, None)
                        [
                            self.bools.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                            if self.thread else
                            self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                        ]
                    
                    for reactGroup in reactGroups:
                        reactGroup["content"] = json.loads(reactGroup["content"])
                        msgObj = MessageObject.fromDict(reactGroup, None)
                        [
                            self.bools.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                            if self.thread else
                            self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                        ]
            
            except Exception as e:
                self.onErrorCallBack(e)
        
        
        ws = websocket.WebSocketApp(
            url,
            header=headers,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            on_open=on_open
        )
        
        self.ws = ws
        self.thread = thread
        
        if not isinstance(reconnect, int):
            reconnect = 5
        
        self._should_reconnect = True
        ws.run_forever()
    
    
    def ws_ping_scheduler(self):
        payload = {
            "version": 1,
            "cmd": 2,
            "subCmd": 1,
            "data": {"eventId": int(time.time() * 1000)}
        }
        
        encoded_data = json.dumps(payload["data"]).encode()
        data_length = len(encoded_data)
        header = struct.pack("<BIB", payload["version"], payload["cmd"], payload["subCmd"])
        data = header + encoded_data
        self.ws.send(data, websocket.ABNF.OPCODE_BINARY)
        
        self.ping_interval = threading.Timer(1 * 60, self.ws_ping_scheduler)
        self.ping_interval.start()
    
    
    def listen(self, thread=False, reconnect=5):
        if not isinstance(reconnect, int) or reconnect < 0:
            reconnect = 5
        
        self._should_reconnect = True
        
        while True:
            try:
                self._listen(thread, reconnect)
            except Exception as e:
                logger.error(f"Listen error: {e}")
            
            if not self._should_reconnect:
                logger.info("Auto reconnect disabled, stopping.")
                break
            
            logger.info(f"Reconnecting in {reconnect} seconds...")
            time.sleep(reconnect)
        
        self.bools = ThreadPoolExecutor()
    """
    END LISTEN METHODS
    """
    
    """
    EVENTS
    """
    
    def onLoggingIn(self, phone=None):
        """Called when the client is logging in.
        
        Args:
            phone: The phone number of the client
        """
        #os.system('cls' if os.name == 'nt' else 'clear')
        
    def onLoggedIn(self, phone=None):
        """Called when the client is successfully logged in.
            
        Args:
            phone: The phone number of the client
        """
        #os.system('cls' if os.name == 'nt' else 'clear')
    
    def onListening(self):
        logger.debug(f"Listening for: {self.bot} - {self.uid} at {self.typeLogin} | {self.apiLogintype}")
    
    def onMessage(
        self,
        mid=None,
        userId=None,
        message=None,
        data=None,
        threadId=None,
        type=ThreadType.USER
    ):
        logger.info("{} from {} in {}".format(message, threadId, type.name))
    
    def onEvent(self, EventData, EventType):
        """Called when the client listening, and some events occurred.

        Args:
            EventData (EventObject): Event data (As a `EventObject` object)
            EventType (EventType/GroupEventType): Event Type
        """
    
    def onMessageDelivered(
        self,
        msg_ids=None,
        threadId=None,
        type=ThreadType.USER,
        ts=None
    ):
        logger.info(
            "Marked messages {} as delivered in [({}, {})] at {}.".format(
                msg_ids, threadId, type.name, int(ts / 1000)
            )
        )

    def onMarkedSeen(
        self,
        msg_ids=None,
        threadId=None,
        type=ThreadType.USER,
        ts=None
    ):
        logger.info(
            "Marked messages {} as seen in [({}, {})] at {}.".format(
                msg_ids, threadId, type.name, int(ts / 1000)
            )
        )
    
    def onErrorCallBack(self, error, ts=int(time.time())):
        if "login" in str(error):
            msg = "❌ Imei Cookies Has Expired Or Null Error To Run!"
            logger.error(msg)
            print(f"[ERROR #{ts}] {msg}")
        else:
            logger.error(f"An error occurred at {ts}: {error}")
            print(traceback.format_exc())
    
    """
    END EVENTS
    """
