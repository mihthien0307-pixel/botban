import json

import random

from ..util import utilzone
_util = utilzone
from ..util.pack import *
from ..app import appstate
from ..models import *

class SendAPi:
    def send(self, message, threadId, type=ThreadType.USER, mark_message=None, ttl=0):
        """Send message to a thread.
            
        Args:
            message (Message): Message to send
            threadId (int | str): User/Group ID to send to
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        threadId = str(int(threadId) or self.uid)
        if message.mention:
            return self.sendMentionMessage(message, threadId, ttl)
        else:
            return self.sendMessage(message, threadId, type, mark_message, ttl)
    
    def sendMessage(
        self,
        message,
        threadId,
        threadType,
        mark_message=None,
        ttl=0
    ):
        """Send message to a thread (user/group).

        Args:
            message (Message): Message to send
            threadId (int | str): User/Group ID to send to
            threadType (ThreadType): ThreadType.USER, ThreadType.GROUP
            mark_message (str): Send messages as `Urgent` or `Important` mark

        Returns:
            object: User/Group (returns sent message info)

        Raises:
            ZaloAPIException: If request failed
            ZaloUserError: If input is invalid
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0,
        }

        clientId = utilzone.now()

        payload = {
            "params": {
                "message": message.text,
                "clientId": clientId,
                "imei": self._imei,
                "ttl": ttl,
            }
        }

        if mark_message and mark_message.lower() in ("important", "urgent"):
            payload["params"]["metaData"] = {
                "urgency": 1 if mark_message.lower() == "important" else 2
            }

        if message.style:
            payload["params"]["textProperties"] = message.style

        if threadType == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
            payload["params"]["toid"] = str(threadId)
        elif threadType == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending requests: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, dict):
                results["clientId"] = clientId
            elif isinstance(results, str):
                try:
                    results = json.loads(results)
                    results["clientId"] = clientId
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending requests: {results}"
                    )

            return (
                Group.fromDict(results, None)
                if threadType == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending requests: {error_message}"
        )
    
    def sendbug(self, message, threadId, threadType, clientId=None, mark_message=None, ttl=0):
        params = {"zpw_ver": 645,"zpw_type": self.apiLogintype,"nretry": 0,}
        clientId = clientId or utilzone.now()
        payload = {"params": {"message": message.text,"clientId": clientId,"imei": self._imei,"ttl": ttl,}}
        if mark_message and mark_message.lower() in ("important", "urgent"):
            payload["params"]["metaData"] = {"urgency": 1 if mark_message.lower() == "important" else 2}
        if message.style:
            payload["params"]["textProperties"] = message.style
        if message.mention:
            payload["params"]["mentionInfo"] = message.mention
        if threadType == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
            payload["params"]["toid"] = str(threadId)
        elif threadType == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg"
            payload["params"]["grid"] = str(threadId)
            payload["params"]["visibility"] = 0
        else:
            raise ZaloUserError("Thread type is invalid")
        payload["params"] = self._encode(payload["params"])
        response = self._post(url, params=params, data=payload)
        data = response.json()
        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException("Error #1337 when sending requests: Data is None")

            results = self._decode(results)
            results = results.get("data") or results
            if isinstance(results, dict):
                results["clientId"] = clientId
            elif isinstance(results, str):
                try:
                    results = json.loads(results)
                    results["clientId"] = clientId
                except Exception:
                    raise ZaloAPIException(f"Error #1337 when sending requests: {results}")
            return Group.fromDict(results, None) if threadType == ThreadType.GROUP else User.fromDict(results, None)
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def replyMessageStyle(self, message,   replyMsg, threadId, threadType, ttl=0,
                          color=None, title=None, mention=None, userId=None):
        """
        Gửi tin reply có style màu + tiêu đề.

        Params:
            color    : "gr" (xanh) | "r" (đỏ) | "yl" (vàng) | "or" (cam)
            title    : tiêu đề in đậm đặt trước nội dung
            mention  : đối tượng Mention (optional)
            userId   : uid người dùng — nếu truyền vào sẽ prepend tên,
                       GROUP thì @mention, USER thì chỉ lấy tên
        """
        import json

        def dem_ki_tu_utf16_units(chuoi: str) -> int:
            """Đếm theo số code unit UTF-16 (mỗi unit = 2 byte)"""
            return len(chuoi.encode("utf-16-le")) // 2

        color_map = {"gr": "15a85f", "r": "db342e", "yl": "f7b503", "or": "f27806"}
        params = {"zpw_ver": 645, "zpw_type": self.apiLogintype, "nretry": 0}

        # ── Lấy size font tùy chỉnh (lệnh `fontsize`), fallback 12/11 ──────
        title_size, body_size = 12, 11
        try:
            from src.services.utils.jsonio import read_settings as _rs
            _fs = _rs(self.uid)
            title_size = int(_fs.get("font_title_size", 12))
            body_size  = int(_fs.get("font_body_size", 11))
        except Exception:
            pass

        # ── Extract text + existing style ─────────────────────────────────
        if isinstance(message, str):
            text      = message
            style_str = None
            mention   = mention
        else:
            text      = message.text or ""
            style_str = message.style if getattr(message, "style", None) else None
            mention   = mention if mention is not None else getattr(message, "mention", None)

        # ── Build styled text: [uname\n]title[\n]body với offset chính xác ──
        # Thứ tự cố định: mention-name (nếu có) → title (nếu có) → body
        # Mention offset luôn = 0 (trỏ đúng vào tên đầu chuỗi)
        if color or title or userId is not None:
            hex_color = color_map.get((color or "").lower(), color or "ffffff")
            nl        = chr(10)
            styles    = []
            cursor    = 0  # con trỏ vị trí UTF-16
            full_text = ""

            # -- Phần 1: tên người dùng (mention) --
            if userId is not None:
                try:
                    uname = self.userName(str(userId))
                except Exception:
                    uname = str(userId)

                uname_len = dem_ki_tu_utf16_units(uname)

                if threadType == ThreadType.GROUP:
                    from api.util.msg import Mention as _Mention
                    mention = _Mention(userId, offset=0, length=uname_len)

                full_text += uname + nl
                cursor    += uname_len + 1  # +1 cho '\n'

            # -- Phần 2: title (màu + bold) --
            if title:
                tag_len = dem_ki_tu_utf16_units(title)
                styles.append({
                    "start": cursor,
                    "len":   tag_len,
                    "st":    f"c_{hex_color},b,f_{title_size}",
                })
                full_text += title + nl
                cursor    += tag_len + 1

            # -- Phần 3: body --
            body_len = dem_ki_tu_utf16_units(text)
            if body_len > 0:
                styles.append({
                    "start": cursor,
                    "len":   body_len,
                    "st":    f"f_{body_size}",
                })
                full_text += text

            style_str = json.dumps({"styles": styles, "ver": 0}) if styles else style_str
            text      = full_text

        payload = {
            "params": {
                "message": text,
                "clientId": utilzone.now(),
                "qmsgOwner": str(int(getattr(replyMsg, "uidFrom", self.uid)) or self.uid),
                "qmsgId": getattr(replyMsg, "msgId", ""),
                "qmsgCliId": getattr(replyMsg, "cliMsgId", ""),
                "qmsgType": utilzone.getClientMessageType(getattr(replyMsg, "msgType", 0)),
                "qmsg": "" if not isinstance(getattr(replyMsg, "content", ""), str) else replyMsg.content,
                "qmsgTs": getattr(replyMsg, "ts", 0),
                "qmsgAttach": json.dumps({}),
                "qmsgTTL": 0,
                "ttl": ttl
            }
        }

        if not isinstance(getattr(replyMsg, "content", None), str):
            payload["params"]["qmsg"] = ""
            payload["params"]["qmsgAttach"] = json.dumps(
                getattr(replyMsg.content, "toDict", lambda: {})()
            )

        if style_str:
            payload["params"]["textProperties"] = style_str

        mention_val = mention if mention is not None else (
            getattr(message, "mention", None) if not isinstance(message, str) else None
        )
        if mention_val is not None:
            payload["params"]["mentionInfo"] = str(mention_val) if not isinstance(mention_val, str) else mention_val

        if threadType == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/quote"
            payload["params"]["toid"] = str(threadId)

        elif threadType == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/quote"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)

        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])
        response = self._post(url, params=params, data=payload)
        data = response.json()

        results = data.get("data") if data.get("error_code") == 0 else None

        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results

            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}

            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}

            return results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
       
    def replyMessage(
        self,
        message,
        replyMsg,
        threadId,
        threadType,
        ttl=0
    ):
        """Reply message in group/user by ID.

        Args:
            message (Message): Message object to send
            replyMsg (Message): Message object to reply to
            threadId (int | str): User/Group ID to send to
            threadType (ThreadType): ThreadType.USER, ThreadType.GROUP

        Returns:
            object: User/Group (returns sent message info)

        Raises:
            ZaloAPIException: If request failed
            ZaloUserError: If input is invalid
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0,
        }

        clientId = utilzone.now()

        payload = {
            "params": {
                "message": message.text,
                "clientId": clientId,
                "qmsgOwner": str(int(replyMsg.uidFrom) or self.uid),
                "qmsgId": replyMsg.msgId,
                "qmsgCliId": replyMsg.cliMsgId,
                "qmsgType": utilzone.getClientMessageType(replyMsg.msgType),
                "qmsg": replyMsg.content,
                "qmsgTs": replyMsg.ts,
                "qmsgAttach": json.dumps({}),
                "qmsgTTL": 0,
                "ttl": ttl,
            }
        }

        if not isinstance(replyMsg.content, str):
            payload["params"]["qmsg"] = ""
            payload["params"]["qmsgAttach"] = json.dumps(
                replyMsg.content.toDict()
            )

        if message.style:
            payload["params"]["textProperties"] = message.style

        if message.mention:
            payload["params"]["mentionInfo"] = message.mention

        if threadType == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/quote"
            payload["params"]["toid"] = str(threadId)
        elif threadType == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/quote"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending requests: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, dict):
                results["clientId"] = clientId
            elif isinstance(results, str):
                try:
                    results = json.loads(results)
                    results["clientId"] = clientId
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending requests: {results}"
                    )

            return (
                Group.fromDict(results, None)
                if threadType == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending requests: {error_message}"
        )

    
    def sendMentionMessage(self, message, groupId, ttl=0):
        """Send message to a group with mention by ID.

        Args:
            message (Message): Message to send (text + mention)
            groupId (int | str): Group ID to send to
            ttl (int): Time-to-live for message

        Returns:
            Group: Sent message info

        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0,
        }

        clientId = utilzone.now()

        payload = {
            "params": {
                "grid": str(groupId),
                "message": message.text,
                "mentionInfo": message.mention,
                "clientId": clientId,
                "visibility": 0,
                "ttl": ttl,
            }
        }

        if message.style:
            payload["params"]["textProperties"] = message.style

        payload["params"] = self._encode(payload["params"])

        response = self._post(
            "https://tt-group-wpa.chat.zalo.me/api/group/mention",
            params=params,
            data=payload,
        )

        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending requests: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, dict):
                results["clientId"] = clientId
            elif isinstance(results, str):
                try:
                    results = json.loads(results)
                    results["clientId"] = clientId
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending requests: {results}"
                    )

            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending requests: {error_message}"
        )

        
    def sendReaction(
        self,
        messageObject,
        reactionIcon,
        threadId,
        threadType,
        reactionType=75
    ):
        """Reaction message by ID.

        Args:
            messageObject (Message): Message object to send reaction
            reactionIcon (str): Icon/Text to reaction
            threadId (int | str): Group/User ID contain message to reaction
            threadType (ThreadType): ThreadType.USER, ThreadType.GROUP

        Returns:
            object: User/Group message reaction data

        Raises:
            ZaloAPIException: If request failed
            ZaloUserError: If input is invalid
        """
        params = {
            "zpw_ver": 647,
            "zpw_type": 30,
        }

        payload = {
            "params": {
                "react_list": [
                    {
                        "message": json.dumps(
                            {
                                "rMsg": [
                                    {
                                        "gMsgID": int(messageObject.msgId),
                                        "cMsgID": int(messageObject.cliMsgId),
                                        "msgType": utilzone.getClientMessageType(
                                            messageObject.msgType
                                        ),
                                    }
                                ],
                                "rIcon": reactionIcon,
                                "rType": reactionType,
                                "source": 6,
                            }
                        ),
                        "clientId": utilzone.now(),
                    }
                ],
                "imei": self._imei,
            }
        }

        if threadType == ThreadType.USER:
            url = "https://reaction.chat.zalo.me/api/message/reaction"
            payload["params"]["toid"] = str(threadId)
        elif threadType == ThreadType.GROUP:
            url = "https://reaction.chat.zalo.me/api/group/reaction"
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending requests: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending requests: {results}"
                    )

            return (
                Group.fromDict(results, None)
                if threadType == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending requests: {error_message}"
        )

    
    def sendMultiReaction(
        self,
        messageObject,
        reactionIcon,
        threadId,
        threadType,
        reactionType=75,
        numreact=1
    ):
        """Reaction message by ID.

        Args:
            messageObject (MessageReaction): Message(s) data to reaction
            reactionIcon (str): Icon/Text to reaction
            threadId (int | str): Group/User ID contain message to reaction
            threadType (ThreadType): ThreadType.USER, ThreadType.GROUP

        Returns:
            object: User/Group message reaction data

        Raises:
            ZaloAPIException: If request failed
            ZaloUserError: If input is invalid
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
        }

        payload = {
            "params": {
                "react_list": [
                    {
                        "message": {
                            "rMsg": [],
                            "rIcon": reactionIcon,
                            "rType": reactionType,
                            "source": 6,
                        },
                        "clientId": utilzone.now(),
                    }
                ],
                "imei": self._imei,
            }
        }

        if not isinstance(messageObject, dict):
            raise ZaloUserError("Reaction type is invalid")

        for _ in range(numreact):
            payload["params"]["react_list"][0]["message"]["rMsg"].append(
                {
                    "gMsgID": int(messageObject.msgId),
                    "cMsgID": int(messageObject.cliMsgId),
                    "msgType": utilzone.getClientMessageType(
                        messageObject.msgType
                    ),
                }
            )

        if threadType == ThreadType.USER:
            url = "https://reaction.chat.zalo.me/api/message/reaction"
            payload["params"]["toid"] = str(threadId)
        elif threadType == ThreadType.GROUP:
            url = "https://reaction.chat.zalo.me/api/group/reaction"
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")

        # Encode payload
        payload["params"]["react_list"][0]["message"] = json.dumps(
            payload["params"]["react_list"][0]["message"]
        )
        payload["params"] = self._encode(payload["params"])

        # Sync request
        response = self._post(url, params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending requests: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending requests: {results}"
                    )

            return (
                Group.fromDict(results, None)
                if threadType == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending requests: {error_message}"
        )
        
    def sendRemoteFile(self, fileUrl, threadId, type, fileName="default", fileSize=None, extension="vrxx", ttl=0, local_path=None):
        """
        Send File to a User/Group with url.
            
        Args:
            fileUrl (str): File url to send
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            fileName (str): File name to send
            fileSize (int): File size to send
            extension (str): type of file to send (py, txt, mp4, ...)
            local_path (str, optional): Path to local file to compute checksum
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        fileChecksum = None
        if local_path and os.path.exists(local_path):
            with open(local_path, "rb") as file:
                fileChecksum = hashlib.md5(file.read()).hexdigest()
        elif not fileSize:
            try:
                with self._state._session.get(fileUrl) as response:
                    if response.status_code == 200:
                        fileSize = int(response.headers.get("Content-Length", len(response.content)))
                        fileChecksum = hashlib.md5(response.content).hexdigest()
                    else:
                        fileSize = 0
                        fileChecksum = hashlib.md5(b"").hexdigest() 
            except:
                raise ZaloAPIException("Unable to get url content")
        else:
            fileChecksum = hashlib.md5(b"").hexdigest() 
    
        has_extension = fileName.rsplit(".")
        extension = has_extension[-1:][0] if len(has_extension) >= 2 else extension
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "fileId": str(int(utilzone.now() * 2)),
                "checksum": fileChecksum,
                "checksumSha": "",
                "extension": extension,
                "totalSize": fileSize,
                "fileName": fileName,
                "clientId": utilzone.now(),
                "fType": 1,
                "fileCount": 0,
                "fdata": "{}",
                "fileUrl": fileUrl,
                "zsource": 401,
                "ttl": ttl
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/asyncfile/msg"
            payload["params"]["toid"] = str(threadId)
            payload["params"]["imei"] = self._imei
        elif type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/asyncfile/msg"
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
        
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendRemoteVideo(self, videoUrl, thumbnailUrl, duration, threadId, type, width=1280, height=720, message=None, ttl=0):
        """Send (Forward) video to a User/Group with url.
        
        Warning:
            This is a feature created through the forward function.
            Because Zalo Web does not allow viewing videos.
        
        Args:
            videoUrl (str): Video link to send
            thumbnailUrl (str): Thumbnail link for video
            duration (int | str): Time for video (ms)
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            width (int): Width of the video
            height (int): Height of the video
            message (Message): Message to send with video
        
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        try:
            with self._state._session.head(videoUrl) as response:
                if response.status_code == 200:
                    fileSize = int(response.headers.get("Content-Length", len(response.content)))
                else:
                    fileSize = 0
                
        except Exception as e:
            raise ZaloAPIException(f"Unable to get url content: {e}")
            
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "clientId": str(utilzone.now()),
                "ttl": ttl,
                "zsource": 704,
                "msgType": 5,
                "msgInfo": json.dumps({
                    "videoUrl": str(videoUrl),
                    "thumbUrl": str(thumbnailUrl),
                    "duration": int(duration),
                    "width": int(width),
                    "height": int(height),
                    "fileSize": fileSize,
                    "properties": {
                        "color": -1,
                        "size": -1,
                        "type": 1003,
                        "subType": 0,
                        "ext": {
                            "sSrcType": -1,
                            "sSrcStr": "",
                            "msg_warning_type": 0
                        }
                    },
                    "title": message.text or "" if message else ""
                })
            }
        }
        
        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toId"] = str(threadId)
            payload["params"]["imei"] = self._imei
        elif type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendRemoteImage(self, image_url, threadId, type, width=2560, height=2560, message=None, ttl=0):
        """Send remote image (via URL) to a User/Group.

        Args:
            image_url (str): Image URL
            threadId (int | str): User/Group ID
            threadType (ThreadType): ThreadType.USER or ThreadType.GROUP
            width (int): Image width
            height (int): Image height
            message (Message): Optional message attached to image
            ttl (int): Time-to-live (0 = unlimited)

        Returns:
            object: User/Group response

        Raises:
            ZaloAPIException: If request failed
            ZaloUserError: If input is invalid
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0,
        }

        clientId = utilzone.now()

        payload = {
            "params": {
                "photoId": int(clientId * 2),
                "clientId": int(clientId),
                "desc": message.text if message else "",
                "width": width,
                "height": height,
                "rawUrl": image_url,
                "thumbUrl": image_url,
                "hdUrl": image_url,
                "thumbSize": "0",
                "fileSize": "0",
                "hdSize": "0",
                "zsource": -1,
                "jcp": json.dumps(
                    {"sendSource": 1, "convertible": "jxl"}
                ),
                "ttl": ttl,
                "imei": self._imei,
            }
        }

        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention

        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
            payload["params"]["toid"] = str(threadId)
            payload["params"]["normalUrl"] = image_url
        elif type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
            payload["params"]["grid"] = str(threadId)
            payload["params"]["oriUrl"] = image_url
        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                raise ZaloAPIException(
                    "Error #1337 when sending image: Data is None"
                )

            results = self._decode(results)
            results = results.get("data") or results

            if isinstance(results, dict):
                results["clientId"] = clientId
            elif isinstance(results, str):
                try:
                    results = json.loads(results)
                    results["clientId"] = clientId
                except Exception:
                    raise ZaloAPIException(
                        f"Error #1337 when sending image: {results}"
                    )

            return (
                Group.fromDict(results, None)
                if type == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(
            f"Error #{error_code} when sending image: {error_message}"
        )
            
    
    def sendRemoteVoice(self, voiceUrl, threadId, type, fileSize=None, ttl=0):
        """Send voice by url.
            
        Args:
            voiceUrl (str): Voice link to send
            threadId (int | str): User/Group ID to change status in
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            fileSize (int | str): Voice content length (size) to send
        
        Returns:
            object: `User/Group` response
        
        Raises:
            ZaloAPIException: If request failed
        """
        with self._state._session.get(voiceUrl) as response:
            if response.status_code == 200:
                fileSize = fileSize if fileSize else int(response.headers.get("Content-Length", len(response.content)))
            else:
                fileSize = fileSize if fileSize else 0
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "ttl": ttl,
                "zsource": -1,
                "msgType": 3,
                "clientId": str(utilzone.now()),
                "msgInfo": json.dumps({
                    "voiceUrl": str(voiceUrl),
                    "m4aUrl": str(voiceUrl),
                    "fileSize": int(fileSize)
                })
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toId"] = str(threadId)
            payload["params"]["imei"] = self._imei
        else:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendLocalImage(self, imagePath, threadId, type, width=2560, height=2560, message=None, custom_payload=None, ttl=0):
        """Send Image to a User/Group with local file.
            
        Args:
            imagePath (str): Image directory to send
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            width (int): Image width to send
            height (int): Image height to send
            message (Message): Message to send with image
            
        Returns:
            object: `User/Group` objects response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        if custom_payload:
            if type == ThreadType.USER:
                url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
            elif type == ThreadType.GROUP:
                url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
            else:
                raise ZaloUserError("Thread type is invalid")
            
            payload = custom_payload
        
        else:
            uploadImage = self._uploadImage(imagePath, threadId, type)
            
            payload = {
                "params": {
                    "photoId": uploadImage.get("photoId", int(utilzone.now() * 2)),
                    "clientId": uploadImage.get("clientFileId", int(utilzone.now() - 1000)),
                    "desc": message.text if message else "" or "",
                    "width": width,
                    "height": height,
                    "rawUrl": uploadImage["normalUrl"],
                    "thumbUrl": uploadImage["thumbUrl"],
                    "hdUrl": uploadImage["hdUrl"],
                    "thumbSize": "53932",
                    "fileSize": "247671",
                    "hdSize": "344622",
                    "zsource": -1,
                    "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                    "ttl": ttl,
                    "imei": self._imei
                }
            }
        
            if message and message.mention:
                payload["params"]["mentionInfo"] = message.mention
            
            if type == ThreadType.USER:
                url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
                payload["params"]["toid"] = str(threadId)
                payload["params"]["normalUrl"] = uploadImage["normalUrl"]
            elif type == ThreadType.GROUP:
                url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
                payload["params"]["grid"] = str(threadId)
                payload["params"]["oriUrl"] = uploadImage["normalUrl"]
            else:
                raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def sendMultiRemoteImage(self, imageUrlList, threadId, type, width=2560, height=2560, message=None, ttl=0):
        """Send Multiple Image to a User/Group with remote file.
            
        Args:
            imageUrlList (list): List image url to send
            width (int): Image width to send
            height (int): Image height to send
            message (Message): Message to send with image
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        uploadData = []
        
        if not isinstance(imageUrlList, list) or len(imageUrlList) < 1:
            raise ZaloUserError("image url must be a list to be able to send multiple at once.")
        
        groupLayoutId = str(utilzone.now())
        
        for i, imageUrl in enumerate(imageUrlList):
            payload = {
                "params": {
                    "photoId": int(utilzone.now() * 2),
                    "clientId": int(utilzone.now() - 1000),
                    "desc": message.text if message else "" or "",
                    "width": width,
                    "height": height,
                    "groupLayoutId": groupLayoutId,
                    "totalItemInGroup": len(imageUrlList),
                    "isGroupLayout": 1,
                    "idInGroup": i,
                    "rawUrl": imageUrl,
                    "thumbUrl": imageUrl,
                    "hdUrl": imageUrl,
                    "thumbSize": "53932",
                    "fileSize": "247671",
                    "hdSize": "344622",
                    "zsource": -1,
                    "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                    "ttl": ttl,
                    "imei": self._imei
                }
            }
        
            if message and message.mention:
                payload["params"]["mentionInfo"] = message.mention
            
            if type == ThreadType.USER:
                payload["params"]["toid"] = str(threadId)
                payload["params"]["normalUrl"] = imageUrl
                url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
            elif type == ThreadType.GROUP:
                payload["params"]["grid"] = str(threadId)
                payload["params"]["oriUrl"] = imageUrl
                url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
            else:
                raise ZaloUserError("Thread type is invalid")
            payload["params"] = self._encode(payload["params"])
            response = self._post(url, params={"zpw_ver": 645, "zpw_type": self.apiLogintype, "nretry": 0}, data=payload)
            data = response.json()
            results = data.get("data") if data.get("error_code") == 0 else None
            if results:
                results = self._decode(results)
                results = results.get("data") if results.get("data") else results
                if results is None:
                    results = {"error_code": 1337, "error_message": "Data is None"}
                
                if isinstance(results, str):
                    try:
                        results = json.loads(results)
                    except:
                        results = {"error_code": 1337, "error_message": results}
                
                uploadData.append(
                    Group.fromDict(results, None) 
                    if type == ThreadType.GROUP else 
                    User.fromDict(results, None)
                )
            else:
                error_code = data.get("error_code")
                error_message = data.get("error_message") or data.get("data")
                raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def sendMultiLocalImage(self, imagePathList, threadId, type, width=2560, height=2560, message=None, ttl=0):
        """Send Multiple Image to a User/Group with local file.
            
        Args:
            imagePathList (list): List image directory to send
            width (int): Image width to send
            height (int): Image height to send
            message (Message): Message to send with image
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        uploadData = []
        
        if not isinstance(imagePathList, list) or len(imagePathList) < 1:
            raise ZaloUserError("image path must be a list to be able to send multiple at once.")
        
        groupLayoutId = str(utilzone.now())
        
        for i, imagePath in enumerate(imagePathList):
            uploadImage = self._uploadImage(imagePath, threadId, type)
        
            payload = {
                "params": {
                    "photoId": uploadImage.get("photoId", int(utilzone.now() * 2)),
                    "clientId": uploadImage.get("clientFileId", int(utilzone.now() - 1000)),
                    "desc": message.text if message else "" or "",
                    "width": width,
                    "height": height,
                    "groupLayoutId": groupLayoutId,
                    "totalItemInGroup": len(imagePathList),
                    "isGroupLayout": 1,
                    "idInGroup": i,
                    "rawUrl": uploadImage["normalUrl"],
                    "thumbUrl": uploadImage["thumbUrl"],
                    "hdUrl": uploadImage["hdUrl"],
                    "thumbSize": "53932",
                    "fileSize": "247671",
                    "hdSize": "344622",
                    "zsource": -1,
                    "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                    "ttl": ttl,
                    "imei": self._imei
                }
            }
        
            if message and message.mention:
                payload["params"]["mentionInfo"] = message.mention
            
            if type == ThreadType.USER:
                payload["params"]["toid"] = str(threadId)
                payload["params"]["normalUrl"] = uploadImage["normalUrl"]
            elif type == ThreadType.GROUP:
                payload["params"]["grid"] = str(threadId)
                payload["params"]["oriUrl"] = uploadImage["normalUrl"]
            else:
                raise ZaloUserError("Thread type is invalid")
            
            data = self.sendLocalImage(imagePath, threadId, type, width, height, message, custom_payload=payload)
            uploadData.append(data.toDict())
        
        return (
            Group.fromDict(uploadData, None) 
            if type == ThreadType.GROUP else 
            User.fromDict(uploadData, None)
        )
    
    def sendLocalGif(self, gifPath, thumbnailUrl, threadId, type, gifName="vrxx.gif", width=500, height=500, ttl=0):
        """Send Gif to a User/Group with local file.
            
        Args:
            gifPath (str): Gif path to send
            thumbnailUrl (str): Thumbnail of gif to send
            gifName (str): Gif name to send
            width (int): Gif width to send
            height (int): Gif height to send
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(gifPath):
            raise ZaloUserError(f"{gifPath} not found")
            
        files = [("chunkContent", open(gifPath, "rb"))]
        gifSize = len(open(gifPath, "rb").read())
        gifName = gifName if gifName else gifPath if "/" not in gifPath else gifPath.rstrip("/")[1]
        fileChecksum = hashlib.md5(open(gifPath, "rb").read()).hexdigest()
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "type": 1,
            "params": {
                "clientId": str(utilzone.now()),
                "fileName": gifName,
                "totalSize": gifSize,
                "width": width,
                "height": height,
                "msg": "",
                "type": 1,
                "ttl": ttl,
                "thumb": thumbnailUrl,
                "checksum": fileChecksum,
                "totalChunk": 1,
                "chunkId": 1
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/gif"
            params["params"]["toid"] = str(threadId)
        elif type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/gif"
            params["params"]["visibility"] = 0
            params["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        params["params"] = self._encode(params["params"])
        
        response = self._post(url, params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendSticker(self, stickerType, stickerId, cateId, threadId, type, ttl=0):
        """Send Sticker to a User/Group.
            
        Args:
            stickerType (int | str): Sticker type to send
            stickerId (int | str): Sticker id to send
            cateId (int | str): Sticker category id to send
            threadId (int | str): User/Group ID to send to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "stickerId": int(stickerId),
                "cateId": int(cateId),
                "type": int(stickerType),
                "clientId": utilzone.now(),
                "imei": self._imei,
                "ttl": ttl,
            }
        }
        
        if type == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sticker"
            payload["params"]["zsource"] = 106
            payload["params"]["toid"] = str(threadId)
        elif type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sticker"
            payload["params"]["zsource"] = 103
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendCustomSticker(
        self,
        staticImgUrl,
        animationImgUrl,
        threadId,
        threadType,
        reply=None,
        width=None,
        height=None,
        ttl=0,
        ai=False
    ):
        width = int(width) if width else 0
        height = int(height) if height else 0

        params = {
            "zpw_ver": 669,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }

        payload = {
            "params": {
                "clientId": utilzone.now(),
                "title": "",
                "oriUrl": staticImgUrl,
                "thumbUrl": staticImgUrl,
                "hdUrl": staticImgUrl,
                "width": width,
                "height": height,
                "properties": json.dumps({
                    "subType": 0,
                    "color": -1,
                    "size": -1,
                    "type": 3,
                    "ext": json.dumps({
                        "sSrcStr": "",
                        "sSrcType": -1
                    })
                }),
                "contentId": utilzone.now(),
                "thumb_height": width,
                "thumb_width": height,
                "webp": json.dumps({
                    "width": width,
                    "height": height,
                    "url": animationImgUrl
                }),
                "zsource": -1,
                "ttl": ttl
            }
        }

        if ai:
            payload["params"]["jcp"] = json.dumps({
                "pStickerType": 1
            })

        if reply:
            payload["params"]["refMessage"] = str(reply)

        if threadType == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_url"
            payload["params"]["toId"] = str(threadId)

        elif threadType == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_url"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)

        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        data = response.json()

        results = data.get("data") if data.get("error_code") == 0 else None

        if results:
            results = self._decode(results)
            results = results.get("data") if isinstance(results, dict) and results.get("data") else results

            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}

            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except Exception:
                    results = {"error_code": 1337, "error_message": results}

            return (
                Group.fromDict(results, None)
                if threadType == ThreadType.GROUP
                else User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendLink(self, linkUrl, title, threadId, type, thumbnailUrl=None, domainUrl=None, desc=None, message=None, ttl=0):
        """Send link to a User/Group with url.
            
        Args:
            linkUrl (str): Link url to send
            domainUrl (str): Main domain of Link to send (eg: github.com)
            threadId (int | str): User/Group ID to send link to
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            thumbnailUrl (str): Thumbnail link url for card to send
            title (str): Title for card to send
            desc (str): Description for card to send
            message (Message): Message object to send with the link
            
        Returns:
            object: `User/Group` message id response
            dict: A dictionary containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "msg": message.text if message else "" or "",
                "href": linkUrl,
                "src": domainUrl or "",
                "title": str(title),
                "desc": desc or "",
                "thumb": thumbnailUrl or "",
                "type": 0,
                "media": json.dumps({
                    "type": 0,
                    "count": 0,
                    "mediaTitle": "",
                    "artist": "",
                    "streamUrl": "",
                    "stream_icon": ""
                }),
                "ttl": ttl,
                "clientId": utilzone.now()
            }
        }
        
        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention
        
        if type == ThreadType.USER:
            url = "https://tt-chat4-wpa.chat.zalo.me/api/message/link"
            payload["params"]["toid"] = str(threadId)
        elif type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendlink"
            payload["params"]["imei"] = self._imei
            payload["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendCall(self, target_id, callid_random):
        payload = {
            "params": {
                "calleeId": target_id,
                "callId": callid_random,
                "codec": "[]\n",
                "typeRequest": 1,
                "imei": self._imei
            }
        }
        payload["params"] = self._encode(payload["params"])
        call_url1 = f'https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall?zpw_ver=646&zpw_type={self.typeLogin}'
        response = self._post(call_url1, params=payload["params"], data=payload)
        json_data = json.loads(response.text)
        call_payload = {
                "params": {
                    'calleeId': target_id,
                    'rtcpAddress': "171.244.25.88:4601",
                    'rtpAddress': "171.244.25.88:4601",
                    'codec': '[{"dynamicFptime":0,"frmPtime":20,"name":"opus/16000/1","payload":112}]\n',
                    'session': callid_random,
                    'callId': callid_random,
                    'imei': self._imei,
                    'subCommand': 3
                }
        }
        call_payload["params"] = self._encode(call_payload["params"])
        call_url2 = f'https://voicecall-wpa.chat.zalo.me/api/voicecall/request?zpw_ver=646&zpw_type={self.typeLogin}'
        response = self._post(call_url2, params=call_payload["params"], data=call_payload)
    
    def sendReport(self, user_id, type, reason=0, content=None):
        """Send report to Zalo.
        
        Args:
            reason (int): Reason for reporting
                1 = Nội dung nhạy cảm
                2 = Làm phiền
                3 = Lừa đảo
                0 = custom
            content (str): Report content (work if reason = custom)
            user_id (int | str): User ID to report
        
        Returns:
            object: `User` send report response
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "idTo": str(user_id),
                "objId": "person.profile"
            }
        }
        
        content = content if content and not reason else "" if not content and not reason else ""
        if content:
            payload["params"]["content"] = content
        
        payload["params"]["reason"] = str( random.randint(1, 3) if not content else reason )
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/report/abuse-v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendBusinessCard(self, userId, qrCodeUrl, threadId, type, phone=None, ttl=0):
        """Send business card by user ID.
            
        Args:
            userId (int | str): Business card user ID
            qrCodeUrl (str): QR Code link with business card profile information
            phone (int | str): Send business card with phone number
            threadId (int | str): User/Group ID to change status in
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
        
        Returns:
            object: `User/Group` send business card response
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "ttl": ttl,
                "msgType": 6,
                "clientId": str(utilzone.now()),
                "msgInfo": {
                    "contactUid": str(userId),
                    "qrCodeUrl": str(qrCodeUrl)
                }
            }
        }
        
        if phone:
            payload["params"]["msgInfo"]["phone"] = str(phone)
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toId"] = str(threadId)
            payload["params"]["imei"] = self._imei
        else:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(threadId)
        
        payload["params"]["msgInfo"] = json.dumps(payload["params"]["msgInfo"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendCardBank(self, data, banknum, nameAccBank, bank, bin_code, threadId, type):
        if not banknum:
            raise ZaloAPIException("Missing bank account number")
        if not nameAccBank:
            raise ZaloAPIException("Missing account owner name")
        if not bank:
            raise ZaloAPIException("Missing bank name")
        
        params = {
            "zpw_ver": 648,
            "zpw_type": self.apiLogintype
        }

        t_type = 1 if type == ThreadType.GROUP else 0

        payload = {
            "params": {
                "binBank": bin_code,
                "numAccBank": banknum,
                "nameAccBank": nameAccBank,
                "cliMsgId": data.cliMsgId,
                "tsMsg": data.ts if t_type == 0 else threadId,
                "destUid": threadId,
                "destType": t_type
            }
        }

        payload["params"] = self._encode(payload["params"])

        response = self._post("https://zimsg.chat.zalo.me/api/transfer/card", 
            params=params, 
            data=payload)

        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None

        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results

        if results is None:
            results = {"error_code": 1337, "error_message": "Data is None"}

        if isinstance(results, str):
            try:
                results = json.loads(results)
            except:
                results = {"error_code": 1337, "error_message": results}
            return results

        error_code = data.get("error_code") 
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")