import os
import math
import time
import asyncio
import aiohttp
import json
import aiofiles
from concurrent.futures import ThreadPoolExecutor, Future
from ..util import utilzone
from ..models import *

class AttachmentsAPi:
    def _uploadImage(self, filePath, threadId, type):
        """Upload images to Zalo.
            
        Args:
            filePath (str): Image path to upload
            threadId (int | str): User/Group ID to upload to.
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            dict: A dictionary containing the image info just uploaded
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
            
        files = [("chunkContent", open(filePath, "rb"))]
        fileSize = len(open(filePath, "rb").read())
        fileName = filePath if "/" not in filePath else filePath.rstrip("/")[1]
        
        params = {
            "params": {
                "totalChunk": 1,
                "fileName": fileName,
                "clientId": utilzone.now(),
                "totalSize": fileSize,
                "imei": self._imei,
                "jxl": 1,
                "chunkId": 1
            },
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
        }
        
        if type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/upload"
            params["type"] = 2
            params["params"]["toid"] = str(threadId)
        elif type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/upload"
            params["type"] = 11
            params["params"]["grid"] = str(threadId)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        params["params"] = self._encode(params["params"])
        
        response = self._post(url, params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(data["data"])
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return results
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    async def _uploadAttachmentAsync(self, filePath, thread_id, thread_type):
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")

        ext = os.path.splitext(filePath)[1][1:].lower()

        urlType = {
            "image": "photo_original/upload",
            "aac": "voice/upload",
            "video": "asyncfile/upload",
            "others": "asyncfile/upload"
        }

        max_size = 9 * 1000 * 1000
        file_size = os.path.getsize(filePath)
        maxtype = ""
        if ext in ["jpg", "jpeg", "png"]:
            fileType = "image"
        elif ext in ["mp3", "aac"]:
            if file_size > max_size:
                fileType = "others"
                maxtype = "khangapi.aac"
            else:
                fileType = "aac"
        elif ext == "mp4":
            fileType = "video"
        else:
            fileType = "others"

        if thread_type == ThreadType.USER:
            base_url = "https://tt-files-wpa.chat.zalo.me/api/message/"
            params = {"type": 2}
            params_extra = {"toid": str(thread_id)}
        else:
            base_url = "https://tt-files-wpa.chat.zalo.me/api/group/"
            params = {"type": 11}
            params_extra = {"grid": str(thread_id)}

        # UPDATE theo src của m
        params.update({
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        })

        chunk_size = 3145728
        total_chunks = math.ceil(file_size / chunk_size)
        clientId = utilzone.now()  # UPDATE theo src

        async def _upload_single_chunk_async(chunk_id, chunk):
            url = base_url + urlType[fileType]
            retry_count = 0
            success = False
            max_retries = 5

            while retry_count < max_retries and not success:
                try:
                    chunk_params = {
                        "totalChunk": total_chunks,
                        "fileName": os.path.basename(filePath),
                        "fileType": fileType,
                        "clientId": clientId,
                        "totalSize": file_size,
                        "imei": self._imei,
                        "jxl": 1,  # UPDATE giống _uploadImage
                        "chunkId": chunk_id,
                        **params_extra
                    }

                    params["params"] = self._encode(chunk_params)

                    files = aiohttp.FormData()
                    files.add_field(
                        "chunkContent",
                        chunk,
                        filename=os.path.basename(filePath),
                        content_type="application/octet-stream"
                    )

                    response = await self._postas(url, params=params, data=files, timeout=30)
                    data = response

                    if data.get("error_code") == 0:
                        results = self._decode(data["data"])
                        if results.get("error_code") == 0:
                            success = True
                            break

                    retry_count += 1
                    if retry_count < max_retries:
                        await asyncio.sleep(1)

                except Exception:
                    retry_count += 1
                    if retry_count < max_retries:
                        await asyncio.sleep(1)

            if not success:
                raise ZaloAPIException(f"Không thể upload file sau {max_retries} lần thử lại")

            results = self._decode(data["data"])
            if results.get("error_code") == 0:
                results = results.get("data")

                if results.get("fileId") and results["fileId"] != "-1":
                    event = asyncio.Event()
                    res = {}

                    async def callback_async(ws_data):
                        res.update({
                            "fileName": os.path.basename(filePath),
                            "totalSize": os.path.getsize(filePath),
                            "fileType": fileType,
                            "fileUrl": ws_data['fileUrl'],
                            "fileId": ws_data['fileId']
                        })
                        event.set()

                    self._upload_callbacks_async[str(results["fileId"])] = callback_async

                    while True:
                        try:
                            await asyncio.wait_for(event.wait(), timeout=2)
                            break
                        except asyncio.TimeoutError:
                            print("Timeout waiting for WebSocket response")

                    if maxtype:
                        url = res["fileUrl"]
                        res["fileUrl"] = f"{url}/{maxtype}"

                    return res

                elif results.get("photoId") and results.get("finished"):
                    return {
                        "fileType": fileType,
                        **results
                    }

        async with aiofiles.open(filePath, 'rb') as f:
            chunks = []
            while True:
                chunk = await f.read(chunk_size)
                if not chunk:
                    break
                chunks.append(chunk)

        max_concurrent_uploads = 8
        semaphore = asyncio.Semaphore(max_concurrent_uploads)
        progress = {"uploaded": 0}

        async def limited_upload(chunk_id, chunk):
            async with semaphore:
                result = await _upload_single_chunk_async(chunk_id + 1, chunk)
                progress["uploaded"] += 1
                percent = (progress["uploaded"] / total_chunks) * 100
                print(f"\rUpload progress: {progress['uploaded']}/{total_chunks} chunks ({percent:.2f}%)", end="")
                return result

        tasks = [limited_upload(i, chunk) for i, chunk in enumerate(chunks)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, dict):
                return result

        # Surface the real error instead of a generic message, to make debugging easier
        errors = [r for r in results if isinstance(r, Exception)]
        if errors:
            raise Exception(f"Upload failed: {errors[0]}")
        raise Exception("Upload failed: No successful chunk returned.")
    
        async def _upload_single_chunk_async(chunk_id, chunk):
            # Gửi request với retry logic
            url = base_url + urlType[fileType]
            retry_count = 0
            success = False
            max_retries = 5
            while retry_count < max_retries and not success:
                try:
                    chunk_params = {
                        "totalChunk": total_chunks,
                        "fileName": os.path.basename(filePath),
                        "fileType": fileType,
                        "clientId": clientId,
                        "totalSize": file_size,
                        "imei": self._imei,
                        "isE2EE": 0,
                        "jxl": 0,
                        "chunkId": chunk_id,
                        **params_extra
                    }

                    # Mã hóa params
                    params["params"] = self._encode(chunk_params)

                    files = aiohttp.FormData()
                    files.add_field(
                        "chunkContent",  # Tên trường
                        chunk,  # Nội dung chunk file
                        filename=os.path.basename(filePath),  # Tên file
                        content_type="application/octet-stream"  # Kiểu dữ liệu
                    )
                    # files = {"chunkContent": (os.path.basename(filePath), chunk, "application/octet-stream")}
                    response = await self._postas(url, params=params, data=files,timeout=3)
                    data = response
                    # print(data)
                    if data.get("error_code") == 0:
                        results = self._decode(data["data"])
                        if results.get("error_code") == 0:
                            success = True
                            break
                    
                    retry_count += 1
                    # if retry_count < max_retries:
                    #     print(f"\rĐang thử lại chunk {chunk_id}/{total_chunks} lần {retry_count}...", end="") # Chờ 2 giây trước khi thử lại
                        
                except Exception as e:
                    # print(f"\nLỗi khi upload chunk {chunk_id}: {str(e)}")
                    retry_count += 1
                    # if retry_count < max_retries:
                    #     print(f"\rĐang thử lại chunk {chunk_id}/{total_chunks} lần {retry_count}...", end="")  # Chờ 2 giây trước khi thử lại
            
            if not success:
                raise ZaloAPIException(f"Không thể upload file sau {max_retries} lần thử lại")
            
            if data.get("error_code") == 0:
                results = self._decode(data["data"])
                if results.get("error_code") == 0:
                    results = results.get("data")

                    if results.get("fileId") and results["fileId"] != "-1":
                        event = asyncio.Event()
                        res = {}
                        async def callback_async(ws_data):
                            print(f"📩 Received callback data: {ws_data}")
                            res.update({
                                "fileName": os.path.basename(filePath),
                                "totalSize": os.path.getsize(filePath),
                                "fileType": fileType,
                                "fileUrl":ws_data['fileUrl'],
                                "fileId":ws_data['fileId']
                            })
                            event.set()

                        self._upload_callbacks_async[str(results["fileId"])] = callback_async
                        while True:
                            try:
                                await asyncio.wait_for(event.wait(), timeout=25)  # Timeout sau 10 giây
                                break
                            except asyncio.TimeoutError:
                                print(f"Timeout waiting for WebSocket response")
                        if maxtype:
                            url = res["fileUrl"]
                            res["fileUrl"] = f"{url}/{maxtype}"
                        return res

                    elif results.get("photoId") and results.get("finished"):
                        return {
                            "fileType": fileType,
                            **results
                        }
    
        # Mở file và gửi từng chunk
        # Đọc toàn bộ file thành các chunk
        async with aiofiles.open(filePath, 'rb') as f:
            chunks = []
            while True:
                chunk = await f.read(chunk_size)
                if not chunk:
                    break
                chunks.append(chunk)

        # Upload tất cả các chunk song song, tối đa 12 chunk/s
        # điều chỉnh nhanh chậm ở đây này :))
        max_concurrent_uploads = 12 * 4
        semaphore = asyncio.Semaphore(max_concurrent_uploads)
        progress = {"uploaded": 0}

        async def limited_upload(chunk_id, chunk):
            async with semaphore:
                result = await _upload_single_chunk_async(chunk_id + 1, chunk)
                progress["uploaded"] += 1
                percent = (progress["uploaded"] / total_chunks) * 100
                print(f"\rUpload progress: {progress['uploaded']}/{total_chunks} chunks ({percent:.2f}%)", end="")
                return result

        tasks = [
            limited_upload(chunk_id, chunk)
            for chunk_id, chunk in enumerate(chunks)
        ]

        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        end_time = time.time()
        duration = end_time - start_time
        num_chunks = len(chunks)
        if duration > 0:
            chunks_per_sec = num_chunks / duration
            print(f"Upload speed: {chunks_per_sec:.2f} chunk(s)/s ({num_chunks} chunks in {duration:.2f}s)")
        else:
            print("Upload completed instantly.")

        for result in results:
            if isinstance(result, dict):
                return result

        raise Exception("Upload failed: No successful chunk returned.")
    
    def _uploadAttachment(self, filePath, threadId, type):
        #ori : N D Q
        #customize: Ryan
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
        
        ext = os.path.splitext(filePath)[1][1:].lower()
        urlType = {
            "image": "photo_original/upload",
            "aac": "voice/upload",
            "video": "asyncfile/upload",
            "gif": "gif?",
            "others": "asyncfile/upload"
        }
        max_size = 9 * 1000 * 1000
        file_size = os.path.getsize(filePath)
        maxtype = ""

        if ext in ["jpg", "jpeg", "png"]:
            fileType = "image"
        elif ext in ["mp3", "aac"]:
            if file_size > max_size:
                fileType = "others"
                maxtype = "ryan_bug.aac"
            else:
                fileType = "aac"
        elif ext == "mp4":
            fileType = "video"
        else:
            fileType = "others"

        if type == ThreadType.USER:
            base_url = "https://tt-files-wpa.chat.zalo.me/api/message/"
            params = {"type": 2}
            params_extra = {"toid": str(threadId)}
        else:
            base_url = "https://tt-files-wpa.chat.zalo.me/api/group/"
            params = {"type": 11}
            params_extra = {"grid": str(threadId)}

        params.update({
            "zpw_ver": 649,
            "zpw_type": self.apiLogintype
        })

        chunk_size = 3145728
        total_chunks = math.ceil(file_size / chunk_size)
        clientId = int(time.time() * 1000)

        def upload_single_chunk(chunk_id, chunk):
            max_retries = 5
            retry_count = 0
            while retry_count < max_retries:
                try:
                    chunk_params = {
                        "totalChunk": total_chunks,
                        "fileName": os.path.basename(filePath),
                        "fileType": fileType,
                        "clientId": clientId,
                        "totalSize": file_size,
                        "imei": self._imei,
                        "isE2EE": 0,
                        "jxl": 0,
                        "chunkId": chunk_id,
                        **params_extra
                    }
                    params["params"] = self._encode(chunk_params)
                    files = [("chunkContent", (os.path.basename(filePath), chunk, "application/octet-stream"))]
                    url = base_url + urlType[fileType]
                    response = self._post(url, params=params.copy(), files=files,timeout=5)
                    data = response.json()
                    break
                except Exception as e:
                    print(f"\nLỗi khi upload chunk {chunk_id}: {str(e)}")
                    retry_count += 1
                    if retry_count < max_retries:
                        print(f"\rĐang thử lại chunk {chunk_id}/{total_chunks} lần {retry_count}...", end="")
                    if retry_count > max_retries:
                        print(f"\rHết lượt thử lại", end="")

            # percent = (chunk_id / total_chunks) * 100
            # print(f"\rĐang upload {os.path.basename(filePath)}: {percent:.2f}%", end="")

            if data.get("error_code") == 0:
                results = self._decode(data["data"])
                if results.get("error_code") == 0:
                    results = results.get("data")
                    if results.get("fileId") and results["fileId"] != "-1":
                        future = Future()

                        def callback(ws_data):
                            future.set_result({
                                "fileName": os.path.basename(filePath),
                                "totalSize": os.path.getsize(filePath),
                                "fileType": fileType,
                                "fileUrl": ws_data['fileUrl'],
                                "fileId": ws_data['fileId']
                            })

                        self._upload_callbacks[str(results["fileId"])] = callback
                        res = future.result()
                        if maxtype:
                            url = res["fileUrl"]
                            res["fileUrl"] = f"{url}/{maxtype}"
                        print(f"\nĐã upload thành công file {res['fileName']}")
                        return res
                    elif results.get("photoId") and results.get("finished"):
                        return {
                            "fileType": fileType,
                            **results
                        }

            return None

        with open(filePath, 'rb') as f, ThreadPoolExecutor(max_workers=10) as executor:
            chunk_id = 1
            while chunk_id <= total_chunks:
                futures = []
                percent = (chunk_id / total_chunks) * 100
                print(f"\rĐang upload {os.path.basename(filePath)}: {percent:.2f}%", end="")
                for _ in range(2):
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    futures.append(executor.submit(upload_single_chunk, chunk_id, chunk))
                    chunk_id += 1

                # Đợi các chunk hoàn tất
                for future in futures:
                    result = future.result()
                    if result:
                        return result

        raise ZaloAPIException("Upload failed: No successful chunk returned.")