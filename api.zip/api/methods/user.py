import json

import requests

from ..util import utilzone
from ..app import appstate
from ..models import *

class ActionAPi:
    def sendFriendRequest(self, userId, msg, language="vi"):
        """Send friend request to a user by ID.
            
        Args:
            userId (int | str): User ID to send friend request
            msg (str): Friend request message
            language (str): Response language or Zalo interface language

        Returns:
            object: `User` Friend requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "toid": str(userId),
                "msg": msg,
                "reqsrc": 30,
                "imei": self._imei,
                "language": language,
                "srcParams": json.dumps({
                    "uidTo": str(userId)
                })
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/sendreq", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def remove_blocked_member(self, grid, member_ids):
        params_data = {
            "grid": grid,
            "members": member_ids
        }

        params = {
            "zpw_ver": 650,
            "zpw_type": self.apiLogintype,
            "params": self._encode(params_data)
        }

        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/remove", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            return {"success": True, "message": "Xóa thành viên bị chặn thành công."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
            return {"success": False, "error_code": error_code, "error_message": error_message}
    
    def unfriendUser(self, userId, language="vi"):
        """Unfriend a user by ID.
        
        Args:
            userId (int | str): User ID to unfriend.
            language (str): Response language or Zalo interface language.

        Returns:
            dict: A dictionary containing the unfriend status information.
        
        Raises:
            ZaloAPIException: If request failed.
        """
        params = {
            "zpw_ver": 641,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "language": language
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/remove", 
                            params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            return {"status": "success", "message": "Unfriended successfully."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message") or data.get("data")
            raise ZaloAPIException(f"Error #{error_code} when unfriending: {error_message}")
    
    def joinGroup(self, url):
            response = self._post(
                "https://tt-group-wpa.chat.zalo.me/api/group/link/join",
                params={
                    "zpw_ver": 648,
                    "zpw_type": self.apiLogintype
                },
                data={
                    "params": self._encode({
                        "link": str(url),
                        "clientLang": "vi"
                    })
                }
            )
            
            
            if isinstance(response, requests.models.Response):
                try:
                    response_data = response.json()  
                except ValueError:
                    raise ValueError("Response does not contain valid JSON")
        
                
                if response_data.get('error_code') == 0:
                    data = response_data.get('data')
                    if data:
                        try:
                            return self._decode(data)
                        except Exception as e:
                            raise ValueError(f"Decoding error: {str(e)}")
                    else:
                        raise ValueError("Data is None")
                else:
                    error_message = response_data.get('error_message', 'Unknown error')
                    error_code = response_data.get('error_code', 0)
                    raise Exception(f"Error #{error_code}: {error_message}")
            else:
                raise TypeError(f"Unexpected response type: expected requests.models.Response, got {type(response)}")
    def leaveGroup(self,gr_id,silent):
        if not gr_id:
            raise ZaloAPIException("Missing Group ID")
        if not silent:
            raise ZaloAPIException("Missing assignees")
        params = {
            "zpw_ver": 648,
            "zpw_type": self.apiLogintype
        }
        si = 1
        if not silent:
            si =0 
        payload = {
            "params": {
                "grids": [str(gr_id)],
                "imei": self._imei,
                "silent": si
            }
        }
        api = "https://tt-group-wpa.chat.zalo.me/api/group/leave"
        payload["params"] = self._encode(payload["params"])

        response = self._post(url= api, 
                            params=params, 
                            data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            
            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return results

        error_code = data.get("error_code") 
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def undoMessage(self, msgId, cliMsgId, threadId, type):
        """Undo message from the client by ID.
            
        Args:
            msgId (int | str): Message ID to undo
            cliMsgId (int | str): Client Msg ID to undo
            threadId (int | str): User/Group ID to undo message
            type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` undo message status
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "msgId": str(msgId),
                "cliMsgIdUndo": str(cliMsgId),
                "clientId": utilzone.now()
            } 
        }
        
        if type == ThreadType.USER:
            url = "https://tt-chat3-wpa.chat.zalo.me/api/message/undo"
            payload["params"]["toid"] = str(threadId)
        elif type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/undomsg"
            payload["params"]["grid"] = str(threadId)
            payload["params"]["visibility"] = 0
            payload["params"]["imei"] = self._imei
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def acceptFriendRequest(self, userId, language="vi"):
        """Accept friend request from user by ID.
            
        Args:
            userId (int | str): User ID to accept friend request
            language (str): Response language or Zalo interface language

        Returns:
            object: `User` Friend accept requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "language": language
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/accept", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockViewFeed(self, userId, isBlockFeed):
        """Block/Unblock friend view feed by ID.
            
        Args:
            userId (int | str): User ID to block/unblock view feed
            isBlockFeed (int): Block/Unblock friend view feed (1 = True | 0 = False)
        
        Returns:
            object: `User` Friend requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "isBlockFeed": isBlockFeed,
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/feed/block", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockUser(self, userId):
        """Block user by ID.
            
        Args:
            userId (int | str): User ID to block
        
        Returns:
            object: `User` Block response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/block", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unblockUser(self, userId):
        """Unblock user by ID.
            
        Args:
            userId (int | str): User ID to unblock
        
        Returns:
            object: `User` Unblock response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/unblock", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    END USER ACTION METHODS
    """