import json, random, time

from ..util import utilzone
from ..app import appstate

class utilsApi:
    def _get(self, *args, **kwargs):
        return self._state._get(*args, **kwargs)
        
    def _post(self, *args, **kwargs):
        return self._state._post(*args, **kwargs)
    
    async def _getas(self, *args, **kwargs):
        return await self._state._getas(*args, **kwargs)
        
    async def _postas(self, *args, **kwargs):
        return await self._state._postas(*args, **kwargs)
    
    def _encode(self, params):
        return utilzone.zalo_encode(params, self._state._config.get("secret_key"))
        
    def _decode(self, params):
        return utilzone.zalo_decode(params, self._state._config.get("secret_key"))

    def makeCall(self,uid):
            callId=int(time.time()) 
            params = {
                "params": self._encode({
                    'calleeId': str(uid),
                    'callId': callId,
                    'codec': '[]\n',
                    'typeRequest': 1,
                    'imei': self._imei
                }),
                "zpw_ver": 650,
                "zpw_type": self.typeLogin
            }
            response = self._get("https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall", params=params)
            data = response.json()
            if data.get("error_code") == 0:
                decoded_data = self._decode(data.get("data"))
                data_fainal = decoded_data.get("data", {})
                data_fainal["callId"] = callId
                return data_fainal
            return None


    def makeCallRequest(self,uid, data_call):
            params = {
                "params": self._encode({
                    'calleeId': str(uid),
                    'rtcpAddress': data_call['rtpIP'],
                    'rtpAddress': data_call['rtpIP'],
                    'codec': json.dumps([{
                        'dynamicFptime': 0,
                        'frmPtime': 20,
                        'name': f"opus/{data_call['zrtc_config']['audioSampleRate']}/{data_call['zrtc_config']['audioChannel']}",
                        'payload': 112
                    }]),
                    'session': data_call['sessId'],
                    'callId': data_call['callId'],
                    'imei': self._imei,
                    'extendData': json.dumps({
                        'supportCallBusy': data_call['settings']['supportCallBusy'],
                        'tpType': 0,
                        "video":json.dumps({"codec":[{"name":"h264","payload":97}]})
                    }),
                    'subCommand': 3
                }),
                "zpw_ver": 650,
                "zpw_type": self.typeLogin
            }
            response = self._get("https://voicecall-wpa.chat.zalo.me/api/voicecall/request", params=params)
            data = response.json()
            if data.get("error_code") == 0:
                decoded_data = self._decode(data.get("data"))
                return decoded_data.get("data")
            return None

    def TaoIDCall(self):
        return ''.join([str(random.randint(0, 9)) for _ in range(9)])