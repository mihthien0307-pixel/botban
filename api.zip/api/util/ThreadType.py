# Kept for backward compatibility – import ThreadType from Enum.py
from .Enum import ThreadType

__all__ = ["ThreadType"]
