import os
from datetime import datetime
import time
timeNow = time.strftime("%H:%M:%S - %d/%m/%Y", time.localtime())
class Logging:
    def __init__(self, theme="default", text_color="white", log_text_color="black"):
        self.reset = "\x1b[0m"
        self.theme = str(theme).lower()
        self.colors = {}
        self.load_color_scheme()

        self.textcolor = {
            "black": "\x1b[30m",
            "white": "\x1b[37m"
        }.get(text_color.lower(), text_color)

        self.log_text_color = {
            "black": self.colors.get("black"),
            "white": self.colors.get("white")
        }.get(log_text_color.lower(), log_text_color)

        self.msg_prefix = "\x1b[38;5;245m│\x1b[0m"
        self.msg_text = "\x1b[38;5;250m"
        self.msg_time = "\x1b[38;5;240m"

        self.log_dir = "assets/log"
        self.error_file = os.path.join(self.log_dir, "error.txt")
        self.message_file = os.path.join(self.log_dir, "message.txt")

        os.makedirs(self.log_dir, exist_ok=True)

    
    def load_color_scheme(self):
        if self.theme in ["catppuccin", "catppuccin-mocha"]:
            self.colors = {
                "red":     "\x1b[48;2;243;139;168m",
                "blue":    "\x1b[48;2;137;180;250m",
                "green":   "\x1b[48;2;166;227;161m",
                "white":   "\x1b[38;2;205;214;244m",
                "black":   "\x1b[38;2;17;17;27m",
                "orange":  "\x1b[48;2;250;179;135m",
                "yellow":  "\x1b[48;2;249;226;175m",
                "magenta": "\x1b[48;2;203;166;247m"
            }
        else:
            self.colors = {
                "red":     "\x1b[41m",
                "blue":    "\x1b[44m",
                "green":   "\x1b[42m",
                "white":   "\x1b[37m",
                "black":   "\x1b[30m",
                "orange":  None,
                "yellow":  "\x1b[43m",
                "magenta": "\x1b[45m"
            }

    
    def _timestamp(self) -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _write(self, path: str, level: str, text: str):
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"[{self._timestamp()}] [{level.upper()}] {text}\n")

    def _log(self, level: str, color_key: str, text: str):
        color = self.colors.get(color_key) or self.colors.get("yellow")
        print(f"{color} {self.log_text_color}{level.upper()} {self.reset} {self.textcolor}{text}")

    
    def info(self, text): self._log("info", "blue", text)
    def debug(self, text): self._log("debug", "magenta", text)
    def success(self, text): self._log("success", "green", text)
    def login(self, text): self._log("login", "green", text)
    def warning(self, text): self._log("warning", "orange", text)
    def notice(self, text): self._log("notice", "yellow", text)
    def event(self, text): self._log("event", "yellow", text)
    def start(self, text): self._log("start", "green", text)
    def stop(self, text): self._log("stop", "red", text)
    def critical(self, text): self._log("failed", "red", text)

    
    def error(self, text):
        self._log("error", "red", text)

    def errorw(self, text):
        self._log("error", "red", text)
        self._write(self.error_file, "error", text)

    
    def msgw(self, text):
        for line in text.strip().splitlines():
            print(
                f"{self.msg_time}{timeNow} "
                f"{self.msg_prefix} "
                f"{self.msg_text}{line}{self.reset}"
            )

        self._write(self.message_file, "message", text)
