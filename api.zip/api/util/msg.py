import json
from . import utilzone
from .Enum import Enum
from .parse import Parse
class Message:
	def __init__(self, text=None, style=None, mention=None, parse_mode=None):
		self.text, self.mention = text, str(mention) if mention else None
		self.style = str(style) if style else None
		self.parse_mode = str(parse_mode) if parse_mode else None
		if not parse_mode: return
		styles = json.loads(self.style)["styles"] if self.style else []
		if self.parse_mode not in ("Markdown", "HTML"):
			raise ValueError("Invalid Parse Mode, Only Support `Markdown` & `HTML`")
		self.text, self.parse_list = Parse(self.text, self.style, self.parse_mode)
		if len(self.parse_list) == 1 and not styles:
			e = self.parse_list[0]
			self.style = MessageStyle(e["start"], e["length"], e["type"])
		elif self.parse_list:
			styles += [MessageStyle(e["start"], e["length"], e["type"], auto_format=False) for e in self.parse_list]
			self.style = MultiMsgStyle(styles)
		self.style = str(self.style) if self.style else None
	def __repr__(self):
		return f"Message(text={self.text!r}, style={self.style!r}, mention={self.mention!r}, parse_mode={self.parse_mode!r})"
class MessageStyle:
	def __new__(self, offset=0, length=1, style="font", color="ffffff", size="18", auto_format=True):
		if not isinstance(offset, int) or not isinstance(length, int):
			raise ValueError("Invalid Length, Offset! Length and Offset must be integers")
		style_map = {
			"bold": "b", "italic": "i", "underline": "u", "strike": "s",
			"color": f"c_{color.replace('#', '')}", "font": f"f_{size}"
		}
		style = style_map.get(style, "f_18")
		data = {"start": offset, "len": length, "st": style}
		return json.dumps({"styles": [data], "ver": 0}) if auto_format else data
class MultiMsgStyle:
	def __init__(self, listStyle):
		self.styleFormat = json.dumps({"styles": listStyle, "ver": 0})
	def __str__(self):
		return self.styleFormat
class MessageReaction:
	def __new__(self, messageObject, auto_format=True):
		msg_id, cli_id = int(messageObject.msgId), int(messageObject.cliMsgId)
		msg_type = utilzone.getClientMessageType(messageObject.msgType)
		if not isinstance(msg_type, int):
			raise ValueError("Msg Type must be int")
		data = {"gMsgID": msg_id, "cMsgID": cli_id, "msgType": msg_type}
		return [data] if auto_format else data
class Mention:
	def __new__(self, uid, length=1, offset=0, auto_format=True):
		if not isinstance(offset, int) or not isinstance(length, int):
			raise ValueError("Invalid Length, Offset! Length and Offset must be integers")

		data = {"pos": offset, "len": length, "uid": uid, "type": 1 if uid == "-1" else 0}
		return json.dumps([data]) if auto_format else data
class MultiMention:
	def __init__(self, listMention):
		self.mentionFormat = json.dumps(listMention)
	def __str__(self):
		return self.mentionFormat