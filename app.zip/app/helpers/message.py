import json

def logMessage(
    logger,
    *,
    chat_type: str,      
    userInfo: str,
    message,
    data,
    forward: bool,
    groupInfo: str | None = None
):
    if chat_type == "USER":
        _log_user(logger, userInfo, message, data, forward)
        return

    if chat_type == "GROUP":
        _log_group(logger, userInfo, groupInfo, message, data, forward)
        return


def _log_user(logger, userInfo, message, data, forward):
    if data.msgType == "webchat":
        if forward:
            logger.msgw(f"{userInfo} vừa chuyển tiếp tin nhắn: {message}")
        else:
            logger.msgw(f"""
Có tin nhắn riêng tư mới từ {userInfo}
Nội dung: {message}
""")

    elif data.msgType == "chat.reaction":
        logger.msgw(f"""
Người dùng {userInfo} vừa thả cảm xúc
Icon: {data.content.get("rIcon")}
""")

    elif data.msgType == "chat.photo":
        _log_photo(logger, userInfo, data)

    else:
        logger.msgw(f"""
Tin nhắn riêng từ {userInfo}
Loại: {data.msgType}
Nội dung: {message}
""")


def _log_group(logger, userInfo, groupInfo, message, data, forward):
    if data.msgType == "webchat":
        if forward:
            logger.msgw(f"{userInfo} vừa chuyển tiếp tin nhắn đến {groupInfo}: {message}")
        else:
            logger.msgw(f"""
Tin nhắn mới trong {groupInfo}
Người gửi: {userInfo}
Nội dung: {message}
""")

    elif data.msgType == "chat.reaction":
        logger.msgw(f"""
{userInfo} vừa thả cảm xúc trong {groupInfo}
Icon: {data.content.get("rIcon")}
""")

    elif data.msgType == "chat.photo":
        _log_photo(logger, f"{userInfo} tại {groupInfo}", data)

    else:
        logger.msgw(f"""
Tin nhắn nhóm {groupInfo}
Người gửi: {userInfo}
Loại: {data.msgType}
Nội dung: {message}
""")


def _log_photo(logger, senderInfo, data):
    import json
    params = json.loads(data.content.get("params", "{}"))

    if params.get("pStickerType") == 1:
        logger.msgw(f"""
{senderInfo} gửi Sticker AI Custom
Link: {data.content.get("href")}
""")
    else:
        logger.msgw(f"""
{senderInfo} gửi ảnh
Link: {data.content.get("href")}
""")
