import time
from api.models import *
from api import *

class Methods:
    def groupInfo(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId)
            return info.gridInfoMap.get(threadId, {}).get("name", "Group không xác định")
        except Exception as e:
            # logger.errorw(f"Lỗi lấy thông tin nhóm {threadId}: {e}")
            return "Null"

    def getGroupTypes(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId)
            if not info:
                return "Null"
            return "cộng đồng" if info.type == 2 else "nhóm"
        except Exception as e:
            # logger.errorw(f"Lỗi lấy loại nhóm {threadId}: {e}")
            return "Null"
        
    def getGroupTypesE(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId)
            if not info:
                return "Null"
            return "community" if info.type == 2 else "group"
        except Exception as e:
            # logger.errorw(f"Lỗi lấy loại nhóm {threadId}: {e}")
            return "Null"

    def userName(self, userId: str) -> str:
        """Lấy tên người dùng, tự retry khi gặp lỗi mạng tạm thời."""
        max_retries = 3
        retry_delay = 1.5

        for attempt in range(max_retries):
            try:
                info = self.fetchUserInfo(userId)
                if info is None:
                    return str(userId)
                profiles = getattr(info, "changed_profiles", None) or {}
                profile  = profiles.get(str(userId)) or {}
                return profile.get("zaloName") or profile.get("displayName") or str(userId)
            except Exception as e:
                err_str = str(e)
                is_transient = any(kw in err_str for kw in [
                    "RemoteDisconnected", "Connection aborted",
                    "ConnectionResetError", "ConnectionError",
                    "Timeout", "timed out", "EOF",
                ])
                if is_transient and attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                logger.errorw(f"Lỗi khi lấy thông tin người dùng {userId}: {e}")
                return str(userId)
        return str(userId)

    def get_platform(self, data) -> str:
        try:
            if data.msgType == "chat.reaction":
                return
            raw = data if isinstance(data, dict) else data.__dict__
            platform_type = raw.get("paramsExt", {}).get("platformType")
            return {
                0: "App",
                1: "Web",
                2: "PC"
            }.get(platform_type, "Null")
        except Exception:
            return
