from .data import *
from .qr import *

def main():
    try:
        try:
            from web.gui import start_gui
            gui_port = int(os.environ.get('GUI_PORT', 5005))
            start_gui(port=gui_port)
            logger.info(f"✅ GUI Manager đang chạy tại http://0.0.0.0:{gui_port}")
        except Exception as _ge:
            logger.warning(f"GUI Manager không khởi động được: {_ge}")

        if not check():
            logger.warning("Chưa có dữ liệu đăng nhập")
            choice = input("1. Quét QR / 2. Thoát: ").strip()
            if choice == "1":
                success = qr()
                if not success:
                    logger.error("Đăng nhập thất bại")
                    return
                logger.info("Đang khởi động bot...")
                time.sleep(2)
            elif choice == "2":
                logger.info("Tạm biệt")
                return
            else:
                logger.error("Lựa chọn không hợp lệ")
                return

        data = load_json(logindb)
        if "data" not in data or not isinstance(data["data"], list):
            logger.error("Không tìm thấy trường dữ liệu nào trong JSON")
            return

        valid_items = []
        for item in data["data"]:
            if item.get("imei") and isinstance(item.get("session_cookies"), dict) and item.get("session_cookies") and item.get("status") is True:
                if check_bot_expiration(item):
                    valid_items.append(item)

        save_config(data)
        if not valid_items:
            logger.warning("Dữ liệu rỗng.")
            return
        start_threads(valid_items)

        # ── Load bot con từ thư mục multibot ─────────────────────────────────
        try:
            import glob as _glob
            _multibot_dir = "data/config/multibot"
            _main_login   = "data/config/login.json"
            _bot_files    = _glob.glob(os.path.join(_multibot_dir, "*-login.json"))
            # Chờ main bot khởi động xong portal server trước khi start bot con
            if _bot_files:
                logger.info("[Multibot] Chờ main bot khởi động portal (5s)...")
                time.sleep(5)
            for _fp in sorted(_bot_files):
                try:
                    with open(_fp, "r", encoding="utf-8") as _f:
                        _items = __import__("json").load(_f)
                    if not isinstance(_items, list):
                        continue
                    for _item in _items:
                        if not isinstance(_item, dict):
                            continue
                        # Bỏ qua record metadata (userClientId)
                        if "userClientId" in _item and len(_item) == 1:
                            continue
                        _imei    = _item.get("imei")
                        _cookies = _item.get("session_cookies") or _item.get("sessionCookies") or {}
                        _status  = _item.get("status", False)
                        _actived = _item.get("isActived", False)
                        _author  = str(_item.get("author_id", ""))
                        _prefix  = _item.get("prefix", "?")
                        _uname   = _item.get("username", "bot_con")
                        if not _imei or not isinstance(_cookies, dict) or not _cookies:
                            continue
                        if not _status or not _actived:
                            continue
                        if not check_bot_expiration(_item):
                            continue
                        logger.info(f"[Multibot] Khởi động bot con: {_uname}")
                        threading.Thread(
                            target=run_bot,
                            args=(_imei, _cookies, _prefix, False, _uname, _author, True),
                            daemon=True,
                        ).start()
                        time.sleep(0.5)
                except Exception as _e:
                    logger.error(f"[Multibot] Lỗi load {_fp}: {_e}")
        except Exception as _ex:
            logger.error(f"[Multibot] Lỗi load multibot: {_ex}")

        try:
            from web.gui import set_runtime
            global mainclient
            set_runtime(
                mainclient if 'mainclient' in globals() else None,
                clientlist
            )
        except Exception:
            pass

        while not shutdown_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Đang dừng bot...")
    except Exception as e:
        logger.error(f"Loi trong qua trinh khoi dong: {e}")
        import traceback
        traceback.print_exc()
    finally:
        clean()

if __name__ == "__main__":
    import atexit
    atexit.register(clean)
    main()