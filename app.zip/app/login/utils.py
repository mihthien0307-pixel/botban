from .packages import *

# Get methods

def get_clientlist() -> Dict[str, object]:
    return clientlist

# IO - Json methods
    
def save_json(filename: str, data: Dict) -> None:
    with lock:
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Lỗi khi lưu dữ liệu vào {filename}: {e}")

def load_json(filename: str) -> Dict:
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"Lỗi: Không tìm thấy tệp {filename}")
        return {"data": []}
    except json.JSONDecodeError:
        logger.error(f"Lỗi: Không thể giải mã JSON từ {filename}")
        return {"data": []}
    
def save_config(data: Dict) -> None:
    save_json(logindb, data)

def save_username_to_config(username: str, author_id: str, imei: str, avatar: str = "") -> None:
    with lock:
        try:
            # ── Thử update trong login.json (main bot) ────────────────────────
            data = load_json(logindb)
            if "data" not in data:
                data["data"] = []
            for user in data["data"]:
                if user.get("imei") == imei or user.get("author_id") == author_id:
                    user["username"] = username
                    user["author_id"] = author_id
                    if avatar:
                        user["avatar"] = avatar
                    with open(logindb, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)
                    return

            # ── Thử update trong các file multibot/*-login.json (bot con) ────
            import glob as _glob
            _multibot_dir = "data/config/multibot"
            for _fp in _glob.glob(os.path.join(_multibot_dir, "*-login.json")):
                try:
                    with open(_fp, "r", encoding="utf-8") as f:
                        items = json.load(f)
                    if not isinstance(items, list):
                        continue
                    changed = False
                    for item in items:
                        if not isinstance(item, dict):
                            continue
                        if item.get("imei") == imei or str(item.get("author_id", "")) == str(author_id):
                            item["username"] = username
                            item["author_id"] = author_id
                            if avatar:
                                item["avatar"] = avatar
                            changed = True
                            break
                    if changed:
                        with open(_fp, "w", encoding="utf-8") as f:
                            json.dump(items, f, indent=4, ensure_ascii=False)
                        return
                except Exception:
                    continue

            # Không tìm thấy ở đâu — bot mới chưa được lưu, bỏ qua âm thầm
        except Exception as e:
            logger.error(f"Lỗi khi cập nhật username: {e}")