import requests
import time
import json
import base64
from PIL import Image
import io
import traceback
import uuid
import hashlib
import qrcode

# Tạo IMEI (UUID dùng cho Zalo)
def generate_zalo_uuid():
    user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    random_uuid = str(uuid.uuid4())
    md5_hash = hashlib.md5(user_agent.encode("utf-8")).hexdigest()
    zalo_uuid = f"{random_uuid}-{md5_hash}"
    return zalo_uuid


# Khởi tạo session và lấy cookie ban đầu
def init_session():
    sessions = requests.Session()
    header1 = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Linux\"",
        "origin": "https://chat.zalo.me",
        "sec-fetch-site": "same-site",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty",
        "Accept-Encoding": "gzip",
        "referer": "https://chat.zalo.me/",
        "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
    }
    payload = {
        "continue": "https://chat.zalo.me/",
        "v": "5.5.7"
    }
    try:
        sessions.get(
            "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
            headers=header1,
            data=payload,
            timeout=15
        )
        sessions.post(
            "https://id.zalo.me/account/logininfo",
            headers=header1,
            data=payload,
            timeout=15
        )
    except Exception as e:
        print(f"[init_session] Lỗi: {e}")
    return sessions


# Xác thực thiết bị client
def verify_client(sessions):
    veri_payload = {
        "type": "device",
        "continue": "https://zalo.me/pc",
        "v": "5.5.7"
    }
    headers = {
        "accept": "*/*",
        "accept-language": "vi,en-US;q=0.9,en;q=0.8,fr-FR;q=0.7,fr;q=0.6",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://id.zalo.me",
        "priority": "u=1, i",
        "referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
        "sec-ch-ua": "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    }
    try:
        sessions.post(
            "https://id.zalo.me/account/verify-client",
            headers=headers,
            data=veri_payload,
            timeout=15
        )
    except Exception as e:
        print(f"[verify_client] Lỗi: {e}")
    return sessions


# Tạo mã QR đăng nhập
def generate_qr_code(sessions):
    payload = {
        "continue": "https://zalo.me/pc",
        "v": "5.5.7"
    }
    headers = {
        "accept": "*/*",
        "accept-language": "vi,en-US;q=0.9,en;q=0.8,fr-FR;q=0.7,fr;q=0.6",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://id.zalo.me",
        "priority": "u=1, i",
        "referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
        "sec-ch-ua": "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    }
    response = sessions.post(
        "https://id.zalo.me/account/authen/qr/generate",
        headers=headers,
        data=payload,
        timeout=20
    )

    # --- FIX: kiểm tra response rỗng trước khi parse JSON ---
    raw = response.text.strip() if response.text else ""
    if not raw:
        print("[generate_qr_code] Response rỗng từ server")
        return None, sessions
    try:
        data = response.json()
    except Exception as e:
        print(f"[generate_qr_code] Không parse được JSON: {e} | raw: {raw[:200]}")
        return None, sessions

    qr_code = data.get("data", {}).get("image")
    if not qr_code:
        print("[generate_qr_code] Không có ảnh QR trong response")
        return None, sessions

    import os
    os.makedirs("data/assets/cache/image", exist_ok=True)
    qr_code_data = qr_code.replace("data:image/png;base64,", "")
    qr_code_bytes = base64.b64decode(qr_code_data)
    qr = Image.open(io.BytesIO(qr_code_bytes))
    qr.save("data/assets/cache/image/qr_code.png")

    code = data["data"]["code"]
    print(f"[generate_qr_code] QR Code tạo thành công: {code}")
    return code, sessions


# Kiểm tra trạng thái session Zalo
def check_session(sessions):
    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        "priority": "u=0, i",
        "sec-ch-ua": "\"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "upgrade-insecure-requests": "1",
        "Referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
        "Referrer-Policy": "strict-origin-when-cross-origin",
    }
    try:
        cookies = sessions.cookies
        response = sessions.get(
            "https://id.zalo.me/account/checksession?continue=https%3A%2F%2Fchat.zalo.me%2Findex.html",
            headers=headers,
            cookies=cookies,
            timeout=15,
        )
        return response
    except Exception as e:
        print(f"[check_session] Lỗi: {e}")
        return None


# Lấy thông tin người dùng sau khi đăng nhập
def get_user_info(sessions):
    headers = {
        "accept": "*/*",
        "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        "priority": "u=1, i",
        "sec-ch-ua": "\"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "Referer": "https://chat.zalo.me/",
        "Referrer-Policy": "strict-origin-when-cross-origin",
    }
    try:
        response = sessions.get(
            "https://jr.chat.zalo.me/jr/userinfo",
            headers=headers,
            timeout=15
        )
        raw = response.text.strip() if response.text else ""
        if not raw:
            return None
        return response.json()
    except Exception as e:
        print(f"[get_user_info] Lỗi: {e}")
        return None


def _safe_json(response, label=""):
    """Parse JSON an toàn, trả None nếu response rỗng hoặc không hợp lệ."""
    try:
        raw = response.text.strip() if response and response.text else ""
        if not raw:
            return None
        return response.json()
    except Exception as e:
        print(f"[{label}] Không parse được JSON: {e}")
        return None


# Chờ người dùng quét QR code
# max_wait: tổng thời gian chờ scan (giây), mặc định 120s (2 phút)
def waiting_scan(code, sessions, max_wait=120):
    check_payload = {
        "code": code,
        "continue": "https://chat.zalo.me/",
        "v": "5.5.7"
    }
    headers = {
        "accept": "*/*",
        "accept-language": "vi,en-US;q=0.9,en;q=0.8,fr-FR;q=0.7,fr;q=0.6",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://id.zalo.me",
        "priority": "u=1, i",
        "referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
        "sec-ch-ua": "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    }

    print("[waiting_scan] Đang chờ quét QR code...")
    deadline = time.time() + max_wait

    while time.time() < deadline:
        try:
            # Dùng timeout dài để long-poll — tránh spam "Timeout, thử lại"
            remaining = deadline - time.time()
            req_timeout = min(30, max(5, remaining))
            response = sessions.post(
                "https://id.zalo.me/account/authen/qr/waiting-scan",
                headers=headers,
                data=check_payload,
                timeout=req_timeout
            )
            status_data = _safe_json(response, "waiting_scan")

            if status_data is None:
                time.sleep(2)
                continue

            error_code = status_data.get("error_code", -1)
            if error_code == 0:
                print("[waiting_scan] Đã quét QR code thành công!")
                return True
            elif error_code == 1:
                # Chưa scan → long-poll lại ngay, không sleep
                continue
            else:
                msg = status_data.get("error_message", "unknown")
                print(f"[waiting_scan] QR hết hạn hoặc lỗi (code={error_code}): {msg}")
                return False

        except requests.exceptions.Timeout:
            # Long-poll hết giờ → bình thường, poll lại không cần log
            continue
        except Exception as e:
            print(f"[waiting_scan] Lỗi kết nối: {e}")
            time.sleep(3)

    print("[waiting_scan] Hết thời gian chờ quét QR")
    return False


# Chờ người dùng xác nhận đăng nhập trên điện thoại
# max_wait: tổng thời gian chờ xác nhận (giây), mặc định 60s
def waiting_confirm(code, sessions, max_wait=60):
    confirm_payload = {
        "code": code,
        "gToken": "",
        "gAction": "CONFIRM_QR",
        "continue": "https://chat.zalo.me/index.html",
        "v": "5.5.7",
    }
    headers = {
        "accept": "*/*",
        "accept-language": "vi,en-US;q=0.9,en;q=0.8,fr-FR;q=0.7,fr;q=0.6",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://id.zalo.me",
        "priority": "u=1, i",
        "referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
        "sec-ch-ua": "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    }

    print("[waiting_confirm] Đang chờ xác nhận trên điện thoại...")
    deadline = time.time() + max_wait

    while time.time() < deadline:
        try:
            remaining = deadline - time.time()
            req_timeout = min(25, max(5, remaining))
            response = sessions.post(
                "https://id.zalo.me/account/authen/qr/waiting-confirm",
                headers=headers,
                data=confirm_payload,
                timeout=req_timeout
            )
            status_data = _safe_json(response, "waiting_confirm")

            if status_data is None:
                time.sleep(2)
                continue

            error_code = status_data.get("error_code", -1)
            if error_code == 0:
                print("[waiting_confirm] Xác nhận đăng nhập thành công!")

                # 1. Lấy zpw_sek từ session cookies
                all_cookies = {c.name: c.value for c in sessions.cookies}
                zpw_sek_val = all_cookies.get("zpw_sek")

                # 2. Nếu chưa có → gọi checksession để Zalo set cookie
                if not zpw_sek_val:
                    try:
                        check_session(sessions)
                        all_cookies = {c.name: c.value for c in sessions.cookies}
                        zpw_sek_val = all_cookies.get("zpw_sek")
                    except Exception as ce:
                        print(f"[waiting_confirm] checksession lỗi: {ce}")

                if zpw_sek_val:
                    imei = generate_zalo_uuid()
                    print("[waiting_confirm] Lấy zpw_sek thành công!")

                    # Lấy thông tin user (uid, tên) từ Zalo
                    uid = None
                    display_name = None
                    try:
                        user_info = get_user_info(sessions)
                        if user_info:
                            # jr/userinfo trả: {userId, name, avatar, ...}
                            uid = str(user_info.get("userId") or user_info.get("uid") or "")
                            display_name = (
                                user_info.get("name")
                                or user_info.get("displayName")
                                or user_info.get("zaloName")
                                or ""
                            )
                            print(f"[waiting_confirm] User: {display_name} ({uid})")
                    except Exception as ue:
                        print(f"[waiting_confirm] Lấy user info lỗi: {ue}")

                    return {
                        "imei":    imei,
                        "cookie":  {"zpw_sek": zpw_sek_val},
                        "uid":     uid,
                        "name":    display_name,
                        "active":  False,
                    }

                print(f"[waiting_confirm] Không tìm thấy zpw_sek trong cookies: {list(all_cookies.keys())}")
                return None
            else:
                # Chưa xác nhận → poll lại ngay
                continue

        except requests.exceptions.Timeout:
            # Long-poll bình thường, không log
            continue
        except Exception as e:
            print(f"[waiting_confirm] Lỗi kết nối: {e}")
            time.sleep(3)

    print("[waiting_confirm] Hết thời gian chờ xác nhận")
    return None


# Hàm chính thực hiện toàn bộ quá trình xác thực
def authenticate_zalo():
    sessions = init_session()
    if not sessions:
        return None

    sessions = verify_client(sessions)

    result = generate_qr_code(sessions)
    if not result or not result[0]:
        print("Không tạo được QR code")
        return None
    code, sessions = result

    scanned = waiting_scan(code, sessions)
    if not scanned:
        print("Đăng nhập thất bại (không quét QR)")
        return None

    data = waiting_confirm(code, sessions)
    if data:
        print("Xác thực thành công")
        print(data)
        user_info = get_user_info(sessions)
        if user_info:
            print(f"Thông tin người dùng: {user_info}")
        return sessions

    return None


if __name__ == "__main__":
    authenticate_zalo()
