from app.core.index import *

# ═══════════════════════════════════════════════════════════
# antiadd.py  –  Bot tự out khi bị add vào nhóm lạ
# Đặt file này vào: zbot/src/command/antimanager/antiadd.py
# ═══════════════════════════════════════════════════════════


def _is_enabled(this):
    """antiadd bật = bot tự out khi bị add vào BẤT KỲ nhóm nào không có trong allowGroup"""
    return read_settings(this.uid).get("antiAddEnabled", False)


def _get_whitelist(this):
    """Danh sách nhóm được phép (bot không out khi bị add vào nhóm này)"""
    return set(str(x) for x in read_settings(this.uid).get("antiAddWhitelist", []) if x)


def _save_whitelist(this, wl):
    s = read_settings(this.uid)
    s["antiAddWhitelist"] = list(wl)
    write_settings(this.uid, s)


# ── Lệnh bật/tắt ────────────────────────────────────────────

def antiAddCommand(this, message, data, userId, threadId, type):
    p = this.prefix
    c = this.rawCommand

    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) > 1 else ""

    s = read_settings(this.uid)

    if sub == "help":
        enabled = s.get("antiAddEnabled", False)
        wl      = _get_whitelist(this)
        return this.replyMessageStyle(
            f"Bot tự out khi bị add vào nhóm lạ\n\n"
            f"  Trạng thái: {'✅ BẬT' if enabled else '❌ TẮT'}\n"
            f"  Whitelist : {len(wl)} nhóm\n\n"
            f"  {p}{c} on/off           – Bật/tắt\n"
            f"  {p}{c} white add        – Cho phép nhóm hiện tại\n"
            f"  {p}{c} white remove     – Xóa nhóm hiện tại khỏi whitelist\n"
            f"  {p}{c} white list       – Xem danh sách whitelist",
            data, threadId, type, color="or", title="ANTIADD", userId=userId
        )

    if sub == "white":
        action = parts[2].lower() if len(parts) > 2 else ""
        wl = _get_whitelist(this)

        if action == "add":
            wl.add(str(threadId))
            _save_whitelist(this, wl)
            return this.replyMessageStyle(
                f"✅ Đã thêm nhóm này vào whitelist.\nBot sẽ không out khi bị add vào nhóm này.",
                data, threadId, type, color="gr", title="SUCCESS", userId=userId
            )
        elif action in ("remove", "rm"):
            wl.discard(str(threadId))
            _save_whitelist(this, wl)
            return this.replyMessageStyle(
                f"✅ Đã xóa nhóm này khỏi whitelist.",
                data, threadId, type, color="gr", title="SUCCESS", userId=userId
            )
        elif action == "list":
            if not wl:
                return this.replyMessageStyle(
                    "Whitelist đang trống.",
                    data, threadId, type, color="or", title="ANTIADD", userId=userId
                )
            lines = "\n".join(f"  • {gid}" for gid in wl)
            return this.replyMessageStyle(
                f"Danh sách nhóm whitelist:\n{lines}",
                data, threadId, type, color="or", title="ANTIADD", userId=userId
            )
        else:
            return this.replyMessageStyle(
                f"Cú pháp:\n"
                f"  {p}{c} white add      – Whitelist nhóm hiện tại\n"
                f"  {p}{c} white remove   – Xóa nhóm hiện tại\n"
                f"  {p}{c} white list     – Xem whitelist",
                data, threadId, type, color="or", title="CAUTION", userId=userId
            )

    if sub == "on":    enabled = True
    elif sub == "off": enabled = False
    else:              enabled = not s.get("antiAddEnabled", False)

    s["antiAddEnabled"] = enabled
    write_settings(this.uid, s)
    this.replyMessageStyle(
        f"AntiAdd đã được {'✅ BẬT' if enabled else '❌ TẮT'}.\n"
        f"{'Bot sẽ tự out khi bị add vào nhóm lạ.' if enabled else ''}",
        data, threadId, type,
        color="gr" if enabled else "r",
        title="ANTIADD", userId=userId,
    )


# ── Event listener ───────────────────────────────────────────
# Gọi từ main.py trong onEvent khi EventType == GroupEventType.JOIN

def antiAdd(this, eventData):
    groupId  = str(getattr(eventData, "groupId",  "") or "")
    sourceId = str(getattr(eventData, "sourceId", "") or "")  # người add
    members  = getattr(eventData, "updateMembers", None) or []

    if not groupId:
        return

    # Chỉ xử lý khi bot chính là người được add vào (updateMembers chứa bot)
    bot_id = str(getattr(this, "uid", "") or "")
    bot_was_added = any(
        str((m.get("id") if isinstance(m, dict) else getattr(m, "id", "")) or "") == bot_id
        for m in members
    )

    if not bot_was_added:
        return

    if not _is_enabled(this):
        return

    # Kiểm tra whitelist
    whitelist = _get_whitelist(this)
    if groupId in whitelist:
        print(f"[antiadd] Nhóm {groupId} trong whitelist, không out.")
        return

    # Kiểm tra allowGroup (nhóm đã được cấu hình bot)
    allow_group = read_settings(this.uid).get("allowGroup", [])
    if groupId in allow_group:
        print(f"[antiadd] Nhóm {groupId} trong allowGroup, không out.")
        return

    print(f"[antiadd] Bot bị add vào nhóm lạ {groupId} bởi {sourceId}, tự out...")

    try:
        from api.util.msg import Message
        from api.util.Enum import ThreadType
        import time

        # Gửi tin nhắn tag đúng người add bot trước khi out
        adder_name = this.userName(sourceId) or sourceId
        try:
            from api.util.msg import Mention
            tag       = f"@{adder_name}"
            msg_text  = f"{tag}\nBạn không thể thêm mình vô nhóm khi chưa được phép!, nếu đây là nhóm quan trọng vui lòng liên hệ lại với mình nhé!"
            mention   = Mention(sourceId, offset=0, length=len(tag))
            this.send(
                Message(text=msg_text, mention=mention),
                groupId,
                ThreadType.GROUP,
            )
            time.sleep(1)
        except Exception as e:
            print(f"[antiadd] Lỗi gửi tin: {e}")

        # Bot tự leave
        this.leaveGroup(groupId, True)
        print(f"[antiadd] Đã out khỏi nhóm {groupId}")

    except Exception as e:
        print(f"[antiadd] Lỗi khi out: {e}")
        import traceback
        print(traceback.format_exc())


dependencies = {
    "name":        "antiadd",
    "permission":  2,
    "description": "Bot tự out khi bị add vào nhóm lạ",
    "cooldown":    3,
    "main":        antiAddCommand,
}
