from app.core.index import *
from src.services.init.admin import admin_of_bot


def _is_card(data) -> bool:
    return getattr(data, "msgType", "") == "chat.recommended"


def antiCard(self, message, data, userId, threadId, type):
    settings = read_settings(self.uid)
    if threadId not in settings.get("antiCard", []):
        return

    if not _is_card(data):
        return

    grInfo    = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId, {})
    adminIds  = grInfo.get("adminIds", [])
    creatorId = grInfo.get("creatorId")

    if userId == creatorId or userId in adminIds:
        return
    if admin_of_bot(self, threadId, userId):
        return

    try:
        self.deleteMessage(data.msgId, data.uidFrom, data.cliMsgId, threadId)
    except Exception:
        pass

    if not hasattr(self, "_antiCardWarn"):
        self._antiCardWarn = {}

    key   = (threadId, userId)
    count = self._antiCardWarn.get(key, 0) + 1
    self._antiCardWarn[key] = count

    if count < 3:
        try:
            self.replyMessageStyle(
                f"Không được phép gửi danh thiếp trong nhóm!\n"
                f"Tin nhắn đã bị xoá. Còn {3 - count} lần nữa sẽ bị kick.",
                data, threadId, type,
                color="yl", title="CẢNH BÁO", userId=userId,
            )
        except Exception:
            pass
        return

    try:
        self.replyMessageStyle(
            "Gửi danh thiếp nhiều lần, đã bị kick khỏi nhóm!",
            data, threadId, type,
            color="r", title="ANTICARD", userId=userId,
        )
    except Exception:
        pass

    try:
        self.kickUsers(userId, threadId)
    except Exception:
        pass

    self._antiCardWarn.pop(key, None)


def antiCardCommand(self, message, data, userId, threadId, type):
    p     = self.prefix
    c     = self.rawCommand
    parts = message.text.strip().split()

    settings = read_settings(self.uid)
    anticards = settings.setdefault("antiCard", [])
    enabled   = threadId in anticards

    if len(parts) < 2:
        enabled = not enabled
    else:
        action = parts[1].lower()
        if action == "on":
            enabled = True
        elif action == "off":
            enabled = False
        else:
            return self.replyMessageStyle(
                f"📍Use: {p}{c} on | off",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

    if enabled and threadId not in anticards:
        anticards.append(threadId)
    if not enabled and threadId in anticards:
        anticards.remove(threadId)

    write_settings(self.uid, settings)

    self.replyMessageStyle(
        f"AntiCard đã được {'bật' if enabled else 'tắt'}.",
        data, threadId, type,
        color="gr", title="COMPLETE", userId=userId,
    )


dependencies = {
    "name":        "anticard",
    "permission":  2,
    "cooldown":    5,
    "description": "Chặn gửi danh thiếp trong nhóm",
    "main":        antiCardCommand,
}
