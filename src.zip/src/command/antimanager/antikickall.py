from app.core.index import *
import threading

# ═══════════════════════════════════════════════════════════════════════════════
# antikickall.py  –  Anti kick all thành viên trong nhóm
#
# Logic whitelist + cảnh báo 3 bậc:
#   Lần 1 → Cảnh báo nhẹ
#   Lần 2 → Cảnh báo nặng hơn
#   Lần 3 → Hạ key bạc (removeGroupAdmins) ngay lập tức
#
# Đặt file tại: zbot/src/command/antimanager/antikickall.py
# ═══════════════════════════════════════════════════════════════════════════════

# ── In-memory: theo dõi số lần kick của từng user trong từng nhóm ─────────────
# key: (threadId, userId) → số lần đã bị cảnh cáo
_kick_warn: dict = {}
_kick_lock = threading.Lock()

WARN_RESET_SECONDS = 300   # Reset bộ đếm sau 5 phút không kick thêm
_warn_timers: dict = {}


# ── Helpers đọc / ghi settings ───────────────────────────────────────────────

def _is_enabled(this, threadId: str) -> bool:
    s = read_settings(this.uid)
    return threadId in s.get("antiKickAllGroups", [])


def _get_whitelist(this) -> set:
    return set(str(x) for x in read_settings(this.uid).get("antiKickAllWhitelist", []) if x)


def _save_whitelist(this, wl: set):
    s = read_settings(this.uid)
    s["antiKickAllWhitelist"] = list(wl)
    write_settings(this.uid, s)


def _toggle_group(this, threadId: str, enable: bool):
    s = read_settings(this.uid)
    groups = s.setdefault("antiKickAllGroups", [])
    if enable and threadId not in groups:
        groups.append(threadId)
    elif not enable and threadId in groups:
        groups.remove(threadId)
    write_settings(this.uid, s)


# ── Reset bộ đếm cảnh cáo ────────────────────────────────────────────────────

def _schedule_warn_reset(threadId: str, userId: str, delay: int = WARN_RESET_SECONDS):
    key = (threadId, userId)

    old = _warn_timers.get(key)
    if old:
        old.cancel()

    def _reset():
        with _kick_lock:
            _kick_warn.pop(key, None)
            _warn_timers.pop(key, None)

    t = threading.Timer(delay, _reset)
    t.daemon = True
    t.start()
    _warn_timers[key] = t


# ── Kiểm tra xem userId có phải admin nhóm zalo không ───────────────────────

def _get_group_info(this, threadId: str) -> dict:
    try:
        gi = this.fetchGroupInfo(threadId)
        gmap = getattr(gi, "gridInfoMap", None) or {}
        info = gmap.get(threadId) or gmap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}


def _get_admin_ids(info: dict) -> list:
    for k in ("adminIds", "adminIdList", "admins", "adminList",
              "adminIdMap", "adminMap", "adminUidList", "adminUidMap"):
        if k not in info:
            continue
        v = info[k]
        if isinstance(v, dict):
            return [x for x in v.keys() if x]
        if isinstance(v, (list, tuple, set)):
            return [x for x in v if x]
        if isinstance(v, str):
            return [x for x in v.replace(" ", "").split(",") if x]
        return []
    return []


def _is_group_admin(this, userId: str, threadId: str) -> bool:
    info = _get_group_info(this, threadId)
    return str(userId) in [str(a) for a in _get_admin_ids(info)]


# ── Hạ key bạc (demote admin nhóm Zalo) ─────────────────────────────────────

def _demote_admin(this, userId: str, threadId: str) -> bool:
    """Hạ quyền admin nhóm Zalo của userId. Trả True nếu thành công."""
    try:
        this.removeGroupAdmins([userId], threadId)
        return True
    except Exception as e:
        print(f"[antikickall] removeGroupAdmins lỗi: {e}")
        return False


# ── Core: gọi khi phát hiện có thành viên bị kick (REMOVE_MEMBER / BLOCK_MEMBER)

def antiKickAll(this, eventData, is_block: bool = False):
    """
    Gọi từ ZaloEventHandle khi:
      - eventType == GroupEventType.REMOVE_MEMBER  (kick bình thường)
      - eventType == GroupEventType.BLOCK_MEMBER   (kick + chặn)

    Nếu muốn phân biệt kick thường và kick+block thì dùng is_block=True.
    """
    groupId  = str(getattr(eventData, "groupId",  "") or "")
    sourceId = str(getattr(eventData, "sourceId", "") or "")   # người thực hiện kick
    members  = getattr(eventData, "updateMembers", None) or []

    if not groupId or not sourceId:
        return

    # Chỉ xử lý khi nhóm đã bật antikickall
    if not _is_enabled(this, groupId):
        return

    # Bot không tự xử lý chính mình
    bot_id = str(getattr(this, "uid", "") or "")
    if sourceId == bot_id:
        return

    # Bỏ qua nếu sourceId trong whitelist
    whitelist = _get_whitelist(this)
    if sourceId in whitelist:
        return

    # Bỏ qua nếu người kick là developer / high admin / bot admin của bot
    from src.services.init.admin import admin_of_bot, isAdminHigh
    if isAdminHigh(this, sourceId) or admin_of_bot(this, groupId, sourceId):
        return

    # Đếm số thành viên bị kick lần này
    kick_count = max(len(members), 1)

    # Tích lũy cảnh cáo
    key = (groupId, sourceId)
    with _kick_lock:
        current = _kick_warn.get(key, 0) + kick_count
        _kick_warn[key] = current

    _schedule_warn_reset(groupId, sourceId)

    actor_name = this.userName(sourceId) or sourceId

    # ── Lần 1: cảnh báo nhẹ ──────────────────────────────────────────────────
    if current == 1:
        try:
            from api.util.msg import Mention
            tag  = f"@{actor_name}"
            text = (
                f"{tag}\n"
                f"⚠️ Cảnh báo lần 1: Bạn vừa kick thành viên khỏi nhóm.\n"
                f"Hãy dừng lại! Kick thêm lần nữa sẽ bị xử lý nặng hơn."
            )
            mention = Mention(sourceId, offset=0, length=len(tag))
            from api.util.msg import Message
            from api.util.Enum import ThreadType
            this.send(Message(text=text, mention=mention), groupId, ThreadType.GROUP)
        except Exception as e:
            print(f"[antikickall] Lỗi gửi cảnh báo lần 1: {e}")

    # ── Lần 2: cảnh báo mạnh ─────────────────────────────────────────────────
    elif current == 2:
        try:
            from api.util.msg import Mention, Message
            from api.util.Enum import ThreadType
            tag  = f"@{actor_name}"
            text = (
                f"{tag}\n"
                f"🚨 Cảnh báo lần 2: Bạn tiếp tục kick thành viên!\n"
                f"Đây là cảnh báo cuối cùng. Kick thêm lần nữa, bạn sẽ bị hạ key bạc ngay lập tức."
            )
            mention = Mention(sourceId, offset=0, length=len(tag))
            this.send(Message(text=text, mention=mention), groupId, ThreadType.GROUP)
        except Exception as e:
            print(f"[antikickall] Lỗi gửi cảnh báo lần 2: {e}")

    # ── Lần 3+: hạ key bạc (demote admin nhóm Zalo) ──────────────────────────
    elif current >= 3:
        # Reset bộ đếm ngay để tránh spam action
        with _kick_lock:
            _kick_warn.pop(key, None)
        old_timer = _warn_timers.pop(key, None)
        if old_timer:
            old_timer.cancel()

        is_admin = _is_group_admin(this, sourceId, groupId)
        demoted  = False
        if is_admin:
            demoted = _demote_admin(this, sourceId, groupId)

        try:
            from api.util.msg import Mention, Message
            from api.util.Enum import ThreadType
            tag  = f"@{actor_name}"
            if demoted:
                text = (
                    f"{tag}\n"
                    f"🔴 Lần 3: Bạn đã bị hạ key bạc (xoá quyền admin nhóm) vì liên tục kick thành viên!"
                )
            else:
                text = (
                    f"{tag}\n"
                    f"🔴 Lần 3: Bạn đã vi phạm quy tắc nhóm (kick thành viên liên tục)!\n"
                    f"{'Đã xoá quyền admin của bạn.' if is_admin else 'Bạn không có quyền admin để hạ.'}"
                )
            mention = Mention(sourceId, offset=0, length=len(tag))
            this.send(Message(text=text, mention=mention), groupId, ThreadType.GROUP)
        except Exception as e:
            print(f"[antikickall] Lỗi gửi thông báo hạ key: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# Lệnh quản lý antikickall
# ═══════════════════════════════════════════════════════════════════════════════

def antiKickAllCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) > 1 else ""

    s       = read_settings(this.uid)
    enabled = threadId in s.get("antiKickAllGroups", [])

    # ── help ─────────────────────────────────────────────────────────────────
    if sub in ("help", ":help", ""):
        wl = _get_whitelist(this)
        return this.replyMessageStyle(
            f"Anti Kick All – Bảo vệ nhóm khỏi bị kick hàng loạt\n\n"
            f"  Trạng thái : {'✅ BẬT' if enabled else '❌ TẮT'} tại nhóm này\n"
            f"  Whitelist  : {len(wl)} thành viên\n\n"
            f"Lệnh:\n"
            f"  {p}{c} on / off          – Bật / tắt tại nhóm này\n"
            f"  {p}{c} white add         – Thêm @mention vào whitelist\n"
            f"  {p}{c} white remove      – Xoá @mention khỏi whitelist\n"
            f"  {p}{c} white list        – Xem danh sách whitelist\n"
            f"  {p}{c} reset @mention    – Reset bộ đếm cảnh cáo của thành viên\n\n"
            f"Cơ chế:\n"
            f"  Kick lần 1 → ⚠️ Cảnh báo nhẹ\n"
            f"  Kick lần 2 → 🚨 Cảnh báo cuối\n"
            f"  Kick lần 3 → 🔴 Hạ key bạc (xoá quyền admin nhóm)",
            data, threadId, type, color="or", title="ANTIKICKALL", userId=userId
        )

    # ── on / off ──────────────────────────────────────────────────────────────
    if sub == "on":
        _toggle_group(this, threadId, True)
        return this.replyMessageStyle(
            "✅ AntiKickAll đã được BẬT tại nhóm này.\n"
            "Bot sẽ cảnh báo và hạ key bạc nếu ai kick thành viên liên tục.",
            data, threadId, type, color="gr", title="ANTIKICKALL", userId=userId
        )

    if sub == "off":
        _toggle_group(this, threadId, False)
        return this.replyMessageStyle(
            "❌ AntiKickAll đã được TẮT tại nhóm này.",
            data, threadId, type, color="r", title="ANTIKICKALL", userId=userId
        )

    # ── white ─────────────────────────────────────────────────────────────────
    if sub == "white":
        action = parts[2].lower() if len(parts) > 2 else ""
        wl     = _get_whitelist(this)
        uids   = extractUids(data)

        if action == "add":
            if not uids:
                return this.replyMessageStyle(
                    "Vui lòng @mention thành viên muốn thêm vào whitelist.",
                    data, threadId, type, color="yl", title="CAUTION", userId=userId
                )
            added = []
            for uid in uids:
                wl.add(str(uid))
                added.append(this.userName(uid) or str(uid))
            _save_whitelist(this, wl)
            names = ", ".join(added)
            return this.replyMessageStyle(
                f"✅ Đã thêm vào whitelist: {names}\nNhững thành viên này sẽ không bị theo dõi bởi AntiKickAll.",
                data, threadId, type, color="gr", title="SUCCESS", userId=userId
            )

        elif action in ("remove", "rm"):
            if not uids:
                return this.replyMessageStyle(
                    "Vui lòng @mention thành viên muốn xoá khỏi whitelist.",
                    data, threadId, type, color="yl", title="CAUTION", userId=userId
                )
            removed = []
            for uid in uids:
                if str(uid) in wl:
                    wl.discard(str(uid))
                    removed.append(this.userName(uid) or str(uid))
            _save_whitelist(this, wl)
            if not removed:
                return this.replyMessageStyle(
                    "Không tìm thấy thành viên nào trong whitelist.",
                    data, threadId, type, color="yl", title="CAUTION", userId=userId
                )
            names = ", ".join(removed)
            return this.replyMessageStyle(
                f"✅ Đã xoá khỏi whitelist: {names}",
                data, threadId, type, color="gr", title="SUCCESS", userId=userId
            )

        elif action == "list":
            if not wl:
                return this.replyMessageStyle(
                    "Whitelist đang trống.\nDùng lệnh white add @mention để thêm.",
                    data, threadId, type, color="or", title="ANTIKICKALL", userId=userId
                )
            lines = []
            for i, uid in enumerate(wl, 1):
                name = this.userName(uid) or uid
                lines.append(f"  {i}. {name} ({uid})")
            return this.replyMessageStyle(
                f"Danh sách whitelist AntiKickAll ({len(wl)} người):\n" + "\n".join(lines),
                data, threadId, type, color="or", title="ANTIKICKALL", userId=userId
            )

        else:
            return this.replyMessageStyle(
                f"Cú pháp:\n"
                f"  {p}{c} white add @mention\n"
                f"  {p}{c} white remove @mention\n"
                f"  {p}{c} white list",
                data, threadId, type, color="yl", title="CAUTION", userId=userId
            )

    # ── reset ─────────────────────────────────────────────────────────────────
    if sub == "reset":
        uids = extractUids(data)
        if not uids:
            return this.replyMessageStyle(
                "Vui lòng @mention thành viên cần reset bộ đếm cảnh báo.",
                data, threadId, type, color="yl", title="CAUTION", userId=userId
            )
        reset_names = []
        with _kick_lock:
            for uid in uids:
                key = (threadId, str(uid))
                _kick_warn.pop(key, None)
                old = _warn_timers.pop(key, None)
                if old:
                    old.cancel()
                reset_names.append(this.userName(uid) or str(uid))
        names = ", ".join(reset_names)
        return this.replyMessageStyle(
            f"✅ Đã reset bộ đếm cảnh báo cho: {names}",
            data, threadId, type, color="gr", title="SUCCESS", userId=userId
        )

    # ── toggle nếu không có sub hợp lệ ──────────────────────────────────────
    new_state = not enabled
    _toggle_group(this, threadId, new_state)
    return this.replyMessageStyle(
        f"AntiKickAll đã {'✅ BẬT' if new_state else '❌ TẮT'} tại nhóm này.",
        data, threadId, type,
        color="gr" if new_state else "r",
        title="ANTIKICKALL", userId=userId
    )


dependencies = {
    "name":        "antikickall",
    "permission":  2,
    "description": "Cảnh báo 3 bậc và hạ key bạc khi admin kick thành viên liên tục",
    "cooldown":    3,
    "main":        antiKickAllCommand,
}
