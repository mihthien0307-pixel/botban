from app.core.index import *
import re
import time
from datetime import datetime


def hasUrl(text):
    if not text:
        return False
    if not isinstance(text, str):
        try:
            text = str(text)
        except Exception:
            return False
    pattern = r"""(?xi)
        (?:https?://\S+)
        |
        (?:www\.\S+)
        |
        (?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?
           \.
           (?:com|vn|net|org|io|me|co|xyz|site|online|info|biz|gg|tv|app|dev|link|cc|id|jp|kr|us|uk|asia)
           (?:[/?#]\S*)?)
    """
    return re.search(pattern, text.lower()) is not None


def antiUrlMessage(self, message, data, userId, threadId, type):
    if not hasattr(self, "_antiUrlLog"):
        self._antiUrlLog = {}

    settings = read_settings(self.uid)
    if threadId not in settings.get("antiUrl", []):
        return

    grInfo    = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId, {})
    adminIds  = grInfo.get("adminIds", [])
    creatorId = grInfo.get("creatorId")

    if userId == creatorId or userId in adminIds:
        return
    if admin_of_bot(self, threadId, userId):
        return

    is_link = False
    if data.msgType == "chat.recommended":
        is_link = True
    elif hasUrl(data.content):
        is_link = True

    if not is_link:
        return

    try:
        self.deleteMessage(data.msgId, data.uidFrom, data.cliMsgId, threadId)
    except Exception:
        pass

    today = datetime.now().strftime("%Y-%m-%d")
    key   = (threadId, userId, today)
    logs  = self._antiUrlLog.get(key, [])
    logs.append(time.time())
    self._antiUrlLog[key] = logs

    count       = len(logs)
    max_violate = 3

    if count < max_violate:
        remain = max_violate - count
        try:
            self.replyMessageStyle(
                f"Không cho phép gửi link tại đây!\n"
                f"Tin nhắn đã bị xoá. Còn {remain} lần nữa là ra đảo.",
                data, threadId, type,
                color="yl", title="CẢNH BÁO", userId=userId
            )
        except Exception:
            pass
        return

    try:
        self.blockUsers(userId, threadId)
    except Exception:
        pass

    self._antiUrlLog.pop(key, None)

    try:
        self.sendMessage(
            "Người dùng vừa bị kick vì spam link!\n"
            "Mọi người vui lòng tuân thủ quy định nhóm!",
            threadId, type
        )
    except Exception:
        pass


def antiUrlCommand(self, message, data, userId, threadId, type):
    p = self.prefix
    c = self.rawCommand

    parts    = message.text.strip().split()
    settings = read_settings(self.uid)
    antiurl  = settings.setdefault("antiUrl", [])
    enabled  = threadId in antiurl

    if len(parts) < 2:
        enabled = not enabled
    else:
        action = parts[1].lower()
        if action == "on":
            enabled = True
        elif action == "off":
            enabled = False
        else:
            return self.replyMessageStyle(
                f"📍Use: {p}{c} on | off",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId
            )

    if enabled and threadId not in antiurl:
        antiurl.append(threadId)
    if not enabled and threadId in antiurl:
        antiurl.remove(threadId)

    write_settings(self.uid, settings)

    self.replyMessageStyle(
        f"AntiUrl đã được {'bật' if enabled else 'tắt'}.",
        data, threadId, type,
        color="gr", title="SUCCESS", userId=userId
    )


dependencies = {
    "name":        "antiurl",
    "permission":  2,
    "description": "Anti url chat",
    "cooldown":    5,
    "main":        antiUrlCommand,
}