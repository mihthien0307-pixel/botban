from app.core.index import *
from src.services.init.admin import admin_of_bot
import threading
import time

MAX_WARNINGS     = 3
WARNING_COOLDOWN = 6 * 60 * 60

_warnings: dict = {}
_lock = threading.Lock()


def _is_enabled(this, threadId: str) -> bool:
    return threadId in read_settings(this.uid).get("antiVoice", [])


def _toggle(this, threadId: str, enable: bool):
    s = read_settings(this.uid)
    lst = s.setdefault("antiVoice", [])
    if enable and threadId not in lst:
        lst.append(threadId)
    elif not enable and threadId in lst:
        lst.remove(threadId)
    write_settings(this.uid, s)


def _get_group_info(this, threadId):
    try:
        gi   = this.fetchGroupInfo(threadId)
        gmap = getattr(gi, "gridInfoMap", None) or {}
        info = gmap.get(threadId) or gmap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}


def _is_zalo_admin(this, userId: str, threadId: str) -> bool:
    info    = _get_group_info(this, threadId)
    creator = str(info.get("creatorId", "") or "")
    admins  = [str(x) for x in (info.get("adminIds") or [])]
    return str(userId) in admins or str(userId) == creator


def _send_text(this, text, threadId):
    try:
        from api.util.msg import Message
        from api.util.Enum import ThreadType
        this.send(Message(text=text), threadId, ThreadType.GROUP)
    except Exception:
        pass


def antiVoice(this, message, data, userId, threadId, type):
    if not _is_enabled(this, str(threadId)):
        return

    if str(userId) == str(getattr(this, "uid", "")):
        return

    if _is_zalo_admin(this, userId, threadId):
        return
    if admin_of_bot(this, threadId, userId):
        return

    if (getattr(data, "msgType", "") or "") != "chat.voice":
        return

    msg_id     = getattr(data, "msgId",    "") or ""
    cli_msg_id = getattr(data, "cliMsgId", "") or ""

    try:
        this.deleteMessage(msg_id, userId, cli_msg_id, threadId)
    except Exception:
        pass

    tid = str(threadId)
    uid = str(userId)
    now = time.time()

    with _lock:
        grp   = _warnings.setdefault(tid, {})
        entry = grp.get(uid, {"count": 0, "ts": now})
        if now - entry.get("ts", 0) > WARNING_COOLDOWN:
            entry = {"count": 0, "ts": now}
        entry["count"] += 1
        entry["ts"]     = now
        grp[uid]        = entry
        cnt = entry["count"]

    name = this.userName(userId) or userId

    if cnt < MAX_WARNINGS:
        _send_text(this,
            f"🚫 {name}, không được gửi voice!\n"
            f"Cảnh báo lần {cnt}/{MAX_WARNINGS}. Tin nhắn đã bị xóa.",
            threadId,
        )
    else:
        _send_text(this,
            f"🚫 {name} bị kick do gửi voice sau {MAX_WARNINGS} lần cảnh báo.",
            threadId,
        )
        try:
            this.kickUsers([userId], threadId)
        except Exception:
            pass
        with _lock:
            _warnings.get(tid, {}).pop(uid, None)


def antiVoiceCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    parts = (getattr(message, "text", "") or "").strip().split()
    sub   = parts[1].lower() if len(parts) > 1 else ""

    enabled = _is_enabled(this, str(threadId))

    if sub == "on":
        _toggle(this, str(threadId), True)
        return this.replyMessageStyle(
            "✅ Đã bật chống voice. Xóa ngay + cảnh báo 3 lần → kick.",
            data, threadId, type, color="gr", title="ANTIVOICE", userId=userId,
        )
    if sub == "off":
        _toggle(this, str(threadId), False)
        return this.replyMessageStyle(
            "❌ Đã tắt chống voice.",
            data, threadId, type, color="r", title="ANTIVOICE", userId=userId,
        )

    trang_thai = "✅ BẬT" if enabled else "❌ TẮT"
    this.replyMessageStyle(
        f"Chống voice: {trang_thai}\n\n"
        f"  {p}{c} on   – Bật\n"
        f"  {p}{c} off  – Tắt\n\n"
        f"Xóa ngay, cảnh báo {MAX_WARNINGS} lần → kick.",
        data, threadId, type, color="or", title="ANTIVOICE", userId=userId,
    )


dependencies = {
    "name":        "antivoice",
    "permission":  2,
    "description": "Chống voice: xóa ngay, cảnh báo 3 lần → kick",
    "cooldown":    3,
    "main":        antiVoiceCommand,
}
