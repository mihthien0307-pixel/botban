# zbot/src/command/antimanager/index.py

from app.core.index import *

# Import dùng absolute path để tránh lỗi relative import
# khi bot con load qua importlib (commandLoader)
from src.command.antimanager.antibot      import antiBot
from src.command.antimanager.antiforward  import antiForward
from src.command.antimanager.antiurl      import antiUrlMessage
from src.command.antimanager.antispam     import antiSpamMessage
from src.command.antimanager.anticard     import antiCard
from src.command.antimanager.antibadword  import antiBadWord
from src.command.antimanager.antivoice    import antiVoice
from src.services.utils.mute_core         import silentListener

# lệnh (đăng ký qua dependencies, không cần import thêm)
from src.command.antimanager.antiadd      import antiAddCommand
from src.command.antimanager.antikickall  import antiKickAllCommand


def handleListenAnti(self, message, data, userId, threadId, type):
    antiBot(self, message, data, userId, threadId, type)
    antiForward(self, message, data, userId, threadId, type)
    antiUrlMessage(self, message, data, userId, threadId, type)
    antiSpamMessage(self, message, data, userId, threadId, type)
    antiCard(self, message, data, userId, threadId, type)
    antiBadWord(self, message, data, userId, threadId, type)
    antiVoice(self, message, data, userId, threadId, type)
    silentListener(self, message, data, userId, threadId, type)
    # antiAdd và antiKickAll là event listener → gọi trong ZaloEventHandle
