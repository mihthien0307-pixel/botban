"""
encode.py  –  Encode/obfuscate Python file
Usage:
  <prefix>encode list
  <prefix>encode <option> <loop>   (reply/quote một file .py)
"""

from app.core.index import *

import base64
import marshal
import zlib
import py_compile
import zipfile
import tempfile
import os
import requests as _requests

# ─────────────────────────────────────────────────────────────────────────────
# ENCODE OPTIONS
# ─────────────────────────────────────────────────────────────────────────────

ENCODE_OPTIONS = [
    "Base64 encode",
    "Zlib + Base64 encode",
    "Marshal + Base64 encode",
    "Zlib + Marshal + Base64 encode",
    "Double Base64 encode",
]


def _enc_base64(src: str) -> str:
    encoded = base64.b64encode(src.encode("utf-8")).decode()
    return (
        "import base64\n"
        f"exec(base64.b64decode({repr(encoded)}).decode('utf-8'))\n"
    )


def _enc_zlib_b64(src: str) -> str:
    compressed = zlib.compress(src.encode("utf-8"), level=9)
    encoded = base64.b64encode(compressed).decode()
    return (
        "import base64, zlib\n"
        f"exec(zlib.decompress(base64.b64decode({repr(encoded)})).decode('utf-8'))\n"
    )


def _enc_marshal_b64(src: str) -> str:
    code_obj = compile(src, "<string>", "exec")
    encoded = base64.b64encode(marshal.dumps(code_obj)).decode()
    return (
        "import base64, marshal\n"
        f"exec(marshal.loads(base64.b64decode({repr(encoded)})))\n"
    )


def _enc_zlib_marshal_b64(src: str) -> str:
    code_obj = compile(src, "<string>", "exec")
    compressed = zlib.compress(marshal.dumps(code_obj), level=9)
    encoded = base64.b64encode(compressed).decode()
    return (
        "import base64, zlib, marshal\n"
        f"exec(marshal.loads(zlib.decompress(base64.b64decode({repr(encoded)}))))\n"
    )


def _enc_double_b64(src: str) -> str:
    first = base64.b64encode(src.encode("utf-8")).decode()
    second = base64.b64encode(first.encode("utf-8")).decode()
    return (
        "import base64\n"
        f"exec(base64.b64decode(base64.b64decode({repr(second)})).decode('utf-8'))\n"
    )


ENCODERS = [
    _enc_base64,
    _enc_zlib_b64,
    _enc_marshal_b64,
    _enc_zlib_marshal_b64,
    _enc_double_b64,
]


def _apply_encode(option: int, src: str, loop: int) -> str:
    """Áp dụng encoder theo option, lặp loop lần."""
    encoder = ENCODERS[option - 1]
    result = src
    for _ in range(loop):
        result = encoder(result)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: lấy attachment từ data (quoted hoặc direct)
# ─────────────────────────────────────────────────────────────────────────────

def _get_attach(data) -> dict | None:
    """
    Trả về dict {'href': ..., 'title': ...} nếu tìm thấy attachment.
    Ưu tiên: quoted message → direct attachment → None.
    """
    if not isinstance(data, dict):
        try:
            data = vars(data)
        except Exception:
            return None

    # quoted message
    quote = data.get("quote") or {}
    if isinstance(quote, dict):
        attach = quote.get("attach") or {}
        if isinstance(attach, str):
            try:
                import json as _json
                attach = _json.loads(attach)
            except Exception:
                attach = {}
        href = attach.get("href") or attach.get("fileUrl") or attach.get("url")
        title = attach.get("title") or attach.get("fileName") or attach.get("name")
        if href:
            return {"href": href, "title": title}

    # direct attach field
    attach = data.get("attach") or {}
    if isinstance(attach, str):
        try:
            import json as _json
            attach = _json.loads(attach)
        except Exception:
            attach = {}
    href = attach.get("href") or attach.get("fileUrl") or attach.get("url")
    title = attach.get("title") or attach.get("fileName") or attach.get("name")
    if href:
        return {"href": href, "title": title}

    return None


# ─────────────────────────────────────────────────────────────────────────────
# MAIN COMMAND
# ─────────────────────────────────────────────────────────────────────────────

def EncodeCommand(self, message, data, userId, threadId, type):
    text = (getattr(message, "text", "") or "").strip().split()

    # ── encode list ──────────────────────────────────────────────────────────
    if len(text) > 1 and text[1].lower() == "list":
        out = "📋 Encode Options:\n"
        for i, desc in enumerate(ENCODE_OPTIONS, 1):
            out += f"  {i}. {desc}\n"
        self.sendSuccess(out.strip(), threadId, type, data)
        return

    # ── validate args ─────────────────────────────────────────────────────────
    if len(text) < 3 or not text[1].isdigit() or not text[2].isdigit():
        self.sendWarning(
            f"Reply/quote một file .py rồi dùng:\n"
            f"{self.prefix}encode <option> <loop>\n"
            f"Ví dụ: {self.prefix}encode 1 3\n"
            f"Xem danh sách: {self.prefix}encode list",
            threadId, type, data
        )
        return

    option = int(text[1])
    loop   = int(text[2])

    if option < 1 or option > len(ENCODE_OPTIONS) or loop < 1:
        self.sendWarning(
            f"Option phải từ 1–{len(ENCODE_OPTIONS)}, loop phải ≥ 1.",
            threadId, type, data
        )
        return

    if loop > 20:
        self.sendWarning("Loop tối đa 20 lần thôi nha.", threadId, type, data)
        return

    # ── lấy file từ quoted/direct attachment ─────────────────────────────────
    file_bytes = None
    filename   = None

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    }

    ad = _get_attach(data)
    if ad and ad.get("href"):
        try:
            r = _requests.get(ad["href"], headers=headers, timeout=20)
            r.raise_for_status()
            file_bytes = r.content
            filename   = (
                ad.get("title")
                or ad["href"].split("/")[-1].split("?")[0]
                or "file.py"
            )
        except Exception as e:
            self.sendWarning(f"Không tải được file: {e}", threadId, type, data)
            return

    # fallback: URL trong text
    if not file_bytes:
        for word in text[3:]:
            if isinstance(word, str) and word.startswith("http"):
                try:
                    r = _requests.get(word, headers=headers, timeout=20)
                    r.raise_for_status()
                    file_bytes = r.content
                    filename   = word.split("/")[-1].split("?")[0] or "url.py"
                    break
                except Exception:
                    pass

    if not file_bytes or not filename:
        self.sendWarning(
            "Reply/quote kèm file .py để encode nhé!",
            threadId, type, data
        )
        return

    if not filename.lower().endswith(".py"):
        self.sendWarning("Chỉ hỗ trợ file Python (.py) thôi nha.", threadId, type, data)
        return

    # ── decode source ─────────────────────────────────────────────────────────
    try:
        src = file_bytes.decode("utf-8-sig")
    except Exception:
        try:
            src = file_bytes.decode("utf-8", errors="ignore")
        except Exception:
            self.sendWarning("Không đọc được nội dung file.", threadId, type, data)
            return

    # ── encode ────────────────────────────────────────────────────────────────
    try:
        result_src = _apply_encode(option, src, loop)
    except SyntaxError as e:
        self.sendError(f"File có lỗi cú pháp Python:\n{e}", threadId, type, data)
        return
    except Exception as e:
        self.sendError(f"Encode thất bại: {e}", threadId, type, data)
        return

    # ── đóng gói zip và upload ────────────────────────────────────────────────
    base_name    = filename[:-3]  # bỏ .py
    out_filename = f"{base_name}_encoded.py"
    zip_filename = f"{base_name}_encoded.zip"
    temp_zip     = None

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            temp_zip = tmp.name

        with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(out_filename, result_src)

        # upload lên Zalo
        upload_result = self._uploadAttachment(temp_zip, threadId, type)
        file_url = (
            upload_result.get("fileUrl")
            if isinstance(upload_result, dict)
            else getattr(upload_result, "fileUrl", None)
        )

        if not file_url:
            self.sendError("Upload thất bại, không lấy được fileUrl.", threadId, type, data)
            return

        file_size = os.path.getsize(temp_zip)

        self.sendRemoteFile(
            fileUrl   = file_url,
            threadId  = threadId,
            type      = type,
            fileName  = zip_filename,
            fileSize  = file_size,
            extension = "zip",
            ttl       = 86400000,
            local_path= temp_zip,
        )

        self.sendSuccess(
            f"✅ Đã encode '{filename}'\n"
            f"Method : {ENCODE_OPTIONS[option - 1]}\n"
            f"Loop   : {loop} lần",
            threadId, type, data
        )

    except Exception as e:
        self.sendError(f"Gửi file thất bại: {e}", threadId, type, data)

    finally:
        if temp_zip and os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# DEPENDENCIES
# ─────────────────────────────────────────────────────────────────────────────

dependencies = {
    "name":        "encode",
    "permission":  0,
    "description": "Encode/obfuscate file Python (.py)",
    "cooldown":    5,
    "alias":       ["enc"],
    "main":        EncodeCommand,
}
