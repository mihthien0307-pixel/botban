# src/command/botTool/evalExecutor.py
# Lệnh eval – chạy code Python / JS / C++ trực tiếp trong chat
# Yêu cầu: Node.js (js), g++ (c++) được cài trên server
from app.core.index import *
import re, json, builtins, traceback, ipaddress, subprocess, tempfile, os

# ─────────────────────────────────────────────
#  Hằng số
# ─────────────────────────────────────────────
MAXLEN    = 10_000_000
URLFULLRE = re.compile(r"(https?://\S+)$")

# ─────────────────────────────────────────────
#  Util – cắt / format output
# ─────────────────────────────────────────────

def _clip(s, limit=MAXLEN):
    if s is None:
        return ""
    s = str(s)
    return s[:limit] + ("\n..." if len(s) > limit else "")


def _strip_fence(s):
    s = ("" if s is None else str(s)).strip()
    if s.startswith("```") and s.endswith("```"):
        lines = s.splitlines()
        if len(lines) >= 2:
            return "\n".join(lines[1:-1]).strip()
    return s


def _extract_url(s):
    s = ("" if s is None else str(s)).strip()
    if not s or "\n" in s:
        return ""
    m = URLFULLRE.fullmatch(s)
    if not m:
        return ""
    return m.group(1).rstrip(").,;\"'")


def _is_blocked_host(host):
    if not host:
        return True
    h = host.lower().strip(".")
    if h == "localhost" or h.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(h)
        return (
            ip.is_private or ip.is_loopback or
            ip.is_link_local or ip.is_reserved or ip.is_multicast
        )
    except ValueError:
        return False


def _safe_fetch(url):
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        if p.scheme not in {"http", "https"}:
            return None
        if _is_blocked_host(p.hostname or ""):
            return None

        r = requests.get(url, timeout=6, stream=True,
                         headers={"User-Agent": "Mozilla/5.0"})
        limit = 1024 * 1024
        buf   = bytearray()
        for chunk in r.iter_content(chunk_size=16384):
            if not chunk:
                continue
            buf.extend(chunk)
            if len(buf) >= limit:
                break

        ct     = (r.headers.get("content-type") or "").lower()
        textok = (
            "application/json" in ct or
            ct.startswith("text/") or
            "xml" in ct or
            "javascript" in ct
        )
        if textok:
            enc = r.encoding or "utf-8"
            txt = bytes(buf).decode(enc, errors="replace")
            if len(buf) >= limit:
                txt += "\n..."
            return txt
        return f"fetched: content-type={ct or 'unknown'} bytes={len(buf)}"
    except Exception:
        return None


# ─────────────────────────────────────────────
#  JSON pretty-print
# ─────────────────────────────────────────────

def _try_load_json(s, limit=2_000_000):
    if not isinstance(s, str):
        return None
    t = _strip_fence(s).strip()
    if not t or len(t) > limit:
        return None
    if (t[0] == "{" and t[-1] == "}") or (t[0] == "[" and t[-1] == "]"):
        try:
            return json.loads(t)
        except Exception:
            return None
    return None


def _deep_parse(obj, depth=4):
    if depth <= 0:
        return obj
    if isinstance(obj, dict):
        return {k: _deep_parse(v, depth) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_parse(x, depth) for x in obj]
    if isinstance(obj, str):
        loaded = _try_load_json(obj)
        if loaded is not None:
            return _deep_parse(loaded, depth - 1)
    return obj


def _pretty_json(obj):
    try:
        if isinstance(obj, (dict, list)):
            return json.dumps(_deep_parse(obj, 4), ensure_ascii=False, indent=2)
        s = _strip_fence(obj)
        t = s.strip()
        if not t or len(t) > 2_000_000:
            return s
        loaded = _try_load_json(t)
        if loaded is not None:
            return json.dumps(_deep_parse(loaded, 4), ensure_ascii=False, indent=2)
        return s
    except Exception:
        return _strip_fence(obj)


def _normalize(obj):
    if isinstance(obj, str):
        url = _extract_url(obj)
        if url:
            fetched = _safe_fetch(url)
            if fetched is not None:
                obj = fetched
    return _clip(_pretty_json(obj))


# ─────────────────────────────────────────────
#  Tách ngôn ngữ từ raw code
#  Ví dụ: ```py\ncode``` → ("py", "code")
#          ```js\ncode``` → ("js", "code")
#  Mặc định không có fence → ("py", raw)
# ─────────────────────────────────────────────

def _dec_lang(raw: str):
    raw = raw.strip()
    # fence ```lang\n...code...```
    if raw.startswith("```"):
        lines = raw.splitlines()
        if len(lines) >= 2:
            lang_tag = lines[0][3:].strip().lower()
            code     = "\n".join(lines[1:])
            if code.endswith("```"):
                code = code[:-3].rstrip()
            lang = {"python": "py", "javascript": "js", "c++": "cpp", "cpp": "cpp"}.get(lang_tag, lang_tag)
            if lang in ("py", "js", "cpp"):
                return lang, code
    # không có fence → mặc định Python
    return "py", raw


# ─────────────────────────────────────────────
#  Ẩn đường dẫn hệ thống trong stderr
# ─────────────────────────────────────────────

_PATH_RE = re.compile(r'(/[^\s"\']+/)')

def _hide_path(s: str) -> str:
    return _PATH_RE.sub("<path>/", s)


# ─────────────────────────────────────────────
#  Chạy Python (exec trong sandbox nhẹ)
# ─────────────────────────────────────────────

def _py_exec(code: str, ctx: dict):
    """
    Trả về (result, error_string).
    - result: giá trị trả về của biểu thức cuối (nếu là expression), hoặc None
    - error_string: None nếu không lỗi
    """
    import io, contextlib

    stdout_buf = io.StringIO()
    result     = None
    error      = None

    # Thêm print override vào ctx để bắt output
    captured_lines = []
    original_print = ctx.get("print")

    def capture_print(*a, **k):
        captured_lines.append(" ".join(map(str, a)))
        if original_print:
            original_print(*a, **k)

    ctx = {**ctx, "print": capture_print}

    try:
        # Thử compile dạng eval (expression) trước
        try:
            compiled = compile(code, "<eval>", "eval")
            result   = eval(compiled, ctx)
        except SyntaxError:
            # Nếu là statement thì exec
            compiled = compile(code, "<exec>", "exec")
            exec(compiled, ctx)

        # Nếu print được gọi và không có return value → dùng captured output
        if result is None and captured_lines:
            result = "\n".join(captured_lines)

    except Exception:
        error = traceback.format_exc(limit=8)

    return result, error


# ─────────────────────────────────────────────
#  Chạy JavaScript (Node.js)
# ─────────────────────────────────────────────

def _js_run(code: str, timeout: int = 6):
    """Trả về (returncode, stdout, stderr)."""
    try:
        with tempfile.NamedTemporaryFile(suffix=".js", delete=False, mode="w", encoding="utf-8") as f:
            f.write(code)
            fname = f.name
        proc = subprocess.run(
            ["node", fname],
            capture_output=True, text=True, timeout=timeout
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 1, "", "Node.js chưa được cài trên server."
    except subprocess.TimeoutExpired:
        return 1, "", f"Timeout sau {timeout}s."
    except Exception as e:
        return 1, "", str(e)
    finally:
        try:
            os.unlink(fname)
        except Exception:
            pass


# ─────────────────────────────────────────────
#  Chạy C++ (g++)
# ─────────────────────────────────────────────

def _cpp_run(code: str, timeout: int = 12):
    """Trả về (returncode, stdout, stderr)."""
    src_file = out_file = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".cpp", delete=False, mode="w", encoding="utf-8") as f:
            f.write(code)
            src_file = f.name
        out_file = src_file.replace(".cpp", ".out")

        # Compile
        compile_proc = subprocess.run(
            ["g++", "-o", out_file, src_file, "-std=c++17"],
            capture_output=True, text=True, timeout=30
        )
        if compile_proc.returncode != 0:
            return compile_proc.returncode, "", compile_proc.stderr

        # Run
        run_proc = subprocess.run(
            [out_file],
            capture_output=True, text=True, timeout=timeout
        )
        return run_proc.returncode, run_proc.stdout, run_proc.stderr

    except FileNotFoundError:
        return 1, "", "g++ chưa được cài trên server."
    except subprocess.TimeoutExpired:
        return 1, "", f"Timeout sau {timeout}s."
    except Exception as e:
        return 1, "", str(e)
    finally:
        for p in [src_file, out_file]:
            if p:
                try:
                    os.unlink(p)
                except Exception:
                    pass


# ─────────────────────────────────────────────
#  Build context cho Python eval
# ─────────────────────────────────────────────

def _build_ctx(this, data, userId, threadId, type_, send_fn):
    return {
        "this":        this,
        "api":         this,
        "Message":     Message,
        "Mention":     Mention,
        "ThreadType":  ThreadType,
        "threadId":    threadId,
        "tid":         threadId,
        "type":        type_,
        "userId":      userId,
        "data":        data,
        "send":        lambda m: send_fn(_normalize(m)),
        "print":       lambda *a, **k: send_fn(" ".join(map(str, a))),
        "BuiltinType": builtins.type,
        "json":        json,
        "requests":    requests,
        "os":          os,
        "re":          re,
    }


# ─────────────────────────────────────────────
#  Lấy raw code từ tin nhắn
# ─────────────────────────────────────────────

def _get_raw_code(message, data) -> str:
    text     = (getattr(message, "text", "") or "").strip()
    quotemsg = (getattr(getattr(data, "quote", None), "msg", None) or "").strip()
    parts    = text.split(maxsplit=1)
    return parts[1].strip() if len(parts) > 1 else quotemsg


# ─────────────────────────────────────────────
#  Chạy eval theo ngôn ngữ
# ─────────────────────────────────────────────

def _run_eval(this, raw: str, ctx: dict, send_fn):
    lang, code = _dec_lang(raw)

    # ── Python ──────────────────────────────
    if lang == "py":
        res, err = _py_exec(code, ctx)
        if err:
            return send_fn("error:\n" + _normalize(_hide_path(err)))
        if res is not None:
            return send_fn(_normalize(res))
        return None

    # ── JavaScript / C++ ────────────────────
    try:
        if lang == "js":
            rc, out, err = _js_run(code, timeout=6)
        elif lang == "cpp":
            rc, out, err = _cpp_run(code, timeout=12)
        else:
            return send_fn(f"Ngôn ngữ '{lang}' chưa được hỗ trợ. Dùng: py | js | cpp")

        if err:
            return send_fn("error:\n" + _normalize(_hide_path(err)))
        return send_fn(_normalize(out if out else f"exit={rc}"))

    except Exception:
        return send_fn("error:\n" + _normalize(_hide_path(traceback.format_exc(limit=5))))


# ─────────────────────────────────────────────
#  Entry point lệnh
# ─────────────────────────────────────────────

def EvalCommand(self, message, data, userId, threadId, type):
    raw = _get_raw_code(message, data)
    if not raw:
        return self.replyMessageStyle(
            "Chưa có code để chạy.\n"
            "Cú pháp: eval <code>\n"
            "Hoặc reply vào tin nhắn chứa code.\n"
            "Hỗ trợ: py | js | cpp",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )

    def send_fn(m: str):
        return self.replyMessageStyle(
            str(m), data, threadId, type,
            color="gr", title="EVAL",
        )

    ctx = _build_ctx(self, data, userId, threadId, type, send_fn)
    return _run_eval(self, raw, ctx, send_fn)


# ─────────────────────────────────────────────
#  dependencies – bot tự load
# ─────────────────────────────────────────────

dependencies = {
    "name":        "eval",
    "description": "Chạy code Python / JS / C++ trực tiếp trong chat",
    "permission":  4,        # Developer only
    "cooldown":    5,
    "alias":       ["exec", "run"],
    "noPrefix":    False,
    "is_main":     False,
    "main":        EvalCommand,
}
