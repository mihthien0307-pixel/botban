"""
shotWebsite.py  –  Chụp ảnh màn hình website
Alias: shot / ss / web

Cách dùng:
  <prefix>shot <url>
  <prefix>shot <url> --full
  <prefix>shot <url> --w 1920 --h 1080
  <prefix>shot <url> --fmt jpeg
  <prefix>shot <url> --w 1440 --full --fmt png
"""

from app.core.index import *

import os
import time
import uuid
import threading
import requests

from io import BytesIO
from PIL import Image
from api.util.Enum import MsgStyle


# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────

CACHE_DIR = "assets/cache/image"
TIMEOUT   = 30      # giây
UA        = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


# ─────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────

def _ToInt(x, default):
    try:
        return int(x)
    except Exception:
        return default


def _NormalizeUrl(url: str) -> str:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def _GetImageSize(path: str):
    try:
        with Image.open(path) as im:
            return im.size
    except Exception:
        return None


def _PickUrl(parts: list[str]) -> str | None:
    """Tìm URL đầu tiên trong danh sách parts."""
    for x in parts:
        if "://" in x or (
            "." in x
            and not x.startswith("-")
            and not x.startswith("--")
        ):
            return x
    return None


def _SaveBytes(data: bytes, path: str, fmt: str) -> str:
    """Lưu raw bytes vào file, convert format nếu cần."""
    buf = BytesIO(data)
    with Image.open(buf) as im:
        rgb = im.convert("RGB") if fmt in ("jpeg", "webp") else im
        rgb.save(path)
    return path


# ─────────────────────────────────────────
# SCREENSHOT PROVIDERS (không cần API key)
# ─────────────────────────────────────────

def _TryThumb(url: str, width: int, height: int, full: bool, fmt: str) -> bytes | None:
    """
    image.thum.io — free, không cần key.
    Hỗ trợ: width, full-page.
    https://image.thum.io/get/[options]/URL
    """
    try:
        opts = f"width/{width}"
        if full:
            opts += "/fullpage"
        api  = f"https://image.thum.io/get/{opts}/{url}"
        r    = requests.get(api, headers={"User-Agent": UA}, timeout=TIMEOUT)
        if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
            return r.content
    except Exception:
        pass
    return None


def _TryMiniShot(url: str, width: int, height: int, full: bool, fmt: str) -> bytes | None:
    """
    mini.s-shot.ru — free, không cần key.
    https://mini.s-shot.ru/{width}x{height}/{width}/JPEG/?{url}
    """
    try:
        f    = "PNG" if fmt == "png" else "JPEG"
        api  = f"https://mini.s-shot.ru/{width}x{height}/{width}/{f}/?{url}"
        r    = requests.get(api, headers={"User-Agent": UA}, timeout=TIMEOUT)
        if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
            return r.content
    except Exception:
        pass
    return None


def _TryMicrolink(url: str, width: int, height: int, full: bool, fmt: str) -> bytes | None:
    """
    api.microlink.io — free tier, không cần key (rate-limited).
    https://api.microlink.io/?url=...&screenshot=true&meta=false&embed=screenshot.url
    """
    try:
        params = {
            "url":        url,
            "screenshot": "true",
            "meta":       "false",
            "embed":      "screenshot.url",
            "viewport.width":  width,
            "viewport.height": height,
        }
        if full:
            params["fullPage"] = "true"

        r = requests.get(
            "https://api.microlink.io/",
            params=params,
            headers={"User-Agent": UA},
            timeout=TIMEOUT,
        )
        data = r.json()
        img_url = (
            data.get("data", {}).get("screenshot", {}).get("url")
            or data.get("data", {}).get("image", {}).get("url")
        )
        if img_url:
            r2 = requests.get(img_url, headers={"User-Agent": UA}, timeout=TIMEOUT)
            if r2.status_code == 200:
                return r2.content
    except Exception:
        pass
    return None


def _TryScreenshotOne(url: str, width: int, height: int, full: bool, fmt: str) -> bytes | None:
    """
    screenshotone.com — free tier 100 req/month.
    https://api.screenshotone.com/take?url=...&viewport_width=...
    """
    try:
        params = {
            "url":            url,
            "viewport_width":  width,
            "viewport_height": height,
            "format":          fmt if fmt in ("png", "jpeg", "webp") else "png",
            "full_page":       "true" if full else "false",
            "block_ads":       "true",
            "block_cookie_banners": "true",
            "delay":           "2",
        }
        r = requests.get(
            "https://api.screenshotone.com/take",
            params=params,
            headers={"User-Agent": UA},
            timeout=TIMEOUT,
        )
        if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
            return r.content
    except Exception:
        pass
    return None


# Provider chain: thử lần lượt đến khi có kết quả
_PROVIDERS = [
    ("Thum.io",        _TryThumb),
    ("s-shot.ru",      _TryMiniShot),
    ("Microlink",      _TryMicrolink),
    ("ScreenshotOne",  _TryScreenshotOne),
]


def _TakeScreenshot(url: str, width: int, height: int, full: bool, fmt: str) -> bytes:
    """
    Thử từng provider theo thứ tự.
    Raise RuntimeError nếu tất cả thất bại.
    """
    errors = []
    for name, fn in _PROVIDERS:
        try:
            result = fn(url, width, height, full, fmt)
            if result and len(result) > 1024:   # bỏ qua ảnh rỗng / lỗi nhỏ
                logger.info(f"[shot] {name} OK cho {url}")
                return result
        except Exception as e:
            errors.append(f"{name}: {e}")

    raise RuntimeError(
        "Tất cả provider đều thất bại:\n" + "\n".join(errors)
    )


# ─────────────────────────────────────────
# MAIN COMMAND
# ─────────────────────────────────────────

def screenshotWebsiteCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    parts = text.split()
    name  = self.userName(userId)

    # ── thiếu URL ────────────────────────────────────────────────────────────
    if len(parts) < 2:
        return self.sendWarning(
            f"Dùng: {self.prefix}shot <url> [tuỳ chọn]\n"
            f"Tuỳ chọn:\n"
            f"  --full          Chụp toàn trang\n"
            f"  --w <số>        Độ rộng (mặc định 1366)\n"
            f"  --h <số>        Chiều cao (mặc định 768)\n"
            f"  --fmt png|jpeg  Định dạng ảnh\n"
            f"Ví dụ: {self.prefix}shot google.com --w 1920 --full",
            threadId, type, data,
        )

    # ── parse args ────────────────────────────────────────────────────────────
    full    = False
    width   = 1366
    height  = 768
    fmt     = "png"

    url_raw = _PickUrl(parts[1:])
    if not url_raw:
        return self.sendWarning("Không tìm thấy URL hợp lệ.", threadId, type, data)

    i = 1
    while i < len(parts):
        a = parts[i].lower()
        if a in ("--full", "-f"):
            full = True
            i += 1
        elif a in ("--w", "--width") and i + 1 < len(parts):
            width = _ToInt(parts[i + 1], width)
            i += 2
        elif a in ("--h", "--height") and i + 1 < len(parts):
            height = _ToInt(parts[i + 1], height)
            i += 2
        elif a in ("--fmt", "--format") and i + 1 < len(parts):
            fmt = parts[i + 1].lower().replace("jpg", "jpeg")
            i += 2
        else:
            i += 1

    if fmt not in ("png", "jpeg", "webp"):
        fmt = "png"

    ext     = "jpg" if fmt == "jpeg" else fmt
    url     = _NormalizeUrl(url_raw)
    outPath = os.path.join(
        CACHE_DIR,
        f"shot_{int(time.time())}_{uuid.uuid4().hex[:8]}.{ext}"
    )

    # ── thực thi trong thread riêng ───────────────────────────────────────────
    def _run():
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)

            self.sendReaction(data, "📷", threadId, type, 100000000)

            img_bytes = _TakeScreenshot(url, width, height, full, fmt)

            _SaveBytes(img_bytes, outPath, fmt)

            size = _GetImageSize(outPath)
            w, h = size if size else (width, height)

            mention = Mention(userId, offset=0, length=len(name))
            caption = Message(
                text    = f"{name}\n🌐 {url}",
                mention = mention,
            )

            self.sendLocalImage(
                outPath, threadId, type,
                width   = w,
                height  = h,
                message = caption,
            )

        except Exception as e:
            logger.error(f"[shot] Error: {e}")
            self.sendError(
                f"Chụp thất bại: {str(e)[:200]}",
                threadId, type, data,
            )
        finally:
            try:
                if os.path.exists(outPath):
                    os.remove(outPath)
            except Exception:
                pass

    threading.Thread(target=_run, daemon=True).start()

    self.sendInfo(
        f"{name}\n"
        f"🔍 Đang chụp: {url}\n"
        f"📐 {width}×{height}{'  |  Full page' if full else ''}  |  {fmt.upper()}",
        threadId, type, data,
    )


# ─────────────────────────────────────────
# DEPENDENCIES
# ─────────────────────────────────────────

dependencies = {
    "name":        "shot",
    "permission":  0,
    "description": "Chụp ảnh màn hình website",
    "cooldown":    8,
    "alias":       ["ss", "screenshot", "web"],
    "main":        screenshotWebsiteCommand,
}
