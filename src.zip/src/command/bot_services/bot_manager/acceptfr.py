# src/command/bot_services/acceptfr.py
from app.core.index import *
import threading
import time
import json as _json
import os

_auto_running = {}
_auto_threads = {}
_muted_users  = {}

# ── Persist path (giống mutegroup) ────────────────────────────────────────
_BASE_DIR   = os.path.join("data", "cache", "acceptfr")
os.makedirs(_BASE_DIR, exist_ok=True)

def _status_path(bot_uid: str) -> str:
    return os.path.join(_BASE_DIR, f"autofr_{bot_uid}.json")

def _load_status(bot_uid: str) -> bool:
    try:
        with open(_status_path(bot_uid), "r", encoding="utf-8") as f:
            return _json.load(f).get("enabled", False)
    except Exception:
        return False

def _save_status(bot_uid: str, enabled: bool):
    try:
        with open(_status_path(bot_uid), "w", encoding="utf-8") as f:
            _json.dump({"enabled": enabled}, f)
    except Exception:
        pass

# ── onLoad: khởi động lại auto nếu đã bật trước đó ──────────────────────
def _on_load(bot):
    bot_uid = str(bot.uid)
    if _load_status(bot_uid):
        _auto_running[bot_uid] = True
        t = threading.Thread(target=_auto_worker, args=(bot, bot_uid), daemon=True)
        _auto_threads[bot_uid] = t
        t.start()

# ─────────────────────────────────────────────────────────────────────────

def _get_items(bot, raw):
    if not raw:
        return []
    decoded = raw
    try:
        decoded = bot._decode(raw)
    except Exception:
        pass
    if isinstance(decoded, str):
        try:
            decoded = _json.loads(decoded)
        except Exception:
            return []
    if not isinstance(decoded, dict):
        return []
    if "error_code" in decoded:
        decoded = decoded.get("data") or {}
    if not isinstance(decoded, dict):
        return []

    results = []
    for item in decoded.get("recommItems", []):
        if not isinstance(item, dict):
            continue
        if item.get("recommItemType") != 1:
            continue
        info = item.get("dataInfo", {})
        uid  = str(info.get("userId") or info.get("uid") or "")
        name = info.get("zaloName") or info.get("displayName") or uid
        if uid:
            results.append({"uid": uid, "name": name})
    return results


def _auto_worker(bot, bot_uid):
    while _auto_running.get(bot_uid, False):
        try:
            raw   = bot.listFriendRequests()
            items = _get_items(bot, raw)
            muted = _muted_users.get(bot_uid, set())
            for item in items:
                if item["uid"] in muted:
                    continue
                try:
                    bot.acceptFriendRequest(item["uid"])
                    time.sleep(0.8)
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(30)


def run(self, message, data, userId, threadId, thread_type):
    bot_uid  = str(self.uid)
    msg_text = (message.text if isinstance(message, Message) else str(message or "")).strip()
    args     = msg_text.split()
    sub     = args[1].lower() if len(args) > 1 else ""

    # ── acceptfr all ──────────────────────────────────────────────────────
    if sub == "all":
        try:
            raw   = self.listFriendRequests()
            items = _get_items(self, raw)
        except Exception as e:
            self.replyMessageStyle(f"Lỗi: {e}", data, threadId, thread_type, color="r", title="LỖI", userId=userId)
            return

        if not items:
            self.replyMessageStyle("Không có lời mời kết bạn nào.", data, threadId, thread_type, color="yl", title="THÔNG BÁO", userId=userId)
            return

        accepted = 0
        for item in items:
            try:
                self.acceptFriendRequest(item["uid"])
                accepted += 1
                time.sleep(0.8)
            except Exception:
                pass

        self.replyMessageStyle(
            f"Đã chấp nhận {accepted}/{len(items)} lời mời kết bạn!",
            data, threadId, thread_type, color="gr", title="THÀNH CÔNG", userId=userId
        )

    # ── acceptfr list ─────────────────────────────────────────────────────
    elif sub == "list":
        try:
            raw   = self.listFriendRequests()
            items = _get_items(self, raw)
        except Exception as e:
            self.replyMessageStyle(f"Lỗi: {e}", data, threadId, thread_type, color="r", title="LỖI", userId=userId)
            return

        if not items:
            self.replyMessageStyle("Không có lời mời kết bạn nào.", data, threadId, thread_type, color="yl", title="THÔNG BÁO", userId=userId)
            return

        lines = [f"Có {len(items)} lời mời kết bạn đang chờ:\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"• {i}. {item['name']}")

        self.replyMessageStyle(
            "\n".join(lines),
            data, threadId, thread_type, color="gr", title="DANH SÁCH", userId=userId
        )

    # ── acceptfr auto on/off ──────────────────────────────────────────────
    elif sub == "auto":
        action = args[2].lower() if len(args) > 2 else ""

        if action == "on":
            if _auto_running.get(bot_uid):
                self.replyMessageStyle("Auto KB đang chạy rồi.", data, threadId, thread_type, color="yl", title="CẢNH BÁO", userId=userId)
                return
            _auto_running[bot_uid] = True
            _save_status(bot_uid, True)
            t = threading.Thread(target=_auto_worker, args=(self, bot_uid), daemon=True)
            _auto_threads[bot_uid] = t
            t.start()
            self.replyMessageStyle(
                "Đã bật Auto KB!\nBot tự động chấp nhận lời mời kết bạn mỗi 30 giây.\n✅ Trạng thái đã được lưu, restart bot vẫn bật.",
                data, threadId, thread_type, color="gr", title="THÀNH CÔNG", userId=userId
            )

        elif action == "off":
            if not _auto_running.get(bot_uid):
                self.replyMessageStyle("Auto KB chưa được bật.", data, threadId, thread_type, color="yl", title="CẢNH BÁO", userId=userId)
                return
            _auto_running[bot_uid] = False
            _save_status(bot_uid, False)
            self.replyMessageStyle("Đã tắt Auto KB.\n✅ Trạng thái đã được lưu.", data, threadId, thread_type, color="gr", title="THÀNH CÔNG", userId=userId)

        else:
            status = "🟢 BẬT" if _auto_running.get(bot_uid) else "🔴 TẮT"
            self.replyMessageStyle(
                f"Trạng thái Auto KB: {status}\nDùng {self.prefix}acceptfr auto on/off để bật/tắt.",
                data, threadId, thread_type, color="gr", title="THÔNG BÁO", userId=userId
            )

    # ── acceptfr unmute -1 ────────────────────────────────────────────────
    elif sub == "unmute":
        pos_str = args[2] if len(args) > 2 else ""
        try:
            pos = int(pos_str)
            if pos >= 0:
                raise ValueError
        except ValueError:
            self.replyMessageStyle(
                f"Dùng: {self.prefix}acceptfr unmute -1  (vị trí âm theo danh sách list)",
                data, threadId, thread_type, color="r", title="LỖI", userId=userId
            )
            return

        try:
            raw   = self.listFriendRequests()
            items = _get_items(self, raw)
        except Exception as e:
            self.replyMessageStyle(f"Lỗi: {e}", data, threadId, thread_type, color="r", title="LỖI", userId=userId)
            return

        if not items:
            self.replyMessageStyle("Danh sách lời mời đang trống.", data, threadId, thread_type, color="yl", title="THÔNG BÁO", userId=userId)
            return

        try:
            target = items[pos]
        except IndexError:
            self.replyMessageStyle(
                f"Vị trí {pos} không hợp lệ. Hiện có {len(items)} lời mời.",
                data, threadId, thread_type, color="r", title="LỖI", userId=userId
            )
            return

        if bot_uid not in _muted_users:
            _muted_users[bot_uid] = set()
        _muted_users[bot_uid].add(target["uid"])

        self.replyMessageStyle(
            f"Đã bỏ qua lời mời từ {target['name']}.\nBot sẽ không tự KB người này.",
            data, threadId, thread_type, color="gr", title="THÀNH CÔNG", userId=userId
        )

    # ── Help ──────────────────────────────────────────────────────────────
    else:
        auto_status = "🟢 BẬT" if _auto_running.get(bot_uid) else "🔴 TẮT"
        self.replyMessageStyle(
            f"Các lệnh acceptfr:\n"
            f"• {self.prefix}acceptfr all         — Chấp nhận KB tất cả\n"
            f"• {self.prefix}acceptfr list        — Xem danh sách lời mời\n"
            f"• {self.prefix}acceptfr auto on/off — Bật/tắt tự động KB\n"
            f"• {self.prefix}acceptfr unmute -1   — Bỏ qua người cuối list\n"
            f"Auto KB: {auto_status}",
            data, threadId, thread_type,
            color="gr",
            title="HƯỚNG DẪN",
            userId=userId,
        )


dependencies = {
    "name":        "acceptfr",
    "description": "Quản lý lời mời kết bạn: xem danh sách, chấp nhận all, auto KB",
    "permission":  2,
    "cooldown":    5,
    "alias":       [],
    "noPrefix":    False,
    "is_main":     False,
    "onLoad":      _on_load,
    "main":        run,
}
