from app.core.index import *

_ANTI_KEYS = [
    ("antiBot",     "Anti Bot"),
    ("antiForward", "Anti Forward"),
    ("antiSpam",    "Anti Spam"),
    ("antiUrl",     "Anti URL"),
]

def antiStatusCommand(self, message, data, userId, threadId, type):
    try:
        settings = read_settings(self.uid)

        lines = ["Anti Status thread now\n"]
        for key, label in _ANTI_KEYS:
            thread_list = settings.get(key, [])
            state = "On" if threadId in thread_list else "Off"
            lines.append(f"   - {label:<16} {state}")

        self.replyMessageStyle(
            "\n".join(lines),
            data, threadId, type,
            color="yl", title="ANTI STATUS", userId=userId,
        )

    except Exception as e:
        logger.error(f"antiStatus error: {e}")
        self.replyMessageStyle(
            "Loi khi doc cai dat anti.",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

dependencies = {
    "name":        "antistatus",
    "description": "Xem trang thai cac loai anti trong thread",
    "permission":  2,
    "cooldown":    3,
    "status":      True,
    "main":        antiStatusCommand,
}