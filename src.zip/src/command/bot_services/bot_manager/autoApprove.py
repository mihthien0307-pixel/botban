"""
autoApprove.py – Ported from ztf → zbot
Vị trí gợi ý: src/command/bot_services/bot_manager/autoApprove.py
"""
from app.core.index import *
import threading
import time

# ──────────────────────────────────────────────
# Background loop – tự động duyệt pending members
# ──────────────────────────────────────────────
def _init_auto_approve_loop(self):
    """Khởi động vòng lặp nền, gọi 1 lần khi bot start."""
    if getattr(self, "_approveLoopStarted", False):
        return
    self._approveLoopStarted = True

    def loop():
        while True:
            try:
                settings = read_settings(self.uid)
                groups   = settings.get("approveGroup", [])
                for groupId in groups:
                    try:
                        pendings = self.viewGroupPending(groupId)
                        if not pendings or not pendings.users:
                            continue
                        for u in pendings.users:
                            try:
                                self.handleGroupPending(u.uid, groupId, True)
                            except Exception:
                                pass
                    except Exception:
                        pass
            except Exception:
                pass
            time.sleep(3)

    threading.Thread(target=loop, daemon=True).start()


# ──────────────────────────────────────────────
# Command handler
# ──────────────────────────────────────────────
def approveCommand(self, message, data, userId, threadId, type):
    parts    = (message.text or "").strip().split()
    settings = read_settings(self.uid)
    approve  = settings.setdefault("approveGroup", [])
    enabled  = threadId in approve

    if len(parts) < 2:
        enabled = not enabled
    else:
        action = parts[1].lower()
        if action == "on":
            enabled = True
        elif action == "off":
            enabled = False
        else:
            self.replyMessageStyle(
                f"Dùng: {self.prefix}{self.rawCommand} on/off",
                data, threadId, type,
                color="yl", title="USAGE",
            )
            return

    if enabled and threadId not in approve:
        approve.append(threadId)
    if not enabled and threadId in approve:
        approve.remove(threadId)

    settings["approveGroup"] = approve
    write_settings(self.uid, settings)

    status = "bật" if enabled else "tắt"
    self.replyMessageStyle(
        f"Auto Approve nhóm đã được {status}.",
        data, threadId, type,
        color="gr" if enabled else "yl",
        title="APPROVE",
    )

    # Khởi động loop nếu chưa chạy
    if enabled:
        _init_auto_approve_loop(self)


dependencies = {
    "name":        "approve",
    "permission":  2,
    "description": "Tự động duyệt thành viên vào nhóm",
    "cooldown":    5,
    "status":      True,
    "main":        approveCommand,
}
