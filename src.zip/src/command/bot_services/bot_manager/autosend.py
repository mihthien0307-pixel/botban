from app.core.index import *
from src.services.utils.jsonio import read_settings, write_settings
from src.services.browserAPI.zingmp3Api import chart_home, get_top100, get_stream, search_songv2
from src.services.browserAPI.soundcloudApi import search_song as sc_search, download as sc_download
from src.services.pillow.zingCard import draw_zing_card
from src.services.pillow.soundcloudCard import draw_soundcloud_card

import os, uuid, time, threading, random, asyncio, requests, re
from datetime import datetime

PLAT_ZING = "zing"
PLAT_SC   = "sc"
_MIN_GAP  = 180 * 60

_CAPTIONS = [
    "Một giai điệu đúng lúc có thể thay đổi cả một ngày dài. 🎵",
    "Âm nhạc là ngôn ngữ mà cảm xúc dùng để nói chuyện với trái tim. 🎶",
    "Có những điều lời nói không chạm tới được — nhưng âm nhạc thì có. 🎼",
    "Cuộc đời không có nhạc nền sẽ chỉ là một bộ phim câm. 🎹",
    "Hãy để âm thanh dẫn đường khi con tim lạc lối. 🎷",
    "Mỗi bài hát là một cuốn nhật ký không cần chữ viết. 🎸",
    "Âm nhạc chữa lành những vết thương mà thời gian chưa kịp xoa dịu. 🎻",
    "Khi mọi thứ trở nên ồn ào, hãy để âm nhạc làm tất cả lặng xuống. 🌙",
    "Không cần lý do — đôi khi chỉ cần một bài hay là đủ. ☕",
    "Âm nhạc không hỏi bạn đang ổn không — nó chỉ ở đó cùng bạn. 🌿",
    "Một ngày bình thường, một bài nhạc hay — đủ rồi. 🌤️",
    "Nghe đi, đừng nghĩ nhiều. 🎧",
]

_ZING_KEYWORDS = [
    "nhạc chill buổi tối", "vpop hit 2025", "rap việt trending",
    "nhạc buồn tâm trạng", "ballad việt hay nhất", "nhạc indie việt 2025",
    "edm việt remix hot", "nhạc khuya tâm trạng", "bài hát đang viral 2025",
]

_SC_KEYWORDS = [
    "lofi chill", "phonk trending", "indie pop 2025", "r&b chill",
    "jazz cafe", "sad vibes", "night drive music", "study beats", "ambient relax",
]


def _caption() -> str:
    return random.choice(_CAPTIONS)


def _all_groups(self) -> list:
    try:
        grid = getattr(self.fetchAllGroups(), "gridVerMap", None) or {}
        return [str(g) for g in (grid if isinstance(grid, dict) else dict(grid)).keys()]
    except Exception:
        return []


def _read_cfg(uid: str) -> dict:
    s = read_settings(uid) or {}
    as_ = s.setdefault("autosend", {})
    as_.setdefault(PLAT_ZING, {"on": False, "times": [], "lastSent": None})
    as_.setdefault(PLAT_SC,   {"on": False, "times": [], "lastSent": None})
    return s


def _stamp(uid: str, plat: str):
    s = read_settings(uid) or {}
    s.setdefault("autosend", {}).setdefault(plat, {})["lastSent"] = time.time()
    write_settings(uid, s)


def _conflict(uid: str, plat: str) -> str | None:
    s     = read_settings(uid) or {}
    other = PLAT_SC if plat == PLAT_ZING else PLAT_ZING
    last  = (s.get("autosend", {}).get(other) or {}).get("lastSent")
    if not last:
        return None
    elapsed = time.time() - last
    if elapsed < _MIN_GAP:
        remain     = int((_MIN_GAP - elapsed) / 60)
        other_name = "ZingMP3" if other == PLAT_ZING else "SoundCloud"
        return (
            f"Bot vừa gửi nhạc từ {other_name} cách đây {int(elapsed / 60)} phút.\n"
            f"Vui lòng chờ thêm ~{remain} phút để tránh spam nhạc."
        )
    return None


def _download_file(url: str) -> str:
    os.makedirs("data/assets/cache/voice", exist_ok=True)
    path = f"data/assets/cache/voice/{uuid.uuid4().hex}.mp3"
    with requests.get(url, stream=True, timeout=30) as r:
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(8192):
                if chunk:
                    f.write(chunk)
    return path


def _upload_card(self, draw_fn, song_info: dict, thread_id, thread_type) -> str | None:
    os.makedirs("data/assets/cache/cards", exist_ok=True)
    card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
    try:
        draw_fn(song_info, card_path)
        res = self._uploadImage(card_path, thread_id, thread_type)
        if isinstance(res, dict):
            return res.get("normalUrl") or res.get("hdUrl")
        if isinstance(res, str) and res.startswith("http"):
            return res
    except Exception as e:
        print(f"[AutoSend] card error: {e}")
    finally:
        try: os.remove(card_path)
        except Exception: pass
    return None


def _send_music(self, image_url: str | None, file_url: str, thread_id, thread_type,
                img_w=2048, img_h=622):
    cap = _caption()
    if image_url:
        self.sendRemoteImage(
            image_url, thread_id, thread_type,
            width=img_w, height=img_h,
            message=Message(text=cap),
        )
    else:
        self.send(Message(text=cap), thread_id, thread_type)
    time.sleep(0.3)
    self.sendRemoteVoice(file_url, thread_id, thread_type)


def _zing_send(self, song: dict, thread_id: str, thread_type) -> bool:
    from app.module.utils import MediaCache
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    sid = song["id"]
    cache = self.MediaCache.get("zing_autosend", sid)
    file_url = None

    if cache:
        file_url = cache.get("fileUrl")
        if not (file_url and self.MediaCache.isAlive(file_url)):
            self.MediaCache.remove("zing_autosend", sid)
            file_url = None

    if not file_url:
        stream = get_stream(sid)
        if not stream or "data" not in stream:
            return False
        d = stream["data"]
        stream_url = d.get("320") or d.get("128")
        if not stream_url or stream_url == "VIP":
            stream_url = d.get("128")
        if not stream_url:
            return False
        fp = None
        try:
            fp = _download_file(stream_url)
            upload = asyncio.run(self._uploadAttachmentAsync(fp, thread_id, thread_type))
        finally:
            if fp and os.path.exists(fp):
                try: os.remove(fp)
                except Exception: pass
        file_url = upload.get("fileUrl")
        if not file_url:
            return False
        self.MediaCache.set("zing_autosend", sid, song, file_url)

    image_url = _upload_card(self, draw_zing_card, {
        "cover": song.get("cover", ""), "title": song.get("title", ""),
        "artist": song.get("artist", ""), "duration": song.get("duration", 0),
    }, thread_id, thread_type)

    try:
        _send_music(self, image_url, file_url, thread_id, thread_type, img_w=2048, img_h=622)
    except Exception as e:
        print(f"[AutoSend-Zing] send error: {e}")
        return False
    return True


def _sc_send(self, song: dict, thread_id: str, thread_type) -> bool:
    from app.module.utils import MediaCache
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    sid = str(song["id"])
    cache = self.MediaCache.get("sc_autosend", sid)
    file_url = None

    if cache:
        file_url = cache.get("fileUrl")
        if not (file_url and self.MediaCache.isAlive(file_url)):
            self.MediaCache.remove("sc_autosend", sid)
            file_url = None

    if not file_url:
        fp = None
        try:
            fp = sc_download(song)
            if not fp:
                return False
            upload = asyncio.run(self._uploadAttachmentAsync(fp, thread_id, thread_type))
        finally:
            if fp and os.path.exists(fp):
                try: os.remove(fp)
                except Exception: pass
        file_url = upload.get("fileUrl")
        if not file_url:
            return False
        self.MediaCache.set("sc_autosend", sid, song, file_url)

    image_url = _upload_card(self, draw_soundcloud_card, {
        "cover": song.get("thumb") or song.get("thumb2") or "",
        "title": song.get("title", ""), "artist": song.get("artist", ""),
        "duration": song.get("duration", 0),
    }, thread_id, thread_type)

    try:
        _send_music(self, image_url, file_url, thread_id, thread_type, img_w=2048, img_h=622)
    except Exception as e:
        print(f"[AutoSend-SC] send error: {e}")
        return False
    return True


def _zing_pick() -> dict | None:
    try:
        data  = chart_home()
        items = (((data.get("data") or {}).get("RTChart") or {}).get("items") or [])
        if not items:
            items = get_top100().get("data") or []
        titles = [
            f"{it['title']} {it.get('artistsNames', '')}".strip()
            for it in items[:20] if isinstance(it, dict) and it.get("title")
        ]
        keyword = random.choice(titles) if titles else random.choice(_ZING_KEYWORDS)
    except Exception:
        keyword = random.choice(_ZING_KEYWORDS)

    res = search_songv2(keyword)
    if not res or res.get("err") != 0:
        return None
    songs = [
        {
            "id":       s.get("encodeId"),
            "title":    s.get("title"),
            "artist":   s.get("artistsNames", "Unknown"),
            "duration": s.get("duration", 0),
            "cover":    s.get("thumbnailM") or s.get("thumbnail") or "",
        }
        for s in (res.get("data") or {}).get("songs") or []
        if s.get("streamingStatus") == 1
    ]
    return random.choice(songs[:10]) if songs else None


def _sc_pick() -> dict | None:
    songs = sc_search(random.choice(_SC_KEYWORDS), limit=10)
    return random.choice(songs[:10]) if songs else None


def _broadcast(self, pick_fn, send_fn, plat: str):
    song = pick_fn()
    if not song:
        return
    for gid in _all_groups(self):
        try:
            send_fn(self, song, gid, ThreadType.GROUP)
            time.sleep(1.5)
        except Exception as e:
            print(f"[AutoSend-{plat}] gid={gid} err: {e}")


def _autosend_worker(self):
    while True:
        time.sleep(1)
        s      = read_settings(self.uid) or {}
        as_    = s.get("autosend", {})
        now_hm = datetime.now().strftime("%H:%M")

        for plat, pick_fn, send_fn in (
            (PLAT_ZING, _zing_pick, _zing_send),
            (PLAT_SC,   _sc_pick,   _sc_send),
        ):
            cfg = as_.get(plat, {})
            if not cfg.get("on") or now_hm not in (cfg.get("times") or []):
                continue
            attr = f"_as_{plat}_last"
            key  = datetime.now().strftime("%Y%m%d") + "|" + now_hm
            if getattr(self, attr, "") == key:
                continue
            setattr(self, attr, key)
            if _conflict(self.uid, plat):
                continue
            try:
                _broadcast(self, pick_fn, send_fn, plat)
                _stamp(self.uid, plat)
            except Exception as e:
                print(f"[AutoSend-{plat}] worker err: {e}")


def _start_worker(self):
    t = getattr(self, "_autosendThread", None)
    if t and t.is_alive():
        return
    self._autosendThread = threading.Thread(target=_autosend_worker, args=(self,), daemon=True)
    self._autosendThread.start()


def _parse_times(raw: str) -> list:
    seen, out = set(), []
    for chunk in re.sub(r"[;|,]", " ", raw).split():
        if ":" not in chunk:
            continue
        hh, mm = chunk.split(":", 1)
        if hh.isdigit() and mm.isdigit() and 0 <= int(hh) <= 23 and 0 <= int(mm) <= 59:
            t = f"{int(hh):02d}:{int(mm):02d}"
            if t not in seen:
                seen.add(t)
                out.append(t)
    return out


def _parse_args(tokens: list) -> dict:
    result = {}
    for m in re.finditer(r"-(\w+)=([^\s]+)", " ".join(tokens)):
        result[m.group(1).lower()] = m.group(2)
    return result


def _help_text(p: str, c: str) -> str:
    return (
        f"Auto Send Music\n"
        f"\n"
        f"Cú pháp:  {p}{c} -<tham số>=<giá trị>\n"
        f"\n"
        f"  Tham số\n"
        f"  ├─ -plat     Nguồn nhạc         zing | sc\n"
        f"  ├─ -action   Hành động           on | off | init | preview\n"
        f"  ├─ -time     Thêm giờ gửi        HH:MM  hoặc  HH:MM,HH:MM,...\n"
        f"  └─ -deltime  Xoá giờ gửi         HH:MM  hoặc  HH:MM,HH:MM,...\n"
        f"\n"
        f"  Ví dụ\n"
        f"  ├─ {p}{c} -plat=zing -action=on\n"
        f"  ├─ {p}{c} -plat=sc   -action=off\n"
        f"  ├─ {p}{c} -plat=zing -time=07:00,20:00\n"
        f"  ├─ {p}{c} -plat=sc   -deltime=12:00\n"
        f"  ├─ {p}{c} -plat=zing -action=init       → gửi tới tất cả nhóm\n"
        f"  ├─ {p}{c} -plat=sc   -action=preview    → gửi thử nhóm hiện tại\n"
        f"  └─ {p}{c} status\n"
        f"\n"
        f"  Lưu ý\n"
        f"  └─ Khi lịch tự động gửi, nếu nguồn kia đã gửi trong vòng 180 phút\n"
        f"     thì bỏ qua lượt đó để tránh spam. Lệnh thủ công (init/preview)\n"
        f"     không bị giới hạn thời gian này."
    )


def _status_text(uid: str) -> str:
    s   = read_settings(uid) or {}
    as_ = s.get("autosend", {})

    def fmt(key, label):
        cfg  = as_.get(key, {})
        on   = "✅ Bật" if cfg.get("on") else "❌ Tắt"
        ts   = ", ".join(sorted(cfg.get("times") or [])) or "Chưa đặt"
        last = cfg.get("lastSent")
        l    = datetime.fromtimestamp(last).strftime("%H:%M  %d/%m/%Y") if last else "Chưa gửi"
        return f"  {label}\n  ├─ Trạng thái  : {on}\n  ├─ Giờ gửi     : {ts}\n  └─ Lần cuối    : {l}"

    return f"Autosend Status\n\n{fmt(PLAT_ZING, 'ZingMP3')}\n\n{fmt(PLAT_SC, 'SoundCloud')}"


def AutoSendCommand(self, message, data, userId, threadId, type):
    from api.util.Enum import ThreadType as _TT

    parts = (message.text or "").strip().split()
    p, c  = self.prefix, self.rawCommand

    def ok(text):   self.replyMessageStyle(text, data, threadId, type, color="gr", title="AUTOSEND", userId=userId)
    def warn(text): self.replyMessageStyle(text, data, threadId, type, color="yl", title="AUTOSEND", userId=userId)
    def err(text):  self.replyMessageStyle(text, data, threadId, type, color="r",  title="AUTOSEND", userId=userId)

    if len(parts) < 2:
        return warn(_help_text(p, c))

    sub = parts[1].lower()

    if sub in ("status", "info"):
        return ok(_status_text(self.uid))
    if sub in ("help", "h", "?"):
        return warn(_help_text(p, c))

    args   = _parse_args(parts[1:])
    plat   = args.get("plat", "").lower()
    action = args.get("action", "").lower()

    if not args:
        return warn(_help_text(p, c))

    if plat and plat not in (PLAT_ZING, PLAT_SC):
        return err(f"Plat không hợp lệ: '{plat}'\nChỉ nhận: zing | sc")

    plat_name = "ZingMP3" if plat == PLAT_ZING else "SoundCloud"

    if action in ("on", "off"):
        if not plat:
            return err("Thiếu -plat=zing hoặc -plat=sc")
        s = _read_cfg(self.uid)
        s["autosend"][plat]["on"] = (action == "on")
        write_settings(self.uid, s)
        if action == "on":
            _start_worker(self)
        hint = f"\nDùng {p}{c} -plat={plat} -time=HH:MM để đặt lịch." if action == "on" else ""
        return ok(f"AutoSend {plat_name} {'đã bật ✅' if action == 'on' else 'đã tắt ❌'}.{hint}")

    if "time" in args:
        if not plat:
            return err("Thiếu -plat=zing hoặc -plat=sc")
        times = _parse_times(args["time"])
        if not times:
            return err("Không đọc được giờ.\nDùng định dạng HH:MM, ví dụ: -time=07:00,20:00")
        s   = _read_cfg(self.uid)
        cur = set(s["autosend"][plat].get("times") or [])
        cur.update(times)
        s["autosend"][plat]["times"] = sorted(cur)
        write_settings(self.uid, s)
        _start_worker(self)
        return ok(f"Đã thêm giờ gửi cho {plat_name}.\nLịch hiện tại: {', '.join(sorted(cur))}")

    if "deltime" in args:
        if not plat:
            return err("Thiếu -plat=zing hoặc -plat=sc")
        to_del = _parse_times(args["deltime"])
        if not to_del:
            return err("Không đọc được giờ cần xoá.")
        s   = _read_cfg(self.uid)
        cur = set(s["autosend"][plat].get("times") or [])
        removed = [t for t in to_del if t in cur]
        cur -= set(to_del)
        s["autosend"][plat]["times"] = sorted(cur)
        write_settings(self.uid, s)
        if not removed:
            return warn(f"Không tìm thấy {', '.join(to_del)} trong lịch.")
        remain = ', '.join(sorted(cur)) or 'trống'
        return ok(f"Đã xoá: {', '.join(removed)}\nLịch còn lại: {remain}")

    if action == "init":
        if not plat:
            return err("Thiếu -plat=zing hoặc -plat=sc")
        pick_fn = _zing_pick if plat == PLAT_ZING else _sc_pick
        send_fn = _zing_send if plat == PLAT_ZING else _sc_send
        ok(f"Đang gửi nhạc {plat_name} tới tất cả nhóm…")
        def _run():
            _broadcast(self, pick_fn, send_fn, plat)
            _stamp(self.uid, plat)
        threading.Thread(target=_run, daemon=True).start()
        return

    if action == "preview":
        if not plat:
            return err("Thiếu -plat=zing hoặc -plat=sc")
        if type == _TT.USER:
            return warn("Lệnh này chỉ dùng được trong nhóm.")
        pick_fn = _zing_pick if plat == PLAT_ZING else _sc_pick
        send_fn = _zing_send if plat == PLAT_ZING else _sc_send
        ok(f"Đang tải và gửi nhạc {plat_name} vào nhóm này…")
        def _run():
            song = pick_fn()
            if not song:
                return err("Không tìm được bài.")
            send_fn(self, song, str(threadId), type)
            _stamp(self.uid, plat)
        threading.Thread(target=_run, daemon=True).start()
        return

    return warn(_help_text(p, c))


def InitAutoSend(self):
    s   = read_settings(self.uid) or {}
    as_ = s.get("autosend", {})
    if (as_.get(PLAT_ZING) or {}).get("on") or (as_.get(PLAT_SC) or {}).get("on"):
        _start_worker(self)


dependencies = {
    "name":        "autosend",
    "permission":  3,
    "cooldown":    3,
    "description": "Auto gửi nhạc ZingMP3 / SoundCloud theo lịch đến tất cả nhóm",
    "main":        AutoSendCommand,
    "onLoad":      InitAutoSend,
}
