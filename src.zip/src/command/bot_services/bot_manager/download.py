"""
download.py  –  Lệnh download video / audio cho zBot
Đặt file này vào:  zBot/src/command/bot_services/download.py
"""

import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.core.index import *
from src.command.bot_services.download_core import (
    process_single_link,
    get_platform_info,
    MAX_WORKERS,
)

URL_RE = re.compile(r"https?://\S+", re.I)


# ── Auto-download state ────────────────────────────────────────────────────────

def _read_dl_auto(self, thread_id: str) -> bool:
    from src.services.utils.jsonio import load_json
    data = load_json(f"data/config/bot/Data-{self.uid}.json", {})
    return str(thread_id) in data.get("dlAuto", [])


def _write_dl_auto(self, thread_id: str, enabled: bool) -> bool:
    from src.services.utils.jsonio import load_json, save_json
    path  = f"data/config/bot/Data-{self.uid}.json"
    data  = load_json(path, {})
    arr   = data.setdefault("dlAuto", [])
    tid   = str(thread_id)
    if enabled and tid not in arr:
        arr.append(tid)
    if not enabled and tid in arr:
        arr.remove(tid)
    save_json(path, data)
    return enabled


def _toggle_dl_auto(self, thread_id: str) -> bool:
    return _write_dl_auto(self, thread_id, not _read_dl_auto(self, thread_id))


# ── Parallel runner ────────────────────────────────────────────────────────────

def _start_parallel(self, data, user_id, thread_id, type, links, is_audio):
    links = (links or [])[:10]
    if not links:
        return

    def _run():
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
            fts = [
                ex.submit(process_single_link, i, u, is_audio, thread_id, type, self, data, user_id)
                for i, u in enumerate(links)
            ]
            for ft in as_completed(fts):
                try:
                    ft.result()
                except Exception as e:
                    print(f"[Download] parallel error: {e}")

    threading.Thread(target=_run, daemon=True).start()


# ── Command handler ────────────────────────────────────────────────────────────

def handleDownload(self, message, data, userId, threadId, type):
    text = (getattr(message, "text", None) or "").strip()
    args = text.split()

    if len(args) < 2:
        self.replyMessageStyle(
            "Vui lòng cung cấp URL.\n"
            f"Ví dụ: {self.prefix}{self.rawCommand} https://...\n"
            f"Tùy chọn: thêm -a để tải âm thanh\n"
            f"         --auto on/off để bật/tắt tự động",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        return

    # --auto toggle
    if "--auto" in args:
        action = None
        for a in args[2:]:
            if a.lower() in ("on", "off"):
                action = a.lower()
                break
        if action == "on":
            enabled = _write_dl_auto(self, threadId, True)
        elif action == "off":
            enabled = _write_dl_auto(self, threadId, False)
        else:
            enabled = _toggle_dl_auto(self, threadId)

        status = "bật ✅" if enabled else "tắt ❌"
        self.replyMessageStyle(
            f"Tự động tải video đã được {status}.",
            data, threadId, type,
            color="gr" if enabled else "r",
            title="AUTO DOWNLOAD",
            userId=userId,
        )
        return

    is_audio = "-a" in args
    if is_audio:
        args = [x for x in args if x != "-a"]

    links = [x for x in args[1:] if x.startswith("http")]
    if not links:
        self.replyMessageStyle(
            "URL không hợp lệ.",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
        return

    _start_parallel(self, data, userId, threadId, type, links, is_audio)


# ── Auto-link listener (gọi từ listenReply) ───────────────────────────────────

def DownloadAutoLink(self, message, data, userId, threadId, type):
    """
    Gọi hàm này trong Listen.listenReply() để tự động phát hiện link và tải.
    """
    if not _read_dl_auto(self, threadId):
        return

    txt = ""
    try:
        # Hỗ trợ cả Message object lẫn string thuần (sau khi main.py reassign)
        if isinstance(message, str):
            txt = message.strip()
        else:
            txt = (getattr(message, "text", None) or "").strip()
    except Exception:
        pass

    # Nếu là chat.recommended (link card), lấy link từ data.content
    links = []
    try:
        if getattr(data, "msgType", None) == "chat.recommended":
            content = getattr(data, "content", None)
            if content:
                # Thử lấy href hoặc link trực tiếp
                for field in ("href", "link", "url"):
                    val = getattr(content, field, None) or (
                        content.get(field) if isinstance(content, dict) else None
                    )
                    if val and val.startswith("http"):
                        links.append(val)
                        break
                # Nếu không có field riêng, scan trong title/description
                if not links:
                    for field in ("title", "description", "subtitle"):
                        val = getattr(content, field, None) or (
                            content.get(field) if isinstance(content, dict) else None
                        ) or ""
                        found = URL_RE.findall(str(val))
                        if found:
                            links.extend(found)
                            break
    except Exception:
        pass

    # Nếu vẫn chưa có link thì scan từ txt
    if not links and txt:
        pfx = getattr(self, "prefix", "") or ""
        if pfx and txt.startswith(pfx):
            return
        links = URL_RE.findall(txt)

    if not links:
        return

    if not hasattr(self, "_DlAutoCooldown"):
        self._DlAutoCooldown = {}

    k    = (str(threadId), str(userId))
    now  = int(time.time() * 1000)
    last = self._DlAutoCooldown.get(k, 0)
    if now - last < 5000:
        return

    self._DlAutoCooldown[k] = now
    try:
        self.sendReaction(data, "/-ok", threadId, type, 10000000)
    except Exception:
        pass
    _start_parallel(self, data, userId, threadId, type, links, False)


# ── dependencies (đăng ký lệnh) ───────────────────────────────────────────────

dependencies = {
    "name":        "download",
    "alias":       ["dl", "tải"],
    "permission":  0,
    "description": "Tải video/audio từ TikTok, YouTube, Facebook, Instagram, ...",
    "cooldown":    5,
    "main":        handleDownload,
}
