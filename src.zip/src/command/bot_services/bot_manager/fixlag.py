"""
fixlag.py  —  Dọn dẹp cache / log / pycache để giảm lag & delay cho bot.
Permission: High Admin (3)
"""

import os
import gc
import shutil
import time

from app.core.index import *
from api.util.Enum import MsgStyle


# ── Helpers reply ─────────────────────────────────────────────────────────────

def _ok(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.SUCCESS.value,
                           title="FIX LAG ✅")

def _warn(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.WARNING.value,
                           title="FIX LAG ⚠️")

def _info(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.INFO.value,
                           title="FIX LAG 🔧")


# ── Util ──────────────────────────────────────────────────────────────────────

def _fmt_size(size_bytes: int) -> str:
    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024*1024):.1f} MB"
    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes} B"


def _dir_size(path: str) -> int:
    total = 0
    try:
        for root, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except Exception:
                    pass
    except Exception:
        pass
    return total


def _count_files(path: str) -> int:
    count = 0
    try:
        for _, _, files in os.walk(path):
            count += len(files)
    except Exception:
        pass
    return count


# ── Các bước dọn dẹp ─────────────────────────────────────────────────────────

def _clear_cache_dirs(base: str) -> tuple[int, int]:
    """Xoá file trong data/assets/cache/*  (giữ lại thư mục con)."""
    cache_root = os.path.join(base, "data", "assets", "cache")
    removed_files = 0
    freed_bytes = 0
    if not os.path.isdir(cache_root):
        return 0, 0
    for sub in os.listdir(cache_root):
        sub_path = os.path.join(cache_root, sub)
        if not os.path.isdir(sub_path):
            continue
        for fname in os.listdir(sub_path):
            fpath = os.path.join(sub_path, fname)
            if os.path.isfile(fpath):
                try:
                    freed_bytes += os.path.getsize(fpath)
                    os.remove(fpath)
                    removed_files += 1
                except Exception:
                    pass
    return removed_files, freed_bytes


def _clear_log_files(base: str) -> tuple[int, int]:
    """Truncate (không xoá) các file log để giữ cấu trúc nhưng giải phóng dung lượng."""
    log_paths = [
        os.path.join(base, "assets", "log", "error.txt"),
        os.path.join(base, "data", "assets", "log", "error.txt"),
    ]
    freed_bytes = 0
    truncated = 0
    for p in log_paths:
        if os.path.isfile(p):
            try:
                freed_bytes += os.path.getsize(p)
                open(p, "w").close()  # truncate
                truncated += 1
            except Exception:
                pass
    return truncated, freed_bytes


def _clear_pycache(base: str) -> tuple[int, int]:
    """Xoá toàn bộ thư mục __pycache__ trong project."""
    removed_dirs = 0
    freed_bytes = 0
    for root, dirs, _ in os.walk(base):
        for d in list(dirs):
            if d == "__pycache__":
                full = os.path.join(root, d)
                try:
                    freed_bytes += _dir_size(full)
                    shutil.rmtree(full, ignore_errors=True)
                    removed_dirs += 1
                except Exception:
                    pass
    return removed_dirs, freed_bytes


def _clear_tempStorage(base: str) -> int:
    """Reset tempStorage.json về {}."""
    path = os.path.join(base, "data", "config", "tempStorage.json")
    freed = 0
    if os.path.isfile(path):
        try:
            freed = os.path.getsize(path)
            with open(path, "w", encoding="utf-8") as f:
                f.write("{}")
        except Exception:
            pass
    return freed


def _gc_collect() -> int:
    """Chạy garbage collector Python, trả về số object thu hồi."""
    try:
        return gc.collect()
    except Exception:
        return 0


# ── Main command ──────────────────────────────────────────────────────────────

def _show_help(self, data, threadId, type, p, c):
    _info(self,
        f"Công cụ dọn dẹp hệ thống để giảm lag & delay bot.\n\n"
        f"  {p}{c}           — Dọn toàn bộ (khuyến nghị)\n"
        f"  {p}{c} cache     — Chỉ xoá cache media\n"
        f"  {p}{c} log       — Chỉ xoá log lỗi\n"
        f"  {p}{c} pyc       — Chỉ xoá __pycache__\n"
        f"  {p}{c} mem       — Chỉ giải phóng RAM (gc)\n"
        f"  {p}{c} status    — Xem dung lượng hiện tại",
        data, threadId, type
    )


def _show_status(self, data, threadId, type, base: str):
    cache_root = os.path.join(base, "data", "assets", "cache")
    log1       = os.path.join(base, "assets", "log", "error.txt")
    log2       = os.path.join(base, "data", "assets", "log", "error.txt")
    tmp_path   = os.path.join(base, "data", "config", "tempStorage.json")

    cache_size  = _dir_size(cache_root)
    cache_files = _count_files(cache_root)
    log_size    = sum(
        os.path.getsize(p) for p in [log1, log2]
        if os.path.isfile(p)
    )
    tmp_size    = os.path.getsize(tmp_path) if os.path.isfile(tmp_path) else 0

    # đếm pycache dirs
    pyc_count = sum(
        1 for root, dirs, _ in os.walk(base)
        for d in dirs if d == "__pycache__"
    )

    _info(self,
        f"📊 Trạng thái hệ thống hiện tại:\n\n"
        f"  🗂️  Cache media : {_fmt_size(cache_size)}  ({cache_files} file)\n"
        f"  📝 Log lỗi     : {_fmt_size(log_size)}\n"
        f"  💾 tempStorage : {_fmt_size(tmp_size)}\n"
        f"  ♻️  __pycache__ : {pyc_count} thư mục\n\n"
        f"Dùng  {self.prefix}{self.rawCommand}  để dọn toàn bộ.",
        data, threadId, type
    )


def fixlagCommand(self, message, data, userId, threadId, type):
    text  = (message.text or "").strip()
    parts = text.split()
    p = self.prefix
    c = self.rawCommand

    # base dir = thư mục chứa main.py  (zbot/)
    base = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        "..", "..", "..", "..", ".."
    ))

    sub = parts[1].lower() if len(parts) > 1 else ""

    if sub == "help":
        return _show_help(self, data, threadId, type, p, c)

    if sub == "status":
        return _show_status(self, data, threadId, type, base)

    t0 = time.time()
    lines = []

    # ── cache ──────────────────────────────────────────────────────────────
    if sub in ("", "cache"):
        files, freed = _clear_cache_dirs(base)
        lines.append(f"🗂️  Cache media   : -{files} file  ({_fmt_size(freed)})")

    # ── log ────────────────────────────────────────────────────────────────
    if sub in ("", "log"):
        truncated, freed = _clear_log_files(base)
        lines.append(f"📝 Log lỗi       : đã xoá {_fmt_size(freed)}")

    # ── pycache ────────────────────────────────────────────────────────────
    if sub in ("", "pyc"):
        dirs, freed = _clear_pycache(base)
        lines.append(f"♻️  __pycache__   : -{dirs} thư mục  ({_fmt_size(freed)})")

    # ── tempStorage ────────────────────────────────────────────────────────
    if sub == "":
        freed = _clear_tempStorage(base)
        if freed:
            lines.append(f"💾 tempStorage   : reset  ({_fmt_size(freed)})")

    # ── RAM / GC ───────────────────────────────────────────────────────────
    if sub in ("", "mem"):
        collected = _gc_collect()
        lines.append(f"🧹 RAM (gc)      : thu hồi {collected} object")

    elapsed = round((time.time() - t0) * 1000)

    if not lines:
        return _warn(self,
            f"Subcommand '{sub}' không hợp lệ.\n"
            f"Dùng  {p}{c} help  để xem hướng dẫn.",
            data, threadId, type
        )

    result = "\n".join(lines)
    _ok(self,
        f"Dọn dẹp hoàn tất trong {elapsed} ms\n\n"
        f"{result}\n\n"
        f"✅ Bot đã được tối ưu, độ trễ sẽ giảm đáng kể!",
        data, threadId, type
    )


dependencies = {
    "name":        "fixlag",
    "alias":       ["fixdelay", "cleanup", "docache"],
    "permission":  3,
    "description": "Dọn cache / log / pycache / RAM để giảm lag & delay bot.",
    "cooldown":    10,
    "main":        fixlagCommand,
}
