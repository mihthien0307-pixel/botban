from app.core.index import *
from api.util.Enum import MsgStyle
from src.services.utils.jsonio import read_settings, write_settings

MIN_SIZE = 8
MAX_SIZE = 30

DEFAULT_TITLE = 12
DEFAULT_BODY  = 11


def fontsizeCommand(self, message, data, userId, threadId, type):
    text  = (message.text if hasattr(message, "text") else str(message)).strip()
    parts = text.split()
    p     = self.prefix

    def ok(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color=MsgStyle.SUCCESS.value,
                               title=MsgStyle.SUCCESS.name,
                               userId=userId)

    def err(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color=MsgStyle.ERROR.value,
                               title=MsgStyle.ERROR.name,
                               userId=userId)

    def info(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color="or", title="CAUTION",
                               userId=userId)

    user_level = self.permissionLevel(userId, threadId)
    if user_level < 3:
        return err("Bạn không có quyền dùng lệnh này (cần cấp 3+).")

    settings = read_settings(self.uid)
    cur_title = int(settings.get("font_title_size", DEFAULT_TITLE))
    cur_body  = int(settings.get("font_body_size", DEFAULT_BODY))

    # Không có tham số -> xem cỡ hiện tại
    if len(parts) < 2:
        return info(
            f"Cỡ chữ hiện tại:\n"
            f"• Title (CAUTION/SUCCESS/...): {cur_title}\n"
            f"• Body (nội dung): {cur_body}\n\n"
            f"Cú pháp:\n"
            f"{p}fontsize <số>            (đặt cả title & body cùng cỡ)\n"
            f"{p}fontsize <title> <body>  (đặt riêng)\n"
            f"{p}fontsize reset           (về mặc định 12/11)"
        )

    arg1 = parts[1].lower()

    if arg1 in ("reset", "default", "md"):
        settings.pop("font_title_size", None)
        settings.pop("font_body_size", None)
        write_settings(self.uid, settings)
        return ok(f"Đã đặt lại cỡ chữ về mặc định ({DEFAULT_TITLE}/{DEFAULT_BODY}).")

    if not arg1.isdigit():
        return err(f"Cú pháp: {p}fontsize <số> hoặc {p}fontsize <title> <body> hoặc {p}fontsize reset")

    new_title = int(arg1)
    new_body  = new_title

    if len(parts) >= 3:
        if not parts[2].isdigit():
            return err(f"Cú pháp: {p}fontsize <title> <body> — cả hai phải là số.")
        new_body = int(parts[2])

    for v in (new_title, new_body):
        if v < MIN_SIZE or v > MAX_SIZE:
            return err(f"Cỡ chữ phải trong khoảng {MIN_SIZE} - {MAX_SIZE}.")

    settings["font_title_size"] = new_title
    settings["font_body_size"]  = new_body
    write_settings(self.uid, settings)

    ok(
        f"Đã đổi cỡ chữ:\n"
        f"• Title: {new_title}\n"
        f"• Body: {new_body}"
    )

    # Demo preview style to/đậm/đỏ giống mẫu
    self.replyMessageStyle(
        f"Đây là ví dụ chữ với cỡ {new_title}/{new_body} vừa đổi.",
        data, threadId, type,
        color="r", title=f"DEMO ✗ zZz 🎌",
        userId=userId,
    )
    return


dependencies = {
    "name":        "fontsize",
    "permission":  3,
    "cooldown":    5,
    "description": "Chỉnh cỡ chữ (to/nhỏ) cho tin nhắn style SUCCESS/ERROR/CAUTION...",
    "alias":       ["fs", "cofont"],
    "main":        fontsizeCommand,
}
