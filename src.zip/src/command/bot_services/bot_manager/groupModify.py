from app.core.index import *
from src.services.pillow.drawGroupInfo import draw_group_info


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _clean_mem_list(memVerList):
    out, seen = [], set()
    for x in memVerList or []:
        if not x:
            continue
        s = str(x)
        if isinstance(x, str) and x.endswith("_0"):
            s = x[:-2]
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _get_group_info(this, threadId):
    try:
        gi = this.fetchGroupInfo(threadId)
        gmap = getattr(gi, "gridInfoMap", None) or {}
        info = gmap.get(threadId) or gmap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}


def _send_ok(this, text, data, threadId, type):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS")


def _send_warn(this, text, data, threadId, type):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING")


def _send_fail(this, text, data, threadId, type):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR")


def _help(p, c):
    return (
        f"Quản Lý Nhóm\n\n"
        f"  {p}{c} list              - Liệt kê thành viên\n"
        f"  {p}{c} find <tên>        - Tìm thành viên theo tên\n"
        f"  {p}{c} name <tên mới>    - Đổi tên nhóm\n"
        f"  {p}{c} settings lock     - Khoá/mở chat nhóm\n"
        f"  {p}{c} settings ign-raid - Áp dụng chế độ anti-raid\n\n"
        f"Sau khi dùng list/find, reply kết quả và gõ:\n"
        f"  kick 1,2   hoặc   kick TênThành Viên\n"
        f"  block 1,2  hoặc   block TênThành Viên"
    )


# ═══════════════════════════════════════════════════════════
# Tìm thành viên theo tên
# ═══════════════════════════════════════════════════════════

def _find_members(this, threadId, query=""):
    info     = _get_group_info(this, threadId)
    mem_list = _clean_mem_list(info.get("memVerList"))

    keywords = [
        " ".join(k.strip().lower().split())
        for k in str(query or "").split(",")
        if k.strip()
    ]
    keywords = list(dict.fromkeys(keywords))

    rows, seen = [], set()
    for uid in mem_list:
        uid = str(uid or "").strip()
        if not uid or uid in seen:
            continue
        try:
            name = this.userName(uid) or uid
        except Exception:
            name = uid
        name_lower = " ".join(name.lower().split())
        if (not keywords) or any(k in name_lower for k in keywords):
            seen.add(uid)
            rows.append((uid, name))
    return rows


# ═══════════════════════════════════════════════════════════
# Reply handler – nhận kick/block sau list/find
# ═══════════════════════════════════════════════════════════

def _apply_member_reply(this, message, data, userId, threadId, type):
    stMap = getattr(this, "groupModifyStates", {})

    q     = getattr(data, "quote", None)
    qmsg  = q.get("globalMsgId") if isinstance(q, dict) else getattr(q, "globalMsgId", None)
    if not qmsg:
        return None

    key = f"{userId}:{threadId}"
    st  = stMap.get(key)
    if not st or str(st.get("threadId")) != str(threadId):
        return None

    if not (st.get("msgId") and str(qmsg) == str(st["msgId"])):
        return None

    txt = (message.text if isinstance(message, Message) else str(message or "")).strip()
    if not txt:
        return None

    head, tail = (txt.split(None, 1) + [""])[:2]
    action = head.lower().strip()
    pick   = tail.strip()

    if action not in ("kick", "block"):
        return None

    rows = st.get("rows") or []
    if not rows:
        return _send_warn(this, "Reply dưới list/find trước.", data, threadId, type)

    toks = [x for x in pick.replace(" ", "").split(",") if x]
    if not toks:
        return _send_warn(
            this,
            "Ví dụ: kick 1,2  hoặc  kick TênNgười",
            data, threadId, type,
        )

    idxs, keys = [], []
    for t in toks:
        if t.isdigit():
            idxs.append(int(t))
        else:
            keys.append(" ".join(t.lower().split()))

    members, seen = [], set()
    for i in sorted(set(idxs)):
        j = i - 1
        if 0 <= j < len(rows):
            uid = rows[j][0]
            if uid not in seen:
                seen.add(uid)
                members.append(uid)

    for uid, name in rows:
        n = " ".join(str(name or "").lower().split())
        if any(k in n for k in keys) and uid not in seen:
            seen.add(uid)
            members.append(uid)

    if not members:
        return _send_fail(this, "Không tìm thấy mục tiêu.", data, threadId, type)

    try:
        if action == "kick":
            this.kickUsers(members, threadId)
            _send_ok(this, f"Đã kick {len(members)} thành viên.", data, threadId, type)
        else:
            this.blockUsers(members, threadId)
            _send_ok(this, f"Đã block {len(members)} thành viên.", data, threadId, type)
    except Exception as e:
        _send_fail(this, f"Thất bại: {e}", data, threadId, type)

    stMap.pop(key, None)
    return True


# ═══════════════════════════════════════════════════════════
# Sub-commands
# ═══════════════════════════════════════════════════════════

def _cmd_list(this, message, data, userId, threadId, type):
    rows = _find_members(this, threadId)
    if not rows:
        return _send_warn(this, "Nhóm không có thành viên.", data, threadId, type)

    body  = "Danh sách thành viên:\n\n"
    body += "\n".join(f"  {i}. {name}" for i, (_, name) in enumerate(rows, 1))

    sent = this.replyMessageStyle(body, data, threadId, type, color="or", title="MEMBER LIST")
    if not sent:
        return

    if not hasattr(this, "groupModifyStates"):
        this.groupModifyStates = {}
    this.groupModifyStates[f"{userId}:{threadId}"] = {
        "threadId": threadId,
        "msgId":    getattr(sent, "msgId", None),
        "rows":     rows,
    }
    return sent


def _cmd_find(this, parts, data, userId, threadId, type):
    if len(parts) < 3:
        return _send_warn(this, "Nhập tên thành viên cần tìm.", data, threadId, type)

    q    = " ".join(parts[2:])
    rows = _find_members(this, threadId, q)
    if not rows:
        return _send_fail(this, f"Không tìm thấy: {q}", data, threadId, type)

    body  = f"Kết quả tìm '{q}':\n\n"
    body += "\n".join(f"  {i}. {name}" for i, (_, name) in enumerate(rows, 1))

    sent = this.replyMessageStyle(body, data, threadId, type, color="or", title="FIND")
    if not sent:
        return

    if not hasattr(this, "groupModifyStates"):
        this.groupModifyStates = {}
    this.groupModifyStates[f"{userId}:{threadId}"] = {
        "threadId": threadId,
        "msgId":    getattr(sent, "msgId", None),
        "rows":     rows,
    }
    return sent


def _cmd_name(this, parts, data, threadId, type):
    if len(parts) < 3:
        return _send_warn(this, "Nhập tên mới cho nhóm.", data, threadId, type)
    new_name   = " ".join(parts[2:])
    old_name   = this.groupInfo(threadId)
    this.changeGroupName(new_name, threadId)
    _send_ok(this, f"Đổi tên: {old_name} → {new_name}", data, threadId, type)


def _cmd_settings(this, parts, data, threadId, type):
    if len(parts) < 3:
        p = getattr(this, "prefix", "")
        c = getattr(this, "rawCommand", "group")
        return _send_warn(
            this,
            f"Cài đặt nhóm:\n"
            f"  {p}{c} settings lock     - Khoá/mở chat\n"
            f"  {p}{c} settings ign-raid - Áp dụng anti-raid",
            data, threadId, type,
        )

    sub       = parts[2].lower()
    group_name = this.groupInfo(threadId)

    if sub == "lock":
        info      = _get_group_info(this, threadId)
        settings  = info.get("setting") or info.get("settings") or {}
        locked    = int(settings.get("lockSendMsg", 0) if isinstance(settings, dict) else 0)
        new_state = 0 if locked else 1
        this.changeGroupSetting(threadId, lockSendMsg=new_state)
        state_txt = "Đã khoá" if new_state else "Đã mở"
        return _send_ok(this, f"{state_txt} chat trong nhóm {group_name}.", data, threadId, type)

    if sub == "ign-raid":
        this.changeGroupSetting(groupId=threadId, defaultMode="anti-raid", lockSendMsg=1)
        return _send_ok(this, f"Áp dụng anti-raid cho nhóm {group_name}.", data, threadId, type)

    return _send_warn(this, f"Không nhận ra sub-command: {sub}", data, threadId, type)


def _cmd_debuginfo(this, data, threadId, type):
    """Lệnh debug tạm – in ra tất cả keys của group info để tìm field link nhóm."""
    import re as _re
    try:
        gi   = this.fetchGroupInfo(str(threadId))
        gmap = getattr(gi, "gridInfoMap", {}) or {}
        info = gmap.get(str(threadId)) or (next(iter(gmap.values()), {}) if gmap else {})
    except Exception as e:
        return _send_fail(this, f"fetchGroupInfo lỗi: {e}", data, threadId, type)

    all_keys = sorted(info.keys()) if isinstance(info, dict) else []
    link_keys = [k for k in all_keys if any(w in k.lower() for w in
                 ("link", "url", "invite", "join", "share", "href", "zalo"))]

    lines = ["=== ALL KEYS ==="]
    lines += all_keys
    lines += ["\n=== LINK-RELATED ==="]
    for k in link_keys:
        lines.append(f"{k}: {str(info.get(k,''))[:80]}")

    _send_ok(this, "\n".join(lines), data, threadId, type)


def _cmd_debuglink(this, data, threadId, type):
    """Debug getGroupLink – in raw response để tìm field chứa URL."""
    try:
        result = this.getGroupLink(str(threadId))
        lines = ["=== getGroupLink RAW ==="]
        if isinstance(result, dict):
            for k, v in result.items():
                lines.append(f"{k}: {str(v)[:120]}")
        else:
            lines.append(str(result))
        _send_ok(this, "\n".join(lines), data, threadId, type)
    except Exception as e:
        _send_fail(this, f"getGroupLink lỗi: {e}", data, threadId, type)


# ═══════════════════════════════════════════════════════════
# Main command
# ═══════════════════════════════════════════════════════════

def _cmd_info(this, data, threadId, type):
    import re as _re, os as _os
    from app.module.utils import _get_user_avatar

    # Fetch group info
    try:
        gi    = this.fetchGroupInfo(str(threadId))
        gmap  = getattr(gi, "gridInfoMap", {}) or {}
        info  = gmap.get(str(threadId)) or (next(iter(gmap.values()),{}) if gmap else {})
    except Exception:
        info = {}

    # Clean avatar URL
    def _clean(url):
        if not url: return ""
        url = _re.sub(r'[?&][whs]=\d+', '', url)
        url = _re.sub(r'[?&]size=\d+', '', url)
        url = _re.sub(r'/w\d+/', '/w2048/', url)
        return url.rstrip('?&')

    group_name   = str(info.get("name") or "Nhóm")
    member_count = int(info.get("totalMember") or info.get("memberCount") or
                       len(_clean_mem_list(info.get("memVerList"))) or 0)
    group_avatar = _clean(info.get("avt") or info.get("avatar") or
                          info.get("fullAvt") or info.get("avatarUrl") or "")

    # URL mời nhóm để tạo QR code
    # getGroupLink trả về: {error_code, data: {link, expiration_date, enabled}}
    qr_url = ""
    try:
        link_resp = this.getGroupLink(str(threadId))
        data_field = link_resp.get("data", {})
        if isinstance(data_field, dict):
            qr_url = str(data_field.get("link", ""))
        # Nếu link bị disabled hoặc chưa có, tạo mới 1 lần
        if not qr_url or not data_field.get("enabled", 1):
            this.newlink(str(threadId))
            link_resp2 = this.getGroupLink(str(threadId))
            data_field2 = link_resp2.get("data", {})
            if isinstance(data_field2, dict):
                qr_url = str(data_field2.get("link", ""))
    except Exception:
        pass

    settings = info.get("setting") or info.get("settings") or {}
    if isinstance(settings, str):
        import json as _j
        try:    settings = _j.loads(settings)
        except: settings = {}

    owner_id  = str(info.get("creatorId") or info.get("ownerId") or "")
    admin_ids = [str(a) for a in (info.get("adminIds") or [])]
    all_ids   = ([owner_id] if owner_id else []) + [a for a in admin_ids if a != owner_id]

    # Fetch name + avatar parallel
    admins   = [None] * len(all_ids[:24])
    all_ids  = all_ids[:24]

    def _fetch_admin(i, uid):
        try:
            uinfo   = this.fetchUserInfo(str(uid))
            changed = getattr(uinfo, "changed_profiles", {}) or {}
            profile = changed.get(str(uid)) or {}
            if not profile:
                unchanged = getattr(uinfo, "unchanged_profiles", {}) or {}
                profile   = unchanged.get(str(uid)) or {}
            name   = profile.get("displayName") or profile.get("zaloName") or str(uid)
            avatar = _clean(profile.get("avatar") or profile.get("avatarUrl") or "")
        except Exception:
            name, avatar = str(uid), ""
        role = "Owner" if str(uid) == owner_id else "Admin"
        admins[i] = {"name": name, "avatar": avatar, "role": role}

    import threading as _th2
    ts = [_th2.Thread(target=_fetch_admin, args=(i,uid), daemon=True)
          for i,uid in enumerate(all_ids)]
    for t in ts: t.start()
    for t in ts: t.join(timeout=12)
    admins = [a for a in admins if a]

    out_path = f"data/assets/cache/image/group_info_{threadId}.png"
    _os.makedirs("data/assets/cache/image", exist_ok=True)

    path, w, h = draw_group_info(
        group_name        = group_name,
        member_count      = member_count,
        group_avatar_url  = group_avatar,
        settings          = settings,
        admins            = admins,
        out_path          = out_path,
        qr_url            = qr_url,
    )
    this.sendLocalImage(path, threadId, type, width=w, height=h, ttl=120000)


def groupManagerCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split()
    p     = getattr(this, "prefix", "")
    c     = getattr(this, "rawCommand", "group")

    if len(parts) < 2:
        return _send_warn(this, _help(p, c), data, threadId, type)

    sub = parts[1].lower()

    if sub == "list":
        return _cmd_list(this, message, data, userId, threadId, type)

    if sub == "find":
        return _cmd_find(this, parts, data, userId, threadId, type)

    if sub == "name":
        return _cmd_name(this, parts, data, threadId, type)

    if sub in ("settings", "stg"):
        return _cmd_settings(this, parts, data, threadId, type)

    if sub == "info":
        return _cmd_info(this, data, threadId, type)

    if sub == "debuginfo":
        return _cmd_debuginfo(this, data, threadId, type)

    if sub == "debuglink":
        return _cmd_debuglink(this, data, threadId, type)

    return _send_warn(this, _help(p, c), data, threadId, type)


# ═══════════════════════════════════════════════════════════
# Reply handler (dùng trong listenReply)
# ═══════════════════════════════════════════════════════════

def GroupModifyReply(this, message, data, userId, threadId, type):
    _apply_member_reply(this, message, data, userId, threadId, type)


# ═══════════════════════════════════════════════════════════
# dependencies
# ═══════════════════════════════════════════════════════════

dependencies = {
    "name":        "group",
    "permission":  3,
    "cooldown":    3,
    "description": "Quản lý nhóm (list, find, kick, block, name, settings)",
    "main":        groupManagerCommand,
}
