from app.core.index import *
from api.util.Enum import MsgStyle

# ─────────────────────────────────────────────────────────────────────────────
#  listGroup command — quản lý danh sách nhóm từ bot
#  Đặt file này vào:  src/command/bot_services/bot_manager/listGroup.py
# ─────────────────────────────────────────────────────────────────────────────


def _norm(s: str) -> str:
    """Chuẩn hoá chuỗi để so sánh (lower + collapse spaces)."""
    return " ".join(str(s or "").lower().split())


def _parse_nums(s: str, mx: int) -> list[int]:
    """Parse chuỗi số kiểu '1,3,5' → [1, 3, 5] (hợp lệ trong [1, mx])."""
    s = (s or "").replace(" ", "")
    if not s:
        return []
    out = []
    for x in s.split(","):
        if x.isdigit():
            v = int(x)
            if 1 <= v <= mx:
                out.append(v)
    return sorted(set(out))


def _parse_cmds(text: str, prefix: str, commands: dict) -> list[str]:
    """Parse chuỗi lệnh phân cách bằng dấu phẩy, trả về list lệnh có prefix."""
    parts = [p.strip() for p in (text or "").split(",")]
    out = []
    for p in parts:
        t = p.strip()
        if not t:
            continue
        if prefix and t.startswith(prefix):
            out.append(t)
            continue
        head = t.split()[0].lower() if t.split() else ""
        if isinstance(commands, dict) and head in commands:
            out.append(f"{prefix}{t}" if prefix else t)
    return out


def _exec_cmd_to(self, data, userId, gid, type_, content: str):
    """Thực thi một lệnh trong ngữ cảnh nhóm khác (gid)."""
    try:
        new_data = data.copy() if isinstance(data, dict) else {}
        new_data["content"] = content
        new_data["mentions"] = []
        self.loadcommands(Message(text=content), new_data, userId, gid, type_)
    except Exception:
        pass


def _get_all_group_ids(self) -> list[str]:
    """Lấy danh sách group IDs từ fetchAllGroups."""
    try:
        groups = self.fetchAllGroups()
        grid_map = getattr(groups, "gridVerMap", None) or {}
        return [str(g) for g in grid_map.keys()]
    except Exception:
        return []


def _get_group_name(self, gid: str) -> str:
    """Lấy tên nhóm qua fetchGroupInfo."""
    try:
        info = self.fetchGroupInfo(str(gid))
        grid_info = getattr(info, "gridInfoMap", None) or {}
        g = grid_info.get(str(gid)) or {}
        if not g and grid_info:
            g = next(iter(grid_info.values()), {})
        return g.get("name") or "Unknown"
    except Exception:
        return "Unknown"


# ─── Handler chính ────────────────────────────────────────────────────────────

def GroupList(self, message, data, userId, threadId, type_):
    """
    Lệnh quản lý danh sách nhóm bot đang tham gia.

    Cách dùng:
      !listgroup                  — Hiện danh sách nhóm
      !listgroup <số>             — Chọn nhóm theo số thứ tự
      !listgroup <tên>            — Chọn nhóm theo tên (tìm gần đúng)
      !listgroup 1,3,5            — Chọn nhiều nhóm
      !listgroup all              — Chọn tất cả nhóm (reply vào tin nhắn danh sách)
      !listgroup all -<số>        — Chọn tất cả trừ số thứ tự
      !listgroup all -<tên>       — Chọn tất cả trừ tên
      !listgroup session          — Xem danh sách đã chọn
      !listgroup goto <số>        — Trỏ tới nhóm đã chọn theo số
      !listgroup goto off         — Thoát chế độ goto
      !listgroup send <nội dung>  — Gửi tin nhắn tới các nhóm đã chọn
      !listgroup changelink       — Đổi link mời tất cả nhóm đã chọn
      !listgroup disablelink      — Vô hiệu link mời các nhóm đã chọn
      !listgroup exit             — Xoá session hiện tại
      !listgroup exit all         — Xoá tất cả session

    Khi đang ở chế độ goto:
      Gõ bất kỳ lệnh nào → bot thực thi lệnh đó trong nhóm đang trỏ tới.

    Khi reply vào tin nhắn danh sách:
      <số> → <lệnh,...>           — Thực thi lệnh trong nhóm chỉ định
      all  → <lệnh,...>           — Thực thi lệnh trong tất cả nhóm
    """

    # ── Khởi tạo state map (lưu trên object bot, không reset khi restart) ──
    if not hasattr(self, "_groupListStates"):
        self._groupListStates = {}
    st_map: dict = self._groupListStates

    prefix  = str(getattr(self, "prefix", "") or "")
    cmds    = getattr(self, "commands", {}) or {}
    key     = f"{userId}:{threadId}"

    # ── Lấy text thực sự (loại bỏ mention) ───────────────────────────────
    raw_text: str = ""
    try:
        content = data.get("content", "") if isinstance(data, dict) else getattr(data, "content", "")
        if isinstance(content, dict):
            content = content.get("title", "")
        raw_text = str(content or "").strip()
        # Bỏ prefix lệnh chính ("!listgroup")
        if prefix and raw_text.lower().startswith(prefix):
            raw_text = raw_text[len(prefix):]
        parts = raw_text.split(None, 1)
        raw_text = parts[1].strip() if len(parts) > 1 else ""
    except Exception:
        raw_text = ""

    # ── Lệnh gốc (chưa có sub-command) → hiện danh sách ─────────────────
    if not raw_text:
        gids = _get_all_group_ids(self)
        if not gids:
            return self.sendWarning("Danh sách nhóm trống!", threadId, type_, data)

        items = [(gid, _get_group_name(self, gid)) for gid in gids]
        items.sort(key=lambda x: (_norm(x[1]), x[0]))
        sorted_gids  = [g for g, _ in items]
        sorted_names = [n for _, n in items]

        body = "Group list:\n" + "\n".join(
            f"{i}. {n}" for i, n in enumerate(sorted_names, 1)
        )
        sent = self.sendSuccess(body, threadId, type_, data)
        if not sent:
            return

        st_map[key] = {
            "threadId": str(threadId),
            "msgId":    getattr(sent, "msgId", None),
            "gids":     sorted_gids,
            "names":    sorted_names,
            "sel":      [],
            "goto":     None,
        }
        return

    # ── Sub-commands ──────────────────────────────────────────────────────
    raw   = raw_text
    low   = raw.lower().strip()
    cmd, _, rest = raw.partition(" ")
    cmdl  = cmd.lower().strip()
    rest  = rest.strip()

    # --- exit all ---
    if low == "exit all":
        st_map.pop(key, None)
        return self.sendSuccess("Đã xoá tất cả session.", threadId, type_, data)

    # --- exit [số,...] ---
    if cmdl == "exit":
        st = st_map.get(key)
        if not st:
            st_map.pop(key, None)
            return self.sendSuccess("Đã thoát session.", threadId, type_, data)

        s = rest.replace(" ", "")
        if not s:
            st_map.pop(key, None)
            return self.sendSuccess("Đã thoát session.", threadId, type_, data)

        sel: list = st.get("sel") or []
        if not sel:
            return self.sendWarning("Session trống.", threadId, type_, data)

        xs = [int(x) for x in s.split(",") if x.isdigit()]
        xs = sorted({x for x in xs if 1 <= x <= len(sel)}, reverse=True)
        if not xs:
            return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)
        for x in xs:
            sel.pop(x - 1)
        st["sel"] = sel
        g = st.get("goto")
        if g and g not in sel:
            st["goto"] = None
        return self.sendSuccess("Đã cập nhật session.", threadId, type_, data)

    # --- session ---
    if cmdl == "session":
        st = st_map.get(key)
        if not st or not st.get("sel"):
            return self.sendWarning("Session trống.", threadId, type_, data)
        sel   = st["sel"]
        gids  = st["gids"]
        names = st["names"]
        pos   = {g: i for i, g in enumerate(gids)}
        lines = ["Các nhóm đã chọn:"]
        for i, gid in enumerate(sel, 1):
            j = pos.get(gid, -1)
            lines.append(f"{i}. {names[j] if j >= 0 else 'Unknown'}")
        return self.sendSuccess("\n".join(lines), threadId, type_, data)

    # --- goto [số | off] ---
    if cmdl == "goto":
        st = st_map.get(key)
        if not st:
            return self.sendWarning("Chưa có session. Gõ !listgroup để tạo.", threadId, type_, data)

        sel   = st.get("sel") or []
        gids  = st["gids"]
        names = st["names"]
        pos   = {g: i for i, g in enumerate(gids)}

        r = rest.replace(" ", "").lower()
        if not r:
            g = st.get("goto")
            if not g:
                return self.sendSuccess("Không có nhóm nào đang trỏ tới.", threadId, type_, data)
            j = pos.get(g, -1)
            return self.sendSuccess(f"Đang trỏ tới: {names[j] if j >= 0 else 'Unknown'}", threadId, type_, data)

        if r in ("off", "0", "none", "exit"):
            st["goto"] = None
            return self.sendSuccess("Đã thoát chế độ goto.", threadId, type_, data)

        if not r.isdigit():
            return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)

        if not sel:
            return self.sendWarning("Chưa chọn nhóm nào. Chọn nhóm trước.", threadId, type_, data)

        i = int(r)
        if i < 1 or i > len(sel):
            return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)

        g = sel[i - 1]
        st["goto"] = g
        j = pos.get(g, -1)
        return self.sendSuccess(f"Goto: {names[j] if j >= 0 else 'Unknown'}", threadId, type_, data)

    # --- send <nội dung> ---
    if cmdl == "send":
        st = st_map.get(key)
        if not st or not st.get("sel"):
            return self.sendWarning("Chưa chọn nhóm nào.", threadId, type_, data)
        if not rest:
            return self.sendWarning("Nội dung tin nhắn trống!", threadId, type_, data)

        sel = st["sel"]
        delay = len(sel) > 4
        for gid in sel:
            self.sendMessage(Message(text=rest), gid, type_)
            if delay:
                time.sleep(1)
        return self.sendSuccess(f"Đã gửi tới {len(sel)} nhóm.", threadId, type_, data)

    # --- changelink ---
    if cmdl == "changelink":
        st = st_map.get(key)
        if not st or not st.get("sel"):
            return self.sendWarning("Chưa chọn nhóm nào.", threadId, type_, data)

        sel   = st["sel"]
        delay = len(sel) > 4
        ok    = 0
        for gid in sel:
            try:
                self.newlink(gid)
                ok += 1
            except Exception:
                pass
            if delay:
                time.sleep(1)
        return self.sendSuccess(
            f"Đổi link thành công {ok}/{len(sel)} nhóm." if ok else "Không đổi được link nào.",
            threadId, type_, data
        )

    # --- disablelink ---
    if cmdl == "disablelink":
        st = st_map.get(key)
        if not st or not st.get("sel"):
            return self.sendWarning("Chưa chọn nhóm nào.", threadId, type_, data)

        sel   = st["sel"]
        delay = len(sel) > 4
        for gid in sel:
            try:
                self.dislink(gid)
            except Exception:
                pass
            if delay:
                time.sleep(1)
        return self.sendSuccess(f"Đã vô hiệu link {len(sel)} nhóm.", threadId, type_, data)

    # ─── Các lệnh cần có session (reply hoặc goto) ───────────────────────

    st = st_map.get(key)
    if not st or str(st.get("threadId")) != str(threadId):
        return self.sendWarning("Chưa có session. Gõ !listgroup để tạo.", threadId, type_, data)

    sel   = st.get("sel") or []
    gids  = st["gids"]
    names = st["names"]
    pos   = {g: i for i, g in enumerate(gids)}

    def _add_idx(i: int):
        gid = gids[i]
        if gid not in sel:
            sel.append(gid)
            st["sel"] = sel
        return self.sendSuccess(f"Đã thêm: {names[i]}", threadId, type_, data)

    def _add_many(idxs: list[int]):
        added = 0
        for i in idxs:
            gid = gids[i]
            if gid not in sel:
                sel.append(gid)
                added += 1
        st["sel"] = sel
        return self.sendSuccess(f"Đã thêm {added} nhóm.", threadId, type_, data)

    # Kiểm tra có phải reply vào tin nhắn danh sách không
    q = data.get("quote") if isinstance(data, dict) else getattr(data, "quote", None)
    q_msg_id = q.get("globalMsgId") if isinstance(q, dict) else getattr(q, "globalMsgId", None)
    is_reply_to_list = bool(
        q_msg_id and st.get("msgId") and str(q_msg_id) == str(st["msgId"])
    )

    # --- Chế độ goto: chuyển lệnh sang nhóm đang trỏ ---
    if not is_reply_to_list:
        if st.get("goto"):
            cmds_list = _parse_cmds(raw, prefix, cmds)
            if cmds_list:
                gid = st["goto"]
                for c in cmds_list:
                    _exec_cmd_to(self, data, userId, gid, type_, c)
            return
        # Không phải reply, không goto → không xử lý nếu có prefix (tránh conflict)
        if prefix and raw.startswith(prefix):
            return
        return

    # ─── Xử lý reply vào tin nhắn danh sách ─────────────────────────────

    # Cú pháp: <target> -> <lệnh,...>
    if "->" in raw:
        lhs, rhs = raw.split("->", 1)
        sel_raw  = lhs.strip()
        cmd_raw  = rhs.strip()

        cmds_list = _parse_cmds(cmd_raw, prefix, cmds)
        if not cmds_list:
            return self.sendWarning("Lệnh không hợp lệ.", threadId, type_, data)

        targets: list[str] = []
        sel_low = sel_raw.lower()
        if sel_low == "all":
            targets = gids[:]
        elif all(c.isdigit() or c in ", " for c in sel_raw):
            xs = _parse_nums(sel_raw, len(gids))
            if not xs:
                return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)
            targets = [gids[x - 1] for x in xs]
        else:
            return self.sendWarning("Định dạng không hợp lệ. Dùng: <số|all> -> <lệnh>", threadId, type_, data)

        delay = len(targets) > 4
        for gid in targets:
            for c in cmds_list:
                _exec_cmd_to(self, data, userId, gid, type_, c)
            if delay:
                time.sleep(1)
        return self.sendSuccess(f"Đã thực thi trong {len(targets)} nhóm.", threadId, type_, data)

    # Cú pháp: all [-<số|tên>]
    if cmdl == "all":
        r = rest.strip()
        ex_nums: list[int] = []
        ex_key = ""

        if r.startswith("-"):
            r2 = r[1:].strip()
            if r2:
                if all(c.isdigit() or c in ", " for c in r2):
                    ex_nums = _parse_nums(r2, len(gids))
                else:
                    ex_key = _norm(r2)

        if ex_nums:
            ex = {x - 1 for x in ex_nums}
            st["sel"] = [gids[i] for i in range(len(gids)) if i not in ex]
        elif ex_key:
            st["sel"] = [gids[i] for i, n in enumerate(names) if ex_key not in _norm(n)]
        else:
            st["sel"] = gids[:]

        if st.get("goto") and st["goto"] not in st["sel"]:
            st["goto"] = None

        return self.sendSuccess(f"Đã chọn {len(st['sel'])} nhóm.", threadId, type_, data)

    # Cú pháp: nhiều số "1,3,5"
    if "," in raw and all(c.isdigit() or c in ", " for c in raw):
        xs = _parse_nums(raw, len(gids))
        if not xs:
            return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)
        return _add_many([x - 1 for x in xs])

    # Cú pháp: nhiều tên "nhóm A, nhóm B"
    if "," in raw:
        ks = [_norm(x) for x in raw.split(",")]
        ks = [k for k in ks if k]
        if ks:
            hit = [
                i for i, n in enumerate(names)
                if any(k == _norm(n) or k in _norm(n) for k in ks)
            ]
            if hit:
                return _add_many(hit)

    # Cú pháp: một số
    if raw.isdigit():
        i = int(raw) - 1
        if i < 0 or i >= len(gids):
            return self.sendWarning("Số thứ tự không hợp lệ.", threadId, type_, data)
        return _add_idx(i)

    # Cú pháp: tìm theo tên
    qn  = _norm(raw)
    hit = [i for i, n in enumerate(names) if qn == _norm(n) or qn in _norm(n)]

    if len(hit) == 1:
        return _add_idx(hit[0])

    if len(hit) > 1:
        lines = (
            ["Nhiều nhóm trùng tên:"]
            + [f"{i}. {names[j]}" for i, j in enumerate(hit, 1)]
            + ["", "Reply số thứ tự hoặc 'all' để chọn tất cả."]
        )
        sent = self.sendSuccess("\n".join(lines), threadId, type_, data)
        if sent:
            # Thu hẹp danh sách về kết quả tìm kiếm
            st["gids"]  = [gids[j] for j in hit]
            st["names"] = [names[j] for j in hit]
            st["msgId"] = getattr(sent, "msgId", None)
        return

    return self.sendWarning("Không tìm thấy nhóm nào.", threadId, type_, data)


# ─── dependencies (zBot command loader) ─────────────────────────────────────

dependencies = {
    "name":        "listgroup",
    "permission":  2,            # Bot Admin trở lên
    "cooldown":    0,
    "description": "Quản lý danh sách nhóm bot đang tham gia",
    "alias":       ["lg", "listg"],
    "main":        GroupList,
}
