"""
im-set.py  –  Lệnh "im" – cài đặt cá nhân cho bot  (zBot)
Đặt tại: src/command/bot_services/bot_manager/im-set.py

Port từ zBug/src/bot/manager/im-set.py
Thích nghi:
  - sendMWarning / sendMSuccess / sendMMessage  →  replyMessageStyle (color)
  - ReadServices / WriteService               →  read_settings / write_settings
  - this.extractUids(data)                    →  extractUids(data)  (standalone)
  - textHelp(c).iAmHelp                       →  chuỗi help nội tuyến
"""

from app.core.index import *                            # extractUids, packages...
from src.services.utils.jsonio import read_settings, write_settings
from src.services.utils.im_core import initCheckFriendRequests


# ── Helpers giao tiếp ────────────────────────────────────────────────────────

def _ok(self, msg, data, userId, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color="gr", title="SUCCESS", userId=userId)

def _warn(self, msg, data, userId, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color="yl", title="WARNING", userId=userId)

def _msg(self, msg, data, userId, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color="or", title="INFO", userId=userId)


# ── Help text ────────────────────────────────────────────────────────────────

def _iAmHelp(c):
    return (
        f"{c} ghost      : Ghost status cho bot\n"
        f"{c} ignore     : Bỏ qua hộp được mời, chờ chủ hộp duyệt\n"
        f"{c} learn      : Học tin nhắn và tự động phản hồi\n"
        f"{c} vietnamese : Chuyển ngôn ngữ bot\n"
        f"{c} friend     : Tự động chấp nhận lời mời kết bạn\n"
        f"{c} dontcare   : Im lặng / xoá tin của một user\n"
        f"{c} lazy       : Chế độ lười – undo tin nhắn qua reaction /-heart"
    )


# ── Hàm chính ─────────────────────────────────────────────────────────────────

def iAm(self, message, data, userId, threadId, type):
    parts = (message.text or "").split()
    c     = self.prefix + self.rawCommand

    if len(parts) < 2:
        return _warn(self, _iAmHelp(c), data, userId, threadId, type)

    action = (parts[1] or "").strip().lower()
    arg    = (parts[2].lower() if len(parts) > 2 else "")

    # ── Toggle helper ────────────────────────────────────────────────────────
    def Toggle(key, onMsg, offMsg, init=None):
        s   = read_settings(self.uid) or {}
        cur = bool(s.get(key, False))
        e   = (not cur) if not arg else (True if arg == "on" else False if arg == "off" else None)
        if e is None:
            return
        s[key] = e
        write_settings(self.uid, s)
        if init:
            try: init()
            except Exception: pass
        return _ok(self, onMsg if e else offMsg, data, userId, threadId, type)

    # ── Các action ───────────────────────────────────────────────────────────

    if action == "friend":
        return Toggle(
            "autoAcceptFriend",
            "I'm friendly now",
            "I'm not friendly..",
            lambda: initCheckFriendRequests(self)
        )

    if action == "lazy":
        return Toggle(
            "undoMode",
            "I'm lazy to undo, send me /-heart to undo",
            "Uhhh, I'm focus :)"
        )

    if action == "ignore":
        return Toggle(
            "ignoreInvite",
            "I'm now ignore box invited to wait owner approve!",
            "I'm no longer ignore box invited to wait owner approve!"
        )

    if action == "vietnamese":
        return Toggle(
            "vi",
            "Tui là một người Việt Nam",
            "I'm still a Vietnamese but I wanna say English"
        )

    if action == "ghost":
        return Toggle(
            "ghostStatus",
            "I'm a ghost bot..!",
            "I'm not a ghost bot, just normally:3"
        )

    if action == "learn":
        Toggle(
            "imLearning",
            "I'm learning to says",
            "I'm lazy, will not learn anything now"
        )
        return

    # ── dontcare ─────────────────────────────────────────────────────────────
    if action == "dontcare":
        op  = arg if arg in ("add", "remove", "rm", "del", "toggle", "list", "clear") else "toggle"
        s   = read_settings(self.uid) or {}
        dc  = s.setdefault("dontCare", [])
        cur = {str(x) for x in dc if x}

        def Save():
            s["dontCare"] = [x for x in dc if x]
            write_settings(self.uid, s)

        if op == "list":
            if not dc:
                return
            out = ["Hated:", ""] + [f"{i}. {self.userName(uid)}" for i, uid in enumerate(dc, 1)]
            return _msg(self, "\n".join(out).strip(), data, userId, threadId, type)

        if op == "clear":
            if not dc:
                return
            s["dontCare"] = []
            write_settings(self.uid, s)
            return _ok(self, "Cleared hated", data, userId, threadId, type)

        uids = [str(x or "").strip() for x in (extractUids(data) or [])]
        uids = [x for x in uids if x]
        if not uids:
            return _warn(self, "No target", data, userId, threadId, type)

        added = removed = 0
        for uid in uids:
            has = uid in cur
            add = (op == "add")    or (op == "toggle" and not has)
            rm  = (op in ("remove", "rm", "del")) or (op == "toggle" and has)

            if add and not has:
                dc.append(uid); cur.add(uid); added += 1
            elif rm and has:
                cur.discard(uid)
                try: dc.remove(uid)
                except ValueError: pass
                removed += 1

        if added or removed:
            Save()

        if len(uids) == 1:
            uid  = uids[0]
            name = self.userName(uid)
            if added:   return _ok(self, f"I dont care {name} say anything", data, userId, threadId, type)
            if removed: return _ok(self, f"Listen to: {name}", data, userId, threadId, type)
            return _ok(self, f"Already my mind for {name} I wouldnt change anything!", data, userId, threadId, type)

        return _ok(self, f"Hmm, I think I should: don't care {added} and listen for {removed}", data, userId, threadId, type)

    # ── Không nhận ra action ─────────────────────────────────────────────────
    return _warn(self, _iAmHelp(c), data, userId, threadId, type)


# ── Đăng ký lệnh ─────────────────────────────────────────────────────────────

dependencies = {
    "name":        "im",
    "permission":  3,
    "cooldown":    3,
    "description": "My setting for bot",
    "main":        iAm,
}
