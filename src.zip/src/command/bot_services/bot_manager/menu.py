from app.core.index import *
from api.util.Enum import PermissionLevel, MsgStyle, ThreadType
from src.services.pillow.menuDraw import draw_menu, MAX_PER_PAGE
import os, math, threading, time

CACHE_DIR = "data/assets/cache/image"
Timeout   = 120

_GLOBAL_MENU_STATES: dict[str, dict] = {}

def _states(self) -> dict:
    """File menu.py có thể bị import 2 lần dưới 2 tên module khác nhau
    (loader động trong commandLoader vs import trực tiếp ở main.py),
    khiến mỗi bản có _states(self) riêng -> state lưu ở 1 bên,
    đọc ở bên kia không thấy. Lưu state trên `self` (instance bot,
    chung cho cả 2 module) để tránh tình trạng này."""
    states = getattr(self, "_menu_states", None)
    if states is None:
        states = _GLOBAL_MENU_STATES
        self._menu_states = states
    return states


def _build_cmd_list(config: dict) -> list[dict]:
    items = []
    for name, conf in sorted(config.items()):
        if not conf.get("status", True):
            continue
        items.append({
            "name":        name,
            "description": conf.get("description", ""),
            "permission":  conf.get("permission", 0),
            "alias":       conf.get("alias", []),
        })
    return items


def _parse_menu_arg(msg: str):
    msg = str(msg).strip().lower()

    if msg in ("out", "ok", "0", "thoat", "thoát"):
        return "exit", None

    parts = msg.split()
    if not parts:
        return None, None

    first = parts[0]

    if first == "next":
        if len(parts) >= 2 and parts[1].isdigit():
            return "next", int(parts[1])
        return "next", None

    if first in ("prev", "back"):
        return "prev", None

    if first.isdigit():
        return "goto", int(first)

    return None, None

def _strip_mention(self, MessageObj, Data) -> str:
    try:
        from app.module.commandLoader import removeMention
        stripped = removeMention(self, Data)
        if stripped:
            return stripped
    except Exception:
        pass
    return MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)

def _send_page(self, page: int, state: dict, userId, threadId, threadType):
    items      = state["items"]
    total_page = state["total_page"]
    prefix     = state["prefix"]
    user_level = state["user_level"]
    bot_name   = getattr(self, "bot", "Bot")
    user_name  = self.userName(userId)
    bg_url     = state.get("bg_url")  # custom background URL

    chunk    = items[(page - 1) * MAX_PER_PAGE : page * MAX_PER_PAGE]
    out_path = os.path.join(CACHE_DIR,
                            f"menu_{self.uid}_{threadId}_u{userId}_p{page}.jpg")

    os.makedirs(CACHE_DIR, exist_ok=True)
    w, h = draw_menu(
        chunk, out_path,
        page=page, total_page=total_page,
        prefix=prefix, user_level=user_level,
        bot_name=bot_name,
        bg_url=bg_url,
    )

    nav_parts = []
    if page < total_page:
        nav_parts.append(f"next / next {page + 1}")
    if page > 1:
        nav_parts.append("prev")
    nav_parts.append("out/ok")
    nav_hint = "  |  ".join(nav_parts)

    cap_text = (
        f"{user_name}\n"
        f"• Page {page}/{total_page}"
    )
    mention = Mention(userId, offset=0, length=len(user_name))
    caption = Message(text=cap_text, mention=mention)

    from api.util import utilzone
    cli_id = int(utilzone.now() - 1000)
    try:
        uploadImage = self._uploadImage(out_path, threadId, threadType)
        custom_payload = {
            "params": {
                "photoId":  uploadImage.get("photoId", int(utilzone.now() * 2)),
                "clientId": uploadImage.get("clientFileId", cli_id),
                "desc":     caption.text if caption else "",
                "width":    w,
                "height":   h,
                "rawUrl":   uploadImage["normalUrl"],
                "thumbUrl": uploadImage["thumbUrl"],
                "hdUrl":    uploadImage["hdUrl"],
                "thumbSize": "53932",
                "fileSize":  "247671",
                "hdSize":    "344622",
                "zsource": -1,
                "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                "ttl": 0,
                "imei": self._imei,
            }
        }
        if caption and caption.mention:
            custom_payload["params"]["mentionInfo"] = caption.mention

        if threadType == ThreadType.USER:
            custom_payload["params"]["toid"]     = str(threadId)
            custom_payload["params"]["normalUrl"] = uploadImage["normalUrl"]
        else:
            custom_payload["params"]["grid"]   = str(threadId)
            custom_payload["params"]["oriUrl"] = uploadImage["normalUrl"]

        cli_id = custom_payload["params"]["clientId"]
        resp = self.sendLocalImage(out_path, threadId, threadType,
                                   width=w, height=h, message=caption,
                                   custom_payload=custom_payload)
    except Exception:
        resp = self.sendLocalImage(out_path, threadId, threadType,
                                   width=w, height=h, message=caption)

    try:
        if not getattr(resp, "clientId", None):
            resp["clientId"] = cli_id
    except Exception:
        pass

    try:
        os.remove(out_path)
    except Exception:
        pass

    return resp

def _menu_key(userId, threadId) -> str:
    return f"{userId}:{threadId}"

def _del_menu_msg(self, state: dict):
    try:
        msg_id = state.get("msgId")
        cli_id = state.get("clientId")
        t_id   = state.get("threadId")
        t_type = state.get("typeGr")
        if not (msg_id and cli_id and t_id):
            return

        if t_type == ThreadType.GROUP:
            self.deleteMessage(msg_id, self.uid, cli_id, t_id)
        else:
            self.undoMessage(msg_id, cli_id, t_id, t_type)
    except Exception as e:
        logger.errorw(f"_del_menu_msg error: {e} | state={state.get('msgId')},{state.get('clientId')},{state.get('threadId')},{state.get('typeGr')}")

def InitTimeoutMenu(self, interval=1):
    def Loop():
        while True:
            now = time.time()
            for key, state in list(_states(self).items()):
                if now - state["time"] > Timeout:
                    _del_menu_msg(self, state)
                    _states(self).pop(key, None)
                    try:
                        uid_part = key.split(":")[0]
                        self.sendMentionStyle(
                            "Menu đã hết hạn, gọi lại để xem nhé.",
                            uid_part,
                            state["threadId"],
                            state["typeGr"],
                        )
                    except Exception:
                        pass
            time.sleep(interval)

    threading.Thread(target=Loop, daemon=True).start()

def menuCommand(self, message, data, userId, threadId, type):
    try:
        msg_text = (message.text if hasattr(message, "text") else str(message)).strip()
        args     = msg_text.split()
        sub      = args[1].lower() if len(args) > 1 else ""

        # ── menu set bgrd=(url) | menu set bgrd=md ──────────────────
        if sub == "set":
            if len(args) < 3:
                self.replyMessageStyle(
                    "Cú pháp: menu set bgrd=(url) hoặc menu set bgrd=md",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return
            third = args[2]
            if not third.lower().startswith("bgrd="):
                self.replyMessageStyle(
                    "Cú pháp: menu set bgrd=(url) hoặc menu set bgrd=md",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return

            user_level = self.permissionLevel(userId, threadId)
            if user_level < 3:
                self.replyMessageStyle(
                    "Bạn không có quyền dùng lệnh này (cần cấp 3+).",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return

            value = third[len("bgrd="):]
            settings = read_settings(self.uid)

            if value.lower() == "md":
                settings.pop("menu_bg_url", None)
                write_settings(self.uid, settings)
                self.replyMessageStyle(
                    "✅ Đã đặt lại nền menu về mặc định.",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value, title=MsgStyle.SUCCESS.title,
                )
            else:
                settings["menu_bg_url"] = value
                write_settings(self.uid, settings)
                self.replyMessageStyle(
                    f"✅ Đã lưu ảnh nền menu:\n{value}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value, title=MsgStyle.SUCCESS.title,
                )
            return
        # ─────────────────────────────────────────────────────────────

        config     = load_command_config(self.uid)
        user_level = self.permissionLevel(userId, threadId)
        items      = _build_cmd_list(config)
        total_page = math.ceil(len(items) / MAX_PER_PAGE) or 1
        prefix     = self.prefix

        # Lấy custom bg_url từ settings nếu có
        _settings = read_settings(self.uid)
        _bg_url   = _settings.get("menu_bg_url")

        if sub == "all":
            bot_name  = getattr(self, "bot", "Bot")
            user_name = self.userName(userId)
            groups: dict[int, list[str]] = {}
            for it in items:
                groups.setdefault(it["permission"], []).append(it["name"])

            section_names = {
                0: "user", 1: "group admin",
                2: "bot admin", 3: "high admin", 4: "developer"
            }

            lines = [f"List Command - {bot_name}", f"{user_name}  ·  Cấp: {PermissionLevel.label(user_level)}", ""]
            for lvl in range(5):
                cmds = groups.get(lvl, [])
                if not cmds:
                    continue
                locked = user_level < lvl
                marker = "🔒" if locked else "✅"
                label  = section_names.get(lvl, str(lvl)).capitalize()
                lines.append(f"{marker} {label}:")
                lines.append(" - ".join(cmds))
                lines.append("")

            lines.append(f"Total: {len(items)} commands")

            mention = Mention(userId, offset=0, length=len(user_name))
            caption = Message(text="\n".join(lines), mention=mention)
            self.replyMessageStyle(
                "\n".join(lines), data, threadId, type,
                color=MsgStyle.INFO.value, title="LIST COMMAND",
            )
            return


        if sub.isdigit():
            req_page = int(sub)
            if req_page < 1 or req_page > total_page:
                self.sendMentionStyle(
                    f"err: page {req_page} not found",
                    userId, threadId, type,
                )
                return
            page = req_page
        else:
            page = 1

        key = _menu_key(userId, threadId)
        old = _states(self).get(key)
        if old:
            _del_menu_msg(self, old)
            _states(self).pop(key, None)

        state = {
            "page":       page,
            "total_page": total_page,
            "items":      items,
            "prefix":     prefix,
            "user_level": user_level,
            "bg_url":     _bg_url,
            "msgId":      None,
            "clientId":   None,
            "threadId":   threadId,
            "typeGr":     type,
            "time":       time.time(),
        }

        self.sendReaction(data, "/-ok", threadId, type, 100000000)
        resp = _send_page(self, page, state, userId, threadId, type)

        msg_id = getattr(resp, "msgId", None)
        cli_id = getattr(resp, "clientId", None) or getattr(resp, "cliMsgId", None)

        if not msg_id:
            return

        state["msgId"]    = msg_id
        state["clientId"] = cli_id
        _states(self)[key] = state

    except Exception as e:
        logger.errorw(f"menu error: {e}")
        self.replyMessageStyle(
            f"Lỗi hiển thị menu: {e}", data, threadId, type,
            color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
        )

def MenuReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Bỏ qua các tin nhắn TỰ ĐỘNG do bot gửi (ảnh menu, reaction...).
    # Không bỏ qua tin nhắn dạng text dù UserId == self.uid, vì với self-bot
    # tài khoản chủ bot và bot là MỘT, nên next/out/... của chủ bot cũng có
    # UserId == self.uid và vẫn phải được xử lý.
    if str(UserId) == str(self.uid) and not isinstance(MessageObj, str):
        return

    key   = _menu_key(UserId, ThreadId)
    state = _states(self).get(key)
    if not state:
        return

    elapsed = time.time() - state["time"]
    if elapsed > Timeout:
        _del_menu_msg(self, state)
        _states(self).pop(key, None)
        return

    Msg    = _strip_mention(self, MessageObj, Data)
    action, target_page = _parse_menu_arg(Msg)

    if action is None:
        return

    total_page = state["total_page"]
    cur_page   = state["page"]

    if action == "exit":
        _del_menu_msg(self, state)
        _states(self).pop(key, None)
        self.sendMentionStyle("Đã thoát menu.", UserId, ThreadId, ThreadType)
        self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
        return

    if action == "next":
        if target_page is not None:
            if target_page < 1 or target_page > total_page:
                self.sendMentionStyle(
                    f"err: page {target_page} not found",
                    UserId, ThreadId, ThreadType,
                )
                return
            page = target_page
        else:
            page = cur_page + 1

        if page > total_page:
            self.sendMentionStyle(
                f"Đây là trang cuối rồi ({cur_page}/{total_page}).",
                UserId, ThreadId, ThreadType,
            )
            return

        if page == cur_page:
            self.sendMentionStyle(
                f"Bạn đang ở trang {cur_page} rồi.",
                UserId, ThreadId, ThreadType,
            )
            return

        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

    if action == "prev":
        page = cur_page - 1
        if page < 1:
            self.sendMentionStyle(
                f"Đây là trang đầu rồi (1/{total_page}).",
                UserId, ThreadId, ThreadType,
            )
            return
        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

    if action == "goto":
        if target_page < 1 or target_page > total_page:
            self.sendMentionStyle(
                f"err: page {target_page} not found",
                UserId, ThreadId, ThreadType,
            )
            return
        page = target_page
        if page == cur_page:
            self.sendMentionStyle(
                f"Bạn đang ở trang {cur_page} rồi.",
                UserId, ThreadId, ThreadType,
            )
            return
        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

def _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType):
    _del_menu_msg(self, state)

    state["page"]     = page
    state["time"]     = time.time()
    state["msgId"]    = None
    state["clientId"] = None

    self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
    resp = _send_page(self, page, state, UserId, ThreadId, ThreadType)

    msg_id = getattr(resp, "msgId", None)
    cli_id = getattr(resp, "clientId", None) or getattr(resp, "cliMsgId", None)

    if not msg_id:
        _states(self).pop(key, None)
        return

    state["msgId"]    = msg_id
    state["clientId"] = cli_id
    _states(self)[key] = state

dependencies = {
    "name":        "menu",
    "permission":  0,
    "cooldown":    5,
    "description": "Hiển thị danh sách lệnh",
    "alias":       ["help"],
    "main":        menuCommand,
}