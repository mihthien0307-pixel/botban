from app.core.index import *
from src.services.pillow.drawModList import draw_mod_list
import threading, os

# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _send_ok(this, text, data, threadId, type):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS")

def _send_warn(this, text, data, threadId, type):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING")

def _send_fail(this, text, data, threadId, type):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR")

def _send_info(this, text, data, threadId, type, title="MOD"):
    this.replyMessageStyle(text, data, threadId, type, color="or", title=title)


def _help(p, c):
    return (
        f"╔══ ACCOUNT MODIFIER ══╗\n\n"
        f"  📍 {p}{c} fr              - Danh sách bạn bè\n"
        f"  📍 {p}{c} grp             - Danh sách nhóm đã tham gia\n"
        f"  📍 {p}{c} leave <số>      - Rời nhóm theo số thứ tự từ .mod grp\n"
        f"  📍 {p}{c} bmemm [groupId] - Thành viên bị chặn\n\n"
        f"╚══════════════════════╝\n"
        f"Nếu không nhập groupId sẽ dùng nhóm hiện tại."
    )


# ═══════════════════════════════════════════════════════════
# Sub: Friends list (Canvas)
# ═══════════════════════════════════════════════════════════

def _cmd_fr(this, data, threadId, type):
    try:
        friends = this.fetchAllFriends()
    except Exception as e:
        return _send_fail(this, f"Lấy danh sách bạn bè thất bại: {e}", data, threadId, type)

    if not friends:
        return _send_warn(this, "Tài khoản chưa có bạn bè.", data, threadId, type)

    items = []
    for u in friends:
        uid  = str(getattr(u, "userId", None) or getattr(u, "uid", "?"))
        name = getattr(u, "displayName", None) or getattr(u, "zaloName", None) or uid
        avt  = getattr(u, "avatar", None) or getattr(u, "avatarUrl", None) or ""
        items.append({"name": name, "sub": f"ID: {uid}", "avatar": avt})

    out = f"data/assets/cache/image/mod_fr_{threadId}.png"
    os.makedirs("data/assets/cache/image", exist_ok=True)
    path, w, h = draw_mod_list(
        title    = "Danh Sách Bạn Bè",
        subtitle = f"Account Friends  •  {len(items)} người",
        items    = items,
        out_path = out,
        mode     = "fr",
    )
    this.sendLocalImage(path, threadId, type, width=w, height=h, ttl=120000)


# ═══════════════════════════════════════════════════════════
# Sub: Groups list (Canvas)
# ═══════════════════════════════════════════════════════════

def _cmd_grp(this, data, threadId, type):
    try:
        result = this.fetchAllGroups()
    except Exception as e:
        return _send_fail(this, f"Lấy danh sách nhóm thất bại: {e}", data, threadId, type)

    group_ids = []
    if hasattr(result, "gridVerMap"):
        gmap = result.gridVerMap or {}
        group_ids = list(gmap.keys())
    elif isinstance(result, dict):
        gmap = result.get("gridVerMap") or result.get("data") or {}
        if isinstance(gmap, dict):
            group_ids = list(gmap.keys())
        elif isinstance(gmap, list):
            group_ids = gmap

    if not group_ids:
        return _send_warn(this, "Tài khoản chưa tham gia nhóm nào.", data, threadId, type)

    import re as _re
    items = [None] * len(group_ids)
    def _fetch_grp(i, gid):
        gname, avt = str(gid), ""
        try:
            gi   = this.fetchGroupInfo(str(gid))
            gmap = getattr(gi, "gridInfoMap", {}) or {}
            info = gmap.get(str(gid)) or {}
            if not isinstance(info, dict):
                info = dict(info) if info else {}
            gname = info.get("name") or this.groupInfo(str(gid)) or str(gid)
            raw_avt = (info.get("avt") or info.get("avatar") or
                       info.get("fullAvt") or info.get("avatarUrl") or "")
            if raw_avt:
                raw_avt = _re.sub(r'[?&][whs]=\d+', '', raw_avt)
                raw_avt = _re.sub(r'[?&]size=\d+', '', raw_avt)
                raw_avt = _re.sub(r'/w\d+/', '/w2048/', raw_avt)
                raw_avt = raw_avt.rstrip('?&')
            avt = raw_avt
        except Exception:
            pass
        items[i] = {"name": gname, "sub": f"ID: {gid}", "avatar": avt}
    threads = [threading.Thread(target=_fetch_grp, args=(i, gid), daemon=True)
               for i, gid in enumerate(group_ids)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=15)
    items = [x for x in items if x]

    out = f"data/assets/cache/image/mod_grp_{threadId}.png"
    os.makedirs("data/assets/cache/image", exist_ok=True)
    path, w, h = draw_mod_list(
        title    = "Danh Sách Nhóm",
        subtitle = f"Account Groups  •  {len(items)} nhóm",
        items    = items,
        out_path = out,
        mode     = "grp",
    )
    this.sendLocalImage(path, threadId, type, width=w, height=h, ttl=120000)


# ═══════════════════════════════════════════════════════════
# Sub: Blocked Members (Canvas)
# ═══════════════════════════════════════════════════════════

def _resolve_name(this, uid):
    """Lấy tên từ uid, fallback về uid nếu không được."""
    try:
        return this.userName(str(uid)) or str(uid)
    except Exception:
        return str(uid)


def _cmd_bmemm(this, parts, data, threadId, type):
    target_gid = parts[2].strip() if len(parts) >= 3 else str(threadId)

    try:
        result = this.get_blocked_members(target_gid)
    except Exception as e:
        return _send_fail(this, f"Lấy danh sách block thất bại: {e}", data, threadId, type)

    if not result.get("success"):
        return _send_fail(
            this,
            f"Lỗi #{result.get('error_code')}: {result.get('error_message')}",
            data, threadId, type
        )

    raw = result.get("blocked_members") or {}

    def _unwrap(d):
        if isinstance(d, dict) and "data" in d:
            return d["data"]
        return d

    raw = _unwrap(raw)

    uid_list = []

    def _extract_uids(obj):
        if isinstance(obj, list):
            for item in obj:
                if isinstance(item, dict):
                    uid = str(item.get("uid") or item.get("userId") or item.get("id") or "").strip()
                    if uid.endswith("_0"):
                        uid = uid[:-2]
                    if uid and uid.isdigit():
                        uid_list.append(uid)
                elif isinstance(item, str) and item.strip():
                    u = item.strip()
                    if u.endswith("_0"):
                        u = u[:-2]
                    if u.isdigit():
                        uid_list.append(u)
        elif isinstance(obj, dict):
            for v in obj.values():
                _extract_uids(v)

    _extract_uids(raw)
    seen = set()
    uid_list = [u for u in uid_list if not (u in seen or seen.add(u))]

    if not uid_list:
        import json as _json
        try:
            debug_str = _json.dumps(raw, ensure_ascii=False)[:300]
        except Exception:
            debug_str = str(raw)[:300]
        return _send_info(
            this,
            f"Nhóm {target_gid} không có thành viên bị chặn.\n[debug raw]: {debug_str}",
            data, threadId, type, title="BLOCKED MEMBERS"
        )

    # Lấy tên + avatar song song
    items = [None] * len(uid_list)

    def _fetch_blocked(i, uid):
        name = _resolve_name(this, uid)
        avt = ""
        try:
            uinfo = this.fetchUserInfo(uid)
            umap = getattr(uinfo, "changed_profiles", None) or {}
            if isinstance(umap, dict):
                info = umap.get(uid) or umap.get(str(uid)) or {}
                if not isinstance(info, dict):
                    info = dict(info) if info else {}
                avt = (info.get("avatar") or info.get("avatarUrl") or
                       info.get("avt") or "")
        except Exception:
            pass
        items[i] = {"name": name, "sub": f"ID: {uid}", "avatar": avt}

    threads = [threading.Thread(target=_fetch_blocked, args=(i, uid), daemon=True)
               for i, uid in enumerate(uid_list)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=12)
    items = [x for x in items if x]

    out = f"data/assets/cache/image/mod_bmemm_{target_gid}.png"
    os.makedirs("data/assets/cache/image", exist_ok=True)
    path, w, h = draw_mod_list(
        title    = "Thành Viên Bị Chặn",
        subtitle = f"Blocked Members  •  Nhóm {target_gid}  •  {len(items)} người",
        items    = items,
        out_path = out,
        mode     = "blocked",
    )
    this.sendLocalImage(path, threadId, type, width=w, height=h, ttl=120000)


# ═══════════════════════════════════════════════════════════
# Sub: Leave group by index
# ═══════════════════════════════════════════════════════════

def _get_group_ids(this):
    try:
        result    = this.fetchAllGroups()
        group_ids = []
        if hasattr(result, "gridVerMap"):
            gmap = result.gridVerMap or {}
            group_ids = list(gmap.keys())
        elif isinstance(result, dict):
            gmap = result.get("gridVerMap") or result.get("data") or {}
            if isinstance(gmap, dict):
                group_ids = list(gmap.keys())
            elif isinstance(gmap, list):
                group_ids = list(gmap)
        return group_ids
    except Exception:
        return []


def _cmd_leave(this, parts, data, threadId, type):
    if len(parts) < 3 or not parts[2].strip().isdigit():
        p = getattr(this, "prefix", "")
        c = getattr(this, "rawCommand", "mod")
        return _send_warn(
            this,
            f"Nhập số thứ tự nhóm cần rời.\nVí dụ: {p}{c} leave 3",
            data, threadId, type
        )

    idx = int(parts[2].strip())
    group_ids = _get_group_ids(this)

    if not group_ids:
        return _send_fail(this, "Không lấy được danh sách nhóm.", data, threadId, type)

    if idx < 1 or idx > len(group_ids):
        return _send_fail(
            this,
            f"Số thứ tự không hợp lệ. Danh sách có {len(group_ids)} nhóm (1 → {len(group_ids)}).",
            data, threadId, type
        )

    target_gid  = str(group_ids[idx - 1])
    target_name = this.groupInfo(target_gid) or target_gid

    try:
        this.leaveGroup(target_gid, silent=True)
        _send_ok(
            this,
            f"Đã rời nhóm #{idx}: {target_name}",
            data, threadId, type
        )
    except Exception as e:
        _send_fail(this, f"Rời nhóm thất bại: {e}", data, threadId, type)


# ═══════════════════════════════════════════════════════════
# Main command
# ═══════════════════════════════════════════════════════════

def modCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split()
    p     = getattr(this, "prefix", "")
    c     = getattr(this, "rawCommand", "mod")

    if len(parts) < 2:
        return _send_warn(this, _help(p, c), data, threadId, type)

    sub = parts[1].lower().strip()

    if sub == "fr":      return _cmd_fr(this, data, threadId, type)
    if sub == "grp":     return _cmd_grp(this, data, threadId, type)
    if sub == "bmemm":   return _cmd_bmemm(this, parts, data, threadId, type)
    if sub == "leave":   return _cmd_leave(this, parts, data, threadId, type)

    return _send_warn(this, _help(p, c), data, threadId, type)


# ═══════════════════════════════════════════════════════════
# Dependencies
# ═══════════════════════════════════════════════════════════

dependencies = {
    "name":        "mod",
    "permission":  3,
    "cooldown":    5,
    "description": "Account Modifier – xem bạn bè, nhóm, thành viên, block, invite, join request",
    "main":        modCommand,
}
