from app.core.index import *
from src.services.utils.null_core import *
dependencies = {
    "name": "null",
    "permission": 3,
    "description": "No Description",
    "cooldown": 5,
    "main": UnknownCommand
}