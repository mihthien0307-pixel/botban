from app.core.index import *
from src.services.pillow.drawAdminList import draw_admin_list
import os, time

CACHE_DIR = "data/assets/cache/image"


def _get_scope_list(settings, scope, threadId):
    if scope == "dev":
        return None, "developer"
    if scope == "high":
        return settings.setdefault("highAdmin", []), "high admin"
    elif scope == "bot":
        return settings.setdefault("adminBot", []), "bot admin"
    elif scope == "group":
        return settings.setdefault("groupAdmin", {}).setdefault(threadId, []), "group admin"
    return None, None


def _scope_from_flag(parts):
    if "-d" in parts:
        return "dev"
    if "-h" in parts:
        return "high"
    if "-b" in parts:
        return "bot"
    if "-g" in parts:
        return "group"
    return None


def _get_avatar(self, uid: str) -> str | None:
    """Lấy avatar URL của uid, trả None nếu lỗi."""
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        return profile.get("avatar") or None
    except Exception:
        return None


def _build_sections(self, settings, threadId: str) -> list[tuple[str, list[dict]]]:
    """
    Xây danh sách các section theo cấp, lấy tên + avatar từng user.
    Trả về: [("Developer", [...]), ("High Admin", [...]), ...]
    """
    dev_admins   = list(dict.fromkeys(settings.get("developerAdmin", [])))
    high_admins  = [u for u in dict.fromkeys(settings.get("highAdmin", []))  if u not in dev_admins]
    bot_admins   = [u for u in dict.fromkeys(settings.get("adminBot",  []))  if u not in dev_admins and u not in high_admins]
    group_admins = [u for u in dict.fromkeys(settings.get("groupAdmin", {}).get(threadId, []))
                    if u not in dev_admins and u not in high_admins and u not in bot_admins]

    def _entries(uid_list):
        out = []
        for uid in uid_list:
            out.append({
                "name":   self.userName(uid),
                "avatar": _get_avatar(self, uid),
            })
        return out

    return [
        ("Developer",   _entries(dev_admins)),
        ("High Admin",  _entries(high_admins)),
        ("Bot Admin",   _entries(bot_admins)),
        ("Group Admin", _entries(group_admins)),
    ]


def whoamiPermission(self, message, data, userId, threadId, type):
    try:
        p     = self.prefix
        c     = self.rawCommand
        text  = message.text or ""
        parts = text.strip().split()

        settings = read_settings(self.uid)
        uids     = extractUids(data)

        if len(parts) == 1 or parts[1].lower() == "help":
            msg = (
                f"Dùng lệnh hợp lệ để quản lý admin trong bot.\n\n"
                f"Ví dụ:\n"
                f"  📍 {p}{c} list — xem danh sách admin.\n"
                f"  📍 {p}{c} add -h @user — thêm High Admin.\n"
                f"  📍 {p}{c} rm -g 2 — xoá Group Admin số 2.\n\n"
                f"Flag cấp bậc:\n"
                f"  -h  High Admin\n"
                f"  -b  Bot Admin\n"
                f"  -g  Group Admin\n"
                f"  -d  Developer (chỉ xem, không thể thêm/xoá)"
            )
            return self.replyMessageStyle(msg, data, threadId, type, color="yl", title="CAUTION", userId=userId)

        if parts[1].lower() == "list":
            text_mode = len(parts) >= 3 and parts[2].lower() == "text"

            dev_admins   = list(dict.fromkeys(settings.get("developerAdmin", [])))
            high_admins  = [u for u in dict.fromkeys(settings.get("highAdmin", []))  if u not in dev_admins]
            bot_admins   = [u for u in dict.fromkeys(settings.get("adminBot",  []))  if u not in dev_admins and u not in high_admins]
            group_admins = [u for u in dict.fromkeys(settings.get("groupAdmin", {}).get(threadId, []))
                            if u not in dev_admins and u not in high_admins and u not in bot_admins]

            if text_mode:
                # ── MODE TEXT (cũ) ────────────────────────────────────────────
                sections_txt = [
                    ("👑 Developer",   dev_admins),
                    ("⭐ High Admin",  high_admins),
                    ("🔧 Bot Admin",   bot_admins),
                    ("🛡️ Group Admin", group_admins),
                ]
                msg     = "📋 Danh sách Admin\n"
                has_any = False
                for title_sec, uid_list in sections_txt:
                    if not uid_list:
                        continue
                    has_any = True
                    msg += f"\n{title_sec}\n"
                    for i, uid in enumerate(uid_list, 1):
                        msg += f"  {i}. {self.userName(uid)}\n"
                if not has_any:
                    msg += "\n(Chưa có admin nào)"
                return self.replyMessageStyle(msg.strip(), data, threadId, type, color="gr", title="ADMIN LIST", userId=userId)

            try:
                sections = _build_sections(self, settings, threadId)
                has_any  = any(entries for _, entries in sections)

                if not has_any:
                    return self.replyMessageStyle(
                        "(Chưa có admin nào)", data, threadId, type,
                        color="yl", title="ADMIN LIST", userId=userId
                    )

                owner = None
                if sections[0][1]:
                    owner = {**sections[0][1][0], "role": "Developer"}

                os.makedirs(CACHE_DIR, exist_ok=True)
                out_path = os.path.join(
                    CACHE_DIR,
                    f"adminlist_{self.uid}_{threadId}_{int(time.time())}.jpg",
                )

                path, w, h = draw_admin_list(owner=owner, admins=[{**e, "role": role} for role, es in sections for e in es], out_path=out_path, source="Admin List")

                mention = Mention(userId, offset=0, length=len(self.userName(userId)))
                caption = Message(
                    text=f"{self.userName(userId)}\nDanh sách Admin",
                    mention=mention,
                )

                self.sendLocalImage(path, threadId, type, width=w, height=h, message=caption)

                try:
                    os.remove(path)
                except Exception:
                    pass

            except Exception as e:
                import traceback; traceback.print_exc()
                logger.errorw(f"whoami list draw error: {e}")
                # Fallback về text nếu vẽ lỗi
                sections_txt = [
                    ("👑 Developer",   dev_admins),
                    ("⭐ High Admin",  high_admins),
                    ("🔧 Bot Admin",   bot_admins),
                    ("🛡️ Group Admin", group_admins),
                ]
                msg = "📋 Danh sách Admin\n"
                for title_sec, uid_list in sections_txt:
                    if not uid_list:
                        continue
                    msg += f"\n{title_sec}\n"
                    for i, uid in enumerate(uid_list, 1):
                        msg += f"  {i}. {self.userName(uid)}\n"
                return self.replyMessageStyle(msg.strip(), data, threadId, type, color="gr", title="ADMIN LIST", userId=userId)

            return

        if parts[1].lower() == "add":
            scope = _scope_from_flag(parts)
            if not scope:
                return self.replyMessageStyle(
                    "Thiếu flag: dùng -h, -b hoặc -g", data, threadId, type, color="r", title="ERROR", userId=userId
                )
            if scope == "dev":
                return self.replyMessageStyle(
                    "⛔ Không thể add vào cấp Developer — cấp này chỉ dành cho main bot.",
                    data, threadId, type, color="r", title="ERROR", userId=userId
                )
            if not uids:
                return self.replyMessageStyle(
                    "Cần @mention người cần thêm", data, threadId, type, color="r", title="ERROR", userId=userId
                )

            admins, scope_name = _get_scope_list(settings, scope, threadId)
            added = []
            for uid in uids:
                if uid not in admins:
                    admins.append(uid)
                    added.append(self.userName(uid))

            write_settings(self.uid, settings)

            if added:
                return self.replyMessageStyle(
                    f"Đã thêm vào {scope_name}:\n" + "\n".join(f"• {n}" for n in added),
                    data, threadId, type, color="gr", title="SUCCESS", userId=userId
                )
            return self.replyMessageStyle(
                "Đã tồn tại trong danh sách", data, threadId, type, color="yl", title="WARNING", userId=userId
            )

        if parts[1].lower() in ("remove", "rm"):
            scope = _scope_from_flag(parts)
            if not scope:
                return self.replyMessageStyle(
                    "Thiếu flag: dùng -h, -b hoặc -g", data, threadId, type, color="r", title="ERROR", userId=userId
                )
            if scope == "dev":
                return self.replyMessageStyle(
                    "⛔ Không thể xoá khỏi cấp Developer.",
                    data, threadId, type, color="r", title="ERROR", userId=userId
                )

            admins, scope_name  = _get_scope_list(settings, scope, threadId)
            protected_uids      = set(settings.get("main_protected_admins", []))

            nums = [p for p in parts if p.isdigit()]
            if nums and not uids:
                idx = int(nums[0]) - 1
                if 0 <= idx < len(admins):
                    target_uid = admins[idx]
                    if not self.is_main_bot and target_uid in protected_uids:
                        return self.replyMessageStyle(
                            f"⛔ Không thể xoá {self.userName(target_uid)} khỏi {scope_name}.\n"
                            f"Đây là high admin được bảo vệ bởi main bot.",
                            data, threadId, type, color="r", title="ERROR", userId=userId
                        )
                    removed_name = self.userName(admins.pop(idx))
                    write_settings(self.uid, settings)
                    return self.replyMessageStyle(
                        f"Đã xoá {removed_name} khỏi {scope_name}",
                        data, threadId, type, color="gr", title="SUCCESS", userId=userId
                    )
                return self.replyMessageStyle(
                    f"Số thứ tự không hợp lệ (1–{len(admins)})",
                    data, threadId, type, color="r", title="ERROR", userId=userId
                )

            if uids:
                removed, not_found, blocked = [], [], []
                for uid in uids:
                    if not self.is_main_bot and uid in protected_uids:
                        blocked.append(self.userName(uid))
                        continue
                    if uid in admins:
                        admins.remove(uid)
                        removed.append(self.userName(uid))
                    else:
                        not_found.append(self.userName(uid))

                if not blocked or removed or not_found:
                    write_settings(self.uid, settings)

                msg = ""
                if blocked:
                    msg += "⛔ Không thể xoá (được main bot bảo vệ):\n" + "\n".join(f"• {n}" for n in blocked)
                if removed:
                    msg += ("\n" if msg else "") + f"Đã xoá khỏi {scope_name}:\n" + "\n".join(f"• {n}" for n in removed)
                if not_found:
                    msg += ("\n" if msg else "") + "Không tìm thấy:\n" + "\n".join(f"• {n}" for n in not_found)

                color = "r" if (blocked and not removed) else ("gr" if removed else "yl")
                title = "ERROR" if (blocked and not removed) else ("SUCCESS" if removed else "WARNING")
                return self.replyMessageStyle(msg.strip(), data, threadId, type, color=color, title=title, userId=userId)

            return self.replyMessageStyle(
                "Cần @mention hoặc số thứ tự để xoá", data, threadId, type, color="r", title="ERROR", userId=userId
            )

        return self.replyMessageStyle(
            "Lệnh không hợp lệ.",
            data, threadId, type, color="r", title="ERROR", userId=userId
        )

    except Exception as e:
        import traceback; traceback.print_exc()
        return self.replyMessageStyle("error", data, threadId, type, color="r", title="ERROR", userId=userId)


dependencies = {
    "name":        "admin",
    "permission":  3,
    "cooldown":    3,
    "description": "admin manager",
    "main":        whoamiPermission,
}