from app.core.index import *
from src.services.index import *
from api.util.Enum import MsgStyle

def botm(self, bots, data):
    uids = extractUids(data)
    if not uids:
        return None

    uid = str(uids[0])
    mention_name = self.userName(uid).strip().lower()

    for bot in bots:
        if bot.get("username", "").strip().lower() == mention_name:
            return bot
    return None

def restartCommand(self, message, data, userId, threadId, type):
    try:
        text  = message.text or ""
        parts = text.strip().split()

        data_config = load_json(logindb)
        bots        = data_config.get("data", [])
        uids        = extractUids(data)

        def ok(msg):
            self.replyMessageStyle(msg, data, threadId, type,
                                   color=MsgStyle.SUCCESS.value,
                                   title=MsgStyle.SUCCESS.name,
                                   userId=userId)

        def warn(msg):
            self.replyMessageStyle(msg, data, threadId, type,
                                   color=MsgStyle.WARNING.value,
                                   title=MsgStyle.WARNING.name,
                                   userId=userId)

        def err(msg):
            self.replyMessageStyle(msg, data, threadId, type,
                                   color=MsgStyle.ERROR.value,
                                   title=MsgStyle.ERROR.name,
                                   userId=userId)

        if len(parts) > 1 and parts[-1].lower() == "os":
            if not self.is_main_bot:
                return
            save_restart_thread(threadId)
            warn("Restarting system...")
            os.execv(sys.executable, [sys.executable] + sys.argv)

        if uids:
            if not self.is_main_bot:
                return

            bot = botm(self, bots, data)
            if not bot or bot.get("is_main"):
                return err("I dont see ur mention id")

            restart_single_bot(bot)
            return ok(f"Restarted bot {bot.get('username')} successfully")

        if len(parts) > 1 and parts[-1].isdigit():
            if not self.is_main_bot:
                return

            idx        = int(parts[-1]) - 1
            valid_bots = [b for b in bots if not b.get("is_main")]

            if idx < 0 or idx >= len(valid_bots):
                return err("Invalid bot index")

            bot = valid_bots[idx]
            restart_single_bot(bot)
            return ok(f"Restarted bot {idx+1}: {bot.get('username')}")

        mybot = next(
            (b for b in bots if str(b.get("author_id")) == str(userId)),
            None
        )

        if not mybot:
            return err("I dont know ur bot")

        restart_single_bot(mybot)
        return ok("Restarted your bot successfully")

    except Exception as e:
        logger.error(f"Restart error: {e}")
        self.replyMessageStyle(
            "Đã xảy ra lỗi",
            data, threadId, type,
            color=MsgStyle.ERROR.value,
            title=MsgStyle.ERROR.name,
            userId=userId
        )

dependencies = {
    "name":        "restart",
    "permission":  3,
    "description": "Restart bot, program",
    "cooldown":    5,
    "main":        restartCommand
}