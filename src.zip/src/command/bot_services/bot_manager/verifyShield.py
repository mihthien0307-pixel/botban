"""
verifyShield.py – Verify Shield cho zbot
"""
import random
import time
import threading
import re
from app.core.index import *

VERIFY_KEY     = "verifyShield"
VERIFY_TIMEOUT = 180   # giây để nhập mã
VERIFY_MAX_TRY = 5     # sai quá 5 lần → kick
VERIFY_WINDOW  = 10


def _gen_token():
    a = "".join(random.choice("0123456789") for _ in range(8))
    b = "".join(random.choice("0123456789") for _ in range(6))
    return f"{a}-{b}-?verifyCaptcha"


def _send_to_group(self, tid, text):
    """Gửi tin vào nhóm (không reply)."""
    try:
        from api.util.msg import Message as _Msg
        self.send(_Msg(text=text), tid, ThreadType.GROUP)
    except Exception:
        pass


def _send_to_user(self, uid, text):
    """Gửi DM cho user."""
    try:
        from api.util.msg import Message as _Msg
        self.send(_Msg(text=text), uid, ThreadType.USER)
    except Exception:
        pass


def _kick(self, uid, tid):
    try:
        self.kickUsers([uid], tid)
    except Exception:
        pass


# ──────────────────────────────────────────────
# Hook gọi khi JOIN
# ──────────────────────────────────────────────
def handle_verify_join(self, eventData):
    try:
        tid = str(getattr(eventData, "groupId", "") or "")
        if not tid:
            return

        s = read_settings(self.uid)
        if tid not in (s.get("verifyOn", []) or []):
            return

        v = s.setdefault(VERIFY_KEY, {})
        g = v.setdefault(tid, {})

        # updateMembers là list dict {"id":..., "dName":..., "avatar":...}
        members = getattr(eventData, "updateMembers", None) or []
        if not members:
            return

        now       = time.time()
        silentMap = s.setdefault("silent", {}).setdefault("group", {}).setdefault(tid, {})
        multi     = len(members) >= 2

        # Token chung nếu nhiều người join cùng lúc
        shared_token = ""
        if multi:
            session = g.get("@session")
            if not isinstance(session, dict) or (now - float(session.get("ts") or 0)) > VERIFY_WINDOW:
                shared_token = _gen_token()
                g["@session"] = {"t": shared_token, "ts": now, "sent": 0}
            shared_token = str(g.get("@session", {}).get("t") or "")
        else:
            g.pop("@session", None)

        joined = []
        for m in members:
            uid = str(m.get("id") if isinstance(m, dict) else getattr(m, "id", ""))
            if not uid or uid == str(self.uid):
                continue
            p = g.get(uid)
            if isinstance(p, dict) and int(p.get("ok") or 0):
                continue
            token = shared_token if multi else _gen_token()
            g[uid] = {"t": token, "ts": now, "try": 0, "ok": 0}
            silentMap[uid] = {"until": 0, "by": str(self.uid), "at": now}
            joined.append(uid)

        v[tid] = g
        s[VERIFY_KEY] = v
        write_settings(self.uid, s)

        if not joined:
            return

        if multi:
            session = g.get("@session") or {}
            if (now - float(session.get("sent") or 0)) > VERIFY_WINDOW:
                session["sent"] = now
                g["@session"]   = session
                v[tid]          = g
                s[VERIFY_KEY]   = v
                write_settings(self.uid, s)
                _send_to_group(self, tid,
                    f"⚠️ VERIFY SHIELD\nBạn cần gửi đúng mã sau để xác minh:\n{shared_token}")
            for uid in joined:
                _send_to_user(self, uid,
                    f"⚠️ VERIFY SHIELD\nGửi đúng mã này vào nhóm để vào:\n{shared_token}")
        else:
            uid   = joined[0]
            token = str(g.get(uid, {}).get("t") or "")
            _send_to_group(self, tid,
                f"⚠️ VERIFY SHIELD\nThành viên mới cần gửi đúng mã:\n{token}")
            _send_to_user(self, uid,
                f"⚠️ VERIFY SHIELD\nGửi đúng mã này vào nhóm để vào:\n{token}")

        _schedule_verify_timeout(self, tid, list(joined))

    except Exception as e:
        logger.error(f"[verifyShield] handle_verify_join error: {e}")


def _schedule_verify_timeout(self, tid, uids):
    def check():
        time.sleep(VERIFY_TIMEOUT + 5)
        try:
            s = read_settings(self.uid)
            v = s.get(VERIFY_KEY, {})
            g = v.get(tid, {})
            for uid in uids:
                p = g.get(uid)
                if isinstance(p, dict) and not int(p.get("ok") or 0):
                    _kick(self, uid, tid)
                    g.pop(uid, None)
            _cleanup(v, g, tid)
            s[VERIFY_KEY] = v
            write_settings(self.uid, s)
        except Exception:
            pass
    threading.Thread(target=check, daemon=True).start()


def _cleanup(v, g, tid):
    alive = any(
        isinstance(pv, dict) and not int(pv.get("ok") or 0)
        for k, pv in g.items() if k != "@session"
    )
    if not alive:
        g.pop("@session", None)
        v.pop(tid, None)
    else:
        v[tid] = g


# ──────────────────────────────────────────────
# Hook kiểm tra mã verify khi nhận tin nhắn
# ──────────────────────────────────────────────
def handle_verify_msg(self, message, data, userId, threadId, type):
    try:
        if getattr(data, "msgType", None) == "chat.reaction":
            return

        tid    = str(threadId)
        fromId = str(getattr(data, "uidFrom", None) or userId)

        s = read_settings(self.uid)
        if tid not in (s.get("verifyOn", []) or []):
            return

        v = s.get(VERIFY_KEY)
        if not isinstance(v, dict):
            return
        g = v.get(tid)
        if not isinstance(g, dict):
            return
        p = g.get(fromId)
        if not isinstance(p, dict) or int(p.get("ok") or 0):
            return

        silentMap = s.setdefault("silent", {}).setdefault("group", {}).setdefault(tid, {})
        now   = time.time()
        ts    = float(p.get("ts") or 0)
        token = str(p.get("t") or "").strip()
        raw   = str(getattr(message, "text", message) or "").strip()

        # Hết timeout → cấp mã mới
        if ts and (now - ts) > VERIFY_TIMEOUT:
            new_token  = _gen_token()
            p["t"]     = new_token
            p["ts"]    = now
            p["try"]   = int(p.get("try") or 0)
            p["ok"]    = 0
            g[fromId]  = p
            v[tid]     = g
            s[VERIFY_KEY] = v
            silentMap[fromId] = {"until": 0, "by": str(self.uid), "at": now}
            write_settings(self.uid, s)
            _send_to_group(self, tid,
                f"⏰ Mã verify đã hết hạn.\nMã mới: {new_token}")
            _send_to_user(self, fromId,
                f"⏰ Mã verify đã hết hạn.\nMã mới: {new_token}")
            _try_delete(self, data, tid)
            return

        # Trích token từ nội dung
        m   = re.search(r"\d{8}-\d{6}-\?verifyCaptcha", raw)
        inp = m.group(0) if m else raw

        if token and (inp == token or token in inp):
            # ✅ Đúng mã
            silentMap.pop(fromId, None)
            g.pop(fromId, None)
            _cleanup(v, g, tid)
            s[VERIFY_KEY] = v
            write_settings(self.uid, s)
            _send_to_group(self, tid, "✅ Verify thành công! Chào mừng bạn vào nhóm.")
            _try_delete(self, data, tid)
            return

        # ❌ Sai mã
        p["try"] = int(p.get("try") or 0) + 1
        tries    = int(p["try"])
        g[fromId] = p
        v[tid]    = g
        s[VERIFY_KEY] = v
        write_settings(self.uid, s)
        _try_delete(self, data, tid)

        if tries >= VERIFY_MAX_TRY:
            # Quá 5 lần → kick
            _kick(self, fromId, tid)
            g.pop(fromId, None)
            silentMap.pop(fromId, None)
            _cleanup(v, g, tid)
            s[VERIFY_KEY] = v
            write_settings(self.uid, s)
            _send_to_group(self, tid,
                f"🚫 Nhập sai mã {VERIFY_MAX_TRY} lần. Đã kick thành viên.")
        else:
            remain = VERIFY_MAX_TRY - tries
            _send_to_group(self, tid,
                f"❌ Sai mã verify. Còn {remain} lần thử.")

    except Exception as e:
        logger.error(f"[verifyShield] handle_verify_msg error: {e}")


def _try_delete(self, data, tid):
    try:
        self.deleteMessage(
            data.msgId,
            getattr(data, "uidFrom", self.uid),
            data.cliMsgId,
            tid,
        )
    except Exception:
        pass


# ──────────────────────────────────────────────
# Command .verify on/off / --flag / --unflag
# ──────────────────────────────────────────────
def verifyCommand(self, message, data, userId, threadId, type):
    try:
        parts    = (message.text or "").strip().split()
        s        = read_settings(self.uid)
        verifyOn = s.setdefault("verifyOn", [])
        tid      = str(threadId)
        enabled  = tid in verifyOn

        if len(parts) >= 2 and parts[1] == "--flag":
            uids = extractUids(data)
            if not uids:
                self.replyMessageStyle(
                    f"Dùng: {self.prefix}{self.rawCommand} --flag @User",
                    data, threadId, type, color="yl", title="USAGE")
                return
            v         = s.setdefault(VERIFY_KEY, {})
            g         = v.setdefault(tid, {})
            silentMap = s.setdefault("silent", {}).setdefault("group", {}).setdefault(tid, {})
            now = time.time()
            for uid in [str(u) for u in uids if str(u) != str(self.uid)]:
                if isinstance(g.get(uid), dict) and int(g[uid].get("ok") or 0):
                    continue
                token = _gen_token()
                g[uid] = {"t": token, "ts": now, "try": 0, "ok": 0}
                silentMap[uid] = {"until": 0, "by": str(userId), "at": now}
                _send_to_group(self, tid,
                    f"⚠️ VERIFY FLAG\nUser phải gửi đúng mã:\n{token}")
            v[tid] = g; s[VERIFY_KEY] = v
            write_settings(self.uid, s)
            return

        if len(parts) >= 2 and parts[1] == "--unflag":
            uids = extractUids(data)
            if not uids:
                self.replyMessageStyle(
                    f"Dùng: {self.prefix}{self.rawCommand} --unflag @User",
                    data, threadId, type, color="yl", title="USAGE")
                return
            v  = s.get(VERIFY_KEY, {})
            g  = v.get(tid, {})
            sg = s.get("silent", {}).get("group", {}).get(tid, {})
            n  = sum(1 for uid in [str(u) for u in uids] if g.pop(uid, None) or sg.pop(uid, None))
            _cleanup(v, g, tid)
            s[VERIFY_KEY] = v
            write_settings(self.uid, s)
            if n:
                self.replyMessageStyle(f"Đã gỡ verify {n} user.", data, threadId, type,
                                       color="gr", title="UNFLAG")
            return

        # Toggle on/off
        if len(parts) < 2:
            enabled = not enabled
        elif parts[1].lower() == "on":
            enabled = True
        elif parts[1].lower() == "off":
            enabled = False
        else:
            return

        if enabled and tid not in verifyOn:
            verifyOn.append(tid)
        elif not enabled and tid in verifyOn:
            verifyOn.remove(tid)

        s["verifyOn"] = verifyOn
        write_settings(self.uid, s)
        self.replyMessageStyle(
            f"Verify Shield đã {'bật' if enabled else 'tắt'}.\n"
            f"{'Thành viên mới sẽ phải nhập mã captcha.' if enabled else ''}",
            data, threadId, type,
            color="gr" if enabled else "yl",
            title="VERIFY SHIELD",
        )

    except Exception as e:
        logger.error(f"verifyCommand error: {e}")


dependencies = {
    "name":        "verify",
    "permission":  3,
    "description": "Bật/Tắt Verify Shield – captcha thành viên mới",
    "cooldown":    3,
    "status":      True,
    "main":        verifyCommand,
}
