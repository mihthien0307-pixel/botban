"""
bussiness_card.py  –  Gửi business card Zalo cho zbot
Đặt tại: src/command/bot_services/bussiness_card.py

Cách dùng:
  !card               → gửi card bản thân
  !card @user         → gửi card người được tag
  !card @user <text>  → gửi card kèm caption text
"""
from app.core.index import *
from app.module.commandLoader import removeMention

import re

def BussinessCardCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Dùng đúng signature: removeMention(self, data)
    raw      = removeMention(self, Data)
    cmd_name = "card"
    prefix   = getattr(self, "prefix", "!")
    text_arg = re.sub(rf"^{re.escape(prefix)}{cmd_name}\b", "", raw, flags=re.IGNORECASE).strip()

    uids    = extractUids(Data)
    targets = uids if uids else [str(UserId)]

    for target_uid in targets:
        try:
            # Signature: sendBusinessCard(userId, qrCodeUrl, threadId, type, phone=None, ttl=0)
            # qrCodeUrl để None nếu không có, bot tự lấy QR của user đó
            self.sendBusinessCard(
                str(target_uid),   # userId – card của ai
                None,              # qrCodeUrl – để None, API tự xử lý
                ThreadId,          # threadId
                ThreadType,        # type
            )
        except Exception as e:
            print(f"[BussinessCard] sendBusinessCard error (uid={target_uid}): {e}")
            self.sendMentionStyle(
                f"❌ Khong the gui business card cho {target_uid}: {e}",
                UserId, ThreadId, ThreadType,
            )


dependencies = {
    "name":        "card",
    "permission":  0,
    "cooldown":    3,
    "description": "Gui business card Zalo – !card [@user] [text]",
    "main":        BussinessCardCommand,
}
