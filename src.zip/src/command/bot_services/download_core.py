"""
download_core.py  –  Core download engine (ported from zBug)
Đặt file này vào:  zBot/src/command/bot_services/download_core.py
"""

import os
import re
import time
import json
import hashlib
import shutil
import threading
import subprocess
import requests

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List

# ── Constants ──────────────────────────────────────────────────────────────────
CACHE_DIR        = "data/assets/cache/download"
MAX_FILE_SIZE_MB = 9999
MAX_WORKERS      = 5
CHUNK_SIZE       = 16384
TIMEOUT          = 60
DOWNLOAD_PLATF   = "download"

os.makedirs(CACHE_DIR, exist_ok=True)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _format_count(count):
    try:
        count = int(count)
        if count >= 1_000_000:
            return f"{count/1_000_000:.1f}M"
        if count >= 1_000:
            return f"{count/1_000:.1f}K"
        return str(count)
    except Exception:
        return "0"


def get_platform_info(url: str):
    u = (url or "").lower()
    if "tiktok.com" in u or "vt.tiktok.com" in u:
        return "TikTok", "tiktok"
    if "facebook.com" in u or "fb.watch" in u or "fb.com" in u:
        return "Facebook", "facebook"
    if "youtube.com" in u or "youtu.be" in u:
        return "YouTube", "youtube"
    if "threads.net" in u or "threads.com" in u:
        return "Threads", "threads"
    if "instagram.com" in u:
        return "Instagram", "instagram"
    if "soundcloud.com" in u:
        return "SoundCloud", "soundcloud"
    if "spotify.com" in u or "open.spotify.com" in u:
        return "Spotify", "spotify"
    if "capcut.com" in u:
        return "CapCut", "capcut"
    return "Other", "video"


def _is_tiktok(url): return "tiktok.com" in (url or "").lower() or "vt.tiktok.com" in (url or "").lower()
def _is_spotify(url): return "spotify.com" in (url or "").lower()


# ── Cache helpers ──────────────────────────────────────────────────────────────

def _ensure_cache(self):
    if not hasattr(self, "MediaCache"):
        from app.module.utils import MediaCache
        self.MediaCache = MediaCache()


def _hash_url(url: str) -> str:
    s = str(url or "").strip()
    if not s:
        return ""
    try:
        return hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest()
    except Exception:
        return "".join(c for c in s if c.isalnum())[:40]


def _build_sid(platform_key: str, url: str) -> str:
    hk = _hash_url(url)
    pk = "".join(c for c in str(platform_key or "other") if c.isalnum() or c in ("_", "-")).lower()[:24]
    return f"{pk}_{hk[:32] if hk else str(int(time.time()*1000))}"


def _is_alive(self, url: str) -> bool:
    try:
        return bool(url) and self.MediaCache.isAlive(url)
    except Exception:
        return False


def _cache_get(self, sid: str) -> dict:
    _ensure_cache(self)
    cache = self.MediaCache.get(DOWNLOAD_PLATF, sid) or {}

    file_url = cache.get("fileUrl")
    if file_url and not _is_alive(self, file_url):
        file_url = None

    audio_url = cache.get("audioFileUrl")
    if audio_url and not _is_alive(self, audio_url):
        audio_url = None

    img_list = cache.get("imageHdList") or []
    if isinstance(img_list, list) and img_list:
        img_list = [u for u in img_list if _is_alive(self, u)]
    else:
        img_list = []

    meta = cache.get("meta", {}) if isinstance(cache, dict) else {}
    if not isinstance(meta, dict):
        meta = {}

    return {
        "cache":        cache,
        "fileUrl":      file_url,
        "audioFileUrl": audio_url,
        "imageHdList":  img_list,
        "meta":         meta,
    }


def _cache_set(self, sid: str, meta: dict, file_url=None, audio_url=None, img_list=None):
    _ensure_cache(self)
    pk   = str((meta or {}).get("downloadPlatform") or "other").lower()
    data = {
        "downloadPlatform": pk,
        "download":         {pk: dict(meta or {})},
    }
    if audio_url:
        data["audioFileUrl"] = audio_url
    if img_list is not None:
        data["imageHdList"] = img_list if isinstance(img_list, list) else []
    self.MediaCache.set(DOWNLOAD_PLATF, sid, data, file_url)


# ── Platform fetchers ──────────────────────────────────────────────────────────

def _fetch_tiktok(url: str):
    for attempt in range(3):
        try:
            r = requests.get(f"https://www.tikwm.com/api/?url={url}", timeout=15)
            r.raise_for_status()
            data = r.json()
            if data.get("code") == 0 and data.get("data"):
                v  = data["data"]
                m  = v.get("music_info", {}) or {}
                imgs = v.get("images", []) or []
                return {
                    "video_url":  v.get("play"),
                    "audio_url":  m.get("play") or v.get("music"),
                    "duration":   v.get("duration", 0),
                    "title":      v.get("title", "TikTok"),
                    "author":     (v.get("author", {}) or {}).get("nickname", "Unknown"),
                    "thumbnail":  v.get("cover"),
                    "images":     imgs,
                    "is_image":   len(imgs) > 0,
                }
        except Exception as e:
            if attempt == 2:
                print(f"[TikTok API] Error: {e}")
            else:
                time.sleep(1)
    return None


def _fetch_spotify(url: str):
    r = requests.get(
        "https://api.zeidteam.xyz/media-downloader/atd2",
        params={"url": url},
        timeout=20,
    )
    r.raise_for_status()
    j = r.json()
    if not j or not j.get("success") or not j.get("data"):
        raise Exception("Spotify API failed")
    d = j["data"] or {}
    music_url = d.get("music")
    if not music_url:
        att = d.get("attachment") or []
        if att:
            music_url = (att[0] or {}).get("url")
    if not music_url:
        raise Exception("Spotify API: missing music url")

    dur_str = str(d.get("duration", "0:0")).strip().split(":")
    try:
        if len(dur_str) == 2:
            duration = int(dur_str[0]) * 60 + int(dur_str[1])
        elif len(dur_str) == 3:
            duration = int(dur_str[0]) * 3600 + int(dur_str[1]) * 60 + int(dur_str[2])
        else:
            duration = 0
    except Exception:
        duration = 0

    return {
        "audio_url": music_url,
        "title":     d.get("title") or "Spotify",
        "author":    d.get("author") or d.get("artist") or "Unknown",
        "thumbnail": d.get("thumbnail"),
        "duration":  duration,
    }


# ── ffmpeg helpers ─────────────────────────────────────────────────────────────

def _ffmpeg_path() -> str:
    return "ffmpeg"


def _has_ffmpeg() -> bool:
    try:
        return bool(shutil.which("ffmpeg") or shutil.which("ffmpeg.exe"))
    except Exception:
        return False


def _get_video_meta(file_path: str):
    probe = shutil.which("ffprobe") or shutil.which("ffprobe.exe")
    if not probe or not file_path or not os.path.exists(file_path):
        return None
    cmd = [probe, "-v", "error", "-print_format", "json",
           "-show_format", "-show_streams", file_path]
    try:
        out  = subprocess.check_output(cmd, stderr=subprocess.STDOUT,
                                        text=True, encoding="utf-8", errors="ignore")
        j    = json.loads(out or "{}")
        streams = j.get("streams") or []
        fmt  = j.get("format") or {}
        v    = next((s for s in streams if (s.get("codec_type") or "").lower() == "video"), None)
        if not v:
            return None
        w, h = int(v.get("width") or 0), int(v.get("height") or 0)
        dur  = v.get("duration") or fmt.get("duration")
        try:
            dur = float(dur or 0)
        except Exception:
            dur = 0.0
        rot = v.get("tags", {}).get("rotate")
        try:
            rot = int(rot) if rot is not None else 0
        except Exception:
            rot = 0
        if rot in (90, 270) and w and h:
            w, h = h, w
        return {"width": w, "height": h, "duration": dur}
    except Exception:
        return None


# ── File download ──────────────────────────────────────────────────────────────

def _download_file(url: str, ext: str = "mp4") -> str | None:
    if not url:
        return None
    try:
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept":     "*/*",
            "Connection": "keep-alive",
        }
        r    = requests.get(url, timeout=TIMEOUT, stream=True, headers=headers, allow_redirects=True)
        r.raise_for_status()
        name = f"{os.getpid()}_{int(time.time()*1_000_000)}.{ext}"
        path = os.path.join(CACHE_DIR, name)
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=CHUNK_SIZE):
                if chunk:
                    f.write(chunk)
        if not os.path.exists(path) or os.path.getsize(path) <= 0:
            try:
                os.remove(path)
            except Exception:
                pass
            return None
        return path
    except Exception as e:
        print(f"[Download] file error: {e}")
        return None


def _download_images_parallel(urls: List[str]) -> List[str]:
    out = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        fts = [ex.submit(_download_file, u, "jpg") for u in urls if u]
        for ft in as_completed(fts):
            try:
                p = ft.result()
                if p:
                    out.append(p)
            except Exception:
                pass
    return out


# ── aio-down wrapper ───────────────────────────────────────────────────────────

def _classify_paths(paths: List[str]) -> dict:
    IMG = {"jpg", "jpeg", "png", "webp", "bmp", "gif"}
    VID = {"mp4", "mkv", "webm", "mov", "m4v", "avi", "flv"}
    AUD = {"mp3", "m4a", "aac", "opus", "ogg", "wav", "flac"}
    V, I, A, O = [], [], [], []
    for p in (paths or []):
        try:
            if not p or not os.path.exists(p) or os.path.getsize(p) <= 0:
                continue
            ext = os.path.splitext(str(p))[1].lower().lstrip(".")
            (I if ext in IMG else V if ext in VID else A if ext in AUD else O).append(p)
        except Exception:
            pass

    def _sort_key(x):
        try:
            b = os.path.basename(x)
            n = "".join(c for c in b if c.isdigit())
            return (int(n) if n else 10**18, b.lower())
        except Exception:
            return (10**18, str(x))

    for lst in (V, I, A, O):
        lst.sort(key=_sort_key)
    return {"videos": V, "images": I, "audios": A, "others": O}


def _try_aio_down(url: str, is_audio: bool = False):
    cmd   = ["aio-down", url, "--paths", CACHE_DIR, "--timeout", str(TIMEOUT), "--retries", "2", "--all"]
    paths, info, buf, in_json = [], None, [], False

    def _add(p):
        if not p:
            return
        p = str(p).strip().strip('"').strip()
        if p and os.path.exists(p) and os.path.getsize(p) > 0:
            paths.append(p)

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, bufsize=1)
        try:
            for line in iter(proc.stdout.readline, ""):
                if not line:
                    break
                s = line.rstrip("\r\n")

                if "SAVED ->" in s:
                    try:
                        part = s.split("SAVED ->", 1)[1].strip()
                        _add(part.split(" bytes=", 1)[0].strip())
                    except Exception:
                        pass

                if s.lstrip().startswith("{"):
                    in_json, buf = True, [s]
                    continue

                if in_json:
                    buf.append(s)
                    if s.strip() == "}":
                        in_json = False
                        try:
                            j = json.loads("\n".join(buf))
                            if isinstance(j, dict):
                                info = j.get("json") if isinstance(j.get("json"), dict) else j
                                for x in (j.get("paths") or []):
                                    _add(x)
                        except Exception:
                            pass
        finally:
            try:
                proc.stdout.close()
            except Exception:
                pass
        try:
            proc.wait(timeout=TIMEOUT + 30)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

        if not paths:
            return None

        seen, uniq = set(), []
        for p in paths:
            if p not in seen:
                seen.add(p); uniq.append(p)

        c = _classify_paths(uniq)

        if is_audio:
            kind = "audio" if c["audios"] else ("video" if c["videos"] else ("image" if c["images"] else "other"))
        else:
            if c["videos"] and c["images"]:
                kind = "mixed"
            elif c["videos"]:
                kind = "video"
            elif c["images"]:
                kind = "image"
            elif c["audios"]:
                kind = "audio"
            else:
                kind = "other"

        return {"kind": kind, "paths": uniq, "classify": c, "info": info}

    except Exception as e:
        print(f"[AioDown] error: {e}")
        return None


# ── yt-dlp wrapper ─────────────────────────────────────────────────────────────

def _download_ytdlp(url: str, is_audio: bool = False):
    try:
        import yt_dlp
    except ImportError:
        raise Exception("yt-dlp không được cài đặt. Chạy: pip install yt-dlp")

    info_opts = {"quiet": True, "no_warnings": True, "skip_download": True}
    with yt_dlp.YoutubeDL(info_opts) as ydl:
        info = ydl.extract_info(url, download=False)
        size = info.get("filesize_approx") or info.get("filesize")
        if size and size > MAX_FILE_SIZE_MB * 1024 * 1024:
            raise Exception(f"File vượt giới hạn {MAX_FILE_SIZE_MB}MB.")

    safe_id  = "".join(filter(str.isalnum, str(info.get("id", "media"))))[:30]
    out_tmpl = os.path.join(CACHE_DIR, f"dl_{safe_id}.%(ext)s")
    has_ff   = _has_ffmpeg()

    def _pick(p):
        return p if p and os.path.exists(p) and os.path.getsize(p) > 0 else None

    def _cleanup(prepared):
        if not prepared:
            return
        base = os.path.splitext(prepared)[0]
        for ext in [".mp4", ".mkv", ".webm", ".m4a", ".opus", ".aac", ".mp3", ".part", ".ytdl"]:
            p = base + ext
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

    def _run(fmt, post, merge_fmt):
        opts = {
            "format":                    fmt,
            "outtmpl":                   out_tmpl,
            "quiet":                     True,
            "no_warnings":               True,
            "retries":                   8,
            "fragment_retries":          8,
            "concurrent_fragment_downloads": 5,
            "http_chunk_size":           10485760,
            "socket_timeout":            20,
            "geo_bypass":                True,
            "forceipv4":                 True,
            "noplaylist":                True,
            "overwrites":                True,
            "continuedl":                True,
            "merge_output_format":       merge_fmt,
            "postprocessors":            post,
            "http_headers": {
                "User-Agent":     "Mozilla/5.0",
                "Accept":         "*/*",
                "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
                "Connection":     "keep-alive",
            },
        }
        with yt_dlp.YoutubeDL(opts) as ydl:
            inf = ydl.extract_info(url, download=True)
            fn  = ydl.prepare_filename(inf)
            return fn, inf

    if is_audio:
        tries = (
            [("bestaudio/best", [{"key": "FFmpegExtractAudio", "preferredcodec": "aac"}], None),
             ("bestaudio[ext=m4a]/bestaudio/best", [{"key": "FFmpegExtractAudio", "preferredcodec": "aac"}], None)]
            if has_ff else
            [("bestaudio[ext=m4a]/bestaudio/best", [], None),
             ("bestaudio/best", [], None)]
        )
    else:
        tries = (
            [("bestvideo[filesize<70M][vcodec^=avc1]+bestaudio/best", [], "mp4"),
             ("bestvideo[filesize<70M]+bestaudio/best", [], "mp4"),
             ("best[ext=mp4][vcodec!=none][acodec!=none][filesize<70M]/best", [], "mp4")]
            if has_ff else
            [("best[ext=mp4][vcodec!=none][acodec!=none][filesize<70M]/best[ext=mp4][vcodec!=none][acodec!=none]/best", [], None),
             ("best[ext=mp4][vcodec!=none][acodec!=none]/best", [], None)]
        )

    last_err = None
    for fmt, post, merge_fmt in tries:
        prepared = None
        try:
            prepared, inf = _run(fmt, post, merge_fmt)
            base = os.path.splitext(prepared)[0]
            if is_audio:
                for ext in ([".aac", ".m4a", ".mp3", ".opus"] if has_ff else [".m4a", ".webm", ".opus", ".aac", ".mp3"]):
                    p = _pick(base + ext)
                    if p:
                        return p, inf
            ok = _pick(prepared)
            if ok:
                return ok, inf
            _cleanup(prepared)
            last_err = Exception("File tải về bị rỗng")
        except Exception as e:
            last_err = e
            _cleanup(prepared)

    raise last_err if last_err else Exception("Tải xuống thất bại.")


# ── Upload helpers ─────────────────────────────────────────────────────────────

def _upload_file(self, path: str, thread_id, type) -> str | None:
    try:
        up = self._uploadAttachment(path, thread_id, type)
        return (up or {}).get("fileUrl")
    except Exception as e:
        print(f"[Upload] error: {e}")
        return None


def _upload_images(self, img_paths: List[str], thread_id, type) -> List[str]:
    hd_list = []
    for p in img_paths:
        try:
            up  = self._uploadImage(p, thread_id, type)
            url = (up or {}).get("hdUrl")
            if url:
                hd_list.append(url)
        except Exception:
            pass
    return hd_list


# ── Send downloaded media ──────────────────────────────────────────────────────

def _build_caption(platform_name: str, title: str, uploader: str) -> str:
    t  = str(title    or "Media")[:100]
    up = str(uploader or "Unknown")[:60]
    return f"Source: {platform_name}\nTitle: {t}\nBy: {up}"


def _send_downloaded(self, platform_name, platform_key, sid, info,
                     file_path, img_paths, audio_path,
                     is_audio, thread_id, type, user_id):
    from api.util.msg import Message

    title    = (info.get("title")    if isinstance(info, dict) else None) or "Media"
    uploader = (info.get("uploader") if isinstance(info, dict) else None) or \
               (info.get("author")   if isinstance(info, dict) else None) or "Unknown"
    caption  = _build_caption(platform_name, title, uploader)

    base_meta = {
        "downloadPlatform": platform_key,
        "title":     title,
        "uploader":  uploader,
        "thumbnail": (info.get("thumbnail") if isinstance(info, dict) else None),
        "width":     int((info.get("width")  if isinstance(info, dict) else 1080) or 1080),
        "height":    int((info.get("height") if isinstance(info, dict) else 1920) or 1920),
    }

    # ── Audio mode ────────────────────────────────────────────────────────────
    if is_audio:
        path = audio_path or file_path
        if not path or not os.path.exists(path):
            raise Exception("Tải audio thất bại.")
        file_url = _upload_file(self, path, thread_id, type)
        try:
            os.remove(path)
        except Exception:
            pass
        if not file_url:
            raise Exception("Upload audio thất bại.")
        meta = dict(base_meta)
        meta["kind"] = "audio"
        try:
            meta["duration"] = int((info.get("duration") if isinstance(info, dict) else 0) or 0)
        except Exception:
            meta["duration"] = 0
        _cache_set(self, sid, meta, file_url=file_url)
        self.sendRemoteVoice(file_url, thread_id, type)
        return

    # ── Video mode ────────────────────────────────────────────────────────────
    video_file_url, img_hd_list = None, []

    if file_path and os.path.exists(file_path):
        try:
            dur = float((info.get("duration") if isinstance(info, dict) else 0) or 0)
        except Exception:
            dur = 0.0

        w, h  = base_meta["width"], base_meta["height"]
        probe = _get_video_meta(file_path)
        if probe:
            if probe.get("width"):  w = int(probe["width"])
            if probe.get("height"): h = int(probe["height"])
            if probe.get("duration"): dur = float(probe["duration"])

        video_file_url = _upload_file(self, file_path, thread_id, type)
        try:
            os.remove(file_path)
        except Exception:
            pass
        if not video_file_url:
            raise Exception("Upload video thất bại.")

        dur_ms   = int(dur * 1000)
        meta_vid = dict(base_meta)
        meta_vid.update({"kind": "video", "durationMs": dur_ms, "width": w, "height": h})

        self.sendRemoteVideo(
            videoUrl=video_file_url,
            thumbnailUrl=meta_vid.get("thumbnail"),
            duration=dur_ms,
            threadId=thread_id,
            type=type,
            width=w,
            height=h,
            message=Message(text=caption),
        )
        base_meta = meta_vid

    # ── Image mode ────────────────────────────────────────────────────────────
    if img_paths:
        try:
            img_hd_list = _upload_images(self, img_paths, thread_id, type)
            if img_hd_list:
                from api.util.msg import Mention
                if len(img_hd_list) == 1:
                    self.sendLocalImage(
                        imagePath=img_paths[0],
                        message=Message(text=caption),
                        threadId=thread_id,
                        type=type,
                    )
                else:
                    name    = self.userName(user_id)
                    mention = Mention(user_id, offset=0, length=len(name))
                    self.send(Message(text=f"{name}\n{caption}", mention=mention), thread_id, type)
                    self.sendMultiRemoteImage(
                        imageUrlList=img_hd_list,
                        message=Message(text=None),
                        threadId=thread_id,
                        type=type,
                    )
        finally:
            for p in img_paths:
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass

    if video_file_url or img_hd_list:
        meta_final = dict(base_meta)
        meta_final["kind"] = (
            "mixed"  if (video_file_url and img_hd_list) else
            "video"  if video_file_url else
            "image"
        )
        _cache_set(self, sid, meta_final, file_url=video_file_url, img_list=img_hd_list)
        return

    raise Exception("Không có media nào được tải xuống.")


# ── Main per-link processor ────────────────────────────────────────────────────

def _normalize_aio_info(platform_key: str, aio_info) -> dict:
    j    = aio_info if isinstance(aio_info, dict) else {}
    meta = j.get("meta") if isinstance(j.get("meta"), dict) else {}
    return {
        "downloadPlatform": platform_key,
        "title":    j.get("title")    or meta.get("title")    or "Media",
        "uploader": j.get("uploader") or j.get("author") or meta.get("uploader") or "Unknown",
        "thumbnail": j.get("thumbnail") or meta.get("thumbnail"),
        "duration": 0,
        "width":    1080,
        "height":   1920,
    }


def process_single_link(i, url, is_audio, thread_id, type, self, data, user_id):
    try:
        _ensure_cache(self)
        platform_name, platform_key = get_platform_info(url)
        sid    = _build_sid(platform_key, url)
        cached = _cache_get(self, sid)

        meta0  = cached.get("meta") or {}
        kind0  = (meta0.get("kind") or "").lower()
        cap0   = _build_caption(platform_name, meta0.get("title") or "Media", meta0.get("uploader") or "Unknown")

        # Trả cache nếu có
        if is_audio and cached.get("fileUrl") and kind0 == "audio":
            self.sendRemoteVoice(cached["fileUrl"], thread_id, type)
            return

        if not is_audio and cached.get("fileUrl") and kind0 in ("video", "mixed"):
            from api.util.msg import Message
            dur = int(meta0.get("durationMs") or 0)
            w   = int(meta0.get("width")  or 1080)
            h   = int(meta0.get("height") or 1920)
            self.sendRemoteVideo(
                videoUrl=cached["fileUrl"],
                thumbnailUrl=meta0.get("thumbnail"),
                duration=dur,
                threadId=thread_id,
                type=type,
                width=w,
                height=h,
                message=Message(text=cap0),
            )
            for hd in (cached.get("imageHdList") or []):
                self.sendMultiRemoteImage(image_url=hd, message=Message(text=None),
                                      threadId=thread_id, type=type, width=1080, height=1080)
            return

        if not is_audio and kind0 == "image":
            from api.util.msg import Message, Mention
            hd_list = cached.get("imageHdList") or []
            if hd_list:
                if len(hd_list) == 1:
                    self.sendMultiRemoteImage(image_url=hd_list[0], message=Message(text=cap0),
                                          threadId=thread_id, type=type, width=1080, height=1080)
                else:
                    name = self.userName(user_id)
                    self.send(Message(text=f"{name}\n{cap0}",
                                       mention=Mention(user_id, offset=0, length=len(name))),
                               thread_id, type)
                    self.sendMultiImage(imageUrlList=hd_list, message=Message(text=None),
                                         threadId=thread_id, type=type)
                return

        # ── TikTok ────────────────────────────────────────────────────────────
        if _is_tiktok(url):
            tk = _fetch_tiktok(url)
            if not tk:
                self.replyMessageStyle("Không lấy được thông tin TikTok.", data, thread_id, type, color="r", title="ERROR", userId=user_id)
                return

            info = {
                "title": tk.get("title") or "TikTok",
                "author": tk.get("author") or "Unknown",
                "uploader": tk.get("author") or "Unknown",
                "duration": tk.get("duration") or 0,
                "thumbnail": tk.get("thumbnail"),
                "width": 1080, "height": 1920,
            }

            audio_path = None
            if (is_audio or tk.get("is_image")) and tk.get("audio_url"):
                audio_path = _download_file(tk["audio_url"], "aac")

            if is_audio:
                _send_downloaded(self, platform_name, platform_key, sid, info,
                                  None, [], audio_path, True, thread_id, type, user_id)
                return

            if tk.get("is_image") and tk.get("images"):
                img_paths = _download_images_parallel(tk["images"])
                _send_downloaded(self, platform_name, platform_key, sid, info,
                                  None, img_paths, audio_path, False, thread_id, type, user_id)
                return

            if tk.get("video_url"):
                file_path = _download_file(tk["video_url"], "mp4")
                _send_downloaded(self, platform_name, platform_key, sid, info,
                                  file_path, [], audio_path, False, thread_id, type, user_id)
                return

            raise Exception("TikTok download failed.")

        # ── aio-down ──────────────────────────────────────────────────────────
        aio = _try_aio_down(url, is_audio=is_audio)
        if aio and isinstance(aio.get("classify"), dict):
            c    = aio["classify"]
            info = _normalize_aio_info(platform_key, aio.get("info") or {})
            V, I, A = c.get("videos") or [], c.get("images") or [], c.get("audios") or []

            if is_audio:
                if A:
                    _send_downloaded(self, platform_name, platform_key, sid, info,
                                      None, [], A[0], True, thread_id, type, user_id)
                    return
                if V:
                    _send_downloaded(self, platform_name, platform_key, sid, info,
                                      V[0], [], None, False, thread_id, type, user_id)
                    return
                if I:
                    _send_downloaded(self, platform_name, platform_key, sid, info,
                                      None, I, None, False, thread_id, type, user_id)
                    return
                raise Exception("AioDown: không có media audio.")

            file_path  = V[0] if V else None
            img_paths  = I if I else []
            if not file_path and not img_paths and A:
                _send_downloaded(self, platform_name, platform_key, sid, info,
                                  None, [], A[0], True, thread_id, type, user_id)
                return
            if not file_path and not img_paths:
                raise Exception("AioDown: không có media.")
            _send_downloaded(self, platform_name, platform_key, sid, info,
                              file_path, img_paths, None, False, thread_id, type, user_id)
            return

        # ── yt-dlp fallback ───────────────────────────────────────────────────
        file_path, info_y = _download_ytdlp(url, is_audio)
        info = info_y if isinstance(info_y, dict) else {}
        info = {
            "title":    info.get("title")    or "Media",
            "uploader": info.get("uploader") or info.get("author") or "Unknown",
            "author":   info.get("uploader") or info.get("author") or "Unknown",
            "duration": info.get("duration") or 0,
            "thumbnail": info.get("thumbnail"),
            "width": 1080, "height": 1920,
        }
        _send_downloaded(self, platform_name, platform_key, sid, info,
                          file_path, [], None, is_audio, thread_id, type, user_id)

    except Exception as e:
        print(f"[Download] error for {url}: {e}")
        try:
            self.replyMessageStyle(
                f"Tải xuống thất bại: {e}",
                data, thread_id, type,
                color="r", title="ERROR", userId=user_id,
            )
        except Exception:
            pass