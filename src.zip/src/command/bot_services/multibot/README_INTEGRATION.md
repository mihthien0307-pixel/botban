# Tích hợp Multibot vào zBot

## Cấu trúc file cần thêm

```
bothat/
├── src/command/bot_services/multibot/   ← THƯ MỤC CHÍNH (mới)
│   ├── multibot_core.py                 ← helpers dùng chung
│   ├── multibot_runner.py               ← restart / shutdown bot
│   ├── multibot_expire.py               ← vòng lặp kiểm tra hạn
│   ├── botManager.py                    ← lệnh ?myapp (auto-load)
│   └── args/
│       ├── createBot.py
│       ├── createBotQR.py
│       ├── deleteBot.py
│       └── manager/
│           ├── activeBot.py
│           ├── restartBot.py
│           ├── stopBot.py
│           ├── updateCredential.py
│           ├── changeOwner.py
│           └── groupManager.py
│
└── data/config/                         ← thư mục data (đã có)
    └── multibot/                        ← TẠO MỚI thư mục này
        └── (các file 1-login.json, 2-login.json ... sẽ tự sinh)
```

---

## Bước 1 – Copy file

Giải nén và copy toàn bộ thư mục `multibot/` vào:
```
bothat/src/command/bot_services/multibot/
```

---

## Bước 2 – Tạo thư mục multibot

```bash
mkdir -p data/config/multibot
```

---

## Bước 3 – Sửa `src/services/init/admin.py`

Thêm vào cuối hàm `initAdmin(self)`, **trong nhánh `is_main_bot`**:

```python
# Ở cuối nhánh if getattr(self, "is_main_bot", False):
from src.command.bot_services.multibot.multibot_expire import loopInitExpire
from src.command.bot_services.multibot.multibot_core import UpsertBotManagerRunning, MAIN_LOGIN
UpsertBotManagerRunning(self.uid, True, MAIN_LOGIN)
loopInitExpire(self)
```

Và ở **nhánh else (bot con)**:
```python
# Ở cuối nhánh else:
from src.command.bot_services.multibot.multibot_core import UpsertBotManagerRunning
fp = f"data/config/multibot/{self.uid}-login.json"
# filePath thực sự sẽ được cập nhật khi run_bot tạo bot
# Dùng helper để ghi nhận:
UpsertBotManagerRunning(self.uid, False, fp)
```

**Cách đơn giản hơn**: Sửa `app/login/data.py` trong hàm `run_bot`, sau khi tạo `client`:
```python
# Sau dòng clientlist[str(author_id)] = client
from src.command.bot_services.multibot.multibot_core import UpsertBotManagerRunning
# filePath lúc này là loginPath từ multibot dir
# Truyền filePath vào run_bot nếu bạn có, hoặc ghi tạm:
UpsertBotManagerRunning(client.uid, is_main_bot, f"data/config/login.json")
```

> Thực ra `bot-manager-database.json` chỉ dùng để tra ngược ra file của bot con khi nó tự gọi lệnh. Nếu **không cần** bot con tự restart chính nó, có thể bỏ qua bước này.

---

## Bước 4 – Thêm `filePath` vào login.json khi tạo bot con (quan trọng)

Trong `multibot_runner.py` hàm `restartABot`, filePath của bot con sẽ được ghi vào `bot-manager-database.json` khi khởi động. Nhưng để tra được ngay từ đầu, hãy đảm bảo khi **tạo bot** (CreateBot / CreateBotQR), file `data/config/multibot/N-login.json` đã được tạo.

File `N-login.json` có format:
```json
[
  {
    "username": "TênBot-0",
    "author_id": "uid_của_chủ",
    "imei": "...",
    "prefix": "/",
    "session_cookies": { "zpw_sek": "..." },
    "is_main_bot": false,
    "mainBot": false,
    "status": false,
    "isActived": false
  },
  { "userClientId": "uid_của_chủ" }
]
```

---

## Bước 5 – Sửa `app/login/data.py` để load bot con khi khởi động

Trong hàm `main()` của `app/login/client.py`, thêm đoạn load bot con từ `data/config/multibot/`:

```python
# Sau khi start_threads(valid_items) xong, thêm:
from src.command.bot_services.multibot.multibot_core import MULTIBOT_DIR, ReadLoginJson, PickBotItem
import os

if os.path.isdir(MULTIBOT_DIR):
    for fn in os.listdir(MULTIBOT_DIR):
        if not fn.endswith("-login.json"):
            continue
        fp    = os.path.join(MULTIBOT_DIR, fn)
        items = ReadLoginJson(fp)
        bot   = PickBotItem(items)
        if not bot:
            continue
        if not bot.get("status"):
            continue
        imei    = bot.get("imei")
        cookies = bot.get("session_cookies") or bot.get("sessionCookies") or {}
        prefix  = bot.get("prefix", "?")
        uid     = bot.get("author_id") or ""
        name    = bot.get("username")
        if imei and cookies:
            run_bot(imei, cookies, prefix, False, name, uid, True)
```

---

## Bước 6 – Kiểm tra

Khởi động bot, dùng lệnh:
```
?myapp
```
Bot sẽ hiển thị menu.

Tạo bot con:
```
?myapp create [IMEI] {"zpw_sek":"..."}
?myapp create qr
```

Xem danh sách:
```
?myapp list
```

---

## Lưu ý quan trọng

- **`MAIN_LOGIN`** = `data/config/login.json` (format zBot, có `session_cookies`)
- **`MULTIBOT_DIR`** = `data/config/multibot/` (các file bot con)
- File bot con dùng cả `session_cookies` lẫn `sessionCookies` để tương thích
- `dataBot` trong `login.json` là dict `{ "uid_chủ": "N-login.json" }` để tra nhanh
- Bot con tự resolve UID của main bot qua portal HTTP `:7799` (đã có sẵn trong zBot)
