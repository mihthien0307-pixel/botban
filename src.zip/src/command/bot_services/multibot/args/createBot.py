"""
args/createBot.py – Tạo bot con bằng IMEI + Session Cookies (text).
"""

from src.command.bot_services.multibot.multibot_core import *

def _UpdateExistingBotLogin(uidFrom, imei, sessionCookies):
    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {})
    if not isinstance(dataBot, dict):
        return None, None, None

    loginFile = dataBot.get(str(uidFrom))
    if not loginFile:
        return None, None, None

    loginPath = os.path.join(MULTIBOT_DIR, loginFile)
    items     = ReadLoginJson(loginPath)
    if not isinstance(items, list) or not items:
        return None, None, None

    bot = PickBotItem(items)
    if not bot:
        return None, None, None

    bot["imei"]             = imei
    bot["session_cookies"]  = sessionCookies
    bot["sessionCookies"]   = sessionCookies
    WriteLoginJson(loginPath, items)
    return bot, loginPath, items


def CreateBot(this, message, data, userId, threadId, type):
    uidFrom = GetUidFrom(data)
    if not uidFrom:
        return SendMention(this, "status:null", userId, threadId, type)

    raw   = (getattr(message, "text", "") or "").strip()
    parts = raw.split(maxsplit=1)
    if len(parts) < 2:
        return SendMention(
            this,
            f"Dùng: {this.prefix}{this.rawCommand} create [IMEI] [SessionCookies JSON]",
            userId, threadId, type
        )

    imei    = parts[0]
    payload = ExtractJsonPayload(parts[1])
    if not payload:
        return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)

    try:
        sessionCookies = json.loads(payload)
    except Exception:
        return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)

    bot, _, _ = _UpdateExistingBotLogin(uidFrom, imei, sessionCookies)
    if bot:
        return SendMention(this, f"Đã cập nhật IMEI & Cookies cho {bot.get('username')}", userId, threadId, type)

    cfg      = jsonLoader(MAIN_LOGIN) or {}
    dataBot  = cfg.get("dataBot", {}) if isinstance(cfg.get("dataBot"), dict) else {}
    username = f"{this.userName(uidFrom)}-{len(cfg.get('data', []))}"
    prefix   = random.choice(["/", ".", "_", "-", ",", ">", "<", ")", "(", "~", "[", "]", ";"])
    botAccount  = SlugName(this.userName(uidFrom))
    botPassword = str(random.randint(100000, 999999))

    newBot = {
        "username":        username,
        "author_id":       str(uidFrom),
        "imei":            imei,
        "prefix":          prefix,
        "session_cookies": sessionCookies,
        "sessionCookies":  sessionCookies,
        "is_main_bot":     False,
        "mainBot":         False,
        "status":          False,
        "isActived":       False,
        "botAccount":      botAccount,
        "botPassword":     botPassword,
        "login":           24,
    }

    os.makedirs(MULTIBOT_DIR, exist_ok=True)
    idx = 1
    while os.path.exists(os.path.join(MULTIBOT_DIR, f"{idx}-login.json")):
        idx += 1
    loginFile = f"{idx}-login.json"
    loginPath = os.path.join(MULTIBOT_DIR, loginFile)

    WriteLoginJson(loginPath, [newBot, {"userClientId": str(uidFrom)}])

    dataBot[str(uidFrom)] = loginFile
    cfg["dataBot"] = dataBot
    saveJson(MAIN_LOGIN, cfg)

    SendMention(this, f"[{prefix}] Tạo bot {this.userName(uidFrom)} thành công!", userId, threadId, type)
    try:
        from api.util.msg import Message, Mention
        from api.util.Enum import ThreadType
        this.sendMessage(
            Message(text=f"Web: {getattr(this, 'appServer', 'N/A')}\nAccount: {botAccount}\nPassword: {botPassword}"),
            str(uidFrom),
            ThreadType.USER,
        )
    except Exception:
        pass
