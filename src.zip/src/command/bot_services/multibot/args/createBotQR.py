"""
args/createBotQR.py – Tạo bot con bằng QR Code.
"""

from src.command.bot_services.multibot.multibot_core import *
from app.module.apiQr import (
    init_session as SessionHeader,
    verify_client as verifyClient,
    generate_qr_code as GenerateLoginQr,
    waiting_scan,
    waiting_confirm,
)


def _UpdateExistingBotLogin(uidFrom, imei, sessionCookies):
    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {})
    if not isinstance(dataBot, dict):
        return None, None, None
    loginFile = dataBot.get(str(uidFrom))
    if not loginFile:
        return None, None, None
    loginPath = os.path.join(MULTIBOT_DIR, loginFile)
    items     = ReadLoginJson(loginPath)
    if not isinstance(items, list) or not items:
        return None, None, None
    bot = PickBotItem(items)
    if not bot:
        return None, None, None
    bot["imei"]            = imei
    bot["session_cookies"] = sessionCookies
    bot["sessionCookies"]  = sessionCookies
    WriteLoginJson(loginPath, items)
    return bot, loginPath, items


def CreateBotQR(this, data, userId, threadId, type):
    from api.util.msg import Message, Mention
    from api.util.Enum import ThreadType

    uidFrom = GetUidFrom(data)
    if not uidFrom:
        return SendMention(this, "status:null", userId, threadId, type)

    u  = uidFrom
    tu = ThreadType.USER

    # Tạo QR
    waitMsg = None
    try:
        waitMsg = sendMCustom(this, "WAITING", "y", "Đang tạo QR đăng nhập...", userId, threadId, type)
    except Exception:
        pass

    sessions = SessionHeader()
    sessions = verifyClient(sessions)
    code, sessions = GenerateLoginQr(sessions)

    qrImagePath = "data/assets/cache/image/qr_code.png"

    if waitMsg:
        try:
            this.deleteMessage(waitMsg.msgId, this.uid, waitMsg.clientId, threadId)
        except Exception:
            pass

    def ProcessQRAuth():
        notifyQr = None
        qrMsgId  = None
        qrCliId  = None

        def DelQr():
            try:
                if notifyQr:
                    this.undoMessage(notifyQr.msgId, notifyQr.clientId, u, tu)
            except Exception:
                pass
            try:
                if qrMsgId:
                    this.undoMessage(qrMsgId, qrCliId, u, tu)
            except Exception:
                pass
            if os.path.exists(qrImagePath):
                try:
                    os.remove(qrImagePath)
                except Exception:
                    pass

        # Gửi ảnh QR vào tin nhắn riêng TRƯỚC khi waiting_scan
        try:
            up      = this._uploadImage(qrImagePath, u, tu)
            qrHdUrl = (up.get("hdUrl") or up.get("normalUrl") or up.get("hdImage")) if up else None
        except Exception as e:
            sendMFailed(this, f"Upload QR thất bại: {e}", userId, threadId, type)
            return

        if qrHdUrl:
            try:
                notifyQr = sendMCustom(this, "WAITING", "y", "Quét QR bằng thiết bị khác để đăng nhập..", userId, threadId, type)
            except Exception:
                pass
            try:
                msg     = this.sendRemoteImage(image_url=qrHdUrl, message=Message(text="Quét QR này để đăng nhập!"), threadId=u, type=tu)
                qrMsgId = getattr(msg, "msgId", None)
                qrCliId = getattr(msg, "clientId", None)
                SendMention(this, "Đã gửi QR vào tin nhắn riêng, hãy quét bằng thiết bị khác!", uidFrom, threadId, type)
            except Exception as e:
                sendMFailed(this, f"Gửi QR thất bại: {e}", userId, threadId, type)
                return
        else:
            sendMFailed(this, "Không tạo được ảnh QR, thử lại sau!", userId, threadId, type)
            return

        try:
            scanResult = waiting_scan(code, sessions)
            if not scanResult:
                DelQr()
                sendMFailed(this, "QR code hết hạn hoặc chưa được quét", userId, threadId, type)
                return

            qrData = waiting_confirm(code, sessions)
            DelQr()
            if not qrData:
                sendMFailed(this, "Xác thực thất bại", userId, threadId, type)
                return

            imei           = qrData.get("imei")
            sessionCookies = qrData.get("cookie", {})

            bot, _, _ = _UpdateExistingBotLogin(uidFrom, imei, sessionCookies)
            if bot:
                sendMSuccess(this, f"Đã cập nhật IMEI & Cookies cho {bot.get('username')}", userId, threadId, type)
                return

            cfg     = jsonLoader(MAIN_LOGIN) or {}
            dataBot = cfg.get("dataBot", {})
            if not isinstance(dataBot, dict):
                dataBot = {}

            username    = f"{this.userName(uidFrom)}-{len(cfg.get('data', []))}"
            prefix      = qrData.get("prefix", "?")
            botAccount  = SlugName(username)
            botPassword = str(random.randint(100000, 999999))

            from datetime import datetime as _dt, timedelta as _td
            _now      = _dt.now()
            _expire   = _now + _td(days=365)
            _act_time = _now.strftime("%H:%M:%S-%d/%m/%Y")
            _exp_time = _expire.strftime("%H:%M:%S-%d/%m/%Y")

            newBot = {
                "username":        username,
                "author_id":       str(uidFrom),
                "imei":            imei,
                "prefix":          prefix,
                "session_cookies": sessionCookies,
                "sessionCookies":  sessionCookies,
                "is_main_bot":     False,
                "mainBot":         False,
                "status":          True,
                "isActived":       True,
                "activedTime":     _act_time,
                "expiredTime":     _exp_time,
                "botAccount":      botAccount,
                "botPassword":     botPassword,
                "login":           24,
            }

            os.makedirs(MULTIBOT_DIR, exist_ok=True)
            idx = 1
            while os.path.exists(os.path.join(MULTIBOT_DIR, f"{idx}-login.json")):
                idx += 1
            loginFile = f"{idx}-login.json"
            loginPath = os.path.join(MULTIBOT_DIR, loginFile)
            WriteLoginJson(loginPath, [newBot, {"userClientId": str(uidFrom)}])

            dataBot[str(uidFrom)] = loginFile
            cfg["dataBot"] = dataBot
            saveJson(MAIN_LOGIN, cfg)

            # Auto-start bot con ngay sau khi tạo
            try:
                from src.command.bot_services.multibot.multibot_runner import restartABot
                threading.Thread(target=restartABot, args=(newBot,), daemon=True).start()
            except Exception:
                pass

            sendMCustom(this,
                "SUCCESS", "y",
                f"""
Bot: {this.userName(uidFrom)}
Prefix: {prefix}
Account: {botAccount}
Password: {botPassword}

✅ Bot đã được kích hoạt và đang khởi động!
""",
                userId, userId, ThreadType.USER,
            )

        except Exception as e:
            try:
                DelQr()
            except Exception:
                pass
            try:
                sendMFailed(this, f"CreateBotQR lỗi: {e}", userId, threadId, type)
            except Exception:
                pass

    threading.Thread(target=ProcessQRAuth, daemon=True).start()
