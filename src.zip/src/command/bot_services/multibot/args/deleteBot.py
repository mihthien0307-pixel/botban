"""
args/deleteBot.py – Xóa bot con khỏi hệ thống.
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import shutdownABot


def DeleteBot(this, bot: dict, filePath: str) -> bool:
    try:
        shutdownABot(bot)
    except Exception:
        pass

    if filePath == MAIN_LOGIN:
        return False  # Không xóa main bot

    if os.path.exists(filePath):
        try:
            os.remove(filePath)
        except Exception as e:
            logger.error(f"[DeleteBot] remove file: {e}")
            return False

    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {})
    if isinstance(dataBot, dict):
        for k, v in list(dataBot.items()):
            if v == os.path.basename(filePath):
                del dataBot[k]
    cfg["dataBot"] = dataBot
    saveJson(MAIN_LOGIN, cfg)
    return True
