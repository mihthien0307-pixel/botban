"""
manager/activeBot.py – Kích hoạt bot con + set thời hạn.
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import restartABot


def ActiveBot(this, bot: dict, filePath: str, items: list, timeExpr: str) -> None:
    now         = datetime.now()
    expireDelta = ParseTimeExpression(timeExpr)
    expireTime  = now + expireDelta

    bot["status"]      = True
    bot["isActived"]   = True
    bot["activedTime"] = now.strftime("%H:%M:%S-%d/%m/%Y")
    bot["expiredTime"] = expireTime.strftime("%H:%M:%S-%d/%m/%Y")

    SaveBotField(filePath, items, bot, "status",      True)
    SaveBotField(filePath, items, bot, "isActived",   True)
    SaveBotField(filePath, items, bot, "activedTime", bot["activedTime"])
    SaveBotField(filePath, items, bot, "expiredTime", bot["expiredTime"])

    restartABot(bot)
