"""
manager/changeOwner.py – Đổi chủ sở hữu một bot con.
"""

from src.command.bot_services.multibot.multibot_core import *


def _MentionsToUids(data) -> list:
    ms = getattr(data, "mentions", None) or []
    out = []
    for m in ms:
        try:
            uid = m.get("uid") if isinstance(m, dict) else getattr(m, "uid", None)
        except Exception:
            uid = None
        uid = str(uid or "").strip()
        if uid:
            out.append(uid)
    return list(dict.fromkeys(out))


def _ResolveLoginFile(this, oldUid, indexToken):
    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {})
    if not isinstance(dataBot, dict):
        dataBot = {}

    if indexToken and str(indexToken).isdigit():
        i = int(indexToken)
        loginFile = f"{i}-login.json"
        loginPath = os.path.join(MULTIBOT_DIR, loginFile)
        if not os.path.exists(loginPath):
            return None, None, None
        return loginFile, cfg, dataBot

    loginFile = str(dataBot.get(str(oldUid)) or "").strip()
    if not loginFile:
        return None, None, None
    return loginFile, cfg, dataBot


def ChangeOwnerBot(this, message, data, userId, threadId, type):
    uidFrom = GetUidFrom(data)
    if not uidFrom:
        return SendMention(this, "status:null", userId, threadId, type)

    raw   = (getattr(message, "text", "") or "").strip()
    parts = raw.split()
    token = parts[1] if len(parts) > 1 else None
    uids  = _MentionsToUids(data)

    oldUid = newUid = None
    if token and str(token).isdigit():
        if len(uids) < 1:
            return SendMention(this, "Hãy mention chủ mới", userId, threadId, type)
        newUid = uids[0]
    else:
        if len(uids) < 2:
            return SendMention(this, "Mention chủ cũ và chủ mới", userId, threadId, type)
        oldUid, newUid = uids[0], uids[1]

    loginFile, cfg, dataBot = _ResolveLoginFile(this, oldUid, token if (token and str(token).isdigit()) else None)
    if not loginFile:
        return SendMention(this, "Không tìm được file login của bot", userId, threadId, type)

    loginPath = os.path.join(MULTIBOT_DIR, loginFile)
    items     = ReadLoginJson(loginPath)

    if token and str(token).isdigit():
        oldUid = None
        for it in items:
            if isinstance(it, dict) and it.get("userClientId"):
                oldUid = str(it["userClientId"]).strip()
                break
        if not oldUid:
            return SendMention(this, "Không tìm được chủ cũ trong file login", userId, threadId, type)

    oldUid = str(oldUid or "").strip()
    newUid = str(newUid or "").strip()
    if not oldUid or not newUid:
        return SendMention(this, "UID không hợp lệ", userId, threadId, type)
    if oldUid == newUid:
        return SendMention(this, "Chủ cũ và mới giống nhau", userId, threadId, type)

    for it in items:
        if not isinstance(it, dict):
            continue
        if str(it.get("userClientId") or "").strip() == oldUid:
            it["userClientId"] = newUid
        if str(it.get("author_id") or it.get("clientBotId") or "").strip() == oldUid:
            it["author_id"]   = newUid
            it["clientBotId"] = newUid

    WriteLoginJson(loginPath, items)

    dataBot.pop(oldUid, None)
    dataBot[newUid] = loginFile
    cfg["dataBot"]  = dataBot
    saveJson(MAIN_LOGIN, cfg)

    return SendMention(this, f"Đã đổi chủ: {oldUid} → {newUid} ({loginFile})", userId, threadId, type)
