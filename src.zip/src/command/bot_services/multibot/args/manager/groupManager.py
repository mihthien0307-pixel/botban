"""
manager/groupManager.py – Liệt kê toàn bộ bot con (canvas với avatar).
"""

from src.command.bot_services.multibot.multibot_core import *
from src.services.pillow.mybotDraw import draw_bot_list
from app.login.utils import get_clientlist
import os as _os


def _extract_avatar_from_info(info) -> str:
    """Lấy avatar URL từ User object — avatar nằm trong info.profile.avatar"""
    if info is None:
        return ""
    try:
        profile = getattr(info, "profile", None)
        if profile:
            url = getattr(profile, "avatar", "") or ""
            if url and url.startswith("http"):
                return url.strip()
        # fallback: thử trực tiếp
        url = getattr(info, "avatar", "") or ""
        if url and url.startswith("http"):
            return url.strip()
    except Exception:
        pass
    return ""


def _get_avatar_for_bot(bot: dict, author_id: str, main_client) -> str:
    """Lấy avatar: thử chính client của bot trước, fallback main bot."""
    # 1. Đã lưu sẵn
    saved = (bot.get("avatar") or "").strip()
    if saved:
        logger.info(f"[Avatar] Using saved avatar for {author_id}: {saved[:60]}")
        return saved

    if not author_id:
        return ""

    # 2. Dùng chính client của bot đó gọi fetchAccountInfo
    try:
        clientlist = get_clientlist()
        bot_client = clientlist.get(str(author_id))
        if bot_client:
            info = bot_client.fetchAccountInfo()
            url = _extract_avatar_from_info(info)
            if url:
                return url
        else:
            logger.info(f"[Avatar] No client found for author_id={author_id}, clientlist keys={list(get_clientlist().keys())}")
    except Exception as e:
        logger.warning(f"[Avatar] fetchAccountInfo failed for {author_id}: {e}")

    # 3. Fallback: main bot fetchUserInfo
    try:
        info = main_client.fetchUserInfo(author_id)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile = profiles.get(str(author_id)) or {}
        url = profile.get("avatar", "") or ""
        if url:
            logger.info(f"[Avatar] Got from fetchUserInfo for {author_id}: {url[:60]}")
            return url.strip()
    except Exception as e:
        logger.warning(f"[Avatar] fetchUserInfo fallback failed for {author_id}: {e}")

    return ""


def _status_for_text(b: dict, src: str) -> str:
    if src == "MAIN" and (b.get("is_main_bot") or b.get("mainBot")):
        return "Main bot"
    exp_str = b.get("expiredTime")
    if exp_str:
        try:
            exp = datetime.strptime(str(exp_str), "%H:%M:%S-%d/%m/%Y")
            if datetime.now() > exp:
                return "Hết hạn"
        except Exception:
            pass
    if not b.get("status"):
        return "Đã dừng"
    return "Đang chạy"


def ListBots(this, message, data, userId, threadId, type):
    arr = BuildBotIndexList()
    if not arr:
        return SendMention(this, "Không có bot nào trong hệ thống", userId, threadId, type)

    cmdb = f"{this.prefix}{this.rawCommand}"

    bot_entries = []
    for i, (b, src, fp) in enumerate(arr, 1):
        if not isinstance(b, dict):
            continue
        author_id = str(b.get("author_id") or b.get("botIntId") or "")

        if src == "MAIN":
            av_url = ""
            try:
                info = this.fetchAccountInfo()
                av_url = _extract_avatar_from_info(info)
            except Exception as e:
                logger.warning(f"[Avatar] Main bot fetchAccountInfo failed: {e}")
        else:
            av_url = _get_avatar_for_bot(b, author_id, this)

        bot_entries.append((i, b, src, av_url))

    if not bot_entries:
        return SendMention(this, "Không có bot nào hợp lệ", userId, threadId, type)

    try:
        cache_dir = "data/assets/cache/image"
        _os.makedirs(cache_dir, exist_ok=True)
        out_path = _os.path.join(cache_dir, f"botlist_{this.uid}_{threadId}.jpg")
        w, h = draw_bot_list(out_path, bot_entries, cmdb=cmdb)
        this.sendLocalImage(out_path, threadId, type, width=w, height=h)
        try:
            _os.remove(out_path)
        except Exception:
            pass
    except Exception as e:
        logger.warning(f"[ListBots] canvas error: {e}")
        lines = [f"📋 Danh sách bot ({len(bot_entries)} bot):\n"]
        for i, b, src, _ in bot_entries:
            st   = _status_for_text(b, src)
            name = b.get("username", "Unknown")
            pref = b.get("prefix", "?")
            uid  = str(b.get("author_id") or b.get("botIntId") or "N/A")
            tag  = "[MAIN] " if (src == "MAIN" and (b.get("is_main_bot") or b.get("mainBot"))) else ""
            lines.append("━━━━━━━━━━━━━━")
            lines.append(f"#{i} {tag}{name}")
            lines.append(f"   Prefix : {pref}")
            lines.append(f"   UID    : {uid}")
            lines.append(f"   Trạng  : {st}")
            if b.get("expiredTime"):
                lines.append(f"   Hết hạn: {b.get('expiredTime')}")
        lines.append("━━━━━━━━━━━━━━")
        lines.append(f"💡 Dùng: {cmdb} detail [index]")
        SendMention(this, "\n".join(lines), userId, threadId, type)
