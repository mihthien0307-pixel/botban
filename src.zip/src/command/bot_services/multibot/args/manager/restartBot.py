"""
manager/restartBot.py – Restart một bot con.
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import restartABot


def RestartBot(this, bot: dict, filePath: str, items: list) -> None:
    bot["status"] = True
    if filePath and filePath.endswith(".json") and filePath != MAIN_LOGIN:
        WriteLoginJson(filePath, items)
    restartABot(bot)
