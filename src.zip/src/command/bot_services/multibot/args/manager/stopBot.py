"""
manager/stopBot.py – Dừng một bot con.
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import shutdownABot


def StopBot(this, bot: dict, filePath: str, items: list) -> None:
    bot["status"] = False
    if filePath and filePath.endswith(".json"):
        if filePath == MAIN_LOGIN:
            cfg, data = _load_main_data()
            bid = str(bot.get("author_id") or bot.get("imei") or "")
            for b in data:
                if str(b.get("author_id") or b.get("imei") or "") == bid:
                    b["status"] = False
            _save_main_data(cfg)
        else:
            WriteLoginJson(filePath, items)
    shutdownABot(bot)
