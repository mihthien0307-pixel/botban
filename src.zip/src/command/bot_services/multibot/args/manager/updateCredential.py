"""
manager/updateCredential.py – Cập nhật IMEI + Cookies cho bot con.
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import restartABot


def UpdateLoginCre(this, message, data, userId, threadId, type):
    raw   = (getattr(message, "text", "") or "").strip()
    parts = raw.split(maxsplit=4)

    if not parts or parts[0].lower() != "update":
        return

    if getattr(this, "is_main_bot", False):
        # Cú pháp: update [index|@mention] IMEI {cookies}
        if len(parts) < 4:
            return SendMention(this, "Cú pháp: update [index/@mention] [IMEI] [Cookies JSON]", userId, threadId, type)

        token   = parts[1]
        imei    = parts[2]
        payload = ExtractJsonPayload(" ".join(parts[3:]))
        if not payload:
            return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)
        try:
            sessionCookies = json.loads(payload)
        except Exception:
            return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)

        bot, filePath, items = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
        if not bot:
            return

        bot["imei"]            = imei
        bot["session_cookies"] = sessionCookies
        bot["sessionCookies"]  = sessionCookies
        SaveBotField(filePath, items, bot, "imei", imei)
        SaveBotField(filePath, items, bot, "session_cookies", sessionCookies)

        restartABot(bot)
        return SendMention(this, "Đã cập nhật!", userId, threadId, type)

    # Bot con tự update
    if len(parts) < 3:
        return SendMention(this, "Cú pháp: update [IMEI] [Cookies JSON]", userId, threadId, type)

    imei    = parts[1]
    payload = ExtractJsonPayload(" ".join(parts[2:]))
    if not payload:
        return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)
    try:
        sessionCookies = json.loads(payload)
    except Exception:
        return SendMention(this, "Cookies JSON không hợp lệ", userId, threadId, type)

    bot, filePath, items = GetOwnBot(this, data, userId, threadId, type)
    if not bot:
        return

    bot["imei"]            = imei
    bot["session_cookies"] = sessionCookies
    bot["sessionCookies"]  = sessionCookies
    WriteLoginJson(filePath, items)
    restartABot(bot)
    SendMention(this, "Đã cập nhật!", userId, threadId, type)
