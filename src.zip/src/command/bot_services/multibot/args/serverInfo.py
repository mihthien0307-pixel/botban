"""
args/serverInfo.py – Hiển thị thông tin bot / server.
"""

from src.command.bot_services.multibot.multibot_core import *


def BuildBotInfoText(bot: dict) -> str:
    name   = bot.get("username") or "Unknown"
    uid    = bot.get("author_id") or bot.get("botIntId") or "None"
    prefix = bot.get("prefix") or "None"
    et     = bot.get("expiredTime") or "None"
    at     = bot.get("activedTime") or "None"
    stt    = "True" if bot.get("status") is True else "False"
    return (
        "@getBotInfo:\n\n"
        f":name {name}\n"
        f":uid {uid}\n"
        f":prefix {prefix}\n"
        f":expiredtime {et}\n"
        f":activedtime {at}\n\n"
        f"@status: {stt}"
    )


def TryBuildServerInfoText(this) -> str:
    try:
        name = str(getattr(this, "bot", "Main Bot"))
        uid  = str(getattr(this, "uid", "N/A"))
        pref = str(getattr(this, "prefix", "?"))
        return (
            "@getServerInfo [Main Bot]\n\n"
            f":name {name}\n"
            f":uid {uid}\n"
            f":prefix {pref}\n"
        )
    except Exception:
        return "@getServerInfo\nNone"
