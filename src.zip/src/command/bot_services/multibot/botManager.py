
from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import restartABot
from src.command.bot_services.multibot.args.createBot import CreateBot
from src.command.bot_services.multibot.args.createBotQR import CreateBotQR
from src.command.bot_services.multibot.args.deleteBot import DeleteBot
from src.command.bot_services.multibot.args.manager.activeBot import ActiveBot
from src.command.bot_services.multibot.args.manager.restartBot import RestartBot
from src.command.bot_services.multibot.args.manager.stopBot import StopBot
from src.command.bot_services.multibot.args.manager.updateCredential import UpdateLoginCre
from src.command.bot_services.multibot.args.manager.changeOwner import ChangeOwnerBot
from src.command.bot_services.multibot.args.manager.groupManager import ListBots
from src.command.bot_services.multibot.args.serverInfo import BuildBotInfoText, TryBuildServerInfoText



def _FindBotByUserId(userId: str):
    """
    Tìm bot theo author_id = userId (người gửi lệnh).
    Tìm trong login.json (main bot) trước, sau đó quét multibot/.
    Trả về (bot_dict, filepath, items_list).
    """
    import json as _json, os as _os
    uid = str(userId or "").strip()

    # Tìm trong login.json (main bot)
    try:
        with open(MAIN_LOGIN, "r", encoding="utf-8") as f:
            cfg = _json.load(f)
        main_bots = cfg.get("data", [])
        for b in main_bots:
            if isinstance(b, dict) and str(b.get("author_id") or "") == uid:
                return b, MAIN_LOGIN, main_bots
    except Exception:
        pass

    # Quét multibot/
    if _os.path.isdir(MULTIBOT_DIR):
        for fname in sorted(_os.listdir(MULTIBOT_DIR)):
            if not fname.endswith("-login.json"):
                continue
            fpath = _os.path.join(MULTIBOT_DIR, fname)
            try:
                items = ReadLoginJson(fpath)
                bot   = PickBotItem(items)
                if bot and str(bot.get("author_id") or "") == uid:
                    return bot, fpath, items
            except Exception:
                continue

    return None, None, None


def botManager(this, message, data, userId, threadId, type):
    try:
        text  = (getattr(message, "text", "") or "").strip()
        parts = text.split()
        cmdb  = f"{this.prefix}{this.rawCommand}"
        isMainBot = getattr(this, "is_main_bot", False)

        # ── Menu khi không có sub-lệnh ────────────────────────────────────
        if len(parts) < 2:
            this.replyMessageStyle(
                f"📋 HƯỚNG DẪN QUẢN LÝ BOT 📋\n\n"
                f"1️⃣ Đây là danh sách lệnh quản lý Bot cá nhân\n\n"
                f"➤『{cmdb} set』 - Cập nhật thông tin chủ bot\n"
                f"   • {cmdb} set name [tên của bạn]\n"
                f"   • {cmdb} set typePlatform [pc/web]\n"
                f"   • {cmdb} set description [giới thiệu]\n"
                f"   • {cmdb} set botInfo [thông tin bot]\n"
                f"   • {cmdb} set expire [số index/@tên] [số ngày / 0=vô hạn]\n"
                f"➤『{cmdb} prefix [prefix mới]』 - Đổi prefix bot\n"
                f"➤『{cmdb} detail』 - Xem thông tin chi tiết bot\n"
                f"➤『{cmdb} restart』 - Khởi động lại bot\n"
                f"➤『{cmdb} start [@tên hoặc số]』 - Bật tất cả bot / bot chỉ định\n"
                f"➤『{cmdb} shutdown』 - Tắt bot\n"
                f"➤『{cmdb} create』 - Tạo bot mới (login bằng data)\n"
                f"➤『{cmdb} qrlogin』 - Tạo bot mới (login bằng QR)\n"
                f"➤『{cmdb} delete [số/@bot]』 - Xóa bot",
                data, threadId, type,
                color=MsgStyle.SUCCESS.value,
                title=MsgStyle.SUCCESS.title,
                userId=userId,
            )
            return

        cmd        = parts[1].lower()
        isMain     = IsMainBotUser(userId)
        hasMention = bool(GetMentionUid(this, data))
        token      = parts[2] if len(parts) > 2 else None



        # ── server ────────────────────────────────────────────────────────
        if cmd == "server":
            return sendMSuccess(this, 
                getattr(this, "appServer", "Chưa cấu hình appServer"),
                userId, threadId, type
            )



        # ── prefix ────────────────────────────────────────────────────────
        if cmd == "prefix":
            args = [x for x in parts[2:] if x != "|"]
            if isMainBot:
                # Main bot: bắt buộc chỉ định bot bằng số index, @mention, hoặc không có args (đổi chính mình)
                # Cú pháp: ,mybot prefix 1 !   →  đổi bot số 1 sang prefix !
                #          ,mybot prefix !      →  đổi chính main bot sang prefix !
                indexToken = args[0] if (hasMention or (args and args[0].isdigit())) else None
                newPrefix  = args[1] if indexToken and len(args) >= 2 else (args[0] if args else None)
                if not newPrefix:
                    arr = BuildBotIndexList()
                    hint = f"{cmdb} prefix [số_bot] [prefix]\nVD: {cmdb} prefix 1 !\n\n"
                    hint += f"Danh sách bot:\n"
                    for i, (b, src, fp_) in enumerate(arr, 1):
                        if not isinstance(b, dict): continue
                        tag = "[MAIN] " if (b.get("is_main_bot") or b.get("mainBot")) else ""
                        hint += f"{i}. {tag}{b.get('username','?')} [prefix: {b.get('prefix','?')}]\n"
                    return sendMFailed(this, hint.strip(), userId, threadId, type)
                if indexToken:
                    bot, fp, items = GetBotByIndexOrMention(this, data, userId, threadId, type, indexToken)
                    if not bot:
                        return
                    SaveBotField(fp, items, bot, "prefix", newPrefix)
                    return sendMSuccess(this, f"Đã cập nhật prefix bot #{indexToken} ({bot.get('username','?')}): {newPrefix}", userId, threadId, type)
                bot, fp, items = GetOwnBotByFilePath(this)
                if not bot:
                    bot, fp, items = GetOwnBot(this, data, userId, threadId, type)
                if not bot:
                    return sendMFailed(this, "Không tìm thấy bot", userId, threadId, type)
                SaveBotField(fp, items, bot, "prefix", newPrefix)
                return sendMSuccess(this, f"Đã cập nhật prefix: {newPrefix}", userId, threadId, type)

            # Bot con: tự đổi prefix của mình
            bot, fp, items = GetOwnBotByFilePath(this)
            if not bot:
                bot, fp, items = GetOwnBot(this, data, userId, threadId, type)
            if not bot:
                return sendMFailed(this, "Không tìm thấy bot", userId, threadId, type)
            newPrefix = args[0] if args else None
            if not newPrefix:
                return sendMFailed(this, f"Dùng: {cmdb} prefix [prefix mới]", userId, threadId, type)
            SaveBotField(fp, items, bot, "prefix", newPrefix)
            return sendMSuccess(this, f"Đã cập nhật prefix: {newPrefix}", userId, threadId, type)

        # ── login type (alias: typeplatform) ─────────────────────────────
        if cmd in ("login", "typeplatform"):
            if len(parts) < 3:
                return sendMFailed(this, "Chọn loại: web hoặc pc", userId, threadId, type)
            loginType  = (parts[2] or "").lower()
            if loginType not in ("web", "pc"):
                return sendMFailed(this, "Chỉ hỗ trợ: web hoặc pc", userId, threadId, type)
            loginValue = 30 if loginType == "web" else 24

            if isMainBot:
                loginToken = parts[3] if len(parts) > 3 else None
                if not loginToken and not hasMention:
                    return sendMFailed(this, "Chỉ định bot cần đổi login type", userId, threadId, type)
                bot, fp, items = GetBotByIndexOrMention(this, data, userId, threadId, type, loginToken)
                if not bot:
                    return
                SaveBotField(fp, items, bot, "login", loginValue)
                return sendMSuccess(this, 
                    f"Đã cập nhật login type: {loginType.upper()} cho {bot.get('username')}",
                    userId, threadId, type
                )

            bot, fp, items = GetOwnBotByFilePath(this)
            if not bot:
                bot, fp, items = GetOwnBot(this, data, userId, threadId, type)
            if not bot:
                return sendMFailed(this, "Không tìm thấy bot", userId, threadId, type)
            SaveBotField(fp, items, bot, "login", loginValue)
            sendMSuccess(this, f"Đã cập nhật login type: {loginType.upper()}", userId, threadId, type)
            restartABot(bot)
            return

        # ── detail (canvas chi tiết bot) ─────────────────────────────────
        if cmd == "detail":
            from src.services.pillow.mybotDraw import draw_bot_detail
            from src.command.bot_services.multibot.args.manager.groupManager import (
                _extract_avatar_from_info, _get_avatar_for_bot,
            )
            import os as _os

            bot, fp = None, None

            if isMainBot:
                if len(parts) >= 3 or hasMention:
                    bot, fp, _ = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
                    if not bot:
                        return
                else:
                    arr = BuildBotIndexList()
                    me  = str(getattr(this, "uid", "") or "")
                    match = next(
                        (b for b, src_, fp_ in arr
                         if str(b.get("author_id") or "") == me
                         and (b.get("is_main_bot") or src_ == "MAIN")),
                        None
                    )
                    bot = match or {
                        "username":   getattr(this, "bot", "Main Bot"),
                        "author_id":  me,
                        "prefix":     getattr(this, "prefix", "?"),
                        "status":     True,
                        "is_main_bot": True,
                        "login":      30,
                    }
                    fp = MAIN_LOGIN
            else:
                bot, fp, _ = GetOwnBotByFilePath(this)
                if not bot:
                    bot, fp, _ = GetOwnBot(this, data, userId, threadId, type)
                if not bot:
                    return sendMFailed(this, "Không tìm thấy bot", userId, threadId, type)

            author_id = str(bot.get("author_id") or bot.get("botIntId") or "")

            av_url = ""
            try:
                if IsMainBotTarget(fp, bot):
                    info  = this.fetchAccountInfo()
                    av_url = _extract_avatar_from_info(info)
                else:
                    av_url = _get_avatar_for_bot(bot, author_id, this)
            except Exception:
                av_url = ""

            server_running = str(getattr(this, "bot", "N/A"))
            creator_name    = server_running

            cache_dir = "data/assets/cache/image"
            _os.makedirs(cache_dir, exist_ok=True)
            out_path = _os.path.join(cache_dir, f"botdetail_{this.uid}_{threadId}.jpg")
            try:
                w, h = draw_bot_detail(
                    out_path, bot, cmdb=cmdb,
                    avatar_url=av_url,
                    creator_name=creator_name,
                    server_running=server_running,
                )
                this.sendLocalImage(out_path, threadId, type, width=w, height=h)
                try:
                    _os.remove(out_path)
                except Exception:
                    pass
            except Exception as e:
                logger.error(f"[mybot detail] canvas error: {e}")
                if IsMainBotTarget(fp, bot):
                    return sendMSuccess(this, TryBuildServerInfoText(this), userId, threadId, type)
                return sendMSuccess(this, BuildBotInfoText(bot), userId, threadId, type)
            return

        # ── qrlogin (alias của create qr) ────────────────────────────────
        if cmd == "qrlogin":
            if not isMainBot:
                return sendMFailed(this, "Chỉ Main Bot mới dùng được lệnh này!", userId, threadId, type)
            return CreateBotQR(this, data, userId, threadId, type)

        # ── shutdown (alias của stop) ─────────────────────────────────────
        if cmd == "shutdown":
            if not isMainBot:
                bot, fp, items = GetOwnBotByFilePath(this)
                if not fp:
                    return sendMFailed(this, "Không tìm thấy filePath trong bot-manager", userId, threadId, type)
                if not bot:
                    return sendMFailed(this, "Không tìm thấy bot trong file login", userId, threadId, type)
                StopBot(this, bot, fp, items)
                return sendMSuccess(this, "Bot đã được tắt.", userId, threadId, type)
            if len(parts) < 3 and not hasMention:
                return sendMFailed(this, "Chỉ định bot cần tắt", userId, threadId, type)
            bot, fp, items = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
            if not bot:
                return
            StopBot(this, bot, fp, items)
            return sendMSuccess(this, f"Đã tắt bot {bot.get('username')}", userId, threadId, type)

        # ── nameserver ────────────────────────────────────────────────────
        if cmd == "nameserver":
            if len(parts) < 3:
                return sendMFailed(this, f"Dùng: {cmdb} nameserver [tên mới]", userId, threadId, type)
            new_name = " ".join(parts[2:])
            bot, fp, items = GetOwnBotByFilePath(this)
            if not bot:
                bot, fp, items = GetOwnBot(this, data, userId, threadId, type)
            if not bot:
                return sendMFailed(this, "Không tìm thấy bot", userId, threadId, type)
            SaveBotField(fp, items, bot, "serverName", new_name)
            return sendMSuccess(this, f"Đã đổi tên server thành: {new_name}", userId, threadId, type)

        # ── set (cập nhật thông tin hiển thị của bot) ─────────────────────
        if cmd == "set":
            if len(parts) < 4:
                return sendMFailed(this,
                    f"Dùng: {cmdb} set [name|typeplatform|description|botinfo|expire] [giá trị]\n\n"
                    f"➤ {cmdb} set name [tên của bạn]\n"
                    f"➤ {cmdb} set typeplatform [pc/web]\n"
                    f"➤ {cmdb} set description [giới thiệu]\n"
                    f"➤ {cmdb} set botinfo [thông tin bot]\n"
                    f"➤ {cmdb} set expire [index/@bot] [số ngày / 30d / 1mo / 0=vô hạn]",
                    userId, threadId, type
                )

            field = parts[2].lower()
            value = " ".join(parts[3:])

            # Tìm bot theo userId (author_id của người gửi lệnh)
            bot, fp, items = _FindBotByUserId(str(userId))
            if not bot:
                return sendMFailed(this, "Không tìm thấy bot của bạn", userId, threadId, type)

            if field == "name":
                SaveBotField(fp, items, bot, "serverName", value)
                return this.replyMessageStyle(
                    f"✅ Đã cập nhật tên đại diện bot: {value}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value,
                    title=MsgStyle.SUCCESS.title,
                    userId=userId,
                )

            if field in ("typeplatform", "platform", "login"):
                v = value.lower()
                if v not in ("web", "pc"):
                    return sendMFailed(this, "Chỉ hỗ trợ: web hoặc pc", userId, threadId, type)
                SaveBotField(fp, items, bot, "login", 30 if v == "web" else 24)
                return this.replyMessageStyle(
                    f"✅ Đã cập nhật nền tảng đăng nhập: {v.upper()}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value,
                    title=MsgStyle.SUCCESS.title,
                    userId=userId,
                )

            if field == "description":
                SaveBotField(fp, items, bot, "description", value)
                return this.replyMessageStyle(
                    f"✅ Đã cập nhật giới thiệu bot: {value}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value,
                    title=MsgStyle.SUCCESS.title,
                    userId=userId,
                )

            if field in ("botinfo", "botInfo".lower()):
                SaveBotField(fp, items, bot, "botInfo", value)
                return this.replyMessageStyle(
                    f"✅ Đã cập nhật thông tin bot: {value}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value,
                    title=MsgStyle.SUCCESS.title,
                    userId=userId,
                )

            if field == "expire":
                # Cú pháp: .mybot set expire [index/@bot] [ngày/0]
                # Chỉ main bot mới đặt expire cho bot khác
                # value = phần sau field, vd "1 30d" hoặc "30d" hoặc "0"
                import datetime as _dt
                expire_parts = value.split()
                if isMain and len(expire_parts) >= 2:
                    # Main bot chỉ định bot cụ thể: .mybot set expire 1 30d
                    target_token = expire_parts[0]
                    time_expr    = expire_parts[1]
                    t_bot, t_fp, t_items = GetBotByIndexOrMention(this, data, userId, threadId, type, target_token if not hasMention else None)
                    if not t_bot:
                        return
                elif isMain and hasMention:
                    time_expr = expire_parts[0] if expire_parts else "0"
                    t_bot, t_fp, t_items = GetBotByIndexOrMention(this, data, userId, threadId, type, None)
                    if not t_bot:
                        return
                else:
                    # Bot con tự đặt expire của mình
                    time_expr = expire_parts[0] if expire_parts else "0"
                    t_bot, t_fp, t_items = bot, fp, items

                target_name = t_bot.get("username", "?")

                if time_expr == "0":
                    SaveBotField(t_fp, t_items, t_bot, "expiredTime", None)
                    return this.replyMessageStyle(
                        f"✅ Đã đặt bot [{target_name}]: Vô hạn ♾️",
                        data, threadId, type,
                        color=MsgStyle.SUCCESS.value,
                        title=MsgStyle.SUCCESS.title,
                        userId=userId,
                    )

                # Hỗ trợ cả số ngày thuần (30) và ParseTimeExpression (30d / 1mo / 1y)
                try:
                    days = int(time_expr)
                    delta = _dt.timedelta(days=days)
                except ValueError:
                    delta = ParseTimeExpression(time_expr)

                if not delta or delta.total_seconds() <= 0:
                    return sendMFailed(this,
                        f"Thời gian không hợp lệ. Ví dụ: 30 | 30d | 1mo | 1y | 0 (vô hạn)",
                        userId, threadId, type)

                expire_dt   = _dt.datetime.now() + delta
                expire_date = expire_dt.strftime("%H:%M:%S-%d/%m/%Y")
                SaveBotField(t_fp, t_items, t_bot, "expiredTime", expire_date)
                days_left = delta.days
                return this.replyMessageStyle(
                    f"✅ [{target_name}] hết hạn: {expire_dt.strftime('%d/%m/%Y %H:%M')} ({days_left} ngày)",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value,
                    title=MsgStyle.SUCCESS.title,
                    userId=userId,
                )

            return sendMFailed(this,
                f"Trường không hợp lệ. Dùng: {cmdb} set [name|typeplatform|description|botinfo|expire] [giá trị]",
                userId, threadId, type
            )

        # ── getupdate (cập nhật credentials bằng QR) ─────────────────────
        if cmd == "getupdate":
            return CreateBotQR(this, data, userId, threadId, type)

        # ── Các lệnh chỉ main bot mới dùng được khi nhắm vào bot khác ────
        if not isMainBot and cmd in ("create", "delete", "list", "group", "changeowner"):
            return sendMFailed(this, "Chỉ Main Bot mới dùng được lệnh này!", userId, threadId, type)

        # ── create ────────────────────────────────────────────────────────
        if cmd == "create":
            if len(parts) > 2 and parts[2].lower() == "qr":
                return CreateBotQR(this, data, userId, threadId, type)
            from api.util.msg import Message as _Msg
            message.text = " ".join(parts[2:])
            return CreateBot(this, message, data, userId, threadId, type)

        # ── list ──────────────────────────────────────────────────────────
        if cmd == "list":
            return ListBots(this, message, data, userId, threadId, type)

        # ── restart / stop cho bot con (tự làm) ───────────────────────────
        if not isMainBot and cmd == "restart":
            bot, fp, items = GetOwnBotByFilePath(this)
            if not fp:
                return sendMFailed(this, "Không tìm thấy filePath trong bot-manager", userId, threadId, type)
            if not bot:
                return sendMFailed(this, "Không tìm thấy bot trong file login", userId, threadId, type)
            RestartBot(this, bot, fp, items)
            return sendMSuccess(this, "Đang khởi động lại bot..!", userId, threadId, type)

        # ── start cho bot con ─────────────────────────────────────────────
        if not isMainBot and cmd == "start":
            # Nếu có chỉ định @mention hoặc số index → bật bot cụ thể
            if hasMention or (len(parts) > 2 and (parts[2].isdigit() or parts[2].startswith("@"))):
                bot, fp, items = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
                if not bot:
                    return
                bot["status"] = True
                WriteLoginJson(fp, items)
                restartABot(bot)
                return sendMSuccess(this, f"Đã bật bot: {bot.get('username', '?')}", userId, threadId, type)
            # Không chỉ định → bật tất cả bot
            arr = BuildBotIndexList()
            count = 0
            for b, src, fp_ in arr:
                if not isinstance(b, dict):
                    continue
                b["status"] = True
                WriteLoginJson(fp_, [b] if not isinstance(b, list) else b)
                try:
                    restartABot(b)
                    count += 1
                except Exception:
                    pass
            return sendMSuccess(this, f"Đã bật tất cả bot ({count} bot) ✅", userId, threadId, type)

        # ── Yêu cầu mainBot cho các lệnh còn lại ─────────────────────────
        if not isMain:
            return sendMFailed(this, "Không có quyền!", userId, threadId, type)

        # ── start (main) ──────────────────────────────────────────────────
        if cmd == "start":
            if len(parts) < 4 and not hasMention:
                return sendMFailed(this, "Chỉ định bot và thời gian (vd: start 1 1h | start 1 0 = vô hạn)", userId, threadId, type)
            timeExpr = parts[-1]
            bot, fp, items = GetBotByIndexOrMention(
                this, data, userId, threadId, type,
                token if len(parts) > 3 else None
            )
            if not bot:
                return
            # 0 = vô hạn
            if timeExpr == "0":
                bot["expiredTime"] = None
                bot["activedTime"] = None
                bot["status"] = True
                WriteLoginJson(fp, items)
                restartABot(bot)
                return sendMSuccess(this,
                    f"Đã kích hoạt bot {bot.get('username', '?')}: Vô hạn ♾️",
                    userId, threadId, type
                )
            ActiveBot(this, bot, fp, items, timeExpr)
            return sendMSuccess(this, 
                f"Đã kích hoạt: {bot.get('activedTime')} → hết hạn {bot.get('expiredTime')}",
                userId, threadId, type
            )

        # ── restart (main) ────────────────────────────────────────────────
        if cmd == "restart":
            if len(parts) < 3 and not hasMention:
                return sendMFailed(this, "Chỉ định bot cần restart", userId, threadId, type)
            bot, fp, items = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
            if not bot:
                return
            RestartBot(this, bot, fp, items)
            return sendMSuccess(this, f"Đã restart {bot.get('username')}", userId, threadId, type)

        # ── delete (main) ─────────────────────────────────────────────────
        if cmd == "delete":
            if len(parts) < 3 and not hasMention:
                return sendMFailed(this, "Chỉ định bot cần xóa", userId, threadId, type)
            bot, fp, _ = GetBotByIndexOrMention(this, data, userId, threadId, type, token)
            if not bot:
                return
            if fp == MAIN_LOGIN:
                return sendMFailed(this, "Không thể xóa main bot!", userId, threadId, type)
            if not DeleteBot(this, bot, fp):
                return sendMFailed(this, "Xóa thất bại", userId, threadId, type)
            return sendMSuccess(this, "Đã xóa bot khỏi hệ thống", userId, threadId, type)

        # ── update ────────────────────────────────────────────────────────
        if cmd == "update":
            if not isMain:
                return sendMFailed(this, "Chỉ main bot mới dùng được!", userId, threadId, type)
            if len(parts) < 4 and not hasMention:
                return sendMFailed(this, "Chỉ định bot cần update", userId, threadId, type)
            message.text = " ".join(parts[1:])
            return UpdateLoginCre(this, message, data, userId, threadId, type)

        # ── changeowner ───────────────────────────────────────────────────
        if cmd == "changeowner":
            return ChangeOwnerBot(this, message, data, userId, threadId, type)

        # ── group (main) ──────────────────────────────────────────────────
        if cmd == "group":
            sub = parts[2].lower() if len(parts) > 2 else ""
            if sub == "set":
                try:
                    res  = this.getGroupLink(threadId) or {}
                    link = res.get("data", {}).get("link") if isinstance(res, dict) else None
                except Exception:
                    link = None
                if not link:
                    return sendMFailed(this, "Không lấy được group link", userId, threadId, type)
                cfg = loadBotManager()
                dg  = cfg.setdefault("dataGroup", {})
                dg["groupSet"] = link
                botManagerSave(cfg)
                return sendMSuccess(this, f"Đã lưu groupSet: {link}", userId, threadId, type)

            if sub == "notify":
                cfg = loadBotManager()
                dg  = cfg.setdefault("dataGroup", {})
                dg["sendNotify"] = not bool(dg.get("sendNotify"))
                botManagerSave(cfg)
                return sendMSuccess(this, f"sendNotify: {dg['sendNotify']}", userId, threadId, type)

            return sendMWarning(this, "Dùng: group set | group notify", userId, threadId, type)

    except Exception as e:
        logger.error(f"[botManager] error: {e}")
        import traceback
        traceback.print_exc()


# ── zBot auto-load ────────────────────────────────────────────────────────────

dependencies = {
    "name":        "mybot",
    "description": "Tạo và quản lý bot con (multibot)",
    "permission":  0,       # Mọi người đều thấy menu, quyền được check bên trong
    "cooldown":    3,
    "alias":       ["botmanager", "bm", "mb"],
    "noPrefix":    False,
    "is_main":     False,
    "main":        botManager,
}
