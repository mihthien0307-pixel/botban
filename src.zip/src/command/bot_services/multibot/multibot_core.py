"""
multibot_core.py
Helpers dùng chung cho toàn bộ hệ thống multibot của zBot.
Thay thế cho ztf/functions/services/hook/core_hook/extra_multibot_core.py
"""

from app.library.packages import *
from src.services.utils.jsonio import load_json, save_json, ensure_dir
from datetime import timedelta

# ── Đường dẫn cố định ────────────────────────────────────────────────────────

MAIN_LOGIN   = "data/config/login.json"
MULTIBOT_DIR = "data/config/multibot"
BOT_MANAGER_PATH = "data/config/bot-manager-database.json"

# ── JSON helpers ──────────────────────────────────────────────────────────────

def jsonLoader(path, default=None):
    return load_json(path, default if default is not None else {})

def saveJson(path, data):
    ensure_dir(os.path.dirname(path))
    save_json(path, data)

# ── Login-file helpers ────────────────────────────────────────────────────────

def ReadLoginJson(path: str) -> list:
    """Đọc file JSON bot-con, trả về list luôn."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.loads(f.read() or "[]")
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and "data" in data:
            return data["data"] if isinstance(data["data"], list) else []
        return []
    except Exception as e:
        logger.error(f"[ReadLoginJson] {e}")
        return []

def WriteLoginJson(path: str, items: list) -> None:
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(items, ensure_ascii=False, indent=4))

# ── Bot-manager-database helpers ──────────────────────────────────────────────

def loadBotManager() -> dict:
    return jsonLoader(BOT_MANAGER_PATH) or {}

def botManagerSave(cfg: dict) -> None:
    saveJson(BOT_MANAGER_PATH, cfg)

def ensureBotManagerData(cfg: dict) -> list:
    arr = cfg.get("data")
    if isinstance(arr, list):
        return arr
    arr = []
    cfg["data"] = arr
    return arr

def NormalizePath(p) -> str:
    s = str(p or "").strip().replace("\\", "/")
    while "//" in s:
        s = s.replace("//", "/")
    return s

def UpsertBotManagerRunning(uid, mainBot, filePath):
    """Ghi nhận bot đang chạy vào bot-manager-database."""
    try:
        cfg  = loadBotManager()
        arr  = ensureBotManagerData(cfg)
        uid  = str(uid or "").strip()
        fp   = NormalizePath(filePath)
        main = bool(mainBot)
        if not uid or not fp:
            return
        for it in arr:
            if not isinstance(it, dict):
                continue
            if (str(it.get("this.uid") or "") == uid
                    and bool(it.get("this.mainBot")) == main
                    and NormalizePath(it.get("filePath")) == fp):
                return
        newArr = [it for it in arr if isinstance(it, dict)
                  and not (str(it.get("this.uid") or "") == uid
                           and bool(it.get("this.mainBot")) == main)]
        newArr.append({"this.uid": uid, "this.mainBot": main, "filePath": fp})
        cfg["data"] = newArr
        botManagerSave(cfg)
    except Exception as e:
        logger.error(f"[UpsertBotManagerRunning] {e}")

# ── Tìm file đang chạy của bot hiện tại ──────────────────────────────────────

def GetThisImei(this) -> str:
    v = getattr(this, "imei", None)
    return str(v) if v else ""

def GetThisBotIntId(this) -> str:
    v = getattr(this, "botIntId", None)
    if v:
        return str(v)
    return str(getattr(this, "uid", "") or "")

def MatchthisBotItem(this, it: dict) -> bool:
    uid = str(getattr(this, "uid", "") or "").strip()
    if uid and str(it.get("uid") or it.get("author_id") or "").strip() == uid:
        return True
    imei = GetThisImei(this)
    if imei and str(it.get("imei") or "").strip() == imei:
        return True
    return False

def GetthisFilePathFromBotManager(this):
    try:
        cfg = loadBotManager()
        arr = cfg.get("data")
        if not isinstance(arr, list):
            return None
        uid  = str(getattr(this, "uid", "") or "").strip()
        main = getattr(this, "is_main_bot", False)
        for it in arr:
            if not isinstance(it, dict):
                continue
            if bool(it.get("this.mainBot")) == bool(main) and str(it.get("this.uid") or "").strip() == uid:
                fp = NormalizePath(it.get("filePath"))
                return fp or None
        return None
    except Exception:
        return None

def GetOwnBotByFilePath(this):
    """Trả về (bot_dict, filepath, items_list) của chính bot this."""
    fp = GetthisFilePathFromBotManager(this)
    if not fp or not os.path.exists(fp):
        return None, None, None
    items = ReadLoginJson(fp)
    if not isinstance(items, list) or not items:
        return None, fp, items
    for it in items:
        if isinstance(it, dict) and MatchthisBotItem(this, it):
            return it, fp, items
    if len(items) == 1 and isinstance(items[0], dict):
        return items[0], fp, items
    return None, fp, items

# ── Main-login helpers ────────────────────────────────────────────────────────

def _load_main_data() -> tuple:
    """Trả về (cfg_dict, data_list)"""
    cfg  = jsonLoader(MAIN_LOGIN) or {}
    data = cfg.get("data", [])
    if not isinstance(data, list):
        data = []
        cfg["data"] = data
    return cfg, data

def _save_main_data(cfg: dict) -> None:
    saveJson(MAIN_LOGIN, cfg)

# ── Bot-index helpers ─────────────────────────────────────────────────────────

def PickBotItem(items: list) -> dict | None:
    """Lấy dict bot chính (không phải userClientId record)."""
    for it in items:
        if isinstance(it, dict) and (it.get("imei") or it.get("session_cookies") or it.get("sessionCookies")):
            return it
    return None

def HasUserClientId(items: list, uid) -> bool:
    uid = str(uid)
    for it in items:
        if isinstance(it, dict) and str(it.get("userClientId") or "") == uid:
            return True
    return False

def BuildBotIndexList() -> list:
    """
    Trả về list các tuple (bot_dict, src_label, filepath).
    src='MAIN' nếu lấy từ login.json chính,
    src=filename nếu từ multibot/*.json.
    """
    cfg, main_bots = _load_main_data()
    account_files  = []
    if os.path.isdir(MULTIBOT_DIR):
        for name in os.listdir(MULTIBOT_DIR):
            if name.endswith("-login.json"):
                account_files.append(os.path.join(MULTIBOT_DIR, name))

    seen   = set()
    result = []

    def AddBot(bot, src, fp):
        if not isinstance(bot, dict):
            return
        imei = str(bot.get("imei") or "")
        uid  = str(bot.get("author_id") or bot.get("botIntId") or "")
        key  = (imei, uid)
        # Chỉ dedup khi có ít nhất 1 field nhận diện, tránh bỏ sót bot thiếu field
        if key != ("", "") and key in seen:
            return
        if key != ("", ""):
            seen.add(key)
        result.append((bot, src, fp))

    for bot in main_bots:
        AddBot(bot, "MAIN", MAIN_LOGIN)

    for fp in account_files:
        try:
            items = ReadLoginJson(fp)
        except Exception:
            continue
        bot = PickBotItem(items)
        if bot:
            AddBot(bot, os.path.basename(fp), fp)

    def SortKey(x):
        bot, src, _ = x
        is_main      = 1 if bot.get("is_main_bot") else 0
        from_main_db = 1 if src == "MAIN" else 0
        name = str(bot.get("username") or "").lower()
        return (-is_main, -from_main_db, name)

    result.sort(key=SortKey)
    return result

def IsMainBotUser(userId) -> bool:
    _, data = _load_main_data()
    for b in data:
        if b.get("is_main_bot") and str(b.get("author_id") or "") == str(userId):
            return True
    return False

# ── Mention helpers ───────────────────────────────────────────────────────────

def GetMentionUid(this, data):
    uids = getattr(this, "extractUids", lambda d: [])(data) or []
    return str(uids[0]) if uids else None

def GetUidFrom(data) -> str | None:
    v = getattr(data, "uidFrom", None)
    return str(v) if v is not None else None

def SendMention(this, text, userId, threadId, type):
    sendMSuccess(this, text, userId, threadId, type)

# ── Lấy bot theo mention hoặc index ──────────────────────────────────────────

def GetOwnBot(this, data, userId, threadId, type):
    """
    Bot con tự tra ra file của mình.
    Logic: dataBot dùng userClientId làm key → tìm file có userClientId == this.uid.
    Fallback: quét thẳng MULTIBOT_DIR.
    """
    thisUid = str(getattr(this, "uid", "") or "").strip()

    # Cách 1: tra dataBot (key = userClientId)
    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {})
    if isinstance(dataBot, dict):
        loginFile = dataBot.get(thisUid)
        if loginFile:
            loginPath = os.path.join(MULTIBOT_DIR, loginFile)
            if os.path.exists(loginPath):
                try:
                    items = ReadLoginJson(loginPath)
                    bot   = PickBotItem(items)
                    if bot:
                        return bot, loginPath, items
                except Exception:
                    pass

    # Cách 2: quét thẳng MULTIBOT_DIR
    # - khớp userClientId == thisUid  (key của dataBot)
    # - hoặc khớp author_id == thisUid (uid Zalo của bot)
    if thisUid and os.path.isdir(MULTIBOT_DIR):
        for fname in sorted(os.listdir(MULTIBOT_DIR)):
            if not fname.endswith("-login.json"):
                continue
            fpath = os.path.join(MULTIBOT_DIR, fname)
            try:
                _items = ReadLoginJson(fpath)
                # Kiểm tra userClientId record trong file
                for rec in _items:
                    if isinstance(rec, dict) and str(rec.get("userClientId") or "") == thisUid:
                        bot = PickBotItem(_items)
                        if bot:
                            return bot, fpath, _items
                # Kiểm tra author_id của bot record
                _bot = PickBotItem(_items)
                if _bot and str(_bot.get("author_id") or "") == thisUid:
                    return _bot, fpath, _items
            except Exception:
                continue

    # Cách 3: fallback uidFrom (người khác gửi lệnh cho bot)
    uidFrom = GetUidFrom(data)
    if uidFrom and isinstance(dataBot, dict):
        loginFile = dataBot.get(str(uidFrom))
        if loginFile:
            loginPath = os.path.join(MULTIBOT_DIR, loginFile)
            if os.path.exists(loginPath):
                try:
                    items = ReadLoginJson(loginPath)
                    bot   = PickBotItem(items)
                    if bot:
                        return bot, loginPath, items
                except Exception:
                    pass

    SendMention(this, "status:null", userId, threadId, type)
    return None, None, None

def GetBotByMention(this, data, userId, threadId, type):
    uid = GetMentionUid(this, data)
    if not uid:
        return None, None, None
    if not getattr(this, "is_main_bot", False):
        SendMention(this, "Permission denied", userId, threadId, type)
        return None, None, None

    cfg     = jsonLoader(MAIN_LOGIN) or {}
    dataBot = cfg.get("dataBot", {}) if isinstance(cfg.get("dataBot"), dict) else {}
    loginFile = dataBot.get(uid)
    if not loginFile:
        SendMention(this, "status:unkownUid", userId, threadId, type)
        return None, None, None

    loginPath = os.path.join(MULTIBOT_DIR, loginFile)
    if not os.path.exists(loginPath):
        SendMention(this, "status:unkownUid", userId, threadId, type)
        return None, None, None

    items = ReadLoginJson(loginPath)
    bot   = PickBotItem(items)
    if not bot:
        SendMention(this, "status:unkownUid", userId, threadId, type)
        return None, None, None

    return bot, loginPath, items

def GetBotByIndexOrMention(this, data, userId, threadId, type, token=None):
    bot, fp, items = GetBotByMention(this, data, userId, threadId, type)
    if bot:
        return bot, fp, items

    if getattr(this, "is_main_bot", False) and token and str(token).isdigit():
        idx = int(token)
        arr = BuildBotIndexList()
        if idx < 1 or idx > len(arr):
            SendMention(this, "Index out of range", userId, threadId, type)
            return None, None, None
        bot, src, fp = arr[idx - 1]
        if fp == MAIN_LOGIN:
            cfg, bots = _load_main_data()
            return bot, MAIN_LOGIN, bots
        items = ReadLoginJson(fp)
        return PickBotItem(items), fp, items

    cfg, bots = _load_main_data()
    uid = str(getattr(this, "uid", "") or "")
    mybot = next((b for b in bots if str(b.get("author_id") or "") == uid), None)
    if not mybot:
        SendMention(this, "status:null", userId, threadId, type)
        return None, None, None
    return mybot, MAIN_LOGIN, bots

# ── SaveBotField ──────────────────────────────────────────────────────────────

def SaveBotField(fp, items, bot, k, v):
    bot[k] = v
    if fp == MAIN_LOGIN:
        cfg, data = _load_main_data()
        bid = str(bot.get("author_id") or bot.get("imei") or "")
        for b in data:
            if str(b.get("author_id") or b.get("imei") or "") == bid:
                b[k] = v
        _save_main_data(cfg)
    else:
        WriteLoginJson(fp, items)

# ── String utils ──────────────────────────────────────────────────────────────

def SlugName(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-zA-Z0-9]", "", s).lower()

def ExtractJsonPayload(s: str) -> str | None:
    s = (s or "").strip()
    m = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", s)
    return m.group(1).strip() if m else None

def ParseTimeExpression(expr: str) -> "timedelta":
    s = (expr or "").strip().lower().replace(" ", "")
    if not s:
        return timedelta()
    pattern = r"(\d+)(mo|min|y|w|d|h|m|s)"
    matches = re.findall(pattern, s)
    delta   = timedelta()
    for value, unit in matches:
        v = int(value)
        if unit == "y":    delta += timedelta(days=v * 365)
        elif unit == "mo": delta += timedelta(days=v * 30)
        elif unit == "w":  delta += timedelta(weeks=v)
        elif unit == "d":  delta += timedelta(days=v)
        elif unit == "h":  delta += timedelta(hours=v)
        elif unit in ("m", "min"): delta += timedelta(minutes=v)
        elif unit == "s":  delta += timedelta(seconds=v)
    return delta

def IsMainBotTarget(fp, bot) -> bool:
    if fp == MAIN_LOGIN:
        return True
    if bot.get("is_main_bot") is True:
        return True
    return False

# ── Message helpers (sendM*) ──────────────────────────────────────────────────

def sendMSuccess(this, text, userId, threadId, type):
    return this.sendSuccess(text, threadId, type)

def sendMWarning(this, text, userId, threadId, type):
    return this.sendWarning(text, threadId, type)

def sendMFailed(this, text, userId, threadId, type):
    return this.sendWarning(text, threadId, type)

def sendMCustom(this, style, flag, text, userId, threadId, type):
    """Gửi tin nhắn custom (WAITING...). Fallback về sendWarning."""
    try:
        return this.sendCustomMsg(style, flag, text, threadId, type)
    except AttributeError:
        return this.sendWarning(text, threadId, type)
