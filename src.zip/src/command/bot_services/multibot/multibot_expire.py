"""
multibot_expire.py – Vòng lặp nền kiểm tra hạn sử dụng của các bot con.
Tương đương ztf/functions/services/hook/core_hook/extra_multibot_core.py -> initExpire.

Gọi loopInitExpire(this) từ initAdmin trong src/services/init/admin.py
(chỉ gọi 1 lần khi main bot khởi động).
"""

from src.command.bot_services.multibot.multibot_core import *
from src.command.bot_services.multibot.multibot_runner import shutdownABot


def _ParseExpired(s) -> datetime | None:
    try:
        return datetime.strptime(str(s), "%H:%M:%S-%d/%m/%Y")
    except Exception:
        return None


def initExpire(this) -> None:
    now = datetime.now()
    arr = BuildBotIndexList()
    if not arr:
        return

    cfg_main  = None
    dirty_main = False

    def _load_main():
        nonlocal cfg_main
        if cfg_main is None:
            cfg_main = jsonLoader(MAIN_LOGIN) or {}

    def _save_main():
        nonlocal cfg_main, dirty_main
        if cfg_main is not None and dirty_main:
            saveJson(MAIN_LOGIN, cfg_main)
            dirty_main = False

    def _remove_databot_by_file(fp):
        nonlocal dirty_main
        _load_main()
        dataBot = cfg_main.get("dataBot", {})
        if not isinstance(dataBot, dict):
            return
        bn = os.path.basename(fp)
        for k, v in list(dataBot.items()):
            if v == bn:
                del dataBot[k]
                dirty_main = True

    for bot, src, fp in arr:
        exp_str = (bot or {}).get("expiredTime") or (bot or {}).get("het_han")
        if not exp_str:
            continue

        exp = _ParseExpired(exp_str)
        if not exp or now <= exp:
            continue

        was_on = bool(bot.get("status"))
        bot["status"]    = False
        bot["isActived"] = False

        if was_on:
            try:
                shutdownABot(bot)
            except Exception:
                pass

        expired_delta  = now - exp
        should_delete  = fp != MAIN_LOGIN and expired_delta.days >= 1

        if fp == MAIN_LOGIN:
            _load_main()
            bots = cfg_main.get("data", [])
            bid  = str(bot.get("author_id") or bot.get("imei") or "")
            for b in bots:
                if isinstance(b, dict):
                    if str(b.get("author_id") or b.get("imei") or "") == bid:
                        b["status"]    = False
                        b["isActived"] = False
                        dirty_main     = True
            continue

        if should_delete:
            try:
                if os.path.exists(fp):
                    os.remove(fp)
            except Exception:
                pass
            _remove_databot_by_file(fp)
            continue

        try:
            items = ReadLoginJson(fp)
            if isinstance(items, list):
                b = PickBotItem(items)
                if b:
                    b["status"]    = False
                    b["isActived"] = False
                WriteLoginJson(fp, items)
        except Exception:
            pass

    _save_main()


def loopInitExpire(this) -> None:
    """Chạy initExpire mỗi 10 giây trong background thread."""
    def _run():
        while True:
            try:
                initExpire(this)
            except Exception as e:
                logger.error(f"[ExpireWatcher] {e}")
            time.sleep(10)

    threading.Thread(target=_run, daemon=True).start()
