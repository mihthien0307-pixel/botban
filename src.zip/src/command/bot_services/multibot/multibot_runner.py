"""
multibot_runner.py
Hàm restart / shutdown một bot con trong zBot.
Tương đương ztf/functions/services/index.py (restartABot / shutdownABot).
"""

from app.library.packages import *
from app.login.packages import clientlist, shutdown_event

def _get_client(author_id, is_main):
    """Trả về client object đang chạy (nếu có)."""
    from app.login.packages import clientlist
    if is_main:
        # Lấy mainclient từ module data
        try:
            from app.login import data as _d
            return getattr(_d, "mainclient", None)
        except Exception:
            return None
    return clientlist.get(str(author_id))

def DeleteBot(this, bot: dict, fp: str) -> bool:
    """Dừng bot, xóa file login, xóa khỏi dataBot trong login.json."""
    import json as _json
    try:
        author_id = str(bot.get("author_id") or "")

        # 1. Dừng bot trước
        try:
            shutdownABot(bot)
        except Exception:
            pass

        # 2. Xóa file login của bot con
        if fp and os.path.isfile(fp):
            os.remove(fp)

        # 3. Xóa entry trong dataBot của login.json
        try:
            with open(MAIN_LOGIN, "r", encoding="utf-8") as f:
                cfg = _json.load(f)
            dataBot = cfg.get("dataBot", {})
            # Tìm key có value = tên file này
            fname = os.path.basename(fp) if fp else ""
            keys_to_del = [k for k, v in dataBot.items() if v == fname or k == author_id]
            for k in keys_to_del:
                dataBot.pop(k, None)
            cfg["dataBot"] = dataBot
            with open(MAIN_LOGIN, "w", encoding="utf-8") as f:
                _json.dump(cfg, f, ensure_ascii=False, indent=4)
        except Exception as e:
            logger.warning(f"DeleteBot: lỗi cập nhật login.json: {e}")

        return True
    except Exception as e:
        logger.error(f"DeleteBot error: {e}")
        return False


def restartABot(bot: dict) -> None:
    """
    Restart một bot theo dict config (dùng format login.json của zBot).
    """
    from main import zrcapis
    from app.login.data import run_bot

    username    = bot.get("username")
    author_id   = str(bot.get("author_id") or bot.get("botIntId") or "")
    imei        = bot.get("imei")
    cookies     = bot.get("session_cookies") or bot.get("sessionCookies") or {}
    prefix      = bot.get("prefix", "?")
    is_main     = bool(bot.get("is_main_bot") or bot.get("mainBot"))
    status      = bot.get("status", False)

    # Dừng instance cũ nếu đang chạy
    target = _get_client(author_id, is_main)
    if target and hasattr(target, "stopListening"):
        try:
            target.stopListening()
        except Exception:
            pass
        for _ in range(10):
            time.sleep(0.5)
            try:
                ws = getattr(target, "ws", None)
                if ws is None or not getattr(ws, "keep_running", False):
                    break
            except Exception:
                break
        time.sleep(1.0)

    # Khởi chạy lại
    threading.Thread(
        target=run_bot,
        args=(imei, cookies, prefix, is_main, username, author_id, status),
        daemon=True
    ).start()

def shutdownABot(bot: dict) -> None:
    """Dừng một bot (không restart)."""
    author_id = str(bot.get("author_id") or bot.get("botIntId") or "")
    is_main   = bool(bot.get("is_main_bot") or bot.get("mainBot"))
    username  = bot.get("username", "unknown")

    target = _get_client(author_id, is_main)
    if target:
        try:
            if hasattr(target, "listening"):
                target.listening = False
            if hasattr(target, "bools") and target.bools:
                try:
                    target.bools.shutdown(wait=False)
                except Exception:
                    pass
            if hasattr(target, "stopListening"):
                try:
                    target.stopListening()
                except Exception:
                    pass
            time.sleep(0.8)
        except Exception as e:
            logger.warning(f"Lỗi stop bot {username}: {e}")

    # Xóa khỏi clientlist để không tự restart
    if not is_main:
        try:
            clientlist.pop(author_id, None)
        except Exception:
            pass
