"""
=====================================================================
 LỆNH SPEEDTEST - VẼ ẢNH KẾT QUẢ ĐO TỐC ĐỘ MẠNG
=====================================================================
Cách dùng:
    1. Đặt file này vào thư mục command của bot (nơi commandLoader quét).
    2. Sửa các biến trong phần CONFIG bên dưới cho khớp cấu trúc thư mục
       thật của project (đường dẫn font, thư mục cache, prefix, ...).
    3. Cần cài thư viện: pip install speedtest-cli pillow
    4. Lệnh dùng: <prefix>speedtest  (alias: speed, toctocdo)
=====================================================================
"""

import os
import math
import random
import time
from datetime import datetime, timezone, timedelta

from PIL import Image, ImageDraw, ImageFont

import speedtest

from api.util.Enum import PermissionLevel


# =====================================================================
# CONFIG - chỉnh lại cho đúng cấu trúc thư mục của bạn
# =====================================================================
# Thư mục chứa font (theo cấu trúc bot: assets/font/...)
FONT_DIR = "assets/font"

# Thư mục lưu ảnh kết quả tạm thời
CACHE_DIR = "data/assets/cache/speedtest"

# Kích thước ảnh xuất ra
IMG_W, IMG_H = 1200, 650

# Múi giờ hiển thị (VN = UTC+7)
TZ_VN = timezone(timedelta(hours=7))


# =====================================================================
# COLORS
# =====================================================================
EDGE_COLOR    = (5, 4, 16)
CENTER_COLOR  = (16, 22, 55)
DOT_COLOR     = (40, 42, 60)
PANEL_BG      = (17, 19, 38)
PANEL_BG2     = (15, 17, 33)
PANEL_BORDER  = (35, 38, 60)
WHITE         = (255, 255, 255)
GRAY          = (160, 165, 180)
GREEN         = (60, 235, 130)
PURPLE        = (175, 90, 240)
BLUE_LIGHT    = (90, 170, 255)
ORANGE        = (255, 190, 60)
NHA_MANG_TEXT = (50, 30, 110)
RING_COLORS   = [
    (60, 170, 240),
    (130, 120, 245),
    (200, 90, 230),
    (235, 70, 170),
    (235, 70, 170),
]


# =====================================================================
# FONT LOADER
# =====================================================================
def _resolve_font_dir() -> str:
    """Tìm thư mục font hợp lệ, tránh lỗi 'cannot open resource'."""
    candidates = [
        FONT_DIR,
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "font"),
        os.path.join(os.getcwd(), "assets", "font"),
        os.path.join(os.getcwd(), "zbot", "assets", "font"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            return c
    raise FileNotFoundError(
        "Khong tim thay thu muc font assets/font. Da thu cac duong dan: "
        + ", ".join(candidates)
        + ". Hay sua bien FONT_DIR cho dung."
    )


def _font(rel_path: str, size: int) -> ImageFont.FreeTypeFont:
    base = _resolve_font_dir()
    path = os.path.join(base, rel_path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Khong tim thay file font: {path}")
    return ImageFont.truetype(path, size)


def _load_fonts():
    return {
        "title":   _font("Goldman/Goldman-Bold.ttf", 50),
        "label":   _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 26),
        "bignum":  _font("Goldman/Goldman-Bold.ttf", 58),
        "unit":    _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 22),
        "ring":    _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 26),
        "netname": _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 26),
        "small":   _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 18),
        "design":  _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 18),
        "boxlbl":  _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 22),
        "boxval":  _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 30),
        "footer":  _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 20),
    }


# =====================================================================
# HELPERS
# =====================================================================
def _lerp_color(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _text_w(d, txt, f):
    b = d.textbbox((0, 0), txt, font=f)
    return b[2] - b[0]


def _centered_text(d, cx, y, txt, f, fill):
    w = _text_w(d, txt, f)
    d.text((cx - w / 2, y), txt, font=f, fill=fill)


def _draw_icon(draw, kind, cx, cy, size, color):
    """Vẽ icon vector đơn giản (không cần font emoji), căn giữa tại (cx, cy)."""
    r = size / 2
    w = max(2, int(size * 0.12))

    if kind == "download":
        draw.line([(cx, cy - r), (cx, cy + r * 0.25)], fill=color, width=w)
        draw.polygon(
            [(cx - r * 0.55, cy - r * 0.05), (cx + r * 0.55, cy - r * 0.05), (cx, cy + r)],
            fill=color
        )

    elif kind == "upload":
        draw.line([(cx, cy - r * 0.25), (cx, cy + r)], fill=color, width=w)
        draw.polygon(
            [(cx - r * 0.55, cy + r * 0.05), (cx + r * 0.55, cy + r * 0.05), (cx, cy - r)],
            fill=color
        )

    elif kind == "ping":
        # cột tín hiệu cao dần
        n = 4
        bar_w = size * 0.16
        gap = size * 0.06
        total_w = n * bar_w + (n - 1) * gap
        x = cx - total_w / 2
        for i in range(n):
            bar_h = size * (0.35 + 0.2 * i)
            draw.rectangle(
                [x, cy + r - bar_h, x + bar_w, cy + r],
                fill=color
            )
            x += bar_w + gap

    elif kind == "jitter":
        pts = [
            (cx - r, cy + r * 0.4),
            (cx - r * 0.35, cy - r * 0.1),
            (cx + r * 0.05, cy + r * 0.2),
            (cx + r * 0.45, cy - r * 0.5),
            (cx + r, cy - r),
        ]
        draw.line(pts, fill=color, width=w, joint="curve")
        for p in pts:
            draw.ellipse([p[0] - w * 0.6, p[1] - w * 0.6, p[0] + w * 0.6, p[1] + w * 0.6], fill=color)

    elif kind == "loss":
        # hộp / package
        draw.rounded_rectangle(
            [cx - r * 0.8, cy - r * 0.7, cx + r * 0.8, cy + r * 0.8],
            radius=size * 0.06, outline=color, width=w
        )
        draw.line([(cx - r * 0.8, cy - r * 0.05), (cx + r * 0.8, cy - r * 0.05)], fill=color, width=w)
        draw.line([(cx, cy - r * 0.7), (cx, cy + r * 0.8)], fill=color, width=w)

    elif kind == "server":
        # globe (trái đất)
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=w)
        draw.ellipse([cx - r * 0.45, cy - r, cx + r * 0.45, cy + r], outline=color, width=max(1, w - 1))
        draw.line([(cx - r, cy), (cx + r, cy)], fill=color, width=max(1, w - 1))
        draw.arc([cx - r, cy - r * 1.35, cx + r, cy + r * 0.35], start=200, end=340, fill=color, width=max(1, w - 1))
        draw.arc([cx - r, cy - r * 0.35, cx + r, cy + r * 1.35], start=20, end=160, fill=color, width=max(1, w - 1))


def _isp_initials(isp_name: str) -> str:
    words = [w for w in isp_name.replace(",", " ").split() if w]
    if not words:
        return "NM"
    if len(words) == 1:
        return words[0][:2].upper()
    return (words[0][0] + words[1][0]).upper()


# =====================================================================
# MAIN DRAW FUNCTION
# =====================================================================
def generate_speedtest_image(result: dict, isp_name: str,
                              designed_by: str = "Admin Bot",
                              vpn_status: str = "TAT") -> str:
    """
    Vẽ ảnh kết quả speedtest và lưu vào CACHE_DIR.

    result: dict trả về từ speedtest-cli (s.results.dict()), gồm các key:
        download, upload, ping, server, timestamp,
        bytes_sent, bytes_received, share, client
        (jitter / packet loss có thể không có -> sẽ hiển thị N/A)

    isp_name: tên nhà mạng / công ty hiển thị bên dưới vòng tròn
    designed_by: tên hiển thị "Designed by: ..."
    vpn_status: "BAT" hoặc "TAT"

    Trả về: đường dẫn file ảnh jpg đã lưu
    """

    F = _load_fonts()

    # ---------------- Xử lý dữ liệu ----------------
    download_mbps = result.get("download", 0) / 1_000_000
    upload_mbps   = result.get("upload", 0) / 1_000_000
    ping_ms       = result.get("ping", 0)
    jitter_ms     = result.get("jitter")
    loss_pct      = result.get("packetLoss")
    if loss_pct is None:
        loss_pct = (result.get("client") or {}).get("loss")

    jitter_txt = f"{jitter_ms:.0f} ms" if jitter_ms is not None else "N/A"
    loss_txt   = f"{loss_pct:.0f}%" if loss_pct is not None else "0%"

    server = result.get("server") or {}
    server_name = server.get("name") or server.get("sponsor") or "N/A"

    ts = result.get("timestamp")
    if ts:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        dt = dt.astimezone(TZ_VN)
    else:
        dt = datetime.now(TZ_VN)
    time_str = dt.strftime("%-d/%-m/%Y, %I:%M:%S %p")

    # ---------------- Tạo canvas ----------------
    img = Image.new("RGB", (IMG_W, IMG_H), EDGE_COLOR)

    # gradient nền (radial, sáng ở giữa-trên, tối dần ra rìa)
    center = (IMG_W * 0.5, IMG_H * 0.45)
    max_dist = math.hypot(IMG_W, IMG_H) / 2
    px = img.load()
    for y in range(IMG_H):
        for x in range(0, IMG_W, 2):
            d = min(math.hypot(x - center[0], y - center[1]) / max_dist, 1.0)
            c = _lerp_color(CENTER_COLOR, EDGE_COLOR, d)
            px[x, y] = c
            px[x + 1, y] = c

    draw = ImageDraw.Draw(img, "RGBA")

    # dot pattern
    random.seed(42)
    for y in range(20, IMG_H, 26):
        for x in range(20, IMG_W, 26):
            if random.random() < 0.55:
                draw.ellipse([x, y, x + 2, y + 2], fill=DOT_COLOR)

    # ---------------- Tiêu đề ----------------
    title = "KET QUA DO TOC DO MANG"
    _centered_text(draw, IMG_W / 2, 28, title, F["title"], WHITE)

    # gạch chân gradient
    line_y = 90
    line_x1, line_x2 = 40, IMG_W - 40
    steps = 200
    for i in range(steps):
        t = i / steps
        c = _lerp_color((230, 60, 110), (60, 90, 230), t)
        x0 = line_x1 + (line_x2 - line_x1) * i / steps
        x1 = line_x1 + (line_x2 - line_x1) * (i + 1) / steps
        draw.line([(x0, line_y), (x1, line_y)], fill=c, width=3)

    # ---------------- Panel layout ----------------
    top_y = 115
    bottom_y = IMG_H - 60
    left_panel = (30, top_y, 320, bottom_y)
    right_panel = (340, top_y, IMG_W - 15, bottom_y)

    draw.rounded_rectangle(left_panel, radius=18, fill=PANEL_BG, outline=PANEL_BORDER, width=2)
    draw.rounded_rectangle(right_panel, radius=18, fill=PANEL_BG, outline=PANEL_BORDER, width=2)

    # ---------------- Vòng tròn gradient (ISP) ----------------
    ring_cx = (left_panel[0] + left_panel[2]) / 2
    ring_cy = top_y + 145
    ring_r_outer = 105
    ring_r_inner = 88

    n_seg = 360
    for i in range(n_seg):
        a0 = i
        a1 = i + 1.2
        t = i / n_seg
        seg_t = t * (len(RING_COLORS) - 1)
        idx = int(seg_t)
        frac = seg_t - idx
        c1 = RING_COLORS[min(idx, len(RING_COLORS) - 1)]
        c2 = RING_COLORS[min(idx + 1, len(RING_COLORS) - 1)]
        color = _lerp_color(c1, c2, frac)
        draw.arc(
            [ring_cx - ring_r_outer, ring_cy - ring_r_outer,
             ring_cx + ring_r_outer, ring_cy + ring_r_outer],
            start=a0, end=a1, fill=color + (255,), width=10
        )

    # vòng tròn trắng bên trong
    draw.ellipse(
        [ring_cx - ring_r_inner, ring_cy - ring_r_inner,
         ring_cx + ring_r_inner, ring_cy + ring_r_inner],
        fill=(228, 228, 245)
    )

    # initials ISP
    initials = _isp_initials(isp_name)
    _centered_text(draw, ring_cx, ring_cy - 18, initials, F["ring"], NHA_MANG_TEXT)

    # ---------------- Tên ISP / Designed by ----------------
    ny = ring_cy + ring_r_outer + 25
    for line in isp_name.split("\n"):
        _centered_text(draw, ring_cx, ny, line, F["netname"], BLUE_LIGHT)
        ny += 32

    ny += 14
    _centered_text(draw, ring_cx, ny, "Designed by:", F["small"], GRAY)
    ny += 26
    _centered_text(draw, ring_cx, ny, designed_by, F["design"], ORANGE)

    # ---------------- Thanh tốc độ Download / Upload ----------------
    rp_x1 = right_panel[0] + 25
    rp_x2 = right_panel[2] - 25
    rp_y = top_y + 30
    bar_height = 12
    bar_radius = 6

    def draw_speed_section(y, label, value, unit, label_color, bar_color, icon_kind):
        # icon
        _draw_icon(draw, icon_kind, rp_x1 + 16, y + 16, 28, label_color)

        # nhãn
        draw.text((rp_x1 + 42, y), label, font=F["label"], fill=label_color)

        # giá trị + đơn vị, căn phải, NẰM TRÊN thanh bar (không đè)
        val_txt = f"{value:.2f}"
        val_w = _text_w(draw, val_txt, F["bignum"])
        unit_w = _text_w(draw, unit, F["unit"])
        total_w = val_w + 12 + unit_w
        val_y = y - 8
        draw.text((rp_x2 - total_w, val_y), val_txt, font=F["bignum"], fill=bar_color)
        draw.text((rp_x2 - unit_w, val_y + 38), unit, font=F["unit"], fill=GRAY)

        # thanh progress bar
        bar_y = y + 64
        draw.rounded_rectangle(
            [rp_x1, bar_y, rp_x2, bar_y + bar_height],
            radius=bar_radius, fill=(35, 38, 58)
        )
        fill_ratio = 0.92
        fill_w = (rp_x2 - rp_x1) * fill_ratio
        draw.rounded_rectangle(
            [rp_x1, bar_y, rp_x1 + fill_w, bar_y + bar_height],
            radius=bar_radius, fill=bar_color
        )
        return bar_y + bar_height

    bar1_bottom = draw_speed_section(rp_y, "DOWNLOAD", download_mbps, "Mbps", GREEN, GREEN, "download")
    bar2_y = bar1_bottom + 45
    bar2_bottom = draw_speed_section(bar2_y, "UPLOAD", upload_mbps, "Mbps", PURPLE, PURPLE, "upload")

    # ---------------- Lưới thống kê 2x2 ----------------
    grid_top = bar2_bottom + 35
    grid_bottom = right_panel[3] - 25
    grid_gap = 18
    box_w = (rp_x2 - rp_x1 - grid_gap) / 2
    box_h = (grid_bottom - grid_top - grid_gap) / 2

    stats = [
        ("Ping",    f"{ping_ms:.0f} ms", (60, 110, 200), "ping"),
        ("Jitter",  jitter_txt,          (140, 90, 60),  "jitter"),
        ("Loss",    loss_txt,            (150, 80, 40),  "loss"),
        ("May chu", server_name,         (40, 110, 100), "server"),
    ]

    for i, (label, value, icon_bg, icon_kind) in enumerate(stats):
        col = i % 2
        row = i // 2
        bx1 = rp_x1 + col * (box_w + grid_gap)
        by1 = grid_top + row * (box_h + grid_gap)
        bx2 = bx1 + box_w
        by2 = by1 + box_h

        draw.rounded_rectangle([bx1, by1, bx2, by2], radius=14, fill=PANEL_BG2)

        icon_r = 26
        icon_cx = bx1 + 45
        icon_cy = by2 - 38
        draw.ellipse(
            [icon_cx - icon_r, icon_cy - icon_r, icon_cx + icon_r, icon_cy + icon_r],
            fill=icon_bg
        )
        _draw_icon(draw, icon_kind, icon_cx, icon_cy, 26, WHITE)

        text_x = bx1 + 85
        draw.text((text_x, by1 + 24), label, font=F["boxlbl"], fill=GRAY)
        draw.text((text_x, by1 + 56), value, font=F["boxval"], fill=WHITE)

    # ---------------- Footer ----------------
    footer_txt = f"Thoi gian: {time_str}   •   VPN: {vpn_status}"
    _centered_text(draw, IMG_W / 2, IMG_H - 38, footer_txt, F["footer"], WHITE)

    # ---------------- Lưu ảnh ----------------
    os.makedirs(CACHE_DIR, exist_ok=True)
    out_path = os.path.join(CACHE_DIR, f"result_{int(time.time())}.jpg")
    img.save(out_path, quality=95)
    return out_path


# =====================================================================
# COMMAND HANDLER (Zalo bot)
# =====================================================================
def main(self, message, data, userId, threadId, type):
    """
    Lệnh: speedtest
    Đo tốc độ mạng và gửi ảnh kết quả vào nhóm/chat.
    """
    from api.util.msg import Message, MessageStyle, Mention

    name = self.userName(userId)
    wait_text = f"@{name} ⏳ Đang đo tốc độ mạng, vui lòng chờ khoảng 15-30 giây..."
    wait_mention = Mention(userId, length=len(name) + 1, offset=0)
    wait_style = MessageStyle(offset=0, length=len(wait_text), style="font", size="12")

    self.replyMessage(
        Message(text=wait_text, mention=wait_mention, style=wait_style),
        data, threadId, type
    )

    try:
        st = speedtest.Speedtest()
        st.get_best_server()
        st.download()
        st.upload()
        result = st.results.dict()

        isp_name = (result.get("client") or {}).get("isp", "Khong xac dinh")

        image_path = generate_speedtest_image(
            result=result,
            isp_name=isp_name,
            designed_by="Admin Bot",
            vpn_status="TAT",
        )

        cap_text = (
            f"@{name}\n"
            f"Kết quả đo tốc độ mạng 🌪️\n"
            f"Người yêu cầu: {name}"
        )
        cap_mention = Mention(userId, length=len(name) + 1, offset=0)

        self.sendLocalImage(
            image_path,
            threadId,
            type,
            width=IMG_W,
            height=IMG_H,
            message=Message(text=cap_text, mention=cap_mention)
        )

    except Exception as e:
        err_text = f"@{name} ❌ Lỗi khi đo tốc độ mạng: {e}"
        err_mention = Mention(userId, length=len(name) + 1, offset=0)
        err_style = MessageStyle(offset=0, length=len(err_text), style="font", size="12")
        self.replyMessage(
            Message(text=err_text, mention=err_mention, style=err_style),
            data, threadId, type
        )


dependencies = {
    "name": "speedtest",
    "description": "Đo tốc độ mạng (download/upload/ping) và xuất ảnh kết quả.",
    "alias": ["speed", "toctocdo"],
    "permission": PermissionLevel.USER.value,
    "cooldown": 30,
    "main": main,
}
