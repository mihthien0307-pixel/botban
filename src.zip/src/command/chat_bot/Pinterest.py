from app.core.index import *
import requests
import json
import time
from urllib.parse import quote

_PINTEREST_LIMIT = 50
_DEFAULT_COUNT   = 3
_MAX_COUNT       = 20

# ── Lấy API key từ config hoặc điền thẳng vào đây ──
_SERPAPI_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"


def _search_pinterest(query: str, limit: int = _PINTEREST_LIMIT) -> list:
    """Tìm ảnh Pinterest qua SerpAPI (engine=google_images, site:pinterest.com)."""
    try:
        params = {
            "engine":   "google_images",
            "q":        f"site:pinterest.com {query}",
            "num":      min(limit, 100),
            "safe":     "active",
            "api_key":  _SERPAPI_KEY,
        }

        resp = requests.get(
            "https://serpapi.com/search.json",
            params=params,
            timeout=20,
        )

        if resp.status_code != 200:
            logger.errorw(f"[Pinterest] SerpAPI HTTP {resp.status_code}: {resp.text[:200]}")
            return []

        data = resp.json()

        # SerpAPI trả kết quả trong "images_results"
        results = data.get("images_results", [])

        urls = []
        for item in results:
            # Ưu tiên ảnh gốc độ phân giải cao, fallback về thumbnail
            url = item.get("original") or item.get("thumbnail")
            if url:
                urls.append(url)
            if len(urls) >= limit:
                break

        return urls

    except Exception as err:
        logger.errorw(f"[Pinterest] Lỗi SerpAPI: {err}")
        return []

def pinterestCommand(self, message, data, userId, threadId, type):
    prefix   = getattr(self, "prefix",      "/")
    cmd_name = getattr(self, "commandName", "pin")

    text_raw = (getattr(message, "text", "") or "").strip()
    cmd_tok  = f"{prefix}{cmd_name}"
    if text_raw.lower().startswith(cmd_tok.lower()):
        args_raw = text_raw[len(cmd_tok):].strip()
    else:
        parts    = text_raw.split(maxsplit=1)
        args_raw = parts[1].strip() if len(parts) > 1 else ""

    if not args_raw:
        guide = (
            f"Thêm từ khoá để tìm kiếm ảnh từ Pinterest!\n\n"
            f"Ví dụ:\n"
            f"📍{prefix}{cmd_name} [Từ_Khoá] - Tìm kiếm ảnh theo từ khoá.\n"
            f"📍{prefix}{cmd_name} [Từ_Khoá] [Số_Lượng] - Tìm kiếm ảnh theo từ khoá và số lượng được yêu cầu."
        )
        return self.replyMessageStyle(
            guide,
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )

    tokens = args_raw.rsplit(maxsplit=1)

    count = _DEFAULT_COUNT
    query = args_raw

    if len(tokens) == 2:
        last = tokens[1]
        if last.isdigit():
            count = max(1, min(int(last), _MAX_COUNT))
            query = tokens[0].strip()

    if not query:
        return self.replyMessageStyle(
            f"Vui lòng nhập từ khoá để tìm kiếm!",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )

    self.sendReaction(data, "🔍", threadId, type, 100000000)

    pool = _search_pinterest(query, limit=max(_PINTEREST_LIMIT, count * 3))

    if not pool:
        self.sendReaction(data, "❌", threadId, type, 100000000)
        return self.replyMessageStyle(
            f"Không tìm thấy ảnh nào với từ khoá: \"{query}\"",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

    selected = pool[:count]

    # Gửi text info trước
    self.replyMessageStyle(
        f"🖼️ Pinterest: \"{query}\"\nĐang gửi {len(selected)} ảnh...",
        data, threadId, type,
        color="gr", title="PINTEREST", userId=userId,
    )

    try:
        self.sendMultiRemoteImage(
            selected, threadId, type,
            width=2560, height=2560,
        )
        self.sendReaction(data, "✅", threadId, type, 100000000)
    except Exception as e:
        logger.errorw(f"[Pinterest] sendMultiRemoteImage thất bại: {e}")
        self.sendReaction(data, "❌", threadId, type, 100000000)
        self.replyMessageStyle(
            "Tìm được ảnh nhưng không thể gửi, vui lòng thử lại sau!",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

dependencies = {
    "name": "pinterest",
    "permission": 0,
    "cooldown": 5,
    "description": "Tìm kiếm ảnh từ Pinterest theo từ khoá",
    "alias": ["pin"],
    "main": pinterestCommand,
}