"""
alysChat.py  –  Lệnh Top Chat (xem ai nhắn tin nhiều nhất)
─────────────────────────────────────────────────────────
Cách dùng:
  top          → top người nhắn tin trong nhóm hiện tại (dạng ảnh card)
  top text     → dạng text thuần (không vẽ ảnh)
  top global   → top nhóm nhắn tin nhiều nhất toàn bot (dạng ảnh)
  top global text → top nhóm, dạng text
─────────────────────────────────────────────────────────
"""

from __future__ import annotations

import os
import time
import logging

from app.core.index import Mention, Message
from src.services.pillow.drawTopChat import draw_top_chat, draw_top_chat_auto
from src.services.data.chatCounter import get_top_group, get_top_global

# ── Cấu hình ──────────────────────────────────────────────────────────────────
import pathlib
_HERE = pathlib.Path(__file__).resolve().parent  # zbot/src/command/chat_bot/

CACHE_DIR     = "data/assets/cache/image"
RANK_ICON_DIR = str(_HERE.parents[2] / "assets" / "topchat")  # zbot/assets/topchat/

# Map rank → tên file icon (15 rank, từ thấp → cao)
# File đặt tên: 01_dong.png … 13_chien_than.png
_RANK_ICONS: dict[int, str] = {
    1:  "01_dong.png",
    2:  "02_bac.png",
    3:  "03_vang.png",
    4:  "04_bach_kim.png",
    5:  "05_kim_cuong.png",
    6:  "06_tinh_anh.png",
    7:  "07_cao_thu.png",
    8:  "08_dai_cao_thu_IV.png",
    9:  "09_dai_cao_thu_IIl.png",
    10: "10_dai_cao_thu_II.png",
    11: "11_dai_cao_thu_I.png",
    12: "12_chien_tuong.png",
    13: "13_chien_than.png",
}

logger = logging.getLogger(__name__)

# ── Helper: gắn icon rank vào mỗi entry ──────────────────────────────────────
def _attach_rank_icons(entries: list[dict]) -> list[dict]:
    """
    Thêm key 'rank_icon' vào mỗi entry (đường dẫn tuyệt đối đến file PNG).
    Nếu không tìm thấy file → để None (drawTopChat tự bỏ qua).
    """
    for entry in entries:
        rank = entry.get("rank", 0)
        filename = _RANK_ICONS.get(rank)
        if filename:
            path = os.path.join(RANK_ICON_DIR, filename)
            entry["rank_icon"] = path if os.path.isfile(path) else None
        else:
            entry["rank_icon"] = None
    return entries


# ── Vẽ & gửi card ảnh ────────────────────────────────────────────────────────
def _send_card(
    self,
    entries: list[dict],
    title: str,
    data,
    userId: str,
    threadId: str,
    msg_type,
    engine: str = "py",
) -> None:
    """Vẽ card Top Chat rồi gửi vào nhóm. Tự dọn file tạm sau khi gửi.

    engine:
      - "py" (mặc định): vẽ bằng Pillow
      - "js": vẽ bằng node-canvas (drawTopChat.js), tự fallback Pillow nếu lỗi
    """
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        out_path = os.path.join(CACHE_DIR, f"topchat_{threadId}_{int(time.time())}.jpg")

        entries = _attach_rank_icons(entries)
        w, h = draw_top_chat_auto(entries, out_path, title=title, engine=engine)

        name    = self.userName(userId)
        mention = Mention(userId, offset=0, length=len(name))
        caption = Message(
            text=f"{name}\n{title}",
            mention=mention,
        )
        self.sendLocalImage(out_path, threadId, msg_type, width=w, height=h, message=caption)

    except Exception as exc:
        logger.error(f"[alysChat] Lỗi vẽ card: {exc}", exc_info=True)
        self.replyMessageStyle(
            f"❌ Không thể tạo ảnh Top Chat.\nLỗi: {exc}",
            data, threadId, msg_type,
            color="r", title="LỖI HỆ THỐNG", userId=userId,
        )

    finally:
        # Dọn file tạm dù thành công hay thất bại
        try:
            if "out_path" in locals() and os.path.isfile(out_path):
                os.remove(out_path)
        except Exception:
            pass


# ── Xuất dạng text thuần ─────────────────────────────────────────────────────
_MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}

def _format_text(entries: list[dict], title: str) -> str:
    """Trả về chuỗi text đẹp dùng khi user gọi lệnh `top text`."""
    lines = [f"🏆 {title}", "─" * 32]
    for e in entries:
        icon = _MEDALS.get(e["rank"], f"#{e['rank']:>2}")
        lines.append(f"{icon}  {e['name']}  —  {e['count']:,} tin nhắn")
    return "\n".join(lines)


# ── Parse tham số lệnh ───────────────────────────────────────────────────────
def _parse_args(message) -> tuple[bool, bool, str]:
    """
    Trả về (is_global, is_text, engine) từ nội dung tin nhắn.
    Hỗ trợ các cách viết: global / gl, text / txt / t, js, py
    """
    raw    = (getattr(message, "text", None) or str(message) or "").strip().lower()
    tokens = set(raw.split())

    is_global = bool(tokens & {"global", "gl"})
    is_text   = bool(tokens & {"text", "txt", "t"})
    engine    = "js" if (tokens & {"js", "node", "canvas"}) else "py"
    return is_global, is_text, engine


# ── Hàm chính ─────────────────────────────────────────────────────────────────
def topChatCommand(self, message, data, userId: str, threadId: str, msg_type) -> None:
    is_global, is_text, engine = _parse_args(message)

    # Lấy dữ liệu
    if is_global:
        entries = get_top_global(n=15)
        title   = "TOP NHÓM NHẮN TIN NHIỀU NHẤT"
    else:
        entries = get_top_group(threadId, n=15)
        title   = "TOP CHAT NHÓM"

    # Không có dữ liệu
    if not entries:
        self.replyMessageStyle(
            "📭 Chưa có dữ liệu tin nhắn nào được ghi nhận trong"
            + (" toàn bot." if is_global else " nhóm này."),
            data, threadId, msg_type,
            color="yl", title="THÔNG BÁO", userId=userId,
        )
        return

    # Gửi kết quả
    if is_text:
        self.replyMessageStyle(
            _format_text(entries, title),
            data, threadId, msg_type,
            color="gr", title=title, userId=userId,
        )
    else:
        _send_card(self, entries, title, data, userId, threadId, msg_type, engine=engine)

    # Reaction xác nhận
    self.sendReaction(data, "👌", threadId, msg_type, 100_000_000)


# ── Metadata lệnh ────────────────────────────────────────────────────────────
dependencies = {
    "name":        "alys",
    "permission":  0,
    "cooldown":    10,
    "description": (
        "Xem top nhắn tin nhiều nhất.\n"
        "  top              → top trong nhóm (ảnh, Pillow)\n"
        "  top js           → top trong nhóm (ảnh, vẽ bằng node-canvas)\n"
        "  top text         → dạng text\n"
        "  top global       → top toàn bot (ảnh)\n"
        "  top global js    → top toàn bot (ảnh, node-canvas)\n"
        "  top global text  → top toàn bot dạng text"
    ),
    "main":        topChatCommand,
}
