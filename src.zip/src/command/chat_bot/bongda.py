from app.core.index import *
import requests, re, unicodedata
from datetime import datetime

# ═══════════════════════════════════════════════════════════
# SerpAPI
# ═══════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
SERP_API_URL = "https://serpapi.com/search.json"


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _norm(s):
    return unicodedata.normalize("NFKD", s.lower()).encode("ascii", "ignore").decode()

def _today_vi():
    now = datetime.now()
    return now.strftime("%d/%m/%Y")

def _fetch_matches(query):
    """
    Gọi SerpAPI google_autocomplete để lấy gợi ý trận đấu,
    sau đó gọi thêm google search để lấy kết quả chi tiết.
    """
    try:
        # Bước 1: Google Search lấy sports_results
        resp = requests.get(
            SERP_API_URL,
            params={
                "engine":  "google",
                "q":       query,
                "api_key": SERP_API_KEY,
                "hl":      "vi",
                "gl":      "vn",
            },
            timeout=10,
        )
        data = resp.json()

        matches = []

        # Lấy từ sports_results (kết quả thể thao trực tiếp của Google)
        sports = data.get("sports_results", {})
        games  = sports.get("games", []) or []

        for g in games:
            teams     = g.get("teams", [])
            highlight = g.get("highlight", "")
            status    = g.get("status",    "")
            league    = g.get("league",    "")
            time_str  = g.get("date",      "") or g.get("time", "")

            if len(teams) >= 2:
                t1     = teams[0]
                t2     = teams[1]
                name1  = t1.get("name",  "?")
                name2  = t2.get("name",  "?")
                score1 = t1.get("score", "")
                score2 = t2.get("score", "")

                if score1 and score2:
                    score_str = f"{score1} - {score2}"
                else:
                    score_str = "vs"

                matches.append({
                    "team1":    name1,
                    "team2":    name2,
                    "score":    score_str,
                    "status":   status or highlight,
                    "league":   league,
                    "time":     time_str,
                })

        # Fallback: lấy từ answer_box nếu không có sports_results
        if not matches:
            answer = data.get("answer_box", {})
            if answer:
                snippet = answer.get("answer") or answer.get("snippet", "")
                if snippet:
                    matches.append({
                        "team1":  "",
                        "team2":  "",
                        "score":  "",
                        "status": snippet,
                        "league": "",
                        "time":   "",
                    })

        return matches, data.get("search_information", {}).get("query_displayed", query)

    except Exception as e:
        print(f"[bongda] fetch error: {e}")
        return [], query


def _format_matches(matches, title, query_display):
    """Định dạng danh sách trận thành text đẹp."""
    today = _today_vi()
    lines = [f"⚽ {title} — {today}\n{'─'*30}"]

    if not matches:
        lines.append("\nKhông tìm thấy kết quả.")
        lines.append(f"🔍 Thử tìm: {query_display}")
        return "\n".join(lines)

    for i, m in enumerate(matches, 1):
        league_str = f"[{m['league']}] " if m["league"] else ""
        time_str   = f" ({m['time']})"   if m["time"]   else ""

        if m["team1"] and m["team2"]:
            score_part = f"{m['team1']}  {m['score']}  {m['team2']}"
        else:
            score_part = m["status"]

        status_str = f"\n   📌 {m['status']}" if m["status"] and m["team1"] else ""

        lines.append(f"\n{i}. {league_str}{score_part}{time_str}{status_str}")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# Sub commands
# ═══════════════════════════════════════════════════════════

def _cmd_today(this, data, threadId, type):
    """Lịch sử/kết quả bóng đá hôm nay."""
    matches, qd = _fetch_matches("kết quả bóng đá hôm nay")
    text = _format_matches(matches, "Kết quả hôm nay", qd)
    this.replyMessageStyle(text, data, threadId, type, color="or", title="BÓNG ĐÁ")


def _cmd_upcoming(this, data, threadId, type):
    """Lịch thi đấu sắp tới."""
    matches, qd = _fetch_matches("lịch thi đấu bóng đá hôm nay tối nay")
    text = _format_matches(matches, "Lịch thi đấu hôm nay", qd)
    this.replyMessageStyle(text, data, threadId, type, color="or", title="LỊCH ĐÁ")


def _cmd_search(this, query, data, threadId, type):
    """Tìm kiếm kết quả theo tên đội/giải."""
    matches, qd = _fetch_matches(f"kết quả bóng đá {query}")
    text = _format_matches(matches, f"Kết quả: {query}", qd)
    this.replyMessageStyle(text, data, threadId, type, color="or", title="BÓNG ĐÁ")


def _cmd_live(this, data, threadId, type):
    """Trận đang diễn ra."""
    matches, qd = _fetch_matches("bóng đá trực tiếp đang diễn ra")
    text = _format_matches(matches, "Trận đang diễn ra", qd)
    this.replyMessageStyle(text, data, threadId, type, color="or", title="🔴 LIVE")


# ═══════════════════════════════════════════════════════════
# Help & Main
# ═══════════════════════════════════════════════════════════

def _help(p, c):
    return (
        f"╔══ BÓNG ĐÁ ══╗\n\n"
        f"  ⚽ {p}{c}              - Kết quả hôm nay\n"
        f"  📅 {p}{c} lich         - Lịch thi đấu hôm nay\n"
        f"  🔴 {p}{c} live         - Trận đang diễn ra\n"
        f"  🔍 {p}{c} <tên đội>    - Tìm theo đội/giải\n\n"
        f"╚═════════════╝\n"
        f"VD: {p}{c} mu\n"
        f"    {p}{c} ngoại hạng anh\n"
        f"    {p}{c} live"
    )


def bongdaCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split(None, 1)
    p = getattr(this, "prefix", "")
    c = getattr(this, "rawCommand", "bongda")

    if len(parts) < 2:
        return _cmd_today(this, data, threadId, type)

    sub = parts[1].strip().lower()

    if sub in ("lich", "lịch", "schedule"):
        return _cmd_upcoming(this, data, threadId, type)
    if sub in ("live", "tt", "trực tiếp"):
        return _cmd_live(this, data, threadId, type)
    if sub in ("help", "h", "?"):
        return this.replyMessageStyle(_help(p, c), data, threadId, type, color="or", title="BÓNG ĐÁ")

    return _cmd_search(this, sub, data, threadId, type)


dependencies = {
    "name":        "bongda",
    "permission":  0,
    "cooldown":    5,
    "description": "Xem kết quả, lịch thi đấu, trực tiếp bóng đá qua SerpAPI.",
    "alias":       ["bd", "football"],
    "main":        bongdaCommand,
}
