from app.core.index import *
import random

CAPTIONS = [
    # 0-4%
    "Trong sạch như nước cất, chắc là thánh rồi 😇",
    # 5-9%
    "Gần như thánh thiện, chỉ thỉnh thoảng liếc nhìn thôi 👀",
    # 10-14%
    "Vẫn lành, nhưng hay xem phim 18+ 'vì nghệ thuật' 🎬",
    # 15-19%
    "Cơ bản là ngoan, nhưng lịch sử tìm kiếm hơi đáng ngờ 🔍",
    # 20-24%
    "Bình thường thôi, chỉ là hay nghĩ bậy một chút xíu 😶",
    # 25-29%
    "Bắt đầu có dấu hiệu... nhưng tự nhủ là 'ai chả vậy' 🤔",
    # 30-34%
    "Não cứ tự chèn quảng cáo không phù hợp vào mọi lúc 🧠",
    # 35-39%
    "Hay cười khẩy khi nghe từ ngữ bình thường một cách bất thường 😏",
    # 40-44%
    "Google biết hết. Google không phán xét. Google lo lắng. 💻",
    # 45-49%
    "Đang ở vùng xám, tâm trí đi lạc thường xuyên 📡",
    # 50-54%
    "Chính xác ở giữa, nửa thánh nửa... không thánh 🕯️",
    # 55-59%
    "Nghiêng về phía tối rồi đó, nhưng vẫn còn tự kiểm soát được 😅",
    # 60-64%
    "Hay tìm lý do 'khoa học' để giải thích những sở thích kỳ lạ 🔬",
    # 65-69%
    "Bạn bè hay nhắn 'mày ổn không?' sau mấy câu joke của mày 😂",
    # 70-74%
    "Đang ở giai đoạn 'tôi chỉ đang... tìm hiểu cuộc sống' ✨",
    # 75-79%
    "Lịch sử trình duyệt nếu bị lộ thì cần một luật sư 📋",
    # 80-84%
    "Ở một mình với wifi là một sự kết hợp nguy hiểm 🔥",
    # 85-89%
    "Gần đỉnh rồi! Não đã đặt chế độ 'auto-pilot bậy' 🛸",
    # 90-94%
    "Thôi thì mình cứ gọi là 'người trưởng thành tự do' cho lịch sự 🌶️",
    # 95-99%
    "Gần chạm đỉnh! Đức Phật đang lắc đầu ngao ngán 🙏",
    # 100%
    "FULL DÂM! Xin chúc mừng, bạn đã mở khóa thành tựu LEGEND OF THE HORNY 🔞🎉",
]

def _get_caption(percent: int) -> str:
    if percent == 100:
        return CAPTIONS[20]
    return CAPTIONS[min(percent // 5, 19)]

def _get_name(self, uid: str, fallback: str) -> str:
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        return profile.get("displayName") or profile.get("zaloName") or fallback
    except Exception:
        return fallback

def checkDamCommand(self, message, data, userId, threadId, type):
    mentions = getattr(data, "mentions", None) or []

    target_uid = None
    for m in mentions:
        uid = str(m.get("uid", ""))
        if uid and uid != str(self.uid):
            target_uid = uid
            break

    if target_uid:
        name = _get_name(self, target_uid, "Người dùng")
    else:
        name = _get_name(self, userId, self.userName(userId))

    percent = random.randint(0, 100)
    caption = _get_caption(percent)

    result_text = (
        f"Chỉ số dâm của {name} là {percent}%\n"
        f"📍{caption}"
    )

    self.replyMessageStyle(
        result_text,
        data, threadId, type,
        color="gr", title="SUCCESS",
        userId=userId,
    )

    self.sendReaction(data, "", threadId, type, -1)
    self.sendReaction(data, "🌶️", threadId, type, 100000000)

dependencies = {
    "name": "dam",
    "permission": 0,
    "cooldown": 5,
    "description": "Đo chỉ số dâm của bản thân hoặc ai đó",
    "main": checkDamCommand,
}
