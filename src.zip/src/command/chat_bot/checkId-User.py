from app.core.index import *
import json


def _resolve_target(self, message, data, userId):
    # Ưu tiên 1: mention
    mentions = getattr(data, "mentions", None) or []
    for m in mentions:
        uid = str(m.get("uid", "")).strip()
        if uid and uid != str(self.uid):
            return uid

    # Không mention → trả về bản thân
    return str(userId)


def getId(self, message, data, userId, threadId, type):
    target_uid = _resolve_target(self, message, data, userId)

    try:
        display_name = self.userName(target_uid) or target_uid
    except Exception:
        display_name = target_uid

    text = (
        f"👤 Tên: {display_name}\n"
        f"🆔 User ID: {target_uid}\n"
        f"📖 Thread ID: {threadId}"
    )

    return self.replyMessageStyle(
        text,
        data,
        threadId,
        type,
        color="gr",
        title="SUCCESS",
        userId=userId,
    )


dependencies = {
    "name":        "uid",
    "permission":  0,
    "description": "Lấy UID người dùng",
    "cooldown":    3,
    "alias": ["id"],
    "main": getId,
}