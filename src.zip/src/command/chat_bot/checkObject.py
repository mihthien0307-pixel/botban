from app.core.index import *
import json

def checkData(self, message, data, userId, threadId, type):
    if not getattr(data, "quote", None):
        return self.replyMessageStyle(
            "Vui lòng reply 1 message để lấy data!",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )

    try:
        dataQuoted = data.quote

        if hasattr(dataQuoted, "__dict__"):
            dataQuoted = dataQuoted.__dict__

        if "attach" in dataQuoted and dataQuoted["attach"]:
            try:
                dataQuoted["attach"] = json.loads(dataQuoted["attach"])
            except Exception:
                pass

        json_str = json.dumps(dataQuoted, ensure_ascii=False, indent=4)

        return self.replyMessageStyle(
            json_str,
            data, threadId, type,
            color="gr", title="SUCCESS", userId=userId,
        )

    except Exception as e:
        return self.replyMessageStyle(
            f"Lỗi xử lý data: {str(e)}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


dependencies = {
    "name": "source",
    "permission": 0,
    "description": "Get Message Data",
    "cooldown": 5,
    "main": checkData
}
