import json, os, time
from typing import Any, Dict, List, Optional

_MEM_ROOT = "data/config/agent_memory"
_TRIM_COOLDOWN = 30.0
_trim_ts: Dict[str, float] = {}

def _path(botUid: str, threadId: str) -> str:
    d = os.path.join(_MEM_ROOT, str(botUid))
    os.makedirs(d, exist_ok=True)
    safe = str(threadId).replace("/", "_").replace("\\", "_")
    return os.path.join(d, f"{safe}.json")

def _load(botUid: str, threadId: str) -> List[Dict]:
    p = _path(botUid, threadId)
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []

def _save(botUid: str, threadId: str, items: List[Dict]) -> bool:
    try:
        with open(_path(botUid, threadId), "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False

def _maybe_trim(botUid: str, threadId: str, keep: int):
    key = f"{botUid}:{threadId}"
    now = time.time()
    if now - _trim_ts.get(key, 0) < _TRIM_COOLDOWN:
        return
    _trim_ts[key] = now
    items = _load(botUid, threadId)
    if len(items) > keep:
        _save(botUid, threadId, items[-keep:])

def Write(botUid: str, uidFrom: str, threadId: str, q: str, a: str,
          meta: Optional[Dict] = None, ts: Optional[int] = None,
          limitKeep: int = 200) -> bool:
    keep = max(50, int(limitKeep or 200))
    _maybe_trim(botUid, threadId, keep)
    items = _load(botUid, threadId)
    items.append({
        "bot_uid":  str(botUid),
        "uid_from": str(uidFrom),
        "thread_id": str(threadId),
        "q": str(q or ""),
        "a": str(a or ""),
        "meta": meta or {},
        "ts": int(ts or time.time()),
    })
    if len(items) > keep:
        items = items[-keep:]
    return _save(botUid, threadId, items)

def GetText(botUid: str, threadId: str, limit: int = 12) -> str:
    lim = max(1, int(limit or 12))
    items = _load(botUid, threadId)[-lim:]
    lines = []
    for it in items:
        q = (it.get("q") or "").strip()
        a = (it.get("a") or "").strip()
        if q or a:
            lines.append(f"- User: {q}\n  Agent: {a}")
    return "\n".join(lines)

def GetItems(botUid: str, threadId: str, limit: int = 50) -> List[Dict]:
    lim = max(1, int(limit or 50))
    items = _load(botUid, threadId)[-lim:]
    return [{"q": it.get("q") or "", "a": it.get("a") or "", "ts": it.get("ts") or 0}
            for it in items]

def GetLast(botUid: str, threadId: str, offset: int = 0) -> Optional[Dict]:
    items = _load(botUid, threadId)
    idx = -(1 + max(0, int(offset or 0)))
    try:
        it = items[idx]
        return {"q": it.get("q") or "", "a": it.get("a") or "", "ts": it.get("ts") or 0}
    except IndexError:
        return None

def Clear(botUid: str, threadId: str) -> bool:
    return _save(botUid, threadId, [])