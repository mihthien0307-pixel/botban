import json
import time
import requests
from typing import List, Optional

class ApiModels:
    KEY_PATH = "data/config/ai-database.json"

    def __init__(self):
        self._idx = 0
        self.keys = self._load()

    def _load(self) -> List[str]:
        try:
            with open(self.KEY_PATH, "r", encoding="utf-8") as f:
                return json.load(f).get("GEMINI") or []
        except Exception:
            return []

    def _rotate(self) -> Optional[str]:
        if not self.keys:
            return None
        key = self.keys[self._idx]
        self._idx = (self._idx + 1) % len(self.keys)
        return key

    def geminiCall(self, prompt: str, model: str = "gemini-2.5-flash") -> str:
        last = None
        attempts = max(1, len(self.keys)) * 3  

        for attempt in range(attempts):
            key = self._rotate()
            if not key:
                break
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:generateContent?key={key}"
            )
            body = {"contents": [{"parts": [{"text": prompt}]}]}
            try:
                r = requests.post(url, json=body, timeout=30)

                if r.status_code in (503, 429):
                    wait = 3 if r.status_code == 503 else 5
                    time.sleep(wait)
                    last = Exception(f"{r.status_code} {r.reason} for url: {url}")
                    continue

                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            except Exception as e:
                last = e

        raise last or RuntimeError("No Gemini API keys configured")

class GeminiContent:
    def __init__(self, api: ApiModels):
        self.api = api
        self.prompt = ""

    def getText(self) -> str:
        return self.api.geminiCall(self.prompt)