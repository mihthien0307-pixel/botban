from app.core.index import *
import ast
import traceback
import os
import sys
import threading

MAX_LEN = 1500


def split_send(send, msg):
    msg = str(msg)
    if len(msg) <= MAX_LEN:
        send(msg)
        return
    for i in range(0, len(msg), MAX_LEN):
        send(msg[i:i + MAX_LEN], i == 0)


def SysCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    quote = getattr(data, "quote", None)
    parts = text.split(maxsplit=1)

    # ── sys reset ────────────────────────────────────────────────────────────────
    if len(parts) > 1 and parts[1].strip().lower() == "reset":
        from src.services.init.admin import save_restart_thread
        save_restart_thread(threadId)

        self.replyMessageStyle(
            "Tiến hành khởi động lại...\n✅✅✅",
            data, threadId, type,
            color="or", title="SYSTEM", userId=userId,
        )

        def _do_restart():
            import time
            time.sleep(1.5)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        threading.Thread(target=_do_restart, daemon=True).start()
        return

    if len(parts) == 1:
        if not quote or not getattr(quote, "msg", None):
            return self.replyMessageStyle(
                "What do u wanna run?",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        code = quote.msg.strip()
    else:
        code = parts[1].strip()

    _sent = [False]

    def send(msg, is_first=False):
        uid = userId if (is_first or not _sent[0]) else None
        _sent[0] = True
        return split_send(
            lambda x, f=is_first: self.replyMessageStyle(
                str(x), data, threadId, type,
                color="gr", title="OUTPUT", userId=uid,
            ),
            msg,
        )

    try:
        tree = ast.parse(code)

        ctx = {
            "self":       self,
            "this":       self,
            "client":     self,
            "Message":    Message,
            "threadId":   threadId,
            "ThreadType": ThreadType,
            "type":       type,
            "userId":     userId,
            "data":       data,
            "send":       send,
            "print":      lambda *a: send(" ".join(map(str, a)))
        }

        result = None

        if tree.body and isinstance(tree.body[-1], ast.Expr):
            expr      = ast.Expression(tree.body[-1].value)
            tree.body = tree.body[:-1]
            exec(compile(tree, "<sys>", "exec"), {}, ctx)
            result = eval(compile(expr, "<sys>", "eval"), {}, ctx)
        else:
            exec(compile(tree, "<sys>", "exec"), {}, ctx)

        if result is not None:
            send(result)

    except Exception:
        self.replyMessageStyle(
            "ERROR:\n" + traceback.format_exc(limit=5),
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


dependencies = {
    "name":        "sys",
    "permission":  4,
    "description": "System command",
    "cooldown":    5,
    "main":        SysCommand,
}