from app.core.index import *
import requests, unicodedata
from datetime import datetime

# ═══════════════════════════════════════════════════════════
# SerpAPI
# ═══════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
SERP_API_URL = "https://serpapi.com/search.json"


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _today_vi():
    return datetime.now().strftime("%d/%m/%Y %H:%M")

def _fetch_gold(query="giá vàng hôm nay"):
    """
    Gọi SerpAPI google search, lấy answer_box / knowledge_graph / organic.
    Trả về dict chứa các loại giá vàng tìm được.
    """
    try:
        resp = requests.get(
            SERP_API_URL,
            params={
                "engine":  "google",
                "q":       query,
                "api_key": SERP_API_KEY,
                "hl":      "vi",
                "gl":      "vn",
            },
            timeout=10,
        )
        data = resp.json()

        results = []

        # ── 1. Answer box (thường chứa bảng giá trực tiếp) ──
        ab = data.get("answer_box", {})
        if ab:
            # Dạng bảng
            table = ab.get("table", [])
            for row in table:
                if isinstance(row, dict):
                    label = row.get("label") or row.get("name") or ""
                    buy   = row.get("buy")   or row.get("mua")  or ""
                    sell  = row.get("sell")  or row.get("ban")  or ""
                    price = row.get("price") or row.get("gia")  or ""
                    if label:
                        if buy and sell:
                            results.append({"label": label, "buy": buy, "sell": sell, "price": ""})
                        elif price:
                            results.append({"label": label, "buy": "", "sell": "", "price": price})

            # Dạng snippet
            if not results:
                snippet = ab.get("answer") or ab.get("snippet") or ab.get("result") or ""
                title   = ab.get("title", "")
                if snippet:
                    results.append({"label": title or "Giá vàng", "buy": "", "sell": "", "price": snippet})

        # ── 2. Knowledge graph ──
        if not results:
            kg = data.get("knowledge_graph", {})
            if kg:
                label = kg.get("title", "Giá vàng")
                desc  = kg.get("description") or kg.get("price") or ""
                facts = kg.get("facts", []) or []
                for f in facts:
                    k = f.get("name", "")
                    v = f.get("value", "")
                    if k and v:
                        results.append({"label": k, "buy": "", "sell": "", "price": v})
                if not results and desc:
                    results.append({"label": label, "buy": "", "sell": "", "price": desc})

        # ── 3. Organic results (fallback lấy snippet đầu tiên) ──
        if not results:
            organic = data.get("organic_results", [])
            for item in organic[:3]:
                title   = item.get("title", "")
                snippet = item.get("snippet", "")
                if snippet and ("vàng" in snippet.lower() or "gold" in snippet.lower()):
                    results.append({"label": title, "buy": "", "sell": "", "price": snippet})

        return results

    except Exception as e:
        print(f"[giavang] fetch error: {e}")
        return []


def _format_result(results, title):
    today = _today_vi()
    lines = [f"💰 {title}\n📅 Cập nhật: {today}\n{'─'*30}"]

    if not results:
        lines.append("\nKhông lấy được dữ liệu.\nThử lại sau ít phút.")
        return "\n".join(lines)

    for r in results:
        label = r["label"]
        if r["buy"] and r["sell"]:
            lines.append(f"\n🏷️  {label}")
            lines.append(f"   Mua: {r['buy']}")
            lines.append(f"   Bán: {r['sell']}")
        elif r["price"]:
            lines.append(f"\n🏷️  {label}: {r['price']}")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# Sub commands
# ═══════════════════════════════════════════════════════════

def _cmd_sjc(this, data, threadId, type):
    results = _fetch_gold("giá vàng SJC hôm nay")
    text = _format_result(results, "Giá Vàng SJC")
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="GIÁ VÀNG SJC")

def _cmd_world(this, data, threadId, type):
    results = _fetch_gold("giá vàng thế giới hôm nay USD")
    text = _format_result(results, "Giá Vàng Thế Giới")
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="VÀNG THẾ GIỚI")

def _cmd_today(this, data, threadId, type):
    results = _fetch_gold("giá vàng hôm nay")
    text = _format_result(results, "Giá Vàng Hôm Nay")
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="GIÁ VÀNG")

def _cmd_search(this, query, data, threadId, type):
    results = _fetch_gold(f"giá vàng {query} hôm nay")
    text = _format_result(results, f"Giá Vàng: {query}")
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="GIÁ VÀNG")


# ═══════════════════════════════════════════════════════════
# Help & Main
# ═══════════════════════════════════════════════════════════

def _help(p, c):
    return (
        f"╔══ GIÁ VÀNG ══╗\n\n"
        f"  💰 {p}{c}           - Giá vàng hôm nay\n"
        f"  🥇 {p}{c} sjc       - Giá vàng SJC\n"
        f"  🌍 {p}{c} tg        - Giá vàng thế giới\n"
        f"  🔍 {p}{c} <loại>    - Tìm theo loại vàng\n\n"
        f"╚══════════════╝\n"
        f"VD: {p}{c} sjc\n"
        f"    {p}{c} 9999\n"
        f"    {p}{c} nhẫn"
    )


def giavangCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split(None, 1)
    p = getattr(this, "prefix", "")
    c = getattr(this, "rawCommand", "giavang")

    if len(parts) < 2:
        return _cmd_today(this, data, threadId, type)

    sub = parts[1].strip().lower()

    if sub in ("sjc",):
        return _cmd_sjc(this, data, threadId, type)
    if sub in ("tg", "thegioi", "thế giới", "world"):
        return _cmd_world(this, data, threadId, type)
    if sub in ("help", "h", "?"):
        return this.replyMessageStyle(_help(p, c), data, threadId, type, color="yl", title="GIÁ VÀNG")

    return _cmd_search(this, sub, data, threadId, type)


dependencies = {
    "name":        "giavang",
    "permission":  0,
    "cooldown":    5,
    "description": "Xem giá vàng hôm nay (SJC, thế giới, các loại) qua SerpAPI.",
    "alias":       ["gv", "gold", "vang"],
    "main":        giavangCommand,
}
