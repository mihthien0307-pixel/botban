from app.core.index import *
import requests, unicodedata
from datetime import datetime

# ═══════════════════════════════════════════════════════════
# SerpAPI
# ═══════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
SERP_API_URL = "https://serpapi.com/search.json"


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _today_vi():
    return datetime.now().strftime("%d/%m/%Y %H:%M")

def _fetch_gas(query="giá xăng hôm nay"):
    try:
        resp = requests.get(
            SERP_API_URL,
            params={
                "engine":  "google",
                "q":       query,
                "api_key": SERP_API_KEY,
                "hl":      "vi",
                "gl":      "vn",
            },
            timeout=10,
        )
        data = resp.json()
        results = []

        # ── 1. Answer box ──
        ab = data.get("answer_box", {})
        if ab:
            table = ab.get("table", [])
            for row in table:
                if isinstance(row, dict):
                    label = row.get("label") or row.get("name") or row.get("loai") or ""
                    price = row.get("price") or row.get("gia")  or row.get("value") or ""
                    change= row.get("change") or row.get("thay_doi") or ""
                    if label and price:
                        results.append({"label": label, "price": price, "change": change})

            if not results:
                snippet = ab.get("answer") or ab.get("snippet") or ab.get("result") or ""
                title   = ab.get("title", "")
                if snippet:
                    results.append({"label": title or "Giá xăng", "price": snippet, "change": ""})

        # ── 2. Knowledge graph ──
        if not results:
            kg = data.get("knowledge_graph", {})
            if kg:
                facts = kg.get("facts", []) or []
                for f in facts:
                    k = f.get("name", "")
                    v = f.get("value", "")
                    if k and v:
                        results.append({"label": k, "price": v, "change": ""})
                if not results:
                    desc = kg.get("description") or kg.get("price") or ""
                    if desc:
                        results.append({"label": kg.get("title", "Giá xăng"), "price": desc, "change": ""})

        # ── 3. Organic fallback ──
        if not results:
            for item in data.get("organic_results", [])[:3]:
                title   = item.get("title", "")
                snippet = item.get("snippet", "")
                if snippet and ("xăng" in snippet.lower() or "dầu" in snippet.lower()):
                    results.append({"label": title, "price": snippet, "change": ""})

        return results

    except Exception as e:
        print(f"[giaxang] fetch error: {e}")
        return []


def _format_result(results, title):
    today = _today_vi()
    lines = [f"⛽ {title}\n📅 Cập nhật: {today}\n{'─'*30}"]

    if not results:
        lines.append("\nKhông lấy được dữ liệu.\nThử lại sau ít phút.")
        return "\n".join(lines)

    for r in results:
        change_str = f"  ({r['change']})" if r["change"] else ""
        lines.append(f"\n🔹 {r['label']}: {r['price']}{change_str}")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# Sub commands
# ═══════════════════════════════════════════════════════════

def _cmd_today(this, data, threadId, type):
    results = _fetch_gas("giá xăng hôm nay")
    text = _format_result(results, "Giá Xăng Hôm Nay")
    this.replyMessageStyle(text, data, threadId, type, color="or", title="GIÁ XĂNG")

def _cmd_e5(this, data, threadId, type):
    results = _fetch_gas("giá xăng E5 RON 92 hôm nay")
    text = _format_result(results, "Giá Xăng E5 RON 92")
    this.replyMessageStyle(text, data, threadId, type, color="or", title="XĂNG E5")

def _cmd_ron95(this, data, threadId, type):
    results = _fetch_gas("giá xăng RON 95 hôm nay")
    text = _format_result(results, "Giá Xăng RON 95")
    this.replyMessageStyle(text, data, threadId, type, color="or", title="XĂNG RON 95")

def _cmd_dau(this, data, threadId, type):
    results = _fetch_gas("giá dầu diesel hôm nay")
    text = _format_result(results, "Giá Dầu Diesel")
    this.replyMessageStyle(text, data, threadId, type, color="or", title="GIÁ DẦU")

def _cmd_search(this, query, data, threadId, type):
    results = _fetch_gas(f"giá xăng {query} hôm nay")
    text = _format_result(results, f"Giá Xăng: {query}")
    this.replyMessageStyle(text, data, threadId, type, color="or", title="GIÁ XĂNG")


# ═══════════════════════════════════════════════════════════
# Help & Main
# ═══════════════════════════════════════════════════════════

def _help(p, c):
    return (
        f"╔══ GIÁ XĂNG ══╗\n\n"
        f"  ⛽ {p}{c}           - Giá xăng hôm nay\n"
        f"  🟢 {p}{c} e5        - Xăng E5 RON 92\n"
        f"  🔵 {p}{c} ron95     - Xăng RON 95\n"
        f"  🟤 {p}{c} dau       - Dầu Diesel\n"
        f"  🔍 {p}{c} <loại>    - Tìm theo loại\n\n"
        f"╚══════════════╝\n"
        f"VD: {p}{c} e5\n"
        f"    {p}{c} ron95\n"
        f"    {p}{c} dau"
    )


def giaxangCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split(None, 1)
    p = getattr(this, "prefix", "")
    c = getattr(this, "rawCommand", "giaxang")

    if len(parts) < 2:
        return _cmd_today(this, data, threadId, type)

    sub = parts[1].strip().lower()

    if sub in ("e5", "92", "ron92"):
        return _cmd_e5(this, data, threadId, type)
    if sub in ("ron95", "95"):
        return _cmd_ron95(this, data, threadId, type)
    if sub in ("dau", "dầu", "diesel"):
        return _cmd_dau(this, data, threadId, type)
    if sub in ("help", "h", "?"):
        return this.replyMessageStyle(_help(p, c), data, threadId, type, color="or", title="GIÁ XĂNG")

    return _cmd_search(this, sub, data, threadId, type)


dependencies = {
    "name":        "giaxang",
    "permission":  0,
    "cooldown":    5,
    "description": "Xem giá xăng dầu hôm nay (E5, RON 95, Diesel) qua SerpAPI.",
    "alias":       ["gx", "xang"],
    "main":        giaxangCommand,
}
