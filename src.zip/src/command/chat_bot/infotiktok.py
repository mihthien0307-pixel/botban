"""
src/command/chat_bot/infotiktok.py
Xem thông tin profile TikTok – TikWM API + SerpAPI autocomplete fallback.

Cách dùng:
  ,infotiktok <username hoặc link>   → hiển thị info profile + videos mới nhất
  ,infotiktok help                   → hướng dẫn
"""

from app.core.index import *
import os
import re
import uuid
import threading
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ════════════════════════════════════════════════════════════════════════════
# Config
# ════════════════════════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
TIKWM_BASE   = "https://tikwm.com"
CACHE_DIR    = "data/assets/cache/infotiktok"
HEADERS      = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# ════════════════════════════════════════════════════════════════════════════
# Canvas config
# ════════════════════════════════════════════════════════════════════════════
W, H   = 1280, 520
PAD    = 36
FONT_DIR = Path("assets/font")

GRAD_TL = (18,  14, 42)
GRAD_TR = (38,  18, 60)
GRAD_BL = (28,  36, 58)
GRAD_BR = (50,  28, 68)

C_ACCENT  = (254,  44,  85)   # TikTok red
C_WHITE   = (255, 255, 255, 255)
C_SUB     = (200, 190, 230, 255)
C_DIM     = (140, 130, 180, 255)
C_STAT_BG = (255, 255, 255, 18)

_fcache: dict = {}
FONT_EMOJI = FONT_DIR / "emoji.ttf"

def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (size, bold)
    if key in _fcache:
        return _fcache[key]
    candidates = (
        [
            FONT_DIR / "Goldman" / "Goldman-Bold.ttf",
            FONT_DIR / "Opensans" / "static" / "OpenSans_Condensed-Bold.ttf",
            FONT_EMOJI,
        ] if bold else [
            FONT_DIR / "Opensans" / "static" / "OpenSans_Condensed-Regular.ttf",
            FONT_DIR / "MJLeQuarte-Regular.ttf",
            FONT_EMOJI,
        ]
    )
    for p in candidates:
        if Path(p).exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


def _font_emoji(size: int) -> ImageFont.FreeTypeFont:
    """Font riêng cho emoji, fallback về _font nếu không có."""
    key = ("emoji", size)
    if key in _fcache:
        return _fcache[key]
    if FONT_EMOJI.exists():
        try:
            f = ImageFont.truetype(str(FONT_EMOJI), size)
            _fcache[key] = f
            return f
        except Exception:
            pass
    return _font(size)


def _round_mask(w: int, h: int, r: int) -> Image.Image:
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w, h), r, fill=255)
    return m


def _fit(d: ImageDraw.ImageDraw, text: str, font, max_w: float) -> str:
    text = str(text or "").replace("\n", " ").replace("\r", "")
    if d.textlength(text, font=font) <= max_w:
        return text
    ell  = "…"
    room = max_w - d.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if d.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell


def _fmt_num(n) -> str:
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000_000:
        return f"{n/1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def _load_avatar(url: str, size: tuple) -> Image.Image | None:
    if not url or not url.startswith("http"):
        return None
    try:
        r = requests.get(url, timeout=8, headers=HEADERS)
        r.raise_for_status()
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        img = img.resize(size, Image.LANCZOS)
        return img
    except Exception:
        return None


def _glass(img: Image.Image, box, radius: int, alpha: int = 22):
    x1, y1, x2, y2 = map(int, box)
    bw, bh = x2 - x1, y2 - y1
    if bw <= 0 or bh <= 0:
        return
    region = img.crop((x1, y1, x2, y2))
    blur   = region.filter(ImageFilter.GaussianBlur(12))
    overlay = Image.new("RGBA", (bw, bh), (255, 255, 255, alpha))
    mask    = _round_mask(bw, bh, radius)
    blur.paste(overlay, (0, 0), overlay)
    blurred = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    blurred.paste(blur, (0, 0), mask)
    img.paste(blurred, (x1, y1), mask)


# ════════════════════════════════════════════════════════════════════════════
# Vẽ canvas
# ════════════════════════════════════════════════════════════════════════════
def _draw_info_card(profile: dict, videos: list, out_path: str):
    """
    Layout: nền gradient tím tối (ảnh 1) + avatar tròn ring đỏ bên trái +
    grid 2 cột thông tin kiểu ảnh 2 (label nhỏ đỏ, value lớn trắng).
    Canvas 1280×580.
    """
    CW, CH = 1280, 580

    # ── Background gradient ─────────────────────────────────────────────────
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), GRAD_TL)
    c.putpixel((1, 0), GRAD_TR)
    c.putpixel((0, 1), GRAD_BL)
    c.putpixel((1, 1), GRAD_BR)
    img = c.resize((CW, CH), Image.BILINEAR).convert("RGBA")

    # Outer glass frame
    _glass(img, (PAD, PAD, CW - PAD, CH - PAD), 40)

    inner = 20
    x1i = PAD + inner
    y1i = PAD + inner
    x2i = CW - PAD - inner
    y2i = CH - PAD - inner

    # ── Title header "TikTok User Info" ────────────────────────────────────
    f_title  = _font(44, bold=True)
    f_label  = _font(20, bold=True)
    f_value  = _font(32, bold=True)
    f_bio    = _font(21)
    f_logo   = _font(26, bold=True)

    d = ImageDraw.Draw(img)

    title_txt = "TikTok User Info"
    tw = int(d.textlength(title_txt, font=f_title))
    # Gradient text effect: vẽ 2 lần offset màu cyan + magenta rồi white đè
    d.text(((CW - tw) // 2 + 2, y1i + 2),  title_txt, font=f_title, fill=(0, 220, 255, 180))
    d.text(((CW - tw) // 2 - 2, y1i + 2),  title_txt, font=f_title, fill=(255, 60, 180, 180))
    d.text(((CW - tw) // 2,     y1i),       title_txt, font=f_title, fill=C_WHITE)

    # Accent line dưới title
    line_y = y1i + 56
    d.rounded_rectangle((x1i, line_y, CW // 2 - 20, line_y + 3), 2,
                         fill=(0, 200, 255, 200))
    d.rounded_rectangle((CW // 2 + 20, line_y, x2i, line_y + 3), 2,
                         fill=(*C_ACCENT, 200))

    # ── Avatar (trái) ──────────────────────────────────────────────────────
    AVT_SIZE = 160
    content_y = line_y + 18
    avt_cx = x1i + 20 + AVT_SIZE // 2          # center x avatar
    avt_cy = content_y + (y2i - content_y) // 2 # center y avatar

    avt_x = avt_cx - AVT_SIZE // 2
    avt_y = avt_cy - AVT_SIZE // 2

    avatar_img = _load_avatar(profile.get("avatar_url", ""), (AVT_SIZE, AVT_SIZE))

    # Ring đơn giản: vẽ circle đặc rồi paste avatar đè lên
    RING = 5
    ring_size = AVT_SIZE + RING * 2
    ring_layer = Image.new("RGBA", (ring_size, ring_size), (0, 0, 0, 0))
    ring_draw  = ImageDraw.Draw(ring_layer)
    ring_draw.ellipse((0, 0, ring_size - 1, ring_size - 1), fill=(*C_ACCENT, 255))
    img.paste(ring_layer, (avt_x - RING, avt_y - RING), ring_layer)

    if avatar_img:
        mask = _round_mask(AVT_SIZE, AVT_SIZE, AVT_SIZE // 2)
        img.paste(avatar_img, (avt_x, avt_y), mask)
    else:
        ph = Image.new("RGBA", (AVT_SIZE, AVT_SIZE), (50, 45, 80, 255))
        mask = _round_mask(AVT_SIZE, AVT_SIZE, AVT_SIZE // 2)
        img.paste(ph, (avt_x, avt_y), mask)

    # ID dưới avatar
    uid_txt = f"ID: {profile.get('uid', '')}"
    d = ImageDraw.Draw(img)
    f_uid = _font(17)
    uw = int(d.textlength(uid_txt, font=f_uid))
    d.text((avt_cx - uw // 2, avt_y + AVT_SIZE + 8), uid_txt, font=f_uid, fill=C_DIM)

    # ── Info grid (phải) ───────────────────────────────────────────────────
    # 4 hàng × 2 cột
    username  = profile.get("username") or ""
    nickname  = profile.get("nickname") or username
    verified  = profile.get("verified", False)
    bio       = profile.get("bio") or ""

    grid_x1 = avt_x + AVT_SIZE + 40
    grid_x2 = x2i - 10
    grid_y1 = content_y + 10
    grid_y2 = y2i - 10

    rows = [
        [("ID  USERNAME",  username),             ("✔  VERIFIED",   "Yes" if verified else "No")],
        [("👥  FOLLOWERS", _fmt_num(profile.get("followers",    0))),
         ("➡  FOLLOWING",  _fmt_num(profile.get("following",   0)))],
        [("❤  TOTAL LIKES", _fmt_num(profile.get("likes",       0))),
         ("🎬  VIDEOS",    _fmt_num(profile.get("videos_count", 0)))],
        [("📝  BIO", _fit(ImageDraw.Draw(img), bio or "—", f_value, grid_x2 - grid_x1 - 24))],
    ]

    n_rows  = len(rows)
    cell_h  = (grid_y2 - grid_y1) // n_rows
    cell_gap = 8

    for row_i, row in enumerate(rows):
        # Hàng cuối (bio) có thể full-width nếu chỉ 1 ô
        is_full = (len(row) == 1 or (len(row) == 2 and row[1] is None))
        n_cols  = 1 if is_full else 2
        cell_w  = (grid_x2 - grid_x1 - cell_gap * (n_cols - 1)) // n_cols

        cy1 = grid_y1 + row_i * cell_h
        cy2 = cy1 + cell_h - cell_gap

        for col_i in range(n_cols):
            item = row[col_i] if col_i < len(row) else None
            if item is None:
                continue
            lbl, val = item

            cx1 = grid_x1 + col_i * (cell_w + cell_gap)
            cx2 = cx1 + (grid_x2 - grid_x1 if is_full else cell_w)

            _glass(img, (cx1, cy1, cx2, cy2), 14, alpha=28)
            d = ImageDraw.Draw(img)

            # Accent bar kiri
            d.rounded_rectangle((cx1, cy1 + 10, cx1 + 3, cy2 - 10), 2,
                                 fill=(*C_ACCENT, 255))

            # Label
            d.text((cx1 + 14, cy1 + 10), lbl, font=f_label, fill=(*C_ACCENT, 255))

            # Value
            val_str = str(val or "—")
            d.text((cx1 + 14, cy1 + 36), val_str, font=f_value, fill=C_WHITE)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.save(out_path, "PNG")
    return out_path, CW, CH


# ════════════════════════════════════════════════════════════════════════════
# API lấy dữ liệu
# ════════════════════════════════════════════════════════════════════════════
def _tikwm_headers():
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept":     "application/json, text/plain, */*",
        "Referer":    TIKWM_BASE + "/",
        "Origin":     TIKWM_BASE,
    }


def _clean_username(raw: str) -> str:
    """Trích username từ link hoặc @username."""
    raw = raw.strip().lstrip("@")
    # Link dạng tiktok.com/@username hoặc tiktok.com/@username/video/...
    m = re.search(r"tiktok\.com/@([A-Za-z0-9_.]+)", raw)
    if m:
        return m.group(1)
    # Chỉ username thuần
    if re.match(r"^[A-Za-z0-9_.]+$", raw):
        return raw
    return raw


def _get_user_info(username: str) -> dict | None:
    """Lấy profile user qua TikWM."""
    try:
        r = requests.get(
            f"{TIKWM_BASE}/api/user/info",
            params={"unique_id": username},
            headers=_tikwm_headers(),
            timeout=12,
        )
        r.raise_for_status()
        j    = r.json()
        data = (j.get("data") or {})
        user = data.get("user") or data.get("userInfo", {}).get("user") or {}
        stat = data.get("stats") or data.get("userInfo", {}).get("stats") or {}
        if not user:
            return None
        return {
            "username":     user.get("uniqueId") or username,
            "nickname":     user.get("nickname") or username,
            "bio":          user.get("signature") or "",
            "avatar_url":   user.get("avatarLarger") or user.get("avatarMedium") or "",
            "verified":     bool(user.get("verified")),
            "uid":          str(user.get("id") or user.get("uid") or ""),
            "followers":    stat.get("followerCount") or 0,
            "following":    stat.get("followingCount") or 0,
            "likes":        stat.get("heartCount")     or stat.get("heart") or 0,
            "videos_count": stat.get("videoCount")     or 0,
        }
    except Exception as e:
        logger.errorw(f"[infotiktok] user info error: {e}")
        return None


def _get_user_videos(username: str, limit: int = 4) -> list:
    """Lấy video mới nhất của user qua TikWM."""
    try:
        r = requests.get(
            f"{TIKWM_BASE}/api/user/posts",
            params={"unique_id": username, "count": limit},
            headers=_tikwm_headers(),
            timeout=12,
        )
        if r.status_code != 200:
            return []
        j     = r.json()
        items = (j.get("data") or {}).get("videos") or []
        return [
            {
                "title":      v.get("title") or v.get("desc") or "",
                "cover":      v.get("cover") or v.get("origin_cover") or "",
                "play_count": int(v.get("play_count") or v.get("playCount") or 0),
                "digg_count": int(v.get("digg_count") or v.get("diggCount") or 0),
            }
            for v in items[:limit]
        ]
    except Exception:
        return []


def _search_serpapi(keyword: str) -> list[str]:
    """Fallback: SerpAPI autocomplete → trả về list username gợi ý."""
    try:
        r = requests.get(
            "https://serpapi.com/search.json",
            params={
                "engine":  "google_autocomplete",
                "q":       f"tiktok.com/@{keyword}",
                "api_key": SERP_API_KEY,
            },
            timeout=8,
            headers=HEADERS,
        )
        r.raise_for_status()
        results = []
        for s in r.json().get("suggestions", []):
            val = s.get("value", "")
            m   = re.search(r"@([A-Za-z0-9_.]+)", val)
            if m:
                u = m.group(1)
                if u not in results:
                    results.append(u)
            if len(results) >= 5:
                break
        return results
    except Exception as e:
        logger.errorw(f"[infotiktok] SerpAPI error: {e}")
        return []


# ════════════════════════════════════════════════════════════════════════════
# Helpers gửi tin
# ════════════════════════════════════════════════════════════════════════════
def _err(ctx, msg, data, threadId, type, userId=None):
    ctx.replyMessageStyle(msg, data, threadId, type,
                          color="r", title="LỖI", userId=userId)

def _info(ctx, msg, data, threadId, type, userId=None):
    ctx.replyMessageStyle(msg, data, threadId, type,
                          color="or", title="TIKTOK INFO", userId=userId)


# ════════════════════════════════════════════════════════════════════════════
# Handler chính
# ════════════════════════════════════════════════════════════════════════════
class InfoTikTokHandler:

    HELP = (
        "🎵 TIKTOK INFO\n\n"
        "  {p}infotiktok <username>       – xem thông tin profile\n"
        "  {p}infotiktok <link tiktok>    – xem profile từ link\n\n"
        "Ví dụ:\n"
        "  {p}infotiktok charlidamelio\n"
        "  {p}infotiktok @khaby.lame\n"
        "  {p}infotiktok https://www.tiktok.com/@khaby.lame\n"
    )

    def __init__(self, ctx, MsgObj, Data, UserId, ThreadId, ThreadType):
        self.ctx        = ctx
        self.MsgObj     = MsgObj
        self.Data       = Data
        self.UserId     = str(UserId)
        self.ThreadId   = ThreadId
        self.ThreadType = ThreadType
        self.prefix     = getattr(ctx, "prefix", ",")

    def run(self):
        text  = (getattr(self.MsgObj, "text", None) or "").strip()
        parts = text.split(None, 1)
        body  = parts[1].strip() if len(parts) >= 2 else ""

        if not body or body.lower() == "help":
            return _info(self.ctx, self.HELP.format(p=self.prefix),
                         self.Data, self.ThreadId, self.ThreadType, self.UserId)

        username = _clean_username(body)
        self.ctx.sendReaction(self.Data, "🔍", self.ThreadId, self.ThreadType, 100000000)
        threading.Thread(target=self._fetch_and_send, args=(username,), daemon=True).start()

    def _fetch_and_send(self, username: str):
        profile = _get_user_info(username)

        # Nếu không tìm thấy, thử SerpAPI để gợi ý
        if not profile:
            suggestions = _search_serpapi(username)
            if suggestions:
                lines = "\n".join(f"• @{u}" for u in suggestions[:5])
                return _err(
                    self.ctx,
                    f"Không tìm thấy @{username}.\n\nGợi ý có thể bạn muốn tìm:\n{lines}",
                    self.Data, self.ThreadId, self.ThreadType, self.UserId,
                )
            return _err(
                self.ctx,
                f"Không tìm thấy profile @{username}.\nKiểm tra lại username nhé!",
                self.Data, self.ThreadId, self.ThreadType, self.UserId,
            )

        videos = _get_user_videos(username, limit=4)

        out_path = None
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            out_path = os.path.join(CACHE_DIR, f"{uuid.uuid4().hex}.png")
            _draw_info_card(profile, videos, out_path)

            with Image.open(out_path) as im:
                img_w, img_h = im.size

            res     = self.ctx._uploadImage(out_path, self.ThreadId, self.ThreadType)
            img_url = None
            if isinstance(res, dict):
                img_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                img_url = res

            if img_url:
                self.ctx.sendRemoteImage(
                    img_url, self.ThreadId, self.ThreadType,
                    width=img_w, height=img_h,
                    message=None,
                    ttl=86000000,
                )
            else:
                self.ctx.sendLocalImage(
                    out_path, self.ThreadId, self.ThreadType,
                    width=img_w, height=img_h,
                    ttl=86000000,
                )

        except Exception as e:
            logger.errorw(f"[infotiktok] canvas error: {e}")
            # Text fallback
            bio_line = f"\n📝 {profile['bio']}" if profile.get("bio") else ""
            txt = (
                f"🎵 @{profile['username']}"
                + (" ✓" if profile.get("verified") else "") + "\n"
                f"👤 {profile['nickname']}{bio_line}\n\n"
                f"👥 Followers: {_fmt_num(profile['followers'])}\n"
                f"➡ Following: {_fmt_num(profile['following'])}\n"
                f"❤ Likes:     {_fmt_num(profile['likes'])}\n"
                f"🎬 Videos:   {_fmt_num(profile['videos_count'])}\n\n"
                f"🔗 https://www.tiktok.com/@{profile['username']}"
            )
            _info(self.ctx, txt, self.Data, self.ThreadId, self.ThreadType, self.UserId)
        finally:
            if out_path and os.path.exists(out_path):
                try:
                    os.remove(out_path)
                except Exception:
                    pass


# ════════════════════════════════════════════════════════════════════════════
# Entry point
# ════════════════════════════════════════════════════════════════════════════
def InfoTikTokCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    InfoTikTokHandler(self, MessageObj, Data, UserId, ThreadId, ThreadType).run()


# ════════════════════════════════════════════════════════════════════════════
dependencies = {
    "name":        "infotiktok",
    "permission":  0,
    "cooldown":    5,
    "description": "Xem thông tin profile TikTok – avatar, followers, likes, video mới nhất",
    "main":        InfoTikTokCommand,
}
