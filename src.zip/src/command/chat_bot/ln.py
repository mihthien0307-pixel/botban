from app.core.index import *
from src.services.pillow.drawLoveCard import draw_love_card
import os
import json
import datetime

LOVE_FILE = "data/love_day.json"
CACHE_DIR = "data/assets/cache/image"


def load_love_data() -> dict:
    if os.path.exists(LOVE_FILE):
        with open(LOVE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_love_data(data: dict):
    os.makedirs(os.path.dirname(LOVE_FILE), exist_ok=True)
    with open(LOVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _ok(self, msg, data, threadId, type, userId=None):
    self.replyMessageStyle(msg, data, threadId, type,
                           color="gr", title="SUCCESS", userId=userId)


def _err(self, msg, data, threadId, type, userId=None):
    self.replyMessageStyle(msg, data, threadId, type,
                           color="r", title="ERROR", userId=userId)


def _get_profile(self, uid: str) -> dict:
    """Lấy profile dict của uid, trả về {} nếu lỗi."""
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        return profiles.get(str(uid)) or {}
    except Exception:
        return {}


def _get_display_name(self, uid: str) -> str:
    p = _get_profile(self, uid)
    return p.get("displayName") or p.get("zaloName") or str(uid)


def _get_avatar_url(self, uid: str) -> str:
    return _get_profile(self, uid).get("avatar", "") or ""


def _send_love_card(self, love_data: dict, data, userId, threadId, type):
    """Vẽ canvas ghép đôi và gửi ảnh, fallback về text nếu lỗi."""
    date_str    = love_data["date"]
    name1       = love_data.get("name1", "???")
    name2       = love_data.get("name2", "???")
    title       = love_data.get("title", "THÔNG TIN NGÀY YÊU")
    avatar1_url = love_data.get("avatar1", "")
    avatar2_url = love_data.get("avatar2", "")

    start_date = datetime.datetime.strptime(date_str, "%d/%m/%Y").date()
    today      = datetime.date.today()
    days       = (today - start_date).days

    if days < 0:
        days_display = "???"
        days_label   = "Chua toi ngay yeu"
    elif today.day == start_date.day and today.month == start_date.month and today.year > start_date.year:
        days_display = str(days)
        days_label   = "Ki niem ngay yeu nhau!"
    elif days > 0 and days % 30 == 0:
        days_display = str(days)
        days_label   = f"Tron {days // 30} thang yeu nhau"
    else:
        days_display = str(days)
        days_label   = "yeu nhau"

    try:
        out_path      = os.path.join(CACHE_DIR, f"love_{threadId}.jpg")
        path, w, h    = draw_love_card(
            name1       = name1,
            name2       = name2,
            date_str    = date_str,
            days        = days_display,
            days_label  = days_label,
            avatar1_url = avatar1_url,
            avatar2_url = avatar2_url,
            title       = title,
            out_path    = out_path,
            seed        = hash(str(threadId)) % 999,
        )
        self.sendReaction(data, "💕", threadId, type, 100000000)
        self.sendLocalImage(path, threadId, type, width=w, height=h, message=None)
        try:
            os.remove(path)
        except Exception:
            pass
    except Exception:
        # fallback text
        self.sendReaction(data, "💕", threadId, type, 100000000)
        self.replyMessageStyle(
            f"{title}\nNgay: {date_str}\n{name1} - {name2}\n{days_label}",
            data, threadId, type, color="bl", title="NGAY YEU", userId=userId,
        )


def loveCommand(self, message, data, userId, threadId, type):
    text      = (getattr(message, "text", None) or "").strip()
    args      = text.split()

    # Chuẩn hoá args: bỏ phần prefix+tên lệnh ở đầu (vd: ",ln" hoặc "!ln")
    # Đảm bảo args[0] luôn là tên lệnh "ln", args[1] là sub-command
    if args and args[0].lstrip(getattr(self, "prefix", ",")) != "ln":
        # prefix chưa bị tách → args[0] = ",ln", giữ nguyên
        pass
    elif args and args[0] == "ln":
        # prefix đã bị tách trước → thêm placeholder để giữ index đúng
        args = ["_ln"] + args

    love_data = load_love_data()

    # ── ln check ─────────────────────────────────────────────────────────────
    if len(args) >= 2 and args[1].lower() == "check":
        if not love_data.get("date"):
            self.sendReaction(data, "💔", threadId, type, 100000000)
            _err(self, "Chua set ngay yeu nao het", data, threadId, type, userId)
            return
        _send_love_card(self, love_data, data, userId, threadId, type)
        return

    # ── ln add <ngay> <thang> <nam> @nguoi [@nguoi2] ────────────────────────
    # Tag 1 nguoi  → nguoi go lenh = nguoi 1, nguoi tag = nguoi 2
    # Tag 2 nguoi  → nguoi tag dau = nguoi 1, nguoi tag sau = nguoi 2
    if len(args) >= 5 and args[1].lower() == "add":
        try:
            day   = int(args[2])
            month = int(args[3])
            year  = int(args[4])
            date_obj = datetime.date(year, month, day)
            date_str = date_obj.strftime("%d/%m/%Y")
        except Exception:
            _err(self, "Ngay khong hop le. Dung: ln add <ngay> <thang> <nam> @nguoi",
                 data, threadId, type, userId)
            return

        uids = extractUids(data)

        if len(uids) == 0:
            _err(self,
                 "Phai tag it nhat 1 nguoi!\n"
                 f"Dung: {self.prefix}ln add {day} {month} {year} @nguoi",
                 data, threadId, type, userId)
            return
        elif len(uids) == 1:
            # Nguoi go lenh tu dong la nguoi 1
            uid1 = str(userId)
            uid2 = uids[0]
        else:
            # Tag du 2 nguoi nhu cu
            uid1, uid2 = uids[0], uids[1]

        name1       = _get_display_name(self, uid1)
        name2       = _get_display_name(self, uid2)
        avatar1_url = _get_avatar_url(self, uid1)
        avatar2_url = _get_avatar_url(self, uid2)

        new_data = {
            "date":    date_str,
            "name1":   name1,
            "name2":   name2,
            "avatar1": avatar1_url,
            "avatar2": avatar2_url,
            "title":   love_data.get("title", "THONG TIN NGAY YEU"),
        }
        save_love_data(new_data)

        self.sendReaction(data, "💖", threadId, type, 100000000)
        _ok(self,
            f"Da set ngay yeu thanh cong!\n"
            f"Ngay: {date_str}\n"
            f"{name1} - {name2}",
            data, threadId, type, userId)
        return

    # ── ln set <tiêu đề> ─────────────────────────────────────────────────────
    if len(args) >= 3 and args[1].lower() == "set":
        title = " ".join(args[2:])
        love_data["title"] = title
        save_love_data(love_data)
        self.sendReaction(data, "✅", threadId, type, 100000000)
        _ok(self, f"Đã cập nhật tiêu đề: {title}", data, threadId, type, userId)
        return

    # ── ln name 1|2 <tên> ────────────────────────────────────────────────────
    if len(args) >= 4 and args[1].lower() == "name":
        if args[2] not in ["1", "2"]:
            _err(self, "Dùng: ln name 1 <tên> hoặc ln name 2 <tên>", data, threadId, type, userId)
            return
        name_value   = " ".join(args[3:])
        love_data["name1" if args[2] == "1" else "name2"] = name_value
        save_love_data(love_data)
        self.sendReaction(data, "✅", threadId, type, 100000000)
        _ok(self, f"Đã cập nhật tên {args[2]}: {name_value}", data, threadId, type, userId)
        return

    # ── ln avatar 1|2 @mention ────────────────────────────────────────────────
    if len(args) >= 3 and args[1].lower() == "avatar":
        if args[2] not in ["1", "2"]:
            _err(self, "Dùng: ln avatar 1 @tên hoặc ln avatar 2 @tên", data, threadId, type, userId)
            return
        uids = extractUids(data)
        if not uids:
            _err(self, "Hãy tag (@) người cần lấy avatar.", data, threadId, type, userId)
            return
        key = "avatar1" if args[2] == "1" else "avatar2"
        love_data[key] = _get_avatar_url(self, uids[0])
        save_love_data(love_data)
        self.sendReaction(data, "✅", threadId, type, 100000000)
        _ok(self, f"Đã cập nhật avatar {args[2]}!", data, threadId, type, userId)
        return

    # ── ln days <ngày> <tháng> <năm> ─────────────────────────────────────────
    if len(args) == 5 and args[1].lower() == "days":
        try:
            date_obj = datetime.date(int(args[4]), int(args[3]), int(args[2]))
            love_data["date"] = date_obj.strftime("%d/%m/%Y")
            save_love_data(love_data)
            self.sendReaction(data, "✅", threadId, type, 100000000)
            _ok(self, f"Đã cập nhật ngày yêu: {love_data['date']}", data, threadId, type, userId)
        except Exception:
            _err(self, "Ngày không hợp lệ.", data, threadId, type, userId)
        return

    # ── ln remove <ngày> <tháng> <năm> ──────────────────────────────────────
    if len(args) == 5 and args[1].lower() == "remove":
        if not love_data.get("date"):
            _err(self, "Không có ngày yêu để xoá.", data, threadId, type, userId)
            return
        input_date = f"{args[2].zfill(2)}/{args[3].zfill(2)}/{args[4]}"
        if input_date != love_data.get("date"):
            _err(self, "Ngày nhập không khớp.", data, threadId, type, userId)
            return
        save_love_data({})
        self.sendReaction(data, "💔", threadId, type, 100000000)
        _ok(self, "Đã xoá ngày yêu thành công.", data, threadId, type, userId)
        return

    # ── Sai cú pháp ──────────────────────────────────────────────────────────
    p = self.prefix
    _err(self,
         f"Sai cú pháp lệnh ln\n\n"
         f"👉 {p}ln add <ngay> <thang> <nam> @nguoi\n"
         f"👉 {p}ln check\n"
         f"👉 {p}ln set <tiêu đề>\n"
         f"👉 {p}ln name 1 <tên>  |  ln name 2 <tên>\n"
         f"👉 {p}ln avatar 1 @tên  |  ln avatar 2 @tên\n"
         f"👉 {p}ln days <ngày> <tháng> <năm>\n"
         f"👉 {p}ln remove <ngày> <tháng> <năm>",
         data, threadId, type, userId)


dependencies = {
    "name":        "ln",
    "permission":  2,
    "cooldown":    0,
    "description": "Điếm ngày yêu – canvas ghép đôi",
    "main":        loveCommand,
}
