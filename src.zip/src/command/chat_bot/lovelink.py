"""
lovelink.py  –  Tạo link love (nqduan API) cho zbot
Đặt tại: src/command/chat_bot/lovelink.py

Cách dùng:
  !lovelink <text>                → tự chọn nhạc đầu tiên
  !lovelink <text> | <ma_nhac>   → chọn mã nhạc cụ thể
  !lovelink                      → xem danh sách mã nhạc
"""
from app.core.index import *
from app.module.commandLoader import removeMention

import re
import requests as _req

API_URL = "https://nqduan.id.vn/api/lovelink"
TIMEOUT = 30

def _fetch_lovelink(text, audio=None):
    params = {"text": text}
    if audio:
        params["audio"] = audio
    resp = _req.get(
        API_URL, params=params, timeout=TIMEOUT,
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"},
    )
    try:
        return resp.json()
    except Exception:
        return resp.text

def _pick_first_audio(available_audios):
    if not isinstance(available_audios, list) or not available_audios:
        return ""
    a = available_audios[0]
    return a.get("code") or a.get("id") or a.get("value") or ""

def _format_audio_list(available_audios, prefix, cmd, text_hint):
    if not isinstance(available_audios, list) or not available_audios:
        return ""
    lines = ["🎵 Danh sach ma nhac co san:\n"]
    for i, item in enumerate(available_audios, 1):
        name = item.get("name") or item.get("title") or f"Audio {i}"
        code = item.get("code") or item.get("id") or item.get("value") or ""
        lines.append(f"{i}. {name}" + (f" ({code})" if code else ""))
        if code:
            lines.append(f"   Su dung: {prefix}{cmd} {text_hint} {code}\n")
        else:
            lines.append("")
    return "\n".join(lines)

def _parse_args(raw_text):
    raw_text = raw_text.strip()
    if not raw_text:
        return "", ""
    if "|" in raw_text:
        parts = [p.strip() for p in raw_text.split("|", 1)]
        return parts[0], parts[1] if len(parts) > 1 else ""
    tokens = raw_text.split()
    if len(tokens) == 1:
        return tokens[0], ""
    return " ".join(tokens[:-1]), tokens[-1]

def LovelinkCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Dùng đúng signature: removeMention(self, data)
    raw = removeMention(self, Data)
    cmd_name = "lovelink"
    prefix   = getattr(self, "prefix", "!")
    raw = re.sub(rf"^{re.escape(prefix)}{cmd_name}\b", "", raw, flags=re.IGNORECASE).strip()

    def _reply(msg):
        self.sendMentionStyle(msg, UserId, ThreadId, ThreadType)

    if not raw:
        try:
            data = _fetch_lovelink("Hello")
            if isinstance(data, dict) and data.get("available_audios"):
                lst = _format_audio_list(data["available_audios"], prefix, cmd_name, "<text>")
                _reply(lst or "❌ Khong lay duoc danh sach nhac.")
                return
        except Exception as e:
            print(f"[Lovelink] fetch audio list error: {e}")
        _reply(
            f"❌ Vui long nhap noi dung text!\n"
            f"📝 Su dung: {prefix}{cmd_name} <text> [ma nhac]\n"
            f"💡 Go {prefix}{cmd_name} de xem danh sach ma nhac"
        )
        return

    text, audio = _parse_args(raw)
    if not text:
        _reply(f"❌ Vui long nhap noi dung text!\n📝 {prefix}{cmd_name} <text> [ma nhac]")
        return

    try:
        data = _fetch_lovelink(text, audio)
    except Exception as e:
        _reply(f"❌ Loi goi API lovelink: {e}")
        return

    if isinstance(data, str) and data.startswith("http"):
        _reply(f"💕 Link love da duoc tao!\n\n🔗 {data}")
        return

    if not isinstance(data, dict):
        _reply(f"💕 Ket qua:\n{data}")
        return

    if data.get("success") is False:
        avail = data.get("available_audios")
        if avail:
            if not audio:
                picked = _pick_first_audio(avail)
                if picked:
                    try:
                        retry = _fetch_lovelink(text, picked)
                    except Exception:
                        retry = {}
                    link = None
                    if isinstance(retry, dict):
                        link = retry.get("link") or retry.get("url")
                    elif isinstance(retry, str) and retry.startswith("http"):
                        link = retry
                    if link:
                        _reply(
                            f"💕 Link love da duoc tao!\n\n🔗 {link}\n\n"
                            f"🎵 (Tu chon ma nhac: {picked}. Doi nhac: {prefix}{cmd_name} {text} | <ma>)"
                        )
                        return
            lst = _format_audio_list(avail, prefix, cmd_name, text)
            msg = f"⚠️ {data.get('message','Ban chua chon ma nhac.')}\n\n"
            if data.get("instruction"):
                msg += f"{data['instruction']}\n\n"
            msg += lst or ""
            _reply(msg)
        else:
            _reply(f"❌ {data.get('message','Co loi xay ra')}")
        return

    if data.get("success") is True and data.get("link"):
        _reply(f"💕 Link love da duoc tao!\n\n🔗 {data['link']}")
        return

    if data.get("url"):
        _reply(f"💕 Link love da duoc tao!\n\n🔗 {data['url']}")
        return

    import json as _json
    _reply(f"💕 Ket qua:\n{_json.dumps(data, ensure_ascii=False)}")


dependencies = {
    "name":        "lovelink",
    "permission":  0,
    "cooldown":    5,
    "description": "Tao link love – !lovelink <text> [ma nhac]",
    "main":        LovelinkCommand,
}
