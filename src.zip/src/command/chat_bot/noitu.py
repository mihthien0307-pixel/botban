# -*- coding: utf-8 -*-
"""
noitu.py – Chơi nối từ với AI (SerpAPI Google Autocomplete).
Luật: tiếng ĐẦU của từ mới = tiếng CUỐI của từ trước.
"""

import time
import threading
import requests as _requests

from app.core.index import *
from src.services.utils.jsonio import load_json, save_json

SERP_API_KEY     = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
SERP_API_URL     = "https://serpapi.com/search.json"
LEADERBOARD_FILE = "data/config/noitu_leaderboard.json"
TIMEOUT_SEC      = 30

_games: dict = {}

def _lb_load(): return load_json(LEADERBOARD_FILE, default={})
def _lb_save(data): save_json(LEADERBOARD_FILE, data)

def _lb_add(self, uid, pts=1):
    lb = _lb_load()
    name = self.userName(uid) or uid
    if uid not in lb: lb[uid] = {"name": name, "points": 0}
    lb[uid]["points"] += pts
    lb[uid]["name"] = name
    _lb_save(lb)

def _end_game(threadId):
    g = _games.get(threadId)
    if g:
        t = g.get("timer")
        if t:
            try: t.cancel()
            except: pass
    _games.pop(threadId, None)

def _last_syl(w):
    parts = w.strip().split()
    return parts[-1] if parts else w

def _first_syl(w):
    parts = w.strip().split()
    return parts[0] if parts else w

def _norm(t): return t.strip().lower()

def _ai_next_word(last_word: str, used_words: set) -> str | None:
    end_syllable = _last_syl(last_word)
    try:
        params = {
            "engine":  "google_autocomplete",
            "q":       end_syllable + " ",   # dấu cách → gợi ý cụm 2 tiếng
            "hl":      "vi",
            "gl":      "vn",
            "api_key": SERP_API_KEY,
        }
        resp = _requests.get(SERP_API_URL, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        for s in data.get("suggestions", []):
            val = (s.get("value") or "").strip().lower()
            if not val:
                continue
            parts = val.split()
            # Lấy tối đa 2 tiếng đầu
            for length in (2, 1):
                if len(parts) < length:
                    continue
                candidate = " ".join(parts[:length])
                # Tiếng đầu phải = tiếng cuối của từ trước
                if _first_syl(candidate) != end_syllable:
                    continue
                if candidate == last_word:
                    continue
                if candidate in used_words:
                    continue
                # Không dạng "X X"
                cp = candidate.split()
                if len(cp) == 2 and cp[0] == cp[1]:
                    continue
                return candidate
    except Exception:
        pass
    return None

def _ai_respond(self, threadId, type, data, message_object, user_name, uid):
    if threadId not in _games or not _games[threadId]["active"]:
        return
    g = _games[threadId]
    last_word = g["last_word"]
    used = g["used_words"]
    next_word = _ai_next_word(last_word, used)
    if not next_word:
        self.replyMessageStyle(
            f"Tôi thua rồi 😢! Không tìm được từ nối sau '{last_word}'.\n"
            f"{user_name} thắng! Dùng {self.prefix}nt <từ> để chơi lại.",
            data, threadId, type, color="yl", title="NỐI TỪ"
        )
        _end_game(threadId)
        return
    g["used_words"].add(next_word)
    g["last_word"] = next_word
    g["timestamp"] = time.time()
    is_group = str(type) != "0"   # type "0" = chat riêng, khác = nhóm
    if is_group:
        self.replyMessageStyle(
            f"Từ nối ➜ {next_word}\nTrả lời bằng {self.prefix}nt <từ> trong {TIMEOUT_SEC}s.",
            data, threadId, type, color="gr", title="NỐI TỪ", userId=uid,
        )
    else:
        self.replyMessageStyle(
            f"Từ nối ➜ {next_word}\nTrả lời bằng {self.prefix}nt <từ> trong {TIMEOUT_SEC}s.",
            data, threadId, type, color="gr", title="NỐI TỪ",
        )
    def _timeout():
        if threadId in _games and _games[threadId]["active"]:
            self.sendMessage(Message(text=(
                f"⏰ Hết thời gian! {user_name} thua.\n"
                f"Trò chơi kết thúc. Dùng {self.prefix}nt <từ> để chơi lại."
            )), threadId, type)
            _end_game(threadId)
    t = threading.Timer(TIMEOUT_SEC, _timeout)
    g["timer"] = t
    t.start()

def NoidtuCommand(self, message, data, userId, threadId, type):
    text = (getattr(message, "text", "") or "").strip().split(maxsplit=1)
    if len(text) < 2 or not text[1].strip():
        self.sendWarning(f"Nhập từ để nối! Ví dụ: {self.prefix}nt cá mập", threadId, type, data)
        return
    user_word = _norm(text[1].strip())
    user_name = self.userName(userId) or userId

    if threadId not in _games or not _games[threadId]["active"]:
        _games[threadId] = {"used_words": {user_word}, "last_word": user_word,
                            "timestamp": time.time(), "active": True, "timer": None}
        _lb_add(self, userId)
        _ai_respond(self, threadId, type, data, None, user_name, userId)
        return

    g = _games[threadId]
    if g.get("timer"):
        try: g["timer"].cancel()
        except: pass
        g["timer"] = None

    last_word = g["last_word"]
    end_syllable = _last_syl(last_word)
    used = g["used_words"]

    if _first_syl(user_word) != end_syllable:
        self.replyMessageStyle(
            f"Sai rồi! '{user_word}' phải bắt đầu bằng '{end_syllable}'.\n"
            f"Trò chơi kết thúc. Dùng {self.prefix}nt <từ> để chơi lại.",
            data, threadId, type, color="r", title="NỐI TỪ"
        )
        _end_game(threadId)
        return

    if user_word in used:
        self.replyMessageStyle(
            f"Từ '{user_word}' đã được dùng rồi!\nTrò chơi kết thúc. Dùng {self.prefix}nt <từ> để chơi lại.",
            data, threadId, type, color="r", title="NỐI TỪ"
        )
        _end_game(threadId)
        return

    parts = user_word.split()
    if len(parts) == 2 and parts[0] == parts[1]:
        self.replyMessageStyle(
            f"Từ '{user_word}' trùng lặp không hợp lệ!\nTrò chơi kết thúc. Dùng {self.prefix}nt <từ> để chơi lại.",
            data, threadId, type, color="r", title="NỐI TỪ"
        )
        _end_game(threadId)
        return

    g["used_words"].add(user_word)
    g["last_word"] = user_word
    g["timestamp"] = time.time()
    _lb_add(self, userId)
    _ai_respond(self, threadId, type, data, None, user_name, userId)

def BxhntCommand(self, message, data, userId, threadId, type):
    lb = _lb_load()
    if not lb:
        self.sendInfo("Bảng xếp hạng hiện trống!", threadId, type, data)
        return
    top = sorted(lb.items(), key=lambda x: x[1]["points"], reverse=True)[:10]
    medals = ["🥇","🥈","🥉"]
    lines = ["🏆 Bảng xếp hạng Nối Từ 🏆"]
    for i, (_, info) in enumerate(top):
        icon = medals[i] if i < 3 else f"{i+1}."
        lines.append(f"{icon} {info['name']}: {info['points']} điểm")
    self.sendInfo("\n".join(lines), threadId, type, data)

def ResetbxhCommand(self, message, data, userId, threadId, type):
    _lb_save({})
    self.sendSuccess("Đã reset bảng xếp hạng nối từ!", threadId, type, data)

dependencies = {
    "name": "nt", "description": "Chơi nối từ với AI (SerpAPI)",
    "permission": 0, "cooldown": 2, "alias": ["noitu"],
    "noPrefix": False, "is_main": False, "main": NoidtuCommand,
}
dependencies_bxh = {
    "name": "bxhnt", "description": "Bảng xếp hạng nối từ",
    "permission": 0, "cooldown": 5, "alias": ["bxh_nt"],
    "noPrefix": False, "is_main": False, "main": BxhntCommand,
}
dependencies_reset = {
    "name": "resetbxh", "description": "Reset bảng xếp hạng nối từ",
    "permission": 2, "cooldown": 0, "alias": [],
    "noPrefix": False, "is_main": False, "main": ResetbxhCommand,
}
