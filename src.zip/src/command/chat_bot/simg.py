"""
src/command/chat_bot/simg.py

Lệnh simg — Reply vào 1 STK (ảnh) → bot tag mention người dùng + SUCCESS + gửi lại ảnh đó.

Cách dùng:
  Reply vào một tin nhắn có ảnh, rồi gõ: ,simg
"""

from app.core.index import *
import json, os, time, threading, requests, re
from io import BytesIO

CACHE_DIR = "data/assets/cache/image"


def _get_image_url_from_quote(data) -> str | None:
    """Lấy URL ảnh từ tin nhắn được quote."""
    try:
        quote = getattr(data, "quote", None)
        if not quote:
            return None

        # Lấy raw attach string
        raw = getattr(quote, "attach", None)
        if not raw:
            return None

        attach = raw if isinstance(raw, dict) else json.loads(raw)

        # Thử lấy hdUrl → href → params webp/jpg
        url = (
            attach.get("hdUrl")
            or attach.get("href")
            or (attach.get("params") or {}).get("url")
            or None
        )
        if url:
            # Giải mã ký tự escape nếu có
            url = url.replace("\\/", "/")
            import urllib.parse
            url = urllib.parse.unquote(url)
            # Ưu tiên jpg thay jxl
            url = url.replace("/jxl", "/jpg").replace(".jxl", ".jpg")
        return url or None
    except Exception:
        return None


def _download_image(url: str) -> tuple[bytes, str] | None:
    """Tải ảnh từ URL, trả về (bytes, ext)."""
    try:
        r = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        r.raise_for_status()
        content_type = r.headers.get("Content-Type", "image/jpeg")
        ext = "jpg"
        if "png" in content_type:
            ext = "png"
        elif "webp" in content_type:
            ext = "webp"
        elif "gif" in content_type:
            ext = "gif"
        return r.content, ext
    except Exception:
        return None


def simgCommand(self, message, data, userId, threadId, type):
    # ── Kiểm tra có quote không ───────────────────────────────────────────────
    quote = getattr(data, "quote", None)
    if not quote:
        return self.replyMessageStyle(
            "Reply vào 1 tin nhắn có ảnh (STK) rồi dùng lệnh này nhé!",
            data, threadId, type,
            color="yl", title="SIMG", userId=userId,
        )

    image_url = _get_image_url_from_quote(data)
    if not image_url:
        return self.replyMessageStyle(
            "Không lấy được link ảnh từ tin nhắn được reply. Hãy reply vào 1 ảnh!",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

    # ── Lấy tên người dùng ───────────────────────────────────────────────────
    name = self.userName(userId) or str(userId)

    # ── Gửi reaction loading ──────────────────────────────────────────────────
    self.sendReaction(data, "/-flag", threadId, type, 100000000)

    # ── Xử lý trên thread riêng ───────────────────────────────────────────────
    def _do():
        out_path = None
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)

            # Tải ảnh về
            result = _download_image(image_url)
            if not result:
                self.sendReaction(data, "", threadId, type, -1)
                return self.replyMessageStyle(
                    "Không tải được ảnh từ link. Ảnh có thể đã hết hạn.",
                    data, threadId, type,
                    color="r", title="ERROR", userId=userId,
                )

            img_bytes, ext = result
            out_path = os.path.join(
                CACHE_DIR,
                f"simg_{self.uid}_{userId}_{int(time.time())}.{ext}",
            )
            with open(out_path, "wb") as f:
                f.write(img_bytes)

            # ── Bước 1: Gửi text riêng — SUCCESS + nội dung (tên/@mention do replyMessageStyle tự xử lý) ──
            self.replyMessageStyle(
                "Đây là hình ảnh bạn yêu cầu!",
                data, threadId, type,
                color="gr", title="SUCCESS",
                userId=userId,
            )

            # ── Bước 2: Gửi ảnh riêng (không kèm caption) ────────────────────
            self.sendLocalImage(
                out_path, threadId, type,
                width=2560, height=2560,
            )
            self.sendReaction(data, "/-ok", threadId, type, 100000000)

        except Exception as e:
            logger.errorw(f"[simg] error: {e}")
            self.sendReaction(data, "", threadId, type, -1)
            self.replyMessageStyle(
                f"Lỗi xử lý ảnh: {e}",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        finally:
            if out_path and os.path.isfile(out_path):
                try:
                    os.remove(out_path)
                except Exception:
                    pass

    threading.Thread(target=_do, daemon=True).start()


dependencies = {
    "name":        "simg",
    "permission":  0,
    "cooldown":    3,
    "description": "Reply vào ảnh (STK)",
    "main":        simgCommand,
}
