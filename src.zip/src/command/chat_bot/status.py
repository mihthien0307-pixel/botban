"""
src/command/chat_bot/status.py

Lệnh ,status [text]
- Gửi "@tên /-flag\nloading..." ngay lập tức
- Vẽ ảnh → gửi ảnh
- Xóa tin nhắn loading

Cache avatar URL theo uid để tránh gọi API lặp lại.
"""

from app.core.index import *
from src.services.pillow.drawStatusCard import draw_status_card
import os, time, threading, re

CACHE_DIR    = "data/assets/cache/image"

# ── Avatar URL cache ──────────────────────────────────────────────────────────
# Format: { uid_str: (avatar_url_or_None, timestamp) }
_avatar_cache: dict = {}
_AVATAR_CACHE_TTL   = 600          # 10 phút — tự động làm mới
_avatar_cache_lock  = threading.Lock()


def _get_avatar_url(self, uid):
    uid_str = str(uid)
    now     = time.time()

    # Kiểm tra cache trước
    with _avatar_cache_lock:
        entry = _avatar_cache.get(uid_str)
        if entry is not None:
            cached_url, cached_ts = entry
            if now - cached_ts < _AVATAR_CACHE_TTL:
                return cached_url          # Cache còn hạn → dùng luôn

    # Cache hết hạn hoặc chưa có → gọi API
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        av       = profile.get("avatar") or profile.get("avatarUrl") or ""
        if av:
            av = re.sub(r"[?&]w=\d+", "", av)
        result = av if av else None
    except Exception:
        result = None

    # Lưu vào cache
    with _avatar_cache_lock:
        _avatar_cache[uid_str] = (result, now)

    return result


def _delete_msg(self, msg_obj, thread_id):
    """Xóa tin nhắn loading."""
    if not msg_obj:
        return
    mid = getattr(msg_obj, "msgId",   None)
    cid = getattr(msg_obj, "clientId", None)
    if not (mid and cid):
        return
    try:
        self.deleteMessage(mid, self.uid, cid, thread_id)
    except Exception:
        pass


def statusCommand(self, message, data, userId, threadId, type):
    text_raw    = (getattr(message, "text", None) or "").strip()
    parts       = text_raw.split(None, 1)
    status_text = parts[1].strip() if len(parts) > 1 else ""

    # ── Không có nội dung → hướng dẫn ────────────────────────────────────────
    if not status_text:
        p = self.prefix
        c = self.rawCommand
        return self.replyMessageStyle(
            f"Tạo ảnh status cá nhân.\n\n"
            f"Cách dùng:\n"
            f"  {p}{c} [nội dung status]\n\n"
            f"Ví dụ:\n"
            f"  {p}{c} hi\n"
            f"  {p}{c} Đang bận học bài\n"
            f"  {p}{c} Chill thôi ☕",
            data, threadId, type,
            color="or", title="STATUS", userId=userId,
        )

    # ── Gửi loading mention ngay lập tức ─────────────────────────────────────
    name        = self.userName(userId)
    loading_msg = self.sendMentionStyle(
        f"⏳ Đang tạo ảnh status...",
        userId,
        threadId,
        type,
    )
    self.sendReaction(data, "/-flag", threadId, type, 100000000)

    # ── Chạy vẽ + gửi ảnh trên thread riêng ─────────────────────────────────
    def _do():
        avatar_url = _get_avatar_url(self, userId)   # Dùng cache
        os.makedirs(CACHE_DIR, exist_ok=True)
        out_path = os.path.join(
            CACHE_DIR,
            f"status_{self.uid}_{userId}_{int(time.time())}.jpg",
        )

        try:
            w, h = draw_status_card(
                status_text=status_text,
                user_name=name,
                avatar_url=avatar_url,
                out_path=out_path,
            )
        except Exception as e:
            _delete_msg(self, loading_msg, threadId)
            self.sendReaction(data, "", threadId, type, -1)
            logger.errorw(f"[status] draw error: {e}")
            return self.replyMessageStyle(
                f"Không tạo được ảnh: {e}", data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

        # Xóa loading TRƯỚC khi gửi ảnh
        _delete_msg(self, loading_msg, threadId)

        try:
            mention = Mention(userId, offset=0, length=len(name))
            caption = Message(text=name, mention=mention)
            self.sendLocalImage(out_path, threadId, type, width=w, height=h, message=caption)
            self.sendReaction(data, "👌", threadId, type, 100000000)
        except Exception as e:
            logger.errorw(f"[status] send error: {e}")
            self.replyMessageStyle(
                f"Lỗi gửi ảnh: {e}", data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        finally:
            try:
                os.remove(out_path)
            except Exception:
                pass

    threading.Thread(target=_do, daemon=True).start()


dependencies = {
    "name":        "status",
    "permission":  0,
    "description": "Tạo ảnh status cá nhân với nền tối gradient.",
    "cooldown":    5,
    "alias":       ["st"],
    "main":        statusCommand,
}
