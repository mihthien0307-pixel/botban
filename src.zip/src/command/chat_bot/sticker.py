from app.core.index import *
from src.services.pillow.stickerCore import (
    MaxStickerSize, GetMediaWh,
    CreateStickerUrl,
)
from PIL import Image, ImageDraw
from io import BytesIO
import os, urllib, json, requests


# ─── Pixel art helpers ────────────────────────────────────────────────────────

def _apply_pixel_effect(img: Image.Image, pixel_size: int) -> Image.Image:
    """Thu nhỏ rồi phóng to NEAREST → tạo khối vuông pixel rõ ràng."""
    img = img.convert("RGBA")
    ow, oh  = img.size
    small   = img.resize((max(1, ow // pixel_size), max(1, oh // pixel_size)), Image.BOX)
    return small.resize((ow, oh), Image.NEAREST)

def _apply_dot_grid(img: Image.Image, pixel_size: int, dot_ratio: float = 0.75) -> Image.Image:
    """Overlay lưới chấm tròn halftone lên ảnh đã pixelate, nền trắng."""
    w, h = img.size
    result = Image.new("RGBA", (w, h), (255, 255, 255, 255))
    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    r    = int(pixel_size * dot_ratio / 2)
    for y in range(0, h, pixel_size):
        for x in range(0, w, pixel_size):
            cx, cy = x + pixel_size // 2, y + pixel_size // 2
            draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
    result.paste(img.convert("RGBA"), (0, 0), mask)
    return result

def _apply_pixel_grid(img: Image.Image, pixel_size: int, line_color=(180, 180, 180, 180), line_width=1) -> Image.Image:
    """Overlay lưới đường kẻ ô vuông lên ảnh đã pixelate (giống màn hình LED/pixel art grid).
    Nền giữ nguyên ảnh gốc, chỉ vẽ đường kẻ lên trên.
    """
    img = img.convert("RGBA")
    w, h = img.size
    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    # Vẽ đường dọc
    for x in range(0, w, pixel_size):
        draw.line([(x, 0), (x, h)], fill=line_color, width=line_width)
    # Vẽ đường ngang
    for y in range(0, h, pixel_size):
        draw.line([(0, y), (w, y)], fill=line_color, width=line_width)
    return Image.alpha_composite(img, overlay)

def _make_pixel_sticker(imageUrl: str, outputPath: str, pixel_size: int, dot: bool):
    """Tải ảnh, áp pixel art (+ lưới ô vuông nếu dot bật), lưu WebP."""
    resp = requests.get(imageUrl, headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
    resp.raise_for_status()
    img = Image.open(BytesIO(resp.content)).convert("RGBA")

    # Giới hạn kích thước
    w, h = img.size
    if max(w, h) > MaxStickerSize:
        s   = MaxStickerSize / max(w, h)
        img = img.resize((max(1, int(w * s)), max(1, int(h * s))), Image.LANCZOS)

    out = _apply_pixel_effect(img, pixel_size)
    if dot:
        out = _apply_pixel_grid(out, pixel_size)

    # Dùng absolute path để tránh lỗi khi bot chạy từ thư mục khác
    absPath = os.path.abspath(outputPath)
    os.makedirs(os.path.dirname(absPath), exist_ok=True)
    out.save(absPath, "WEBP", quality=95, method=6)


# ─── Command ──────────────────────────────────────────────────────────────────

def StickerCommand(self, message, data, userId, threadId, type):
    p   = self.prefix
    c   = self.commandName
    cmd = f"{p}{c}"

    Help = (
        f"Quote ảnh/video để tạo sticker.\n"
        f"Args:\n"
        f"  {cmd} sqr           — sticker vuông\n"
        f"  {cmd} spin          — sticker xoay\n"
        f"  {cmd} [1-100]       — bo góc theo phần trăm\n"
        f"  {cmd} -scale=0.5    — thu nhỏ ảnh trong khung (0.5–1.0)\n"
        f"  {cmd} pixel         — hiệu ứng pixel art (size 8)\n"
        f"  {cmd} pixel [4-32]  — pixel art với ô tùy chỉnh\n"
        f"  {cmd} pixel dot     — pixel art + lưới ô vuông (pixel grid)\n"
        f"  {cmd} pixel dot 10  — kết hợp size + dot"
    )

    spin          = False
    sqr           = False
    pixel         = False
    dot           = False
    radiusPercent = 0
    scaleFactor   = 1.0
    pixelSize     = 8
    sqrDefaultR   = 20
    fps           = 30
    scale         = MaxStickerSize
    seconds       = 30
    q             = 95
    spinFps       = 60
    spinSeconds   = 6

    tokens = (message.text or "").split()
    for part in tokens[1:]:
        pl = part.lower()
        if pl == "spin":
            spin = True
            radiusPercent = 100
            continue
        if pl == "sqr":
            sqr = True
            continue
        if pl == "pixel":
            pixel = True
            continue
        if pl == "dot":
            dot = True
            continue
        if pl.startswith("-scale=") or pl.startswith("scale="):
            try:
                v = float(pl.split("=", 1)[1])
                if v > 1.0:
                    v = v / 100.0
                if 0.5 <= v <= 1.0:
                    scaleFactor = v
            except Exception:
                pass
            continue
        if pl.isdigit():
            v = int(pl)
            if pixel and 4 <= v <= 32:
                pixelSize = v
            elif 1 <= v <= 100:
                radiusPercent = v
            continue

    if sqr:
        if radiusPercent == 100:
            radiusPercent = 0
        if radiusPercent == 0:
            radiusPercent = sqrDefaultR

    if not data.quote:
        return self.replyMessageStyle(
            Help, data, threadId, type,
            color="yl", title="STICKER", userId=userId,
        )

    outputPath = "data/assets/cache/sticker/sticker.webp"
    os.makedirs(os.path.abspath("data/assets/cache/sticker"), exist_ok=True)

    try:
        attach   = json.loads(data.quote.attach)
        imageUrl = attach.get("hdUrl") or attach.get("href")
        if not imageUrl:
            return self.replyMessageStyle(
                "Không lấy được link ảnh từ tin nhắn được quote.",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

        imageUrl = urllib.parse.unquote(imageUrl.replace("\\/", "/"))
        imageUrl = imageUrl.replace("/jxl", "/jpg").replace(".jxl", ".jpg")

        if pixel:
            _make_pixel_sticker(imageUrl, outputPath, pixelSize, True)
        else:
            CreateStickerUrl(
                imageUrl, outputPath,
                maxSize=MaxStickerSize,
                radiusPercent=radiusPercent,
                spin=spin,
                fps=fps, scale=scale, seconds=seconds, q=q,
                spinFps=spinFps, spinSeconds=spinSeconds,
                sqr=sqr, scaleFactor=scaleFactor,
            )

        uploadId = self._state.user_id
        r   = self._uploadAttachment(outputPath, uploadId, ThreadType.USER)
        url = r["fileUrl"] + f"?HAT={self.userName(self.uid).replace(' ', '-')}.webp"
        w, h = GetMediaWh(outputPath)
        self.sendCustomSticker(
            staticImgUrl=url, animationImgUrl=url,
            threadId=threadId, threadType=type,
            width=w, height=h, ttl=3600000, ai=True,
        )

    except Exception as e:
        logger.errorw(f"sticker error: {e}")
        self.replyMessageStyle(
            f"Tạo sticker thất bại: {e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
    finally:
        try: os.remove(os.path.abspath(outputPath))
        except Exception: pass


dependencies = {
    "name":        "sticker",
    "alias":       ["stk"],
    "permission":  0,
    "cooldown":    3,
    "description": "Create Sticker",
    "main":        StickerCommand,
}
