"""
src/command/chat_bot/truyentranh.py
Tìm & đọc truyện tranh – NetTruyen + MangaDex fallback.

Cách dùng:
  ,tt <tên truyện>     → tìm kiếm, hiển thị canvas danh sách
  reply số (1–10)      → gửi bìa + link truyện, xóa ảnh list, chỉ reply 1 lần
  ,tt help             → hướng dẫn
"""

from app.core.index import *
from app.module.commandLoader import removeMention
from src.services.pillow.drawMangaList import draw_manga_list

import os
import re
import time
import uuid
import threading
import requests

# ════════════════════════════════════════════════════════════════════════════
# Config
# ════════════════════════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
CACHE_DIR    = "data/assets/cache/manga"
SESSION_TTL  = 120
MAX_RESULTS  = 10

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


# ════════════════════════════════════════════════════════════════════════════
# Helpers gửi tin
# ════════════════════════════════════════════════════════════════════════════
def _err(ctx, msg, data, threadId, type, userId=None):
    ctx.replyMessageStyle(msg, data, threadId, type,
                          color="r", title="LỖI", userId=userId)

def _info(ctx, msg, data, threadId, type, userId=None):
    ctx.replyMessageStyle(msg, data, threadId, type,
                          color="or", title="TRUYỆN TRANH", userId=userId)


# ════════════════════════════════════════════════════════════════════════════
# API tìm kiếm
# ════════════════════════════════════════════════════════════════════════════

def _search_nettruyen(keyword: str) -> list[dict]:
    """NetTruyen API – VN, không bị block DNS."""
    try:
        r = requests.get(
            "https://otruyenapi.com/v1/api/tim-kiem",
            params={"keyword": keyword, "limit": MAX_RESULTS},
            timeout=8,
            headers=HEADERS,
        )
        r.raise_for_status()
        data  = r.json()
        items = (data.get("data") or {}).get("items") or []
        results = []
        for m in items:
            slug      = m.get("slug", "")
            thumb_url = m.get("thumb_url", "")
            if thumb_url and not thumb_url.startswith("http"):
                thumb_url = f"https://img.otruyenapi.com/uploads/comics/{thumb_url}"
            results.append({
                "title":  m.get("name") or (m.get("origin_name") or ["?"])[0],
                "author": ", ".join(m.get("author") or []),
                "status": {"ongoing": "Đang tiến hành", "completed": "Hoàn thành"}.get(
                              m.get("status", ""), m.get("status", "")),
                "genres": ", ".join(g.get("name", "") for g in (m.get("category") or [])[:4]),
                "thumb":  thumb_url,
                "url":    f"https://www.google.com/search?q={requests.utils.quote(m.get('name', slug))}+đọc+truyện+tranh+online",
            })
        return results
    except Exception as e:
        logger.errorw(f"[tt] NetTruyen error: {e}")
        return []


def _search_mangadex(keyword: str) -> list[dict]:
    """MangaDex – fallback nếu NetTruyen lỗi."""
    try:
        r = requests.get(
            "https://api.mangadex.org/manga",
            params={
                "title":              keyword,
                "limit":              MAX_RESULTS,
                "order[relevance]":   "desc",
                "includes[]":         ["cover_art", "author"],
                "availableTranslatedLanguage[]": ["vi", "en"],
            },
            timeout=8,
            headers=HEADERS,
        )
        r.raise_for_status()
        results = []
        for manga in r.json().get("data", []):
            mid   = manga.get("id", "")
            attrs = manga.get("attributes", {})
            titles = attrs.get("title", {})
            title  = titles.get("vi") or titles.get("en") or next(iter(titles.values()), "?")
            author = ""
            thumb_url = ""
            for rel in manga.get("relationships", []):
                rtype  = rel.get("type", "")
                rattrs = rel.get("attributes") or {}
                if rtype == "author" and not author:
                    author = rattrs.get("name", "")
                if rtype == "cover_art" and not thumb_url:
                    fname = rattrs.get("fileName", "")
                    if fname:
                        thumb_url = f"https://uploads.mangadex.org/covers/{mid}/{fname}.256.jpg"
            status_map = {"ongoing": "Đang tiến hành", "completed": "Hoàn thành",
                          "hiatus": "Tạm ngưng", "cancelled": "Đã huỷ"}
            status = status_map.get(attrs.get("status", ""), attrs.get("status", ""))
            genres = ", ".join(
                (t.get("attributes", {}).get("name", {}).get("en", "") or
                 next(iter(t.get("attributes", {}).get("name", {}).values()), ""))
                for t in attrs.get("tags", [])[:4]
            )
            results.append({
                "title": title, "author": author, "status": status,
                "genres": genres, "thumb": thumb_url,
                "url": f"https://mangadex.org/title/{mid}",
            })
        return results
    except Exception as e:
        logger.errorw(f"[tt] MangaDex error: {e}")
        return []


def _search_serpapi(keyword: str) -> list[dict]:
    """Fallback cuối: SerpAPI."""
    try:
        r = requests.get(
            "https://serpapi.com/search.json",
            params={"engine": "google_autocomplete", "q": f"{keyword} truyện tranh",
                    "api_key": SERP_API_KEY, "gl": "vn", "hl": "vi"},
            timeout=8, headers=HEADERS,
        )
        r.raise_for_status()
        results = []
        for s in r.json().get("suggestions", []):
            val   = s.get("value", "")
            clean = re.sub(r"(truyện tranh|manga|online|đọc|full|chap|chapter|tập).*",
                           "", val, flags=re.IGNORECASE).strip().strip("-").strip()
            if not clean:
                continue
            results.append({
                "title": clean, "author": "", "status": "", "genres": "", "thumb": "",
                "url": f"https://mangadex.org/search?q={requests.utils.quote(clean)}",
            })
            if len(results) >= MAX_RESULTS:
                break
        return results
    except Exception as e:
        logger.errorw(f"[tt] SerpAPI error: {e}")
        return []


def _search(keyword: str) -> list[dict]:
    results = _search_nettruyen(keyword)
    if not results:
        results = _search_mangadex(keyword)
    if not results:
        results = _search_serpapi(keyword)
    return results


# ════════════════════════════════════════════════════════════════════════════
# Session
# ════════════════════════════════════════════════════════════════════════════
class MangaSession:
    __slots__ = ("items", "keyword", "time", "msgId", "cliMsgId", "threadId", "typeGr")

    def __init__(self, items, keyword, msgId, cliMsgId, threadId, typeGr):
        self.items    = items
        self.keyword  = keyword
        self.time     = time.time()
        self.msgId    = msgId
        self.cliMsgId = cliMsgId
        self.threadId = threadId
        self.typeGr   = typeGr

    def is_expired(self) -> bool:
        return time.time() - self.time > SESSION_TTL


# ════════════════════════════════════════════════════════════════════════════
# Countdown reaction (như Zing)
# ════════════════════════════════════════════════════════════════════════════
def _start_countdown(ctx, MsgObj, ThreadId, ThreadType, uid):
    """Đếm ngược 120s lên ảnh list, tự xóa khi hết hạn."""
    if not hasattr(ctx, "_mangaCooldown"):
        ctx._mangaCooldown = {}

    key = str(getattr(MsgObj, "msgId", uid))
    ctx._mangaCooldown[key] = True

    msg = MessageObject(
        msgId    = getattr(MsgObj, "msgId",    None),
        cliMsgId = getattr(MsgObj, "clientId", None),
        msgType  = "webchat",
    )

    def _loop():
        for i in range(SESSION_TTL, 0, -1):
            if not ctx._mangaCooldown.get(key):
                break
            try:
                ctx.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
                time.sleep(1)
                ctx.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
            except Exception:
                break
        ctx._mangaCooldown.pop(key, None)
        # Hết giờ → xóa ảnh list (không gửi text thông báo)
        try:
            if getattr(MsgObj, "msgId", None) and getattr(MsgObj, "clientId", None):
                ctx.deleteMessage(MsgObj.msgId, ctx.uid, MsgObj.clientId, ThreadId)
        except Exception:
            pass

    threading.Thread(target=_loop, daemon=True).start()
    return key


# ════════════════════════════════════════════════════════════════════════════
# Handler chính
# ════════════════════════════════════════════════════════════════════════════
class MangaHandler:

    HELP = (
        "📚 TRUYỆN TRANH\n\n"
        "  {p}truyentranh <tên truyện>  – tìm kiếm truyện\n"
        "  Reply số 1–10       – xem chi tiết & link đọc\n\n"
        "Ví dụ:\n"
        "  {p}truyentranh doremon\n"
        "  {p}truyentranh naruto\n"
        "  {p}truyentranh one piece\n"
    )

    def __init__(self, ctx, MsgObj, Data, UserId, ThreadId, ThreadType):
        self.ctx        = ctx
        self.MsgObj     = MsgObj
        self.Data       = Data
        self.UserId     = str(UserId)
        self.ThreadId   = ThreadId
        self.ThreadType = ThreadType
        self.prefix     = getattr(ctx, "prefix", ",")
        self.cmd        = f"{self.prefix}truyentranh"

    def run(self):
        text  = (getattr(self.MsgObj, "text", None) or "").strip()
        parts = text.split(None, 1)
        body  = parts[1].strip() if len(parts) >= 2 else ""

        if not body or body.lower() == "help":
            return _info(self.ctx, self.HELP.format(p=self.prefix),
                         self.Data, self.ThreadId, self.ThreadType, self.UserId)

        self._do_search(body)

    def _do_search(self, keyword: str):
        self.ctx.sendReaction(self.Data, "🔍", self.ThreadId, self.ThreadType, 100000000)

        items = _search(keyword)

        if not items:
            self.ctx.sendReaction(self.Data, "😕", self.ThreadId, self.ThreadType, 100000000)
            return _err(
                self.ctx,
                f"Không tìm thấy truyện nào cho «{keyword}».\nThử tên khác nhé!",
                self.Data, self.ThreadId, self.ThreadType, self.UserId,
            )

        if not hasattr(self.ctx, "mangaStates"):
            self.ctx.mangaStates = {}

        def _canvas_thread():
            out_path = None
            try:
                os.makedirs(CACHE_DIR, exist_ok=True)
                out_path = os.path.join(CACHE_DIR, f"{uuid.uuid4().hex}.png")
                draw_manga_list(keyword=keyword, items=items, out_path=out_path)

                from PIL import Image as _Img
                with _Img.open(out_path) as im:
                    img_w, img_h = im.size

                caption = (
                    f"📚 Tìm thấy {len(items)} truyện cho «{keyword}»\n"
                    f"Reply số 1–{min(len(items), MAX_RESULTS)} để đọc  •  {SESSION_TTL}s"
                )

                res     = self.ctx._uploadImage(out_path, self.ThreadId, self.ThreadType)
                img_url = None
                if isinstance(res, dict):
                    img_url = res.get("normalUrl") or res.get("hdUrl")
                elif isinstance(res, str) and res.startswith("http"):
                    img_url = res

                SentMsg = None
                if img_url:
                    SentMsg = self.ctx.sendRemoteImage(
                        img_url, self.ThreadId, self.ThreadType,
                        width=img_w, height=img_h,
                        message=Message(text=caption),
                    )
                else:
                    SentMsg = self.ctx.sendLocalImage(
                        out_path, self.ThreadId, self.ThreadType,
                        width=img_w, height=img_h,
                    )
                    _info(self.ctx, caption,
                          self.Data, self.ThreadId, self.ThreadType, self.UserId)

                # Lưu session
                self.ctx.mangaStates[self.UserId] = MangaSession(
                    items    = items,
                    keyword  = keyword,
                    msgId    = getattr(SentMsg, "msgId",    None),
                    cliMsgId = getattr(SentMsg, "clientId", None),
                    threadId = self.ThreadId,
                    typeGr   = self.ThreadType,
                )

                # Bắt đầu đếm ngược
                if SentMsg:
                    _start_countdown(self.ctx, SentMsg, self.ThreadId, self.ThreadType, self.UserId)

            except Exception as e:
                logger.errorw(f"[tt] canvas error: {e}")
                lines = "\n".join(f"{i+1}. {it['title']}" for i, it in enumerate(items[:MAX_RESULTS]))
                _info(self.ctx, f"📚 «{keyword}» – {len(items)} kết quả:\n{lines}\n\nReply số để đọc.",
                      self.Data, self.ThreadId, self.ThreadType, self.UserId)
                self.ctx.mangaStates[self.UserId] = MangaSession(
                    items=items, keyword=keyword,
                    msgId=None, cliMsgId=None,
                    threadId=self.ThreadId, typeGr=self.ThreadType,
                )
            finally:
                if out_path and os.path.exists(out_path):
                    try:
                        os.remove(out_path)
                    except Exception:
                        pass

        threading.Thread(target=_canvas_thread, daemon=True).start()


# ════════════════════════════════════════════════════════════════════════════
# Gửi truyện được chọn
# ════════════════════════════════════════════════════════════════════════════
def _deliver_manga(ctx, session: MangaSession, idx: int,
                   Data, ThreadId, ThreadType, UserId):
    """Gửi 1 truyện, xóa ảnh list, xóa session."""
    def _send():
        try:
            item   = session.items[idx]
            title  = item.get("title", "?")
            url    = item.get("url", "")
            thumb  = item.get("thumb", "")
            author = item.get("author", "")
            status = item.get("status", "")
            genres = item.get("genres", "")

            parts = [f"📖 {title}"]
            if author: parts.append(f"✍ {author}")
            if status: parts.append(f"📌 {status}")
            if genres: parts.append(f"🏷 {genres}")
            parts.append(f"🔗 {url}")
            caption = "\n".join(parts)

            if thumb and thumb.startswith("http"):
                try:
                    ctx.sendRemoteImage(
                        thumb, ThreadId, ThreadType,
                        width=256, height=360,
                        message=Message(text=caption),
                    )
                except Exception:
                    _info(ctx, caption, Data, ThreadId, ThreadType, UserId)
            else:
                _info(ctx, caption, Data, ThreadId, ThreadType, UserId)

        except Exception as e:
            logger.errorw(f"[tt] deliver error idx={idx}: {e}")

        # Xóa ảnh list sau khi gửi xong (như Zing xóa list nhạc)
        try:
            if session.msgId and session.cliMsgId:
                ctx.deleteMessage(session.msgId, ctx.uid, session.cliMsgId, ThreadId)
        except Exception:
            pass

        # Dừng countdown
        try:
            key = str(session.msgId)
            if hasattr(ctx, "_mangaCooldown"):
                ctx._mangaCooldown.pop(key, None)
        except Exception:
            pass

    threading.Thread(target=_send, daemon=True).start()


# ════════════════════════════════════════════════════════════════════════════
# Entry points
# ════════════════════════════════════════════════════════════════════════════
def TruyenTranhCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    MangaHandler(self, MessageObj, Data, UserId, ThreadId, ThreadType).run()


def TruyenTranhReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    uid     = str(UserId)
    states  = getattr(self, "mangaStates", {})
    session = states.get(uid)

    is_reply = Data.quote or getattr(Data, "reference", None)
    if not session or not is_reply:
        return

    if session.is_expired():
        states.pop(uid, None)
        return _err(self, "Session đã hết hạn. Tìm lại nhé!",
                    Data, ThreadId, ThreadType, uid)

    # Lấy text từ nhiều field vì Zalo reply ảnh để text vào content
    raw = (
        getattr(MessageObj, "text", None)
        or getattr(MessageObj, "content", None)
        or (getattr(Data, "content", None) if isinstance(getattr(Data, "content", None), str) else None)
        or ""
    ).strip()
    raw = re.sub(r"@\S+", "", raw).strip()

    if not raw:
        return

    # Parse số đầu tiên hợp lệ (chỉ cho phép 1 truyện mỗi lần)
    idx = None
    for part in re.split(r"[,\s]+", raw):
        part = part.strip()
        if part.isdigit():
            n = int(part) - 1
            total = min(len(session.items), MAX_RESULTS)
            if 0 <= n < total:
                idx = n
                break

    if idx is None:
        total = min(len(session.items), MAX_RESULTS)
        _info(self, f"⚠️ Nhập số từ 1 đến {total}.", Data, ThreadId, ThreadType, uid)
        return

    # Xóa session ngay → chỉ reply được 1 lần
    states.pop(uid, None)

    self.sendReaction(Data, "📖", ThreadId, ThreadType, 100000000)
    _deliver_manga(self, session, idx, Data, ThreadId, ThreadType, uid)


def InitTimeoutManga(self, Interval: int = 5):
    """Dọn session hết hạn định kỳ."""
    def _loop():
        while True:
            for uid, session in list(getattr(self, "mangaStates", {}).items()):
                if session.is_expired():
                    self.mangaStates.pop(uid, None)
            time.sleep(Interval)
    threading.Thread(target=_loop, daemon=True).start()


# ════════════════════════════════════════════════════════════════════════════
dependencies = {
    "name":        "truyentranh",
    "permission":  0,
    "cooldown":    5,
    "description": "Tìm & đọc truyện tranh – NetTruyen canvas + reply chọn",
    "main":        TruyenTranhCommand,
}
