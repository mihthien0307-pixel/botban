from app.core.index import *
import requests, re, unicodedata

# ═══════════════════════════════════════════════════════════
# SerpAPI
# ═══════════════════════════════════════════════════════════
SERP_API_KEY = "29db9d57b0f479f1ee974d512ecb4fbe9027f77ae953b939230217ec41091907"
SERP_API_URL = "https://serpapi.com/search.json"

# ═══════════════════════════════════════════════════════════
# Data tướng hardcode
# format: (tên, tier, vị trí, win_rate, pick_rate, ban_rate)
# ═══════════════════════════════════════════════════════════
CHAMPIONS_RAW = [
    # S Tier
    ("Biron",         "S", "top",     "50.43%", "6.21%",  "0.25%"),
    ("Thane",         "S", "support", "50.97%", "5.88%",  "0.08%"),
    ("Mina",          "S", "support", "52.04%", "7.47%",  "0.17%"),
    ("Butterfly",     "S", "jungle",  "47.35%", "13.68%", "0.22%"),
    ("Toro",          "S", "support", "48.04%", "19.39%", "0.54%"),
    ("Nakroth",       "S", "jungle",  "50.42%", "33.69%", "2.24%"),
    ("Maloch",        "S", "top",     "50.36%", "7.96%",  "0.09%"),
    ("Ignis",         "S", "mid",     "49.98%", "3.22%",  "0.02%"),
    ("Astrid",        "S", "top",     "53.7%",  "0.9%",   "0.01%"),
    ("Wonder Woman",  "S", "top",     "55.72%", "1.63%",  "0.01%"),
    ("TeeMee",        "S", "support", "51.23%", "2.78%",  "3.49%"),
    ("Tulen",         "S", "mid",     "50.98%", "15.04%", "0.11%"),
    ("Liliana",       "S", "mid",     "49.32%", "13.99%", "0.11%"),
    ("Richter",       "S", "top",     "48.2%",  "7.06%",  "0.04%"),
    ("Sephera",       "S", "support", "51.29%", "2.26%",  "0.03%"),
    ("Florentino",    "S", "top",     "50.86%", "17.39%", "5.54%"),
    ("Hayate",        "S", "adc",     "48.61%", "24.22%", "0.46%"),
    ("Capheny",       "S", "adc",     "49.74%", "10.8%",  "0.06%"),
    ("Celica",        "S", "adc",     "48.96%", "1.22%",  "0.01%"),
    ("Vol'kath",      "S", "jungle",  "51.15%", "5.55%",  "0.12%"),
    ("Eland'orr",     "S", "jungle",  "48.27%", "2.08%",  "0.04%"),
    ("Keera",         "S", "jungle",  "49.77%", "5.45%",  "0.07%"),
    ("Paine",         "S", "jungle",  "52.33%", "3.33%",  "0.1%"),
    ("Zata",          "S", "mid",     "50.59%", "6.19%",  "1.05%"),
    ("Allain",        "S", "top",     "46.76%", "22.88%", "0.54%"),
    ("Lorion",        "S", "mid",     "50.48%", "1.27%",  "0.02%"),
    ("Bright",        "S", "jungle",  "49.95%", "5.17%",  "0.04%"),
    ("Iggy",          "S", "mid",     "50.58%", "4.4%",   "0.04%"),
    ("Aoi",           "S", "jungle",  "52.78%", "6.69%",  "1.28%"),
    ("Aya",           "S", "support", "48.54%", "10.93%", "36.27%"),
    ("Teeri",         "S", "adc",     "53.13%", "6.13%",  "0.03%"),
    ("Bonnie",        "S", "mid",     "50.59%", "2.04%",  "0.03%"),
    ("Ming",          "S", "support", "52.65%", "2.51%",  "0.2%"),
    ("Erin",          "S", "adc",     "49.65%", "3.46%",  "0.07%"),
    ("Tachi",         "S", "top",     "48.92%", "0.9%",   "0.01%"),
    ("Charlotte",     "S", "top",     "47.6%",  "1.78%",  "0.02%"),
    ("Dolia",         "S", "support", "50.41%", "5.34%",  "2.69%"),
    ("Billow",        "S", "jungle",  "49.88%", "25.41%", "8.78%"),
    # A Tier
    ("Airi",          "A", "top",     "49.52%", "6.48%",  "0.03%"),
    ("Lữ Bố",         "A", "top",     "49.46%", "3.91%",  "0.03%"),
    ("Krixi",         "A", "mid",     "49.86%", "23.21%", "0.17%"),
    ("Triệu Vân",     "A", "jungle",  "51.4%",  "28.95%", "0.33%"),
    ("Kahlii",        "A", "mid",     "49.23%", "5.25%",  "0.07%"),
    ("Zephys",        "A", "jungle",  "49.07%", "3.03%",  "0.01%"),
    ("Điêu Thuyền",   "A", "mid",     "51.3%",  "5.57%",  "0.23%"),
    ("Chaugnar",      "A", "support", "54.12%", "3.41%",  "0.37%"),
    ("Violet",        "A", "adc",     "50.7%",  "34.67%", "0.13%"),
    ("Ormarr",        "A", "support", "52.17%", "1.98%",  "0.02%"),
    ("Azzen'Ka",      "A", "mid",     "50.36%", "4.62%",  "0.06%"),
    ("Alice",         "A", "support", "48.85%", "13.94%", "0.66%"),
    ("Gildur",        "A", "top",     "50.87%", "20.3%",  "0.77%"),
    ("Grakk",         "A", "support", "50.71%", "11.58%", "36.98%"),
    ("Aleister",      "A", "mid",     "51.82%", "5.53%",  "34.71%"),
    ("Fennik",        "A", "jungle",  "52.11%", "10.42%", "0.15%"),
    ("Helen",         "A", "support", "48.89%", "2.57%",  "0.69%"),
    ("Ngộ Không",     "A", "jungle",  "48.03%", "18.01%", "3.98%"),
    ("Kriknak",       "A", "jungle",  "48.85%", "3.26%",  "0.02%"),
    ("Arthur",        "A", "top",     "47.06%", "9.12%",  "0.03%"),
    ("Slimz",         "A", "adc",     "51.25%", "7.4%",   "0.03%"),
    ("Ilumia",        "A", "mid",     "52.87%", "4.76%",  "0.05%"),
    ("Raz",           "A", "mid",     "48.81%", "22.9%",  "0.77%"),
    ("Lauriel",       "A", "mid",     "50.83%", "10.39%", "0.48%"),
    ("Kaine",         "A", "jungle",  "50.58%", "6.9%",   "7.03%"),
    ("Murad",         "A", "jungle",  "50.36%", "17%",    "2.94%"),
    ("Zill",          "A", "jungle",  "49.35%", "5.74%",  "0.03%"),
    ("Arduin",        "A", "top",     "51.01%", "5.16%",  "0.02%"),
    ("Stuart",        "A", "adc",     "51.02%", "12.58%", "0.67%"),
    ("Ryoma",         "A", "top",     "50.92%", "10.75%", "0.08%"),
    ("Tel'Annas",     "A", "adc",     "49.54%", "22.19%", "0.15%"),
    ("Superman",      "A", "top",     "49.42%", "0.53%",  "0.03%"),
    ("Xeniel",        "A", "support", "50.68%", "1.89%",  "0.03%"),
    ("Kil'Groth",     "A", "top",     "48.38%", "2.87%",  "0.05%"),
    ("Moren",         "A", "adc",     "53.1%",  "0.69%",  "0.02%"),
    ("Omen",          "A", "top",     "48.61%", "6.65%",  "0.07%"),
    ("The Flash",     "A", "mid",     "49.46%", "1.27%",  "0.04%"),
    ("Rourke",        "A", "jungle",  "53.61%", "1.21%",  "0.02%"),
    ("Roxie",         "A", "top",     "47.95%", "0.26%",  "0.01%"),
    ("Baldum",        "A", "support", "49.09%", "3.06%",  "0.06%"),
    ("Amily",         "A", "top",     "47.71%", "3.57%",  "0.02%"),
    ("Y'bneth",       "A", "support", "52.92%", "6.15%",  "0.22%"),
    ("Elsu",          "A", "adc",     "50.24%", "16.7%",  "32.21%"),
    ("Quillen",       "A", "jungle",  "47.63%", "4.07%",  "0.1%"),
    ("Veres",         "A", "top",     "50.25%", "6.67%",  "0.03%"),
    ("D'Arcy",        "A", "mid",     "50.63%", "2%",     "0.02%"),
    ("Yena",          "A", "top",     "49.28%", "10%",    "0.03%"),
    ("Zip",           "A", "support", "52.65%", "2.93%",  "5.25%"),
    ("Krizzix",       "A", "support", "51.73%", "1.33%",  "0.07%"),
    ("Ishar",         "A", "mid",     "48.24%", "6.47%",  "0.3%"),
    ("Ata",           "A", "top",     "48.64%", "0.42%",  "0.01%"),
    ("Laville",       "A", "adc",     "49.36%", "5.97%",  "0.02%"),
    ("Sinestrea",     "A", "jungle",  "50.51%", "1.42%",  "0.01%"),
    ("Dextra",        "A", "top",     "49.66%", "0.33%",  "0.01%"),
    ("Yan",           "A", "jungle",  "47.06%", "4.87%",  "0.05%"),
    ("Yue",           "A", "mid",     "49.36%", "11.93%", "0.87%"),
    ("Bijan",         "A", "top",     "50.09%", "14.04%", "0.82%"),
    ("Qi",            "A", "top",     "52.54%", "3.33%",  "0.02%"),
    ("Dirak",         "A", "mid",     "53.41%", "6.91%",  "0.2%"),
    ("Bolt Baron",    "A", "top",     "56.66%", "12.89%", "3.52%"),
    ("Flowborn",      "A", "adc",     "52.5%",  "0.89%",  "0.25%"),
    ("Goverra",       "A", "mid",     "52.3%",  "0.65%",  "0.05%"),
    # B Tier
    ("Valhein",       "B", "adc",     "48.88%", "40.05%", "2.7%"),
    ("Veera",         "B", "mid",     "50.09%", "28.55%", "7.33%"),
    ("Mganga",        "B", "mid",     "47.82%", "4.46%",  "0.07%"),
    ("Omega",         "B", "support", "51.42%", "1.01%",  "0.02%"),
    ("Yorn",          "B", "adc",     "48.77%", "10.43%", "0.1%"),
    ("Lumburr",       "B", "support", "53.32%", "3.05%",  "0.03%"),
    ("Natalya",       "B", "mid",     "48.44%", "31.38%", "1.28%"),
    ("Jinna",         "B", "mid",     "49.69%", "0.44%",  "0.02%"),
    ("Zuka",          "B", "top",     "47.98%", "15.5%",  "0.06%"),
    ("Lindis",        "B", "jungle",  "48.35%", "1.37%",  "0.02%"),
    ("Wisp",          "B", "adc",     "53.9%",  "0.95%",  "0.01%"),
    ("Marja",         "B", "top",     "54.1%",  "8.85%",  "4.2%"),
    ("Enzo",          "B", "jungle",  "52.59%", "11.91%", "11.41%"),
    ("Rouie",         "B", "support", "49.04%", "5.59%",  "3.62%"),
    ("Skud",          "B", "top",     "49.0%",  "5.0%",   "0.1%"),
    ("Arum",          "B", "support", "50.0%",  "8.0%",   "0.5%"),
    ("Errol",         "B", "top",     "49.5%",  "4.0%",   "0.05%"),
]

ROLE_VI = {
    "top":     "Trên",
    "jungle":  "Đi Rừng",
    "mid":     "Giữa",
    "adc":     "Dưới",
    "support": "Hỗ Trợ",
}

TIER_EMOJI = {
    "S": "🔴",
    "A": "🟠",
    "B": "🟡",
    "C": "🟢",
    "D": "⚪",
}

CHAMPIONS = [
    {
        "name":  n, "tier": t, "role": r,
        "wr":    wr, "pr": pr, "ban_r": ban,
        "url":   "https://lienquanmobile.gg/champions/{}/build/{}/".format(
            n.lower().replace(' ', '-').replace("'", ''), r
        ),
    }
    for n, t, r, wr, pr, ban in CHAMPIONS_RAW
]

_seen = set()
_dedup = []
for _c in CHAMPIONS:
    if _c["name"] not in _seen:
        _seen.add(_c["name"])
        _dedup.append(_c)
CHAMPIONS = _dedup


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _norm(s):
    return unicodedata.normalize("NFKD", s.lower()).encode("ascii", "ignore").decode()

def _search_champ(query):
    q = _norm(query)
    exact   = [c for c in CHAMPIONS if _norm(c["name"]) == q]
    partial = [c for c in CHAMPIONS if q in _norm(c["name"])]
    return exact or partial


# ═══════════════════════════════════════════════════════════
# SerpAPI – top tướng
# ═══════════════════════════════════════════════════════════

ROLE_QUERY = {
    "top":     "tướng đi đường trên",
    "jungle":  "tướng đi rừng",
    "mid":     "tướng đi đường giữa",
    "adc":     "tướng đi đường dưới",
    "support": "tướng hỗ trợ",
}

def _serp_top_champs(role):
    query_suffix = ROLE_QUERY.get(role, "tướng mạnh nhất") if role else "tướng mạnh nhất"
    q = f"top {query_suffix} liên quân mobile"
    try:
        resp = requests.get(
            SERP_API_URL,
            params={"engine": "google_autocomplete", "q": q,
                    "api_key": SERP_API_KEY, "hl": "vi", "gl": "vn"},
            timeout=8,
        )
        suggestions = resp.json().get("suggestions", [])
        names = []
        for s in suggestions:
            val = s.get("value", "")
            for c in CHAMPIONS:
                if _norm(c["name"]) in _norm(val) and c["name"] not in names:
                    if role is None or c["role"] == role:
                        names.append(c["name"])
        return names
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════
# Sub commands
# ═══════════════════════════════════════════════════════════

def _cmd_search(this, query, data, threadId, type):
    results = _search_champ(query)
    if not results:
        return this.replyMessageStyle(
            f"Không tìm thấy tướng '{query}'.\nThử: .tuong nakroth",
            data, threadId, type, color="yl", title="KHÔNG TÌM THẤY"
        )
    if len(results) == 1:
        c = results[0]
        tier_e  = TIER_EMOJI.get(c["tier"], "⚫")
        role_vi = ROLE_VI.get(c["role"], c["role"])
        text = (
            f"⚔️  {c['name']}\n{'─'*28}\n"
            f"{tier_e} Tier: {c['tier']}\n"
            f"🎯 Vị trí: {role_vi}\n"
            f"📈 Win rate: {c['wr']}\n"
            f"🔥 Pick rate: {c['pr']}\n"
            f"🚫 Ban rate: {c['ban_r']}\n"
            f"🔗 {c['url']}"
        )
        return this.replyMessageStyle(text, data, threadId, type, color="or", title="THÔNG TIN TƯỚNG")

    lines = [f"🔍 Tìm thấy {len(results)} tướng:\n"]
    for i, c in enumerate(results[:12], 1):
        e = TIER_EMOJI.get(c["tier"], "⚫")
        lines.append(f"  {i}. {e} {c['name']} — {ROLE_VI.get(c['role'], c['role'])} — WR: {c['wr']}")
    this.replyMessageStyle("\n".join(lines), data, threadId, type, color="or", title="KẾT QUẢ")


def _cmd_list(this, tier_filter, data, threadId, type):
    from collections import defaultdict
    champs = CHAMPIONS
    if tier_filter:
        tier_filter = tier_filter.upper()
        if tier_filter not in TIER_EMOJI:
            return this.replyMessageStyle(
                "Tier không hợp lệ! Chọn: S, A, B",
                data, threadId, type, color="yl", title="WARNING"
            )
        champs = [c for c in champs if c["tier"] == tier_filter]
    by_tier = defaultdict(list)
    for c in champs:
        by_tier[c["tier"]].append(c["name"])
    lines = [f"⚔️ Danh sách tướng ({len(champs)} tướng):\n"]
    for t in ["S", "A", "B", "C", "D"]:
        if t in by_tier:
            e = TIER_EMOJI[t]
            lines.append(f"{e} Tier {t} ({len(by_tier[t])}): {', '.join(by_tier[t])}")
    this.replyMessageStyle("\n\n".join(lines), data, threadId, type, color="or", title="LIÊN QUÂN TƯỚNG")


def _cmd_top(this, role_raw, data, threadId, type):
    role_map = {
        "tren": "top", "top": "top",
        "rung": "jungle", "jungle": "jungle", "di rung": "jungle",
        "giua": "mid", "mid": "mid",
        "duoi": "adc", "adc": "adc",
        "htro": "support", "support": "support", "ho tro": "support",
    }
    role_filter = role_map.get(_norm(role_raw)) if role_raw else None
    if role_raw and not role_filter:
        return this.replyMessageStyle(
            "Vị trí không hợp lệ!\nChọn: top, rung, mid, adc, support",
            data, threadId, type, color="yl", title="WARNING"
        )

    def parse_pct(s):
        try: return float(s.replace("%", ""))
        except: return 0.0

    serp_names = _serp_top_champs(role_filter)
    if serp_names:
        ordered = []
        for sn in serp_names:
            found = [c for c in CHAMPIONS if _norm(c["name"]) == _norm(sn)]
            if found: ordered.append(found[0])
        seen_names = {c["name"] for c in ordered}
        pool = [c for c in CHAMPIONS if (role_filter is None or c["role"] == role_filter)]
        pool.sort(key=lambda c: parse_pct(c["wr"]), reverse=True)
        for c in pool:
            if c["name"] not in seen_names: ordered.append(c)
        top_list = ordered[:10]
        src_note = "📡 (Google + local)"
    else:
        pool = [c for c in CHAMPIONS if (role_filter is None or c["role"] == role_filter)]
        pool.sort(key=lambda c: parse_pct(c["wr"]), reverse=True)
        top_list = pool[:10]
        src_note = "📊 (local data)"

    title_role = ROLE_VI.get(role_filter, "Tất Cả") if role_filter else "Tất Cả"
    lines = [f"🏆 Top tướng — {title_role} {src_note}:\n"]
    for i, c in enumerate(top_list, 1):
        e = TIER_EMOJI.get(c["tier"], "⚫")
        lines.append(f"  {i}. {e} {c['name']} ({ROLE_VI.get(c['role'], c['role'])}) — WR: {c['wr']} | Pick: {c['pr']}")
    this.replyMessageStyle("\n".join(lines), data, threadId, type, color="or", title="TOP TƯỚNG")


# ═══════════════════════════════════════════════════════════
# Help & Main
# ═══════════════════════════════════════════════════════════

def _help(p, c):
    return (
        f"╔══ LIÊN QUÂN TƯỚNG ══╗\n\n"
        f"  ⚔️  {p}{c} <tên>         - Thông tin tướng\n"
        f"  📋 {p}{c} ds [tier]     - Danh sách (S/A/B)\n"
        f"  🏆 {p}{c} top [vị trí]  - Top theo đường\n\n"
        f"╚═════════════════════╝\n"
        f"VD: {p}{c} murad\n"
        f"    {p}{c} ds S\n"
        f"    {p}{c} top rung"
    )


def tuongCommand(this, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split()
    p = getattr(this, "prefix", "")
    c = getattr(this, "rawCommand", "tuong")

    if len(parts) < 2:
        return this.replyMessageStyle(_help(p, c), data, threadId, type, color="or", title="LIÊN QUÂN")

    sub = parts[1].lower().strip()

    if sub in ("ds", "list"):
        return _cmd_list(this, parts[2] if len(parts) >= 3 else None, data, threadId, type)
    if sub == "top":
        return _cmd_top(this, " ".join(parts[2:]) if len(parts) >= 3 else None, data, threadId, type)

    query = " ".join(parts[1:])
    _cmd_search(this, query, data, threadId, type)


dependencies = {
    "name":        "tuong",
    "permission":  0,
    "cooldown":    3,
    "description": "Tra cứu tướng Liên Quân Mobile (tier, WR, top, danh sách...)",
    "main":        tuongCommand,
}
