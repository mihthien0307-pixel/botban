"""
baucua.py  –  Minigame Bầu Cua Tôm Cá cho zbot
Đặt tại: src/command/games/baucua.py

Cách dùng:
  !baucua bau 10k          → đặt bầu 10 000
  !baucua cua 50k:tom 20k  → đặt nhiều loại (ngăn cách bằng :)
  !baucua bau all          → all-in vào bầu
  !baucua                  → xem hướng dẫn

Đơn vị: k = *1000 | m = *1000000 | b = *1000000000 | % = % số dư
Số dư mỗi user lưu tại data/config/baucua/wallet_<uid>.json
Jackpot toàn server lưu tại data/config/baucua/jackpot.json
"""
from app.core.index import *
from app.module.commandLoader import removeMention
import os, json, random, time, threading

# ── Try import draw card ──────────────────────────────────────────────────────
try:
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location(
        "drawBauCuaCard",
        os.path.join(os.path.dirname(__file__),
                     "..", "..", "services", "pillow", "drawBauCuaCard.py"),
    )
    _mod = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
    make_baucua_result_image = _mod.make_baucua_result_image
    _PILLOW_OK = True
except Exception as _e:
    _PILLOW_OK = False
    print(f"[BauCua] drawBauCuaCard load fail: {_e}")

# ── Hằng số ───────────────────────────────────────────────────────────────────
SYMBOLS = {
    "bau":  {"emoji": "🍐", "name": "Bầu"},
    "cua":  {"emoji": "🦀", "name": "Cua"},
    "tom":  {"emoji": "🦞", "name": "Tôm"},
    "ca":   {"emoji": "🐟", "name": "Cá"},
    "ga":   {"emoji": "🐓", "name": "Gà"},
    "nai":  {"emoji": "🦌", "name": "Nai"},
}
SYMBOL_KEYS  = list(SYMBOLS.keys())
ALIASES: dict[str, str] = {
    # tiếng việt / viết tắt → key
    "bầu":  "bau", "b":    "bau",
    "cua":  "cua", "c":    "cua", "🦀": "cua",
    "tôm":  "tom", "tom":  "tom", "t": "tom", "🦞": "tom",
    "cá":   "ca",  "ca":   "ca",  "🐟": "ca",
    "gà":   "ga",  "ga":   "ga",  "g": "ga",  "🐓": "ga",
    "nai":  "nai", "n":    "nai", "🦌": "nai",
    "🍐":   "bau",
}

JACKPOT_CONTRIB     = 0.6         # % tiền thua góp vào hũ
MAX_JACKPOT_MULT    = 1000        # jackpot tối đa = 1000× tiền cược
MIN_BET             = 1_000       # cược tối thiểu
INIT_BALANCE        = 500_000     # số dư khởi điểm
INIT_JACKPOT        = 1_000_000

DATA_DIR    = "data/config/baucua"
JACKPOT_FILE = os.path.join(DATA_DIR, "jackpot.json")
_lock = threading.Lock()

os.makedirs(DATA_DIR, exist_ok=True)

# ── Wallet helpers ────────────────────────────────────────────────────────────
def _wallet_path(uid: str) -> str:
    return os.path.join(DATA_DIR, f"wallet_{uid}.json")

def _get_balance(uid: str) -> int:
    try:
        with open(_wallet_path(uid), "r", encoding="utf-8") as f:
            return int(json.load(f).get("balance", INIT_BALANCE))
    except Exception:
        return INIT_BALANCE

def _set_balance(uid: str, amount: int):
    with _lock:
        try:
            with open(_wallet_path(uid), "w", encoding="utf-8") as f:
                json.dump({"balance": max(0, amount)}, f)
        except Exception:
            pass

def _get_jackpot() -> int:
    try:
        with open(JACKPOT_FILE, "r", encoding="utf-8") as f:
            return int(json.load(f).get("jackpot", INIT_JACKPOT))
    except Exception:
        return INIT_JACKPOT

def _set_jackpot(amount: int):
    with _lock:
        try:
            with open(JACKPOT_FILE, "w", encoding="utf-8") as f:
                json.dump({"jackpot": max(INIT_JACKPOT, amount)}, f)
        except Exception:
            pass

# ── Parse helpers ─────────────────────────────────────────────────────────────
def _parse_amount(raw: str, balance: int) -> int | None:
    """Trả về số nguyên (VNĐ) hoặc None nếu không hợp lệ. 'all'/'allin' → balance."""
    raw = raw.lower().strip()
    if raw in ("all", "allin", "allIn"):
        return balance
    try:
        if raw.endswith("%"):
            pct = float(raw[:-1])
            return int(balance * pct / 100)
        if raw.endswith("b"):
            return int(float(raw[:-1]) * 1_000_000_000)
        if raw.endswith("m"):
            return int(float(raw[:-1]) * 1_000_000)
        if raw.endswith("k"):
            return int(float(raw[:-1]) * 1_000)
        return int(raw)
    except Exception:
        return None

def _normalize_key(raw: str) -> str | None:
    raw = raw.lower().strip()
    if raw in SYMBOLS:
        return raw
    return ALIASES.get(raw)

def _parse_bets(content: str, balance: int) -> dict[str, int] | str:
    """
    Trả về dict {key: amount} hoặc string lỗi.
    Format: "bau 10k:cua 20k" hoặc "bau10k cua20k"
    """
    import re
    bets: dict[str, int] = {}
    allin_keys: list[str] = []

    # tách theo `:` hoặc khoảng trắng lớn
    # mỗi phần phải là:  <symbol><space?><amount>
    parts = [p.strip() for p in re.split(r"[,;:|]+", content) if p.strip()]
    # fallback: nếu chỉ 1 phần không có dấu phân cách, thử split khoảng trắng
    if len(parts) == 1:
        tokens = content.strip().split()
        if len(tokens) >= 2 and len(tokens) % 2 == 0:
            parts = [f"{tokens[i]} {tokens[i+1]}" for i in range(0, len(tokens), 2)]

    remaining = balance
    for part in parts:
        # cho phép dính nhau: "bau10k"
        m = re.match(r"^([a-zàáâãèéêìíòóôõùúýăđơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỷỹ🍐🦀🦞🐟🐓🦌]+)\s*(.+)$", part, re.UNICODE)
        if not m:
            continue
        sym_raw, amt_raw = m.group(1), m.group(2)
        key = _normalize_key(sym_raw)
        if key is None:
            return f"Không nhận ra loại '{sym_raw}'. Dùng: bau/cua/tom/ca/ga/nai"
        if amt_raw.lower() in ("all", "allin"):
            allin_keys.append(key)
            continue
        amt = _parse_amount(amt_raw, balance)
        if amt is None or amt <= 0:
            return f"Số tiền cược không hợp lệ: '{amt_raw}'"
        if amt > remaining:
            return f"Số dư không đủ (còn {_fmt(remaining)} VNĐ)"
        bets[key] = bets.get(key, 0) + amt
        remaining -= amt

    # xử lý all-in keys chia đều số dư còn lại
    if allin_keys:
        if remaining <= 0:
            return "Số dư không đủ để all-in"
        each = remaining // len(allin_keys)
        leftover = remaining - each * len(allin_keys)
        for i, key in enumerate(allin_keys):
            add = each + (leftover if i == 0 else 0)
            bets[key] = bets.get(key, 0) + add

    return bets

# ── Game logic ────────────────────────────────────────────────────────────────
def _roll() -> list[str]:
    return [random.choice(SYMBOL_KEYS) for _ in range(3)]

def _calc_winnings(bets: dict[str, int], result: list[str]) -> int:
    total = 0
    for key, amt in bets.items():
        count = result.count(key)
        if count:
            total += int(amt * (1 + 0.95 * count))
    return total

def _fmt(n: int) -> str:
    return f"{n:,}".replace(",", ".")

def _is_jackpot(result: list[str]) -> bool:
    return result[0] == result[1] == result[2]

# ── Gui anh ket qua ──────────────────────────────────────────────────────────
def _send_result(self, result, caption, thread_id, thread_type, uid, name):
    img_path = None
    if _PILLOW_OK:
        try:
            img_path = make_baucua_result_image(result)
        except Exception as e:
            print(f"[BauCua] draw error: {e}")

    # Nhom -> mention @ten (length tinh ca ky tu @)
    # Chat rieng -> khong mention, bo @ khoi caption
    from api.util.Enum import ThreadType as _TT
    is_group = (thread_type == _TT.GROUP)
    if is_group:
        mention = Mention(str(uid), length=len(name) + 1, offset=0)
        def _msg(): return Message(text=caption, mention=mention)
    else:
        # Bot @ khoi dong dau
        clean_caption = caption.replace(f"@{name}", name, 1)
        def _msg(): return Message(text=clean_caption)

    if img_path and os.path.exists(img_path):
        try:
            from PIL import Image as _PI
            with _PI.open(img_path) as im:
                w, h = im.size
            res = self._uploadImage(img_path, thread_id, thread_type)
            img_url = None
            if isinstance(res, dict):
                img_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                img_url = res
            if img_url:
                self.sendRemoteImage(
                    img_url, thread_id, thread_type,
                    width=w, height=h,
                    message=_msg(),
                )
                return
        except Exception as e:
            print(f"[BauCua] upload error: {e}")
        finally:
            try:
                if img_path and os.path.exists(img_path):
                    os.remove(img_path)
            except Exception:
                pass

    self.send(_msg(), thread_id, thread_type)

# ── Command main ──────────────────────────────────────────────────────────────
def _help_text(p):
    return (
        f"🎲  BẦU CUA TÔM CÁ\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Cú pháp: {p}baucua <loại> <tiền>[:<loại> <tiền>...]\n\n"
        f"Loại cược:\n"
        f"  bau 🍐 | cua 🦀 | tom 🦞\n"
        f"  ca 🐟  | ga 🐓  | nai 🦌\n\n"
        f"Đơn vị: k=ngàn | m=triệu | b=tỷ | % | all\n\n"
        f"Ví dụ:\n"
        f"  {p}baucua bau 50k\n"
        f"  {p}baucua cua 10k:tom 20k\n"
        f"  {p}baucua ga all\n\n"
        f"Lệnh khác:\n"
        f"  {p}baucua soduhotui   → xem số dư\n"
        f"  {p}baucua hu          → xem jackpot"
    )

def bauCuaCommand(self, message, data, userId, threadId, type):
    uid     = str(getattr(data, "uidFrom", userId) or userId)
    name    = str(getattr(data, "dName", "") or "Bạn")
    thread_id   = threadId
    thread_type = type
    p = getattr(self, "prefix", ".")
    content_raw = removeMention(self, data).strip()

    # Bỏ prefix + lệnh (dùng prefix thực tế từ config)
    import re
    p_esc = re.escape(p)
    content = re.sub(rf"^{p_esc}baucua\s*", "", content_raw, flags=re.IGNORECASE).strip()

    def reply(text: str):
        self.send(Message(text=text), thread_id, thread_type)

    # Subcommand: số dư
    if content.lower() in ("soduhotui", "sodu", "sd", "balance", "wallet"):
        bal = _get_balance(uid)
        reply(f"💰 Số dư của {name}: {_fmt(bal)} VNĐ")
        return

    # Subcommand: jackpot
    if content.lower() in ("hu", "hũ", "jackpot", "jp"):
        jp = _get_jackpot()
        reply(f"🏆 Jackpot hiện tại: {_fmt(jp)} VNĐ")
        return

    # Không có tham số → help
    if not content:
        reply(_help_text(p))
        return

    # Lấy số dư
    balance = _get_balance(uid)

    # Parse bets
    bets_or_err = _parse_bets(content, balance)
    if isinstance(bets_or_err, str):
        reply(f"❌ {bets_or_err}\n\nGõ {p}baucua để xem hướng dẫn.")
        return
    bets: dict[str, int] = bets_or_err

    if not bets:
        reply(_help_text(p))
        return

    total_bet = sum(bets.values())
    if total_bet < MIN_BET:
        reply(f"❌ Cược tối thiểu {_fmt(MIN_BET)} VNĐ.")
        return
    if total_bet > balance:
        reply(f"❌ Số dư không đủ. Bạn có {_fmt(balance)} VNĐ.")
        return

    # Lăn xúc xắc
    result = _roll()
    winnings = _calc_winnings(bets, result)
    net = winnings - total_bet

    jackpot = _get_jackpot()

    # Đóng góp hũ nếu thua
    if net < 0:
        contrib = int(abs(net) * JACKPOT_CONTRIB)
        jackpot += contrib

    # Kiểm tra nổ hũ (3 mặt giống nhau)
    jackpot_win = 0
    is_jp = _is_jackpot(result)
    if is_jp:
        max_jp = total_bet * MAX_JACKPOT_MULT
        jackpot_win = min(jackpot, max_jp)
        jackpot = max(INIT_JACKPOT, jackpot - jackpot_win)
        net += jackpot_win

    # Cập nhật số dư
    new_balance = balance + net
    _set_balance(uid, new_balance)
    _set_jackpot(jackpot)

    # Emoji kết quả 3 xúc xắc
    result_emojis = "  ".join(SYMBOLS[k]["emoji"] for k in result)

    # Build caption
    lines = [
        f"@{name} đã đặt cược:",
    ]
    for key, amt in bets.items():
        s = SYMBOLS[key]
        won = result.count(key) > 0
        lines.append(f"  {s['emoji']} {s['name']}: {_fmt(amt)} VNĐ {'✅' if won else '❌'}")

    lines.append(f"\n🎲 Kết quả: {result_emojis}")
    lines.append(f"💵 Tổng thắng: {_fmt(winnings)} VNĐ")

    if is_jp:
        lines.append(f"\n🎉🎉 NỔ HŨ! +{_fmt(jackpot_win)} VNĐ 🎉🎉")

    if net >= 0:
        lines.append(f"📈 Lợi nhuận: +{_fmt(net)} VNĐ")
    else:
        lines.append(f"📉 Thua lỗ: {_fmt(net)} VNĐ")

    if not is_jp:
        lines.append(f"🏺 Hũ hiện tại: {_fmt(jackpot)} VNĐ")

    lines.append(f"\n💼 Số dư: {_fmt(balance)} → {_fmt(new_balance)} VNĐ")
    caption = "\n".join(lines)

    _send_result(self, result, caption, thread_id, thread_type, uid, name)


dependencies = {
    "name":        "baucua",
    "permission":  0,
    "cooldown":    2,
    "description": "Minigame Bầu Cua Tôm Cá – đặt cược và quay xúc xắc",
    "main":        bauCuaCommand,
}
