"""
boibai.py  –  Bói bài Tarot mỗi ngày cho zbot
Đặt tại: src/command/games/boibai.py  (hoặc chat_bot/)

Cách dùng:
  !boibai           → bói cho bản thân
  !boibai @user     → bói cho người được tag

Mỗi user chỉ được xem 1 lần/ngày, kết quả được lưu vào
data/config/boibai/daily.json và gửi kèm ảnh canvas (Pillow).
"""
from app.core.index import *
from app.module.commandLoader import removeMention

import os, json, random, time
from datetime import datetime
from pathlib import Path

# ── Pillow canvas ──────────────────────────────────────────────────────────────
try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    from io import BytesIO
    import requests as _req
    _PILLOW_OK = True
except Exception as _e:
    _PILLOW_OK = False
    print(f"[BoiBai] Pillow load fail: {_e}")

# ── Dữ liệu bài ──────────────────────────────────────────────────────────────
SUITS_DATA = {
    "Co":     {"icon": "Co", "element": "Nuoc (Cam xuc)", "theme": "Tinh yeu, Hanh phuc, Gia dinh, Truc giac, Su chua lanh",
               "keywords": ["Lang man", "Ket noi", "Binh yen", "Thau hieu", "Cam thong", "Nghe thuat"]},
    "Ro":     {"icon": "Ro", "element": "Dat (Vat chat)",  "theme": "Tien bac, Tai san, Su nghiep, Thuc te, Su on dinh",
               "keywords": ["Dau tu", "Loi nhuan", "Thang tien", "Vung chac", "Quyen luc", "Dia vi"]},
    "Chuon":  {"icon": "Chuon", "element": "Lua (Hanh dong)", "theme": "Sang tao, Cong viec, Tham vong, May man, Su no luc",
               "keywords": ["Nang luong", "Hoc tap", "Giao tiep", "Phat trien", "Tranh dau", "Nhiet huyet"]},
    "Bich":   {"icon": "Bich", "element": "Khi (Tri tue/Thu thach)", "theme": "Suy nghi, Kho khan, Chuong ngai, Su that, Quyet doan",
               "keywords": ["Ly tri", "Thu thach", "Bi an", "Canh bao", "Su that mat long", "Giai thoat"]},
}

CARD_MEANINGS = {
    "A":  {"Co": "Dai hy lam mon. Khoi dau tinh yeu set danh hoac su han gan ky dieu.",
           "Ro": "Van may tai loc bat ngo ap den. Hop dong beo bo hoac tin vui tang luong.",
           "Chuon": "Co den tay ai nguoi nay phat. Khoi dau du an day tham vong.",
           "Bich": "Su that tran trui duoc phoi bay. Quyet dinh dut khoat can duoc dua ra."},
    "2":  {"Co": "Tam dau y hop. Cuoc gap go dinh menh hoac doi tac lam an hop ro.",
           "Ro": "Dong tien len xuong that thuong, can ky nang tai chinh.",
           "Chuon": "Hay tim dong minh, su ho tro tu dong nghiep giup di xa hon.",
           "Bich": "Ban dang dung giua hai dong nuoc, can binh tinh."},
    "3":  {"Co": "Tin vui hy su, mang thai hoac le ky niem.",
           "Ro": "Dau tu sinh loi, ky nang nghe nghiep duoc cap tren cong nhan.",
           "Chuon": "Co hoi mo rong networking, dung ngai buoc ra vung an toan.",
           "Bich": "Can than thi phi, tin don that thiet noi cong so."},
    "4":  {"Co": "Tinh cam on dinh, can lam moi cam xuc tranh nham chan.",
           "Ro": "Tai chinh an toan, tot de tich luy nhung can biet dau tu.",
           "Chuon": "Nghi ngoi nap nang luong truoc khi bat dau hanh trinh moi.",
           "Bich": "Kiet suc tinh than, can nghi ngoi va hoi phuc."},
    "5":  {"Co": "Song gio tinh truong, dung voi buong tay.",
           "Ro": "Chi tieu vuot kiem soat, can that lung buoc bung.",
           "Chuon": "Canh tranh gay gat, hay giu cai dau lanh.",
           "Bich": "Canh bao rui ro bi choi xau hoac mat mat."},
    "6":  {"Co": "Hoi uc ua ve, su chua lanh den tu nhung ket noi cu.",
           "Ro": "Co loc bat ngo ve tien bac.",
           "Chuon": "Moi no luc duoc den dap xung dang.",
           "Bich": "Roi bo rac roi cu de huong toi tuong lai sang hon."},
    "7":  {"Co": "Qua nhieu lua chon khien ban hoang mang.",
           "Ro": "Cham ma chac, dau tu can thoi gian chin muoi.",
           "Chuon": "Ban o the phong thu nhung du ban linh de thang.",
           "Bich": "Can trong nguoi hai mat, hay dung tri tue de bat bai."},
    "8":  {"Co": "Ban muon tim kiem dieu y nghia hon trong tinh cam.",
           "Ro": "Tien bac den tu su cham chi va chuyen mon cao.",
           "Chuon": "Moi thu dang dien ra nhanh chong.",
           "Bich": "Cam giac be tac chi la tam thoi, hay dam buoc ra khoi noi so."},
    "9":  {"Co": "La bai uoc nguyen, mong cau tinh cam de thanh.",
           "Ro": "Doc lap tai chinh, tan huong thanh qua.",
           "Chuon": "Kien cuong, dung bo cuoc ngay truoc vach dich.",
           "Bich": "Lo au va mat ngu, hay tim nguoi chia se."},
    "10": {"Co": "Gia dinh hoa thuan, hanh phuc tron ven.",
           "Ro": "Sung tuc vat chat o muc cao.",
           "Chuon": "Om dom qua nhieu viec, can buong bot.",
           "Bich": "Ket thuc chu ky cu de mo ra khoi dau moi."},
    "J":  {"Co": "Nguoi tre lang man mang nang luong tich cuc.",
           "Ro": "Tin vui tai chinh hoac co hoi kiem tien.",
           "Chuon": "Nguon nang luong bung no cho cong viec va dich chuyen.",
           "Bich": "Tin tuc quan trong can duoc kiem chung."},
    "Q":  {"Co": "Nang luong nu tinh diu dang va chua lanh.",
           "Ro": "Nu doanh nhan thuc te, on dinh vat chat.",
           "Chuon": "Nu hoang giao tiep, truyen cam hung.",
           "Bich": "Sac sao, ly tri, quyet doan."},
    "K":  {"Co": "Su truong thanh, bao dung va cho dua vung chac.",
           "Ro": "Quyen luc tai chinh va thanh cong.",
           "Chuon": "Nha lanh dao truyen lua va dan dat doi nhom.",
           "Bich": "Giai quyet bang ly tri, nguyen tac va minh bach."},
}

ADVICES = [
    "Hay lang nghe truc giac, no la ngon hai dang trong suong mu.",
    "Dung dot chay giai doan, lua chin ep thuong khong ngon.",
    "Su ky luat la cay cau noi giua muc tieu va hien thuc.",
    "Hay danh thoi gian cho gia dinh va suc khoe.",
    "Neu be tac, hay nghi ngoi mot chut roi di tiep.",
    "Dung so sanh hanh trinh cua minh voi nguoi khac.",
    "Kien nhan la chia khoa mo ra co hoi lon.",
    "Dau tu vao tri thuc luon la khoan dau tu co loi.",
]

INTER_TEMPLATES = [
    "Vu tru gui den ban nang luong {element} qua la bai {cardName}. {specificMeaning}",
    "La bai {cardName} xuat hien hom nay voi thong diep: {specificMeaning}",
    "Dong chay {element} dang tac dong manh den ban. {specificMeaning}",
    "Lien quan den {keywords}, la {cardName} cho thay: {specificMeaning}",
    "La bai {cardName} – {specificMeaning}",
]

# ── Lưu dữ liệu ngày ─────────────────────────────────────────────────────────
DATA_DIR  = Path("data/config/boibai")
DATA_FILE = DATA_DIR / "daily.json"

def _load_daily():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        return {}
    try:
        return json.loads(DATA_FILE.read_text("utf-8"))
    except Exception:
        return {}

def _save_daily(data):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")

# ── Vẽ ảnh bói bài (Pillow) ───────────────────────────────────────────────────
FONT_DIR = Path("assets/font")
# Resolve absolute path từ vị trí file này để luôn tìm đúng font dù bot chạy ở đâu
_THIS_DIR = Path(__file__).resolve().parent
_SEARCH = _THIS_DIR
for _ in range(10):
    if (_SEARCH / "assets" / "font").exists():
        break
    _SEARCH = _SEARCH.parent
_FONT_ABS = _SEARCH / "assets" / "font"

def _load_font(size, bold=False):
    # Ưu tiên Sarabun (hỗ trợ tiếng Việt + ký tự đặc biệt, giống speedtest)
    names_bold = [
        "Sarabun/Sarabun-Bold.ttf",
        "Sarabun/Sarabun-SemiBold.ttf",
        "BeVietnamPro-Bold.ttf",
        "Goldman/Goldman-Bold.ttf",
        "Opensans/static/Opensans/OpenSans-Bold.ttf",
    ]
    names_reg = [
        "Sarabun/Sarabun-Regular.ttf",
        "Sarabun/Sarabun-Light.ttf",
        "Goldman/Goldman-Regular.ttf",
        "Opensans/static/Opensans/OpenSans-Regular.ttf",
    ]
    names = names_bold if bold else names_reg
    for root in [_FONT_ABS, FONT_DIR]:
        for rel in names:
            p = root / rel
            if p.exists():
                try: return ImageFont.truetype(str(p), size)
                except: pass
    # Last resort: bất kỳ ttf nào tìm được
    for root in [_FONT_ABS, FONT_DIR]:
        if root.exists():
            for p in root.rglob("*.ttf"):
                if "emoji" not in p.name.lower():
                    try: return ImageFont.truetype(str(p), size)
                    except: pass
    return ImageFont.load_default()


def _load_emoji_font(size):
    """Font riêng để render emoji & ký hiệu suit (♥♦♣♠)."""
    emoji_names = ["emoji.ttf", "emoji2.ttf", "emoji3.ttf", "emoji5.ttf"]
    for root in [_FONT_ABS, FONT_DIR]:
        for name in emoji_names:
            p = root / name
            if p.exists():
                try: return ImageFont.truetype(str(p), size)
                except: pass
    return _load_font(size, bold=True)

def _load_avatar(url, size):
    if url:
        try:
            r = _req.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
            img = Image.open(BytesIO(r.content)).convert("RGBA").resize((size, size), Image.LANCZOS)
            mask = Image.new("L", (size*4, size*4), 0)
            ImageDraw.Draw(mask).ellipse([0,0,size*4-1,size*4-1], fill=255)
            mask = mask.resize((size, size), Image.LANCZOS)
            out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            out.paste(img, mask=mask)
            return out
        except: pass
    ph = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(ph).ellipse([0, 0, size-1, size-1], fill=(100, 40, 160, 255))
    return ph

SUIT_COLORS = {
    "Co":    (220, 50,  80),
    "Ro":    (230, 160, 30),
    "Chuon": (50,  180, 80),
    "Bich":  (80,  100, 220),
}
SUIT_VN = {"Co": "Co", "Ro": "Ro", "Chuon": "Chuon", "Bich": "Bich"}

def _draw_boibai_image(user_name, avatar_url, card_rank, card_suit, interpretation, advice, out_path):
    W, H = 900, 460
    canvas = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(canvas)

    # Gradient nền
    color = SUIT_COLORS.get(card_suit, (80, 40, 160))
    for x in range(W):
        t = x / W
        r = int(20 * (1-t) + color[0]*0.3 * t)
        g = int(10 * (1-t) + color[1]*0.3 * t)
        b = int(40 * (1-t) + color[2]*0.4 * t)
        d.line([(x, 0), (x, H)], fill=(r, g, b, 255))

    # Bokeh
    bokeh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bokeh)
    rng = random.Random(hash(user_name) % 9999)
    for _ in range(40):
        bx = rng.randint(0, W); by = rng.randint(0, H)
        br = rng.randint(8, 40); ba = rng.randint(10, 35)
        bd.ellipse([bx-br, by-br, bx+br, by+br], fill=(*color, ba))
    bokeh = bokeh.filter(ImageFilter.GaussianBlur(radius=10))
    canvas = Image.alpha_composite(canvas, bokeh)
    d = ImageDraw.Draw(canvas)

    f_title  = _load_font(30, bold=True)
    f_card   = _load_font(64, bold=True)
    f_suit   = _load_font(22, bold=True)
    f_body   = _load_font(20)
    f_name   = _load_font(26, bold=True)
    f_label  = _load_font(17)
    f_emoji  = _load_emoji_font(64)   # dùng cho suit symbol ♥♦♣♠

    # Avatar
    AV = 130
    av_img = _load_avatar(avatar_url, AV)
    canvas.alpha_composite(av_img, (36, 36))

    # Tên user
    d.text((36 + AV + 18, 56), user_name[:24], font=f_name, fill=(255, 255, 255, 240))
    d.text((36 + AV + 18, 90), "Que boi hom nay", font=f_label, fill=(255, 255, 255, 140))

    # Panel lá bài (bên phải avatar)
    PX, PY, PW, PH = 36, 196, 200, 220
    panel_bg = Image.new("RGBA", (PW, PH), (255, 255, 255, 28))
    mask = Image.new("L", (PW*4, PH*4), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0,0,PW*4-1,PH*4-1], radius=60, fill=255)
    mask = mask.resize((PW, PH), Image.LANCZOS)
    out_p = Image.new("RGBA", (PW, PH), (0,0,0,0))
    out_p.paste(panel_bg, mask=mask)
    canvas.alpha_composite(out_p, (PX, PY))

    # Số/Chữ lá bài
    _suit_ascii = {"Co": "Co", "Ro": "Ro", "Chuon": "Club", "Bich": "Bich"}
    suit_sym = _suit_ascii.get(card_suit, card_suit)
    card_text = f"{card_rank}"
    d.text((PX + PW//2 - 30, PY + 20), card_text, font=f_card, fill=(*color, 255))
    d.text((PX + PW//2 - 22, PY + 100), suit_sym, font=f_suit, fill=(*color, 220))
    d.text((PX + 16, PY + PH - 36), SUIT_VN[card_suit], font=f_suit, fill=(255, 255, 255, 200))

    # Panel nội dung bên phải
    TX = PX + PW + 24
    TW = W - TX - 24
    TY = 180

    # Diễn giải
    d.text((TX, TY), "Dien giai:", font=f_suit, fill=(*color, 255))
    lines = _wrap(interpretation, f_body, TW, d)
    ly = TY + 30
    for line in lines[:5]:
        d.text((TX, ly), line, font=f_body, fill=(255, 255, 255, 220))
        ly += 24

    # Lời khuyên
    ly += 10
    d.text((TX, ly), "Loi khuyen:", font=f_suit, fill=(*color, 255))
    ly += 26
    adv_lines = _wrap(advice, f_body, TW, d)
    for line in adv_lines[:3]:
        d.text((TX, ly), line, font=f_body, fill=(255, 255, 255, 180))
        ly += 24

    # Tiêu đề trên
    d.text((W//2 - 160, 14), "BOI BAI VAN MENH", font=f_title, fill=(255, 255, 255, 210))
    # Watermark
    d.text((W - 100, H - 28), "zbot", font=f_label, fill=(255, 255, 255, 80))

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=90)
    return out_path

def _wrap(text, font, max_w, draw):
    words = text.split()
    lines = []
    cur = ""
    for w in words:
        test = (cur + " " + w).strip()
        bb = font.getbbox(test)
        if bb[2] - bb[0] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines

# ── Command ───────────────────────────────────────────────────────────────────
def BoiBaiCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Lấy target user (tag hoặc bản thân)
    uids = extractUids(Data)
    target_uid = uids[0] if uids else str(UserId)

    try:
        target_name = self.userName(target_uid) or str(target_uid)
        _uinfo = self.fetchUserInfo(target_uid)
        _changed   = getattr(_uinfo, "changed_profiles",   {}) or {}
        _unchanged = getattr(_uinfo, "unchanged_profiles", {}) or {}
        _profile   = _changed.get(str(target_uid)) or _unchanged.get(str(target_uid)) or {}
        target_avatar = _profile.get("avatar") or _profile.get("avatarUrl") or ""
    except Exception:
        target_name = str(target_uid)
        target_avatar = ""

    # Kiểm tra đã bói hôm nay chưa
    today = datetime.now().strftime("%d/%m/%Y")
    all_data = _load_daily()

    card_data = {}
    text_data  = {}
    is_replay  = False

    if target_uid in all_data and all_data[target_uid].get("date") == today:
        is_replay = True
        card_data = all_data[target_uid]["cardData"]
        text_data  = all_data[target_uid]["textData"]
    else:
        suits  = list(SUITS_DATA.keys())
        ranks  = list(CARD_MEANINGS.keys())
        suit   = random.choice(suits)
        rank   = random.choice(ranks)

        suit_info = SUITS_DATA[suit]
        meaning   = CARD_MEANINGS[rank][suit]
        card_name = f"{rank} {SUIT_VN[suit]}"

        tmpl   = random.choice(INTER_TEMPLATES)
        kw     = random.choice(suit_info["keywords"])
        interp = (tmpl
                  .replace("{element}", suit_info["element"])
                  .replace("{theme}",   suit_info["theme"])
                  .replace("{specificMeaning}", meaning)
                  .replace("{cardName}", card_name)
                  .replace("{keywords}", kw)
                  .replace("{icon}", suit_info["icon"]))
        advice = random.choice(ADVICES)

        card_data = {"rank": rank, "suit": suit, "suitIcon": suit_info["icon"], "fullName": card_name}
        text_data  = {"interpretation": interp, "advice": advice}

        all_data[target_uid] = {"date": today, "cardData": card_data, "textData": text_data}
        _save_daily(all_data)

    # Tạo ảnh
    img_path = None
    if _PILLOW_OK:
        try:
            os.makedirs("data/assets/cache/boibai", exist_ok=True)
            img_path = f"data/assets/cache/boibai/boibai_{target_uid}.jpg"
            _draw_boibai_image(
                target_name, target_avatar,
                card_data["rank"], card_data["suit"],
                text_data["interpretation"], text_data["advice"],
                img_path,
            )
        except Exception as e:
            print(f"[BoiBai] draw error: {e}")
            img_path = None

    msg_text = f"[Boi Bai] Que boi van menh cho {target_name}\nLa bai: {card_data['fullName']}"
    if is_replay:
        msg_text += "\n\nBan da xem boi hom nay roi! Doi hom sau nhe."

    name_tag = self.userName(UserId) or str(UserId)
    mention_text = f"@{name_tag}"

    if img_path and os.path.exists(img_path):
        try:
            image_res = self._uploadImage(img_path, ThreadId, ThreadType)
            image_url = None
            if isinstance(image_res, dict):
                image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
            elif isinstance(image_res, str) and image_res.startswith("http"):
                image_url = image_res

            if image_url:
                self.sendRemoteImage(
                    image_url, ThreadId, ThreadType,
                    width=900, height=460,
                    message=Message(
                        text=f"{mention_text} {msg_text}",
                        mention=Mention(UserId, length=len(mention_text), offset=0)
                    )
                )
            else:
                self.sendMentionStyle(msg_text, UserId, ThreadId, ThreadType)
        except Exception as e:
            print(f"[BoiBai] send image error: {e}")
            self.sendMentionStyle(msg_text, UserId, ThreadId, ThreadType)
        finally:
            try: os.remove(img_path)
            except: pass
    else:
        full_msg = f"{msg_text}\n\n{text_data['interpretation']}\n\n>> {text_data['advice']}"
        self.sendMentionStyle(full_msg, UserId, ThreadId, ThreadType)


dependencies = {
    "name":        "boibai",
    "permission":  0,
    "cooldown":    3,
    "description": "Boi bai van menh moi ngay – 1 lan/ngay/nguoi",
    "main":        BoiBaiCommand,
}
