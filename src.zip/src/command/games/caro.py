from app.core.index import *
from app.module.commandLoader import removeMention
import os, sys, importlib.util, threading, time, json


def _load_engine_module(name, filename):
    key = f"games.caro_engine.{name}"
    m = sys.modules.get(key)
    if m:
        return m
    _dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "caro_engine")
    spec = importlib.util.spec_from_file_location(key, os.path.join(_dir, filename))
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = "games.caro_engine"
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


_board_mod   = _load_engine_module("board",   "board.py")
_session_mod = _load_engine_module("session", "session.py")

Board            = _board_mod.Board
SIZE             = _board_mod.SIZE
cell_to_num      = _board_mod.cell_to_num
num_to_cell      = _board_mod.num_to_cell
SessionManager   = _session_mod.SessionManager
CaroSession      = _session_mod.CaroSession
DIFFICULTY_NAMES = _session_mod.DIFFICULTY_NAMES
TURN_TIMEOUT     = _session_mod.TURN_TIMEOUT

try:
    from src.services.pillow.caroDraw import make_board_image
    _PILLOW_OK = True
except Exception:
    _PILLOW_OK = False

RANK_DIR     = "data/config/caro_rank"
RANK_MEDALS  = ["🥇", "🥈", "🥉"]


# ── Rank & điểm ──────────────────────────────────────────────────────────────

def _rank_path(thread_id):
    os.makedirs(RANK_DIR, exist_ok=True)
    return os.path.join(RANK_DIR, f"thread_{thread_id}.json")

def _load_rank(thread_id):
    try:
        with open(_rank_path(thread_id), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_rank(thread_id, data):
    try:
        with open(_rank_path(thread_id), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _calc_match_points(board, result, session):
    """
    Tính điểm dựa trên cách chơi thực tế của người chơi.
    AI đánh giá toàn bộ nước đi của người qua board history.
    result: 'win' | 'lose' | 'draw' | 'surrender'
    """
    cells = board.cells
    history = board.history
    human = session.human_player
    move_count = session.move_count
    difficulty = session.difficulty

    # Đánh giá chất lượng các nước đi của người chơi
    human_moves = [pos for i, pos in enumerate(history) if i % 2 == 0]
    quality_score = 0
    for r, c in human_moves:
        row_count = sum(1 for cc in range(SIZE) if cells[r][cc] == human)
        col_count = sum(1 for rr in range(SIZE) if cells[rr][c] == human)
        diag1 = sum(1 for d in range(-4, 5)
                    if 0 <= r+d < SIZE and 0 <= c+d < SIZE and cells[r+d][c+d] == human)
        diag2 = sum(1 for d in range(-4, 5)
                    if 0 <= r+d < SIZE and 0 <= c-d < SIZE and cells[r+d][c-d] == human)
        quality_score += max(row_count, col_count, diag1, diag2)

    avg_quality = quality_score / max(len(human_moves), 1)
    diff_mult   = {1: 0.5, 2: 0.8, 3: 1.2, 4: 1.8}.get(difficulty, 1.0)

    if result == "win":
        base = 20 + int(avg_quality * 3)
        pts  = int(base * diff_mult)
    elif result == "draw":
        base = 8 + int(avg_quality * 1.5)
        pts  = int(base * diff_mult)
    elif result == "lose":
        base = max(2, int(avg_quality * 0.8))
        pts  = -int(base * diff_mult * 0.5)
    else:  # surrender
        base = max(1, int(avg_quality * 0.5))
        pts  = -int(base * diff_mult * 0.8)

    return max(-30, min(80, pts))

def _update_rank(self, thread_id, user_id, name, result, pts):
    db  = _load_rank(thread_id)
    uid = str(user_id)
    if uid not in db:
        db[uid] = {"name": name, "points": 0}
    db[uid]["name"]   = name
    db[uid]["points"] = db[uid].get("points", 0) + pts
    _save_rank(thread_id, db)

def _format_rank(db):
    rows = sorted(db.items(), key=lambda x: x[1].get("points", 0), reverse=True)
    if not rows:
        return "Chưa có ai chơi caro ở đây."
    lines = []
    for i, (uid, r) in enumerate(rows):
        medal = RANK_MEDALS[i] if i < 3 else f"{i+1}."
        pts   = r.get("points", 0)
        sign  = "+" if pts >= 0 else ""
        lines.append(f"{medal} {r['name']}  —  {sign}{pts} điểm")
    return "\n".join(lines)


# ── Cooldown đồng hồ trên ảnh bàn cờ ────────────────────────────────────────

def _stop_board_cooldown(ctx, key):
    if key and hasattr(ctx, "_caroCooldown"):
        ctx._caroCooldown[key] = False

def _start_board_cooldown(ctx, MsgObj, ThreadId, ThreadType):
    if not hasattr(ctx, "_caroCooldown"):
        ctx._caroCooldown = {}
    key = MsgObj.msgId
    if not key:
        return
    ctx._caroCooldown[key] = True
    msg = MessageObject(
        msgId    = MsgObj.msgId,
        cliMsgId = getattr(MsgObj, "clientId", None),
        msgType  = "webchat",
    )
    def _loop():
        for i in range(TURN_TIMEOUT, 0, -1):
            if not ctx._caroCooldown.get(key):
                break
            ctx.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            ctx.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        ctx._caroCooldown.pop(key, None)
    threading.Thread(target=_loop, daemon=True).start()

def _delete_old_board(self, session):
    _stop_board_cooldown(self, session.msg_id)
    if session.msg_id and session.cli_msg_id:
        try:
            self.undoMessage(session.msg_id, session.cli_msg_id,
                             session.thread_id, session.thread_type)
        except Exception:
            pass
    session.msg_id     = None
    session.cli_msg_id = None


# ── Gửi bàn cờ ───────────────────────────────────────────────────────────────

def _send_board(self, board, thread_id, thread_type,
                last_r=-1, last_c=-1, move_num=0, difficulty=3, extra="",
                session=None, react_data=None, user_id=None,
                win_line=None, last_player=0, is_final=False):
    if session:
        _delete_old_board(self, session)

    # Reaction "đang xử lý" chỉ khi KHÔNG phải kết quả cuối
    if react_data is not None and not is_final:
        try:
            self.sendReaction(react_data, "🤓", thread_id, thread_type, 100000000)
        except Exception:
            pass

    name         = self.userName(str(user_id)) or str(user_id) if user_id else None
    mention_text = f"@{name}" if name else None
    caption_text = f"{mention_text}\n{extra}" if mention_text and extra else (mention_text or extra)
    mention      = Mention(str(user_id), length=len(mention_text), offset=0) if mention_text else None

    msg = None

    if _PILLOW_OK:
        img_path = img_url = None
        img_w = img_h = 0
        try:
            img_path = make_board_image(
                board.cells,
                last_r=last_r, last_c=last_c,
                move_num=move_num, difficulty=difficulty,
                extra=extra, difficulty_names=DIFFICULTY_NAMES,
                win_line=win_line or [], last_player=last_player,
            )
            from PIL import Image as _Img
            with _Img.open(img_path) as im:
                img_w, img_h = im.size
            res = self._uploadImage(img_path, thread_id, thread_type)
            if isinstance(res, dict):
                img_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                img_url = res
        except Exception as e:
            print(f"[CaroDraw] upload error: {e}")
        finally:
            if img_path and os.path.exists(img_path):
                try:
                    os.remove(img_path)
                except Exception:
                    pass
        if img_url:
            try:
                msg = self.sendRemoteImage(
                    img_url, thread_id, thread_type,
                    width=img_w or 2560, height=img_h or 2560,
                    message=Message(text=caption_text, mention=mention),
                )
            except Exception as e:
                print(f"[CaroDraw] sendRemoteImage error: {e}")

    if msg is None:
        lines = []
        for r in range(SIZE):
            row_parts = []
            for c in range(SIZE):
                val = board.cells[r][c]
                is_last = (r == last_r and c == last_c)
                if val == 1:
                    sym = "(✕)" if is_last else " ✕ "
                elif val == 2:
                    sym = "(◉)" if is_last else " ◉ "
                else:
                    sym = f"{cell_to_num(r, c):>3}"
                row_parts.append(sym)
            lines.append(" ".join(row_parts))
        diff_label = DIFFICULTY_NAMES.get(difficulty, "")
        text = (
            f"🎮 CARO | {diff_label} | Nước #{move_num}\n"
            f"✕ = Bạn  ◉ = Bot\n{'─'*38}\n"
        ) + "\n".join(lines)
        if extra:
            text += f"\n{'─'*38}\n{extra}"
        msg = self.send(
            Message(text=f"{caption_text}\n{text}" if mention_text else text, mention=mention),
            thread_id, thread_type,
        )

    # Xóa reaction sau khi gửi ảnh — chỉ khi KHÔNG phải kết quả cuối
    if react_data is not None and not is_final:
        try:
            self.sendReaction(react_data, "", thread_id, thread_type, -1)
        except Exception:
            pass

    if session and msg and not is_final:
        session.msg_id     = getattr(msg, "msgId",    None)
        session.cli_msg_id = getattr(msg, "clientId", None)
        _start_board_cooldown(self, msg, thread_id, thread_type)

    return msg


# ── Bot đi trước (nước đầu khi bot_first=True) ───────────────────────────────

def _bot_move_first(self, session, data, thread_id, thread_type, user_id):
    """Bot đi nước đầu tiên khi người dùng chọn -a."""
    board = session.board
    p = getattr(self, "prefix", "/")
    c = getattr(self, "rawCommand", None) or getattr(self, "commandName", "caro")

    br, bc = SIZE // 2, SIZE // 2
    board.place(br, bc, session.bot_player)
    session.move_count += 1
    session.is_user_turn = True
    session.touch()

    bot_num    = cell_to_num(br, bc)
    diff_label = DIFFICULTY_NAMES[session.difficulty]
    _send_board(
        self, board, thread_id, thread_type,
        last_r=br, last_c=bc, move_num=session.move_count,
        difficulty=session.difficulty,
        extra=(
            f"🎮 Ván mới! Mức: {diff_label} | 🤖 Bot đi trước\n"
            f"✕ = Bạn  ◉ = Bot (ô {bot_num})\n"
            f"💬 Nhập số ô (1–{SIZE * SIZE}) hoặc: hàng cột\n"
            f"⏳ {TURN_TIMEOUT}s mỗi lượt\n"
            f"🛑 {p}{c} stop · 🏳 {p}{c} lose"
        ),
        session=session, react_data=data, user_id=user_id,
    )
    _start_countdown(self, session, data)


# ── Countdown lượt ───────────────────────────────────────────────────────────

def _start_countdown(self, session, data):
    snap_turn = session.move_count
    def _run():
        remaining = TURN_TIMEOUT
        while remaining > 0:
            sess = SessionManager.get(session.user_id)
            if not sess or not sess.is_user_turn or sess.move_count != snap_turn:
                return
            time.sleep(1)
            remaining -= 1
        sess = SessionManager.get(session.user_id)
        if sess and sess.is_user_turn and sess.move_count == snap_turn:
            _stop_board_cooldown(self, sess.msg_id)
            SessionManager.remove(session.user_id)
            self.send(
                Message(text=f"⌛ Hết {TURN_TIMEOUT}s! Ván cờ kết thúc do timeout."),
                session.thread_id, session.thread_type,
            )
    threading.Thread(target=_run, daemon=True).start()


# ── Parse nước đi ─────────────────────────────────────────────────────────────

def _parse_move(parts):
    try:
        if len(parts) == 1:
            token = parts[0].strip().rstrip(".,")
            if token.isdigit():
                n = int(token)
                if 1 <= n <= SIZE * SIZE:
                    return num_to_cell(n)
                return None, None
            if "," in token:
                a, b = token.split(",", 1)
                return int(a.strip()) - 1, int(b.strip()) - 1
        if len(parts) >= 2:
            a = parts[0].lstrip("-").rstrip(".,")
            b = parts[1].lstrip("-").rstrip(".,")
            if a.isdigit() and b.isdigit():
                return int(parts[0]) - 1, int(parts[1]) - 1
    except Exception:
        pass
    return None, None


# ── Bot đi ────────────────────────────────────────────────────────────────────

def _bot_move(self, session, data, thread_id, thread_type):
    board = session.board
    ai    = session.ai

    try:
        self.sendReaction(data, "🤔", thread_id, thread_type, 100000000)
    except Exception:
        pass

    br, bc = ai.best_move(board, session.bot_player)
    board.place(br, bc, session.bot_player)
    session.move_count += 1

    try:
        self.sendReaction(data, "", thread_id, thread_type, -1)
    except Exception:
        pass

    bot_num = cell_to_num(br, bc)

    if board.check_win(br, bc, session.bot_player):
        win_line = board.get_win_line(br, bc, session.bot_player)
        name = self.userName(session.user_id) or session.user_id
        pts  = _calc_match_points(board, "lose", session)
        _update_rank(self, thread_id, session.user_id, name, "lose", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self, board, thread_id, thread_type,
                    last_r=br, last_c=bc, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🤖 Bot thắng! Ô {bot_num}\n📊 {ai.stats()}\n{sign}{pts} điểm",
                    session=session, user_id=session.user_id,
                    win_line=win_line, last_player=2, is_final=True)
        SessionManager.remove(session.user_id)
        return

    if board.is_full():
        name = self.userName(session.user_id) or session.user_id
        pts  = _calc_match_points(board, "draw", session)
        _update_rank(self, thread_id, session.user_id, name, "draw", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self, board, thread_id, thread_type,
                    last_r=br, last_c=bc, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🤝 Hòa!\n{sign}{pts} điểm",
                    session=session, user_id=session.user_id,
                    last_player=2, is_final=True)
        SessionManager.remove(session.user_id)
        return

    session.is_user_turn = True
    session.touch()
    _send_board(self, board, thread_id, thread_type,
                last_r=br, last_c=bc, move_num=session.move_count,
                difficulty=session.difficulty,
                extra=f"🤖 Bot đặt ô {bot_num}\n💬 Nhập số ô hoặc: hàng cột\n🛑 stop · 🏳 lose",
                session=session, react_data=data, user_id=session.user_id,
                last_player=2)
    _start_countdown(self, session, data)


# ── Người đi ──────────────────────────────────────────────────────────────────

def _player_move(self, row, col, session, data, user_id, thread_id, thread_type):
    board = session.board
    if not (0 <= row < SIZE and 0 <= col < SIZE):
        self.replyMessageStyle(
            f"❌ Số ô ngoài phạm vi! Nhập 1–{SIZE*SIZE}.",
            data, thread_id, thread_type, color="r", title="LỖI", userId=user_id)
        return
    if board.cells[row][col] != 0:
        self.replyMessageStyle(
            f"❌ Ô {cell_to_num(row, col)} đã có quân rồi!",
            data, thread_id, thread_type, color="r", title="LỖI", userId=user_id)
        return

    board.place(row, col, session.human_player)
    session.move_count += 1
    session.is_user_turn = False
    session.touch()

    player_num = cell_to_num(row, col)

    if board.check_win(row, col, session.human_player):
        win_line = board.get_win_line(row, col, session.human_player)
        name = self.userName(str(user_id)) or str(user_id)
        pts  = _calc_match_points(board, "win", session)
        _update_rank(self, thread_id, str(user_id), name, "win", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self, board, thread_id, thread_type,
                    last_r=row, last_c=col, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🎉 Bạn thắng! Ô {player_num}\n{sign}{pts} điểm",
                    session=session, user_id=user_id,
                    win_line=win_line, last_player=1, is_final=True)
        SessionManager.remove(session.user_id)
        return

    if board.is_full():
        name = self.userName(str(user_id)) or str(user_id)
        pts  = _calc_match_points(board, "draw", session)
        _update_rank(self, thread_id, str(user_id), name, "draw", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self, board, thread_id, thread_type,
                    last_r=row, last_c=col, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🤝 Hòa!\n{sign}{pts} điểm",
                    session=session, user_id=user_id,
                    last_player=1, is_final=True)
        SessionManager.remove(session.user_id)
        return

    threading.Thread(
        target=lambda: _bot_move(self, session, data, thread_id, thread_type),
        daemon=True
    ).start()


# ── Lệnh chính ────────────────────────────────────────────────────────────────

class CaroCommand:
    def __init__(self, ctx):
        self._ctx   = ctx
        self.prefix = getattr(ctx, "prefix", "/")
        self.cmd    = getattr(ctx, "rawCommand", None) or getattr(ctx, "commandName", "caro")

    def _reply(self, text, data, threadId, type, *, color, title, userId):
        return self._ctx.replyMessageStyle(
            text, data, threadId, type, color=color, title=title, userId=userId)

    def _guide(self, data, threadId, type, userId):
        p, c = self.prefix, self.cmd
        guide = (
            f"Cách Sử Dụng Lệnh Caro\n\n"
            f"Bắt Đầu Ván Mới:\n"
            f"  📍 {p}{c} start 1 (Dễ)\n"
            f"  📍 {p}{c} start 2 (Trung bình)\n"
            f"  📍 {p}{c} start 3 (Khó)\n"
            f"  📍 {p}{c} start 4 (Ác mộng)\n"
            f"  🤖 Thêm -a để bot đi trước. VD: {p}{c} start 3 -a\n\n"
            f"Xếp Hạng:\n"
            f"  📍 {p}{c} rank. 🏆 Bảng xếp hạng caro của nhóm."
        )
        return self._reply(guide, data, threadId, type, color="or", title="CARO", userId=userId)

    def _extract_parts(self, message):
        text = (getattr(message, "text", "") or "").strip()
        p, c = self.prefix, self.cmd
        if p and text.startswith(p):
            text = text[len(p):].strip()
        parts = text.split()
        if parts and parts[0].lower() == c.lower():
            parts = parts[1:]
        return parts

    def _do_start(self, difficulty, uid, session, data, threadId, type, userId,
                  bot_first=False):
        if session:
            _delete_old_board(self._ctx, session)
            SessionManager.remove(uid)

        diff_label = DIFFICULTY_NAMES[difficulty]
        # Thông báo đang khởi tạo
        try:
            self._ctx.replyMessageStyle(
                f"⏳ Chờ giây lát, đang khởi tạo bàn cờ...\n"
                f"🎮 Chế độ: {diff_label}"
                + (" | 🤖 Bot đi trước" if bot_first else " | 👤 Bạn đi trước"),
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        except Exception:
            pass

        new_sess = SessionManager.create(uid, str(threadId), type, difficulty)
        p, c     = self.prefix, self.cmd

        if bot_first:
            new_sess.is_user_turn = False
            threading.Thread(
                target=lambda: _bot_move_first(self._ctx, new_sess, data, threadId, type, userId),
                daemon=True,
            ).start()
        else:
            _send_board(
                self._ctx, new_sess.board, threadId, type,
                move_num=0, difficulty=difficulty,
                extra=(
                    f"🎮 Ván mới! Mức: {diff_label}\n"
                    f"✕ = Bạn (đi trước)  ◉ = Bot\n"
                    f"💬 Nhập số ô (1–{SIZE*SIZE}) hoặc: hàng cột\n"
                    f"⏳ {TURN_TIMEOUT}s mỗi lượt\n"
                    f"🛑 {p}{c} stop · 🏳 {p}{c} lose"
                ),
                session=new_sess, react_data=data, user_id=userId,
            )
            _start_countdown(self._ctx, new_sess, data)

    def _do_stop(self, uid, session, data, threadId, type, userId):
        if session and session.move_count >= 5:
            p, c = self.prefix, self.cmd
            self._reply(
                f"🚫 Không thể hủy sau 5 nước trở lên.\n"
                f"Dùng {p}{c} lose để đầu hàng (bot thắng).",
                data, threadId, type, color="r", title="CARO", userId=userId,
            )
            return
        if session:
            _delete_old_board(self._ctx, session)
        SessionManager.remove(uid)
        self._reply("🛑 Ván cờ đã hủy. Không tính điểm.",
                    data, threadId, type, color="yl", title="CARO", userId=userId)

    def _do_lose(self, session, uid, data, threadId, type, userId):
        board = session.board
        last  = board.last_move()
        lr, lc = last if last else (-1, -1)
        name = self._ctx.userName(str(userId)) or str(userId)
        pts  = _calc_match_points(board, "surrender", session)
        _update_rank(self._ctx, str(threadId), str(userId), name, "lose", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self._ctx, board, threadId, type,
                    last_r=lr, last_c=lc, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🏳 Bạn đầu hàng! Bot thắng.\n{sign}{pts} điểm",
                    session=session, user_id=userId, is_final=True)
        SessionManager.remove(uid)

    def _do_rank(self, data, threadId, type, userId):
        db   = _load_rank(str(threadId))
        text = _format_rank(db)
        self._reply(f"🏆 Bảng Xếp Hạng Caro\n\n{text}",
                    data, threadId, type, color="or", title="CARO RANK", userId=userId)

    def run(self, message, data, userId, threadId, type):
        parts   = self._extract_parts(message)
        uid     = str(userId)
        session = SessionManager.get(uid)
        sub     = parts[0].lower() if parts else ""

        if sub in ("stop", "quit", "end"):
            if session:
                self._do_stop(uid, session, data, threadId, type, userId)
            else:
                self._reply("❌ Không có ván nào đang chạy.",
                            data, threadId, type, color="r", title="CARO", userId=userId)
            return

        if sub in ("lose", "surrender", "gg"):
            if session:
                self._do_lose(session, uid, data, threadId, type, userId)
            else:
                self._reply("❌ Không có ván nào đang chạy.",
                            data, threadId, type, color="r", title="CARO", userId=userId)
            return

        if sub == "rank":
            self._do_rank(data, threadId, type, userId)
            return

        if sub == "start":
            if session:
                p, c = self.prefix, self.cmd
                self._reply(
                    f"⚠️ Bạn đang có ván cờ chưa kết thúc.\n"
                    f"Vui lòng hoàn thiện ván chơi hoặc dùng:\n"
                    f"  {p}{c} lose  →  🏳 Đầu hàng\n"
                    f"  {p}{c} stop  →  🛑 Hủy (chỉ khả dụng khi chưa quá 5 nước)",
                    data, threadId, type, color="yl", title="CARO", userId=userId,
                )
                return
            thread_session = next(
                (s for s in SessionManager._sessions.values()
                 if s.thread_id == str(threadId) and s.user_id != uid),
                None,
            )
            if thread_session:
                owner = self._ctx.userName(thread_session.user_id) or thread_session.user_id
                self._reply(
                    f"⚠️ Hiện đang có người chơi trong nhóm này.\n"
                    f"Vui lòng thử lại khi ván đó kết thúc.",
                    data, threadId, type, color="yl", title="CARO", userId=userId,
                )
                return
            remaining = parts[1:]
            bot_first = "-a" in [x.lower() for x in remaining]
            lvl_parts = [x for x in remaining if x not in ("-a", "-A")]
            lvl = lvl_parts[0] if lvl_parts else ""
            if lvl in ("1", "2", "3", "4"):
                self._do_start(int(lvl), uid, session, data, threadId, type, userId,
                               bot_first=bot_first)
            elif lvl == "":
                self._do_start(3, uid, session, data, threadId, type, userId,
                               bot_first=bot_first)
            else:
                p, c = self.prefix, self.cmd
                self._reply(
                    f"Chọn mức khó:\n"
                    f"  {p}{c} start 1 (Dễ)\n"
                    f"  {p}{c} start 2 (Trung bình)\n"
                    f"  {p}{c} start 3 (Khó)\n"
                    f"  {p}{c} start 4 (Ác mộng)\n"
                    f"📍Thêm -a để bot đi trước. VD: {p}{c} start 3 -a",
                    data, threadId, type, color="or", title="CARO", userId=userId,
                )
            return

        if sub in ("1", "2", "3", "4"):
            if session:
                p, c = self.prefix, self.cmd
                self._reply(
                    f"⚠️ Bạn đang có ván cờ chưa kết thúc.\n"
                    f"Vui lòng hoàn thiện ván chơi hoặc dùng:\n"
                    f"  {p}{c} lose  →  🏳 Đầu hàng\n"
                    f"  {p}{c} stop  →  🛑 Hủy (chỉ khả dụng khi chưa quá 5 nước)",
                    data, threadId, type, color="yl", title="CARO", userId=userId,
                )
                return
            thread_session = next(
                (s for s in SessionManager._sessions.values()
                 if s.thread_id == str(threadId) and s.user_id != uid),
                None,
            )
            if thread_session:
                owner = self._ctx.userName(thread_session.user_id) or thread_session.user_id
                self._reply(
                    f"⚠️ Hiện đang có người chơi trong nhóm này ({owner}).\n"
                    f"Vui lòng thử lại khi ván đó kết thúc.",
                    data, threadId, type, color="yl", title="CARO", userId=userId,
                )
                return
            bot_first = "-a" in [x.lower() for x in parts[1:]]
            self._do_start(int(sub), uid, session, data, threadId, type, userId,
                           bot_first=bot_first)
            return

        if session and str(threadId) == session.thread_id:
            row, col = _parse_move(parts)
            if row is not None:
                if not session.is_user_turn:
                    try:
                        self._ctx.sendReaction(data, "🤔", threadId, type, 100000000)
                    except Exception:
                        pass
                    return
                _player_move(self._ctx, row, col, session, data, userId, threadId, type)
                return

        self._guide(data, threadId, type, userId)


def caroCommand(self, message, data, userId, threadId, type):
    return CaroCommand(self).run(message, data, userId, threadId, type)


def CaroReply(self, message, data, userId, threadId, type):
    uid     = str(userId)
    session = SessionManager.get(uid)
    if not session or str(threadId) != session.thread_id:
        return

    cleaned = removeMention(self, data).strip() or (getattr(message, "text", "") or "").strip()
    if not cleaned:
        return

    tokens = cleaned.split()
    arg0   = tokens[0].lower().strip()

    if arg0 in ("stop", "quit", "end"):
        _delete_old_board(self, session)
        SessionManager.remove(uid)
        self.replyMessageStyle("🛑 Ván cờ đã hủy. Không tính điểm.",
            data, threadId, type, color="yl", title="CARO", userId=userId)
        return

    if arg0 in ("lose", "surrender", "gg"):
        board = session.board
        last  = board.last_move()
        lr, lc = last if last else (-1, -1)
        name = self.userName(uid) or uid
        pts  = _calc_match_points(board, "surrender", session)
        _update_rank(self, str(threadId), uid, name, "lose", pts)
        sign = "+" if pts >= 0 else ""
        _send_board(self, board, threadId, type,
                    last_r=lr, last_c=lc, move_num=session.move_count,
                    difficulty=session.difficulty,
                    extra=f"🏳 Bạn đầu hàng! Bot thắng.\n{sign}{pts} điểm",
                    session=session, user_id=userId, is_final=True)
        SessionManager.remove(uid)
        return

    if arg0.lstrip("./!?@#$%^&*") in ("caro", "carô", "gomoku"):
        return

    if not session.is_user_turn:
        return

    row, col = _parse_move(tokens)
    if row is None:
        return

    _player_move(self, row, col, session, data, userId, str(threadId), type)


def _start_caro_cleanup(bot_instance):
    def _loop():
        while True:
            time.sleep(30)
            SessionManager.cleanup_expired()
    threading.Thread(target=_loop, daemon=True).start()


dependencies = {
    "name":        "caro",
    "permission":  0,
    "cooldown":    0,
    "description": "Chơi cờ caro với bot AI",
    "main":        caroCommand,
    "onLoad":      _start_caro_cleanup,
}