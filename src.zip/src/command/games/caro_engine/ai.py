import time, random

INF  = 10_000_000_000
GRID = 15
WIN  = 5
DIRS = [(0,1),(1,0),(1,1),(1,-1)]

# ══════════════════════════════════════════════════════════════
# SCORE CONSTANTS  (tất cả level đều dùng, level-4 scale thêm)
# ══════════════════════════════════════════════════════════════
S5       = 100_000_000
S4O      =  20_000_000   # open-4: thắng ngay lượt sau
S4B      =   1_500_000   # blocked-4
S4G      =   8_000_000   # gap-4 (X_XX, XX_X)
S3O      =     300_000   # open-3
S3G      =     150_000   # gap-3
S3B      =      15_000   # blocked-3
S2O      =       2_000
S2B      =         200
S_FORK   =  35_000_000   # double-threat (bắt buộc thắng)
S_DFORK  =  18_000_000   # 4+3 fork
S_D3     =   9_000_000   # double open-3

# Bonus mới cho level 3-4
S_CONN   =       5_000   # connectivity: liền kề quân mình
S_CENTER =       3_000   # gần trung tâm
S_VCF    = S5 * 2        # victory by continuous forced moves (chuỗi thắng tất)

# ── Board utils ───────────────────────────────────────────────

def _in_bounds(r, c):
    return 0 <= r < GRID and 0 <= c < GRID

def _get_line(board, r, c, dr, dc, length=9):
    half = length // 2
    line = []
    for k in range(-half, half + 1):
        nr, nc = r + dr * k, c + dc * k
        line.append(board[nr][nc] if _in_bounds(nr, nc) else -1)
    return line

def _score_line(line, player):
    s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
    if 'XXXXX' in s:
        return S5 * 10
    score = 0
    if '_XXXX_' in s:
        score += S4O
    for pat in ('XX_XX', 'X_XXX', 'XXX_X'):
        if pat in s:
            score += S4G
    for pat in ('_XXXX', 'XXXX_'):
        if pat in s and '_XXXX_' not in s:
            score += S4B
    if '_XXX_' in s:
        score += S3O
    for pat in ('_XX_X_', '_X_XX_', 'XX_X_', '_X_XX', '_X_X_X_', 'X_X_X'):
        if pat in s:
            score += S3G
    for pat in ('BXXX_', '_XXXB'):
        if pat in s:
            score += S3B
    if '_XX_' in s:
        score += S2O
    elif 'XX_' in s or '_XX' in s:
        score += S2B
    return score

def _is_win(board, r, c, player):
    board[r][c] = player
    for dr, dc in DIRS:
        cnt = 1
        for sign in (1, -1):
            nr, nc = r + sign*dr, c + sign*dc
            while _in_bounds(nr, nc) and board[nr][nc] == player:
                cnt += 1; nr += sign*dr; nc += sign*dc
        if cnt >= WIN:
            board[r][c] = 0
            return True
    board[r][c] = 0
    return False

# ══════════════════════════════════════════════════════════════
# THREAT ANALYSIS  (nâng cấp mạnh)
# ══════════════════════════════════════════════════════════════

def _count_threats(board, r, c, player):
    board[r][c] = player
    n4o = n4b = n4g = n3o = n3g = 0
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        if '_XXXX_' in s:
            n4o += 1
        elif any(p in s for p in ('XX_XX','X_XXX','XXX_X')):
            n4g += 1
        elif any(p in s for p in ('_XXXX','XXXX_')):
            n4b += 1
        if '_XXX_' in s:
            n3o += 1
        elif any(p in s for p in ('_XX_X_','_X_XX_','XX_X_','_X_XX')):
            n3g += 1
    board[r][c] = 0
    return n4o, n4b, n4g, n3o, n3g

def _threat_value(board, r, c, player):
    opp = 3 - player
    atk = def_ = 0
    board[r][c] = player
    for dr, dc in DIRS:
        atk += _score_line(_get_line(board, r, c, dr, dc), player)
    board[r][c] = opp
    for dr, dc in DIRS:
        def_ += _score_line(_get_line(board, r, c, dr, dc), opp)
    board[r][c] = 0
    return atk * 1.15 + def_ * 0.95

def _threat_value_v2(board, r, c, player, aggr_bonus=0.0):
    """Phiên bản mạnh hơn: cộng thêm connectivity + center bonus."""
    opp = 3 - player
    atk = def_ = 0
    board[r][c] = player
    for dr, dc in DIRS:
        atk += _score_line(_get_line(board, r, c, dr, dc), player)
    board[r][c] = opp
    for dr, dc in DIRS:
        def_ += _score_line(_get_line(board, r, c, dr, dc), opp)
    board[r][c] = 0

    # Connectivity bonus: đếm quân mình kề
    conn = 0
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if dr == 0 and dc == 0:
                continue
            nr, nc = r + dr, c + dc
            if _in_bounds(nr, nc) and board[nr][nc] == player:
                conn += S_CONN

    # Center bonus
    cx = cy = GRID // 2
    dist = abs(r - cx) + abs(c - cy)
    center_bonus = max(0, S_CENTER * (6 - dist))

    atk_coeff = 1.15 + aggr_bonus
    return atk * atk_coeff + def_ * 0.95 + conn + center_bonus

def _is_fork(board, r, c, player):
    n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
    if n4o >= 2: return True
    if n4o >= 1 and (n4b + n4g) >= 1: return True
    if (n4o + n4g) >= 2: return True
    if n4o >= 1 and n3o >= 1: return True
    if n3o >= 2: return True
    return False

def _fork_score(board, r, c, player):
    n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
    score = 0
    if n4o >= 2:              score += S_FORK
    elif n4o >= 1 and (n4b+n4g) >= 1: score += S_FORK * 0.9
    elif (n4o+n4g) >= 2:     score += S_FORK * 0.85
    elif n4o >= 1 and n3o >= 1: score += S_DFORK
    elif n3o >= 2:            score += S_D3
    elif n4o >= 1:            score += S4O * 0.8
    elif n3o >= 1 and n3g >= 1: score += S3O * 3
    # Thêm: n4b hoặc nhiều n3g cũng tính điểm
    if n4b >= 2:              score += S4B * 1.5
    if n3g >= 2:              score += S3G * 2
    return score

def _is_threat4(board, r, c, player):
    n4o, n4b, n4g, _, _ = _count_threats(board, r, c, player)
    return (n4o + n4b + n4g) >= 1

def _count_open3(board, r, c, player):
    """Đếm số hướng có open-3 sau khi đặt."""
    board[r][c] = player
    n3o = 0
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        if '_XXX_' in s:
            n3o += 1
    board[r][c] = 0
    return n3o

# ══════════════════════════════════════════════════════════════
# DANGER ZONE HEATMAP  (mới — phân tích nguy hiểm toàn bàn)
# ══════════════════════════════════════════════════════════════

def _build_danger_map(board, attacker):
    """
    Trả về dict (r,c) -> danger_score: ô nào càng nguy hiểm
    (nếu attacker đánh vào đó) thì điểm càng cao.
    Dùng để ưu tiên chặn / tấn công vùng nóng.
    """
    danger = {}
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c] == 0:
                score = 0
                for dr, dc in DIRS:
                    score += _score_line(_get_line(board, r, c, dr, dc), attacker)
                if score > 0:
                    danger[(r, c)] = score
    return danger

# ══════════════════════════════════════════════════════════════
# VCF — Victory by Continuous Forced moves (chuỗi 4 liên tiếp)
# ══════════════════════════════════════════════════════════════

def _vcf_search(board, player, depth, start_time, time_limit):
    """
    Tìm chuỗi thắng bắt buộc bằng cách liên tục tạo threat-4.
    Nếu tìm được thì trả về nước đầu tiên, ngược lại None.
    depth: số lượt tối đa (thường 10-14 lượt).
    """
    if time.time() - start_time > time_limit * 0.8:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    # Kiểm tra thắng ngay
    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    # Tìm các nước tạo threat-4
    threat4_moves = [(r, c) for r, c in cands if _is_threat4(board, r, c, player)]
    if not threat4_moves:
        return None

    for r, c in threat4_moves:
        board[r][c] = player
        # Opp phải chặn threat-4
        opp_cands = _get_candidates(board, radius=2)
        opp_blocks = [(or2, oc2) for or2, oc2 in opp_cands
                      if _is_threat4(board, or2, oc2, opp)  # opp phải chặn
                      or _is_win(board, or2, oc2, opp)]

        if not opp_blocks:
            # Opp không cần chặn → ta vẫn có threat-4 đây
            board[r][c] = 0
            return (r, c)

        # Opp phải đánh vào ít nhất 1 trong các nước chặn
        all_win = True
        for or2, oc2 in opp_blocks[:4]:  # giới hạn để không quá chậm
            board[or2][oc2] = opp
            next_move = _vcf_search(board, player, depth - 2, start_time, time_limit)
            board[or2][oc2] = 0
            if next_move is None:
                all_win = False
                break
        board[r][c] = 0
        if all_win and opp_blocks:
            return (r, c)

    return None

# ══════════════════════════════════════════════════════════════
# VCT — Victory by Continuous Threat (chuỗi open-3 → fork)
# ══════════════════════════════════════════════════════════════

def _vct_search(board, player, depth, start_time, time_limit):
    """
    Tìm chuỗi bắt buộc qua open-3 → dẫn đến fork tất yếu.
    Chậm hơn VCF, chỉ dùng cho level 4.
    """
    if time.time() - start_time > time_limit * 0.7:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    # Ưu tiên: nước nào tạo open-3 >= 2 hoặc open-3 + gap-4
    threat_moves = []
    for r, c in cands:
        n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
        if n3o >= 2 or (n3o >= 1 and (n4o + n4g) >= 1) or n4o >= 1:
            threat_moves.append((r, c, n4o * 10 + n3o * 5 + n4g * 3 + n3g))

    threat_moves.sort(key=lambda x: -x[2])

    for r, c, _ in threat_moves[:6]:
        board[r][c] = player
        if _is_fork(board, r, c, player):
            board[r][c] = 0
            return (r, c)
        # Opp phải phản ứng
        opp_cands = _get_candidates(board, radius=2)
        opp_forced = [(or2, oc2) for or2, oc2 in opp_cands
                      if _is_win(board, or2, oc2, opp)
                      or _is_fork(board, or2, oc2, opp)]

        if not opp_forced:
            opp_forced = sorted(opp_cands,
                                key=lambda rc: _threat_value(board, rc[0], rc[1], opp),
                                reverse=True)[:4]

        all_win = True
        for or2, oc2 in opp_forced[:3]:
            board[or2][oc2] = opp
            next_move = _vct_search(board, player, depth - 2, start_time, time_limit)
            board[or2][oc2] = 0
            if next_move is None:
                all_win = False
                break
        board[r][c] = 0
        if all_win:
            return (r, c)

    return None

# ══════════════════════════════════════════════════════════════
# OPENING BOOK  (vào game là phải lên chiến lược ngay)
# ══════════════════════════════════════════════════════════════

_OPENING_RESPONSES = {
    # Đối phương đánh trung tâm → ta đánh cạnh trung tâm theo góc
    (7, 7): [(6, 6), (6, 8), (8, 6), (8, 8), (7, 6), (6, 7)],
    # Đối phương đánh gần trung tâm → ta phản công tích cực
    (6, 6): [(7, 7), (7, 6), (6, 7), (8, 8)],
    (8, 8): [(7, 7), (7, 8), (8, 7), (6, 6)],
    (6, 8): [(7, 7), (6, 7), (7, 8)],
    (8, 6): [(7, 7), (7, 6), (8, 7)],
}

def _opening_book_move(board, bot_player, history_len):
    """
    Trả về nước đi từ opening book nếu còn sớm trong ván.
    Tìm nước thiết lập thế tấn công hai hướng từ sớm.
    """
    if history_len > 6:
        return None
    cx = cy = GRID // 2

    # Nước 1: đánh trung tâm
    if history_len == 0:
        return (cx, cy)

    # Nước 2 (bot đánh sau): phản công gần trung tâm
    if history_len == 1:
        opp_last = None
        for r in range(GRID):
            for c in range(GRID):
                if board[r][c] == (3 - bot_player):
                    opp_last = (r, c)
        if opp_last and opp_last in _OPENING_RESPONSES:
            candidates = _OPENING_RESPONSES[opp_last]
            for r, c in candidates:
                if board[r][c] == 0:
                    return (r, c)
        # Fallback: đánh cạnh trung tâm
        for dr, dc in [(1,1),(-1,-1),(1,-1),(-1,1),(0,1),(1,0)]:
            nr, nc = cx + dr, cy + dc
            if _in_bounds(nr, nc) and board[nr][nc] == 0:
                return (nr, nc)

    # Nước 3-6: ưu tiên xây dựng open-3 từ sớm
    if 2 <= history_len <= 5:
        cands = _get_candidates(board, radius=2)
        best = None
        best_score = -1
        for r, c in cands:
            n3o = _count_open3(board, r, c, bot_player)
            bonus = max(0, 4 - (abs(r - cx) + abs(c - cy)))
            score = n3o * 100 + bonus
            if score > best_score:
                best_score = score
                best = (r, c)
        if best and best_score > 0:
            return best

    return None

# ══════════════════════════════════════════════════════════════
# CANDIDATE GENERATION  (nâng cấp radius cho level 4)
# ══════════════════════════════════════════════════════════════

def _get_candidates(board, radius=2):
    cands = set()
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c]:
                for dr in range(-radius, radius+1):
                    for dc in range(-radius, radius+1):
                        nr, nc = r+dr, c+dc
                        if _in_bounds(nr, nc) and not board[nr][nc]:
                            cands.add((nr, nc))
    return list(cands) or [(GRID//2, GRID//2)]

def _classify_candidates(board, player, opp):
    cands = _get_candidates(board, radius=2)
    wins=[]; blk_win=[]; forks=[]; blk_fork=[]; t4=[]; blk_t4=[]; rest=[]

    for r, c in cands:
        if _is_win(board, r, c, player):
            wins.append((r, c))
        elif _is_win(board, r, c, opp):
            blk_win.append((r, c))
        elif _is_fork(board, r, c, player):
            forks.append((r, c))
        elif _is_fork(board, r, c, opp):
            blk_fork.append((r, c))
        elif _is_threat4(board, r, c, player):
            t4.append((r, c))
        elif _is_threat4(board, r, c, opp):
            blk_t4.append((r, c))
        else:
            rest.append((r, c))

    if wins:     return wins, 3
    if blk_win:  return blk_win + forks, 3
    if forks:    return forks + blk_fork + t4 + blk_t4, 2
    if blk_fork: return blk_fork + t4 + blk_t4 + rest[:6], 2
    if t4 or blk_t4: return t4 + blk_t4 + rest[:12], 1
    return rest, 0


# ══════════════════════════════════════════════════════════════
# ZOBRIST HASH
# ══════════════════════════════════════════════════════════════

import random as _rng
_rng.seed(20240101)
_ZOB = [[[_rng.getrandbits(64) for _ in range(3)] for _ in range(GRID)] for _ in range(GRID)]

def _zhash(board):
    h = 0
    for r in range(GRID):
        for c in range(GRID):
            v = board[r][c]
            if v: h ^= _ZOB[r][c][v]
    return h


# ══════════════════════════════════════════════════════════════
# FULL BOARD EVALUATION  (nâng cấp: mobility + pattern density)
# ══════════════════════════════════════════════════════════════

def _eval_board(board, bot, opp, aggr=1.15):
    ai_s = hu_s = 0
    ai_mobility = 0
    hu_mobility = 0
    cx = cy = GRID // 2

    for r in range(GRID):
        for c in range(GRID):
            p = board[r][c]
            if p == bot:
                for dr, dc in DIRS:
                    ai_s += _score_line(_get_line(board, r, c, dr, dc), bot)
                # Center proximity bonus
                dist = abs(r - cx) + abs(c - cy)
                ai_s += max(0, S_CENTER * (8 - dist))
            elif p == opp:
                for dr, dc in DIRS:
                    hu_s += _score_line(_get_line(board, r, c, dr, dc), opp)
                dist = abs(r - cx) + abs(c - cy)
                hu_s += max(0, S_CENTER * (8 - dist))

    # Mobility: số ô trống xung quanh mỗi quân
    for r in range(GRID):
        for c in range(GRID):
            p = board[r][c]
            if p == 0:
                continue
            free = 0
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    nr, nc = r + dr, c + dc
                    if _in_bounds(nr, nc) and board[nr][nc] == 0:
                        free += 1
            if p == bot:
                ai_mobility += free * S_CONN
            else:
                hu_mobility += free * S_CONN

    ai_s += ai_mobility
    hu_s += hu_mobility

    return int(ai_s * aggr - hu_s)

def _eval_board_v2(board, bot, opp, aggr=1.15):
    """
    Eval nâng cao cho level 4: cộng thêm
    - Pattern density (mật độ cụm quân)
    - Threat asymmetry penalty (phạt nếu opp có nhiều open-3 hơn)
    - 2-move lookahead bonus
    """
    base = _eval_board(board, bot, opp, aggr)

    # Threat asymmetry
    bot_open3 = sum(
        _count_open3(board, r, c, bot)
        for r in range(GRID) for c in range(GRID)
        if board[r][c] == bot
    )
    opp_open3 = sum(
        _count_open3(board, r, c, opp)
        for r in range(GRID) for c in range(GRID)
        if board[r][c] == opp
    )
    asymmetry_bonus = (bot_open3 - opp_open3) * S3O * 0.3

    # Pattern density: thưởng nếu ta có nhiều quân trong vùng 5x5 trung tâm
    cx = cy = GRID // 2
    density_bonus = 0
    for r in range(cx - 3, cx + 4):
        for c in range(cy - 3, cy + 4):
            if _in_bounds(r, c) and board[r][c] == bot:
                density_bonus += S_CENTER * 2

    return int(base + asymmetry_bonus + density_bonus)


# ══════════════════════════════════════════════════════════════
# MULTI-LAYER PRE-FORK PLANNING  (nhìn trước 3 nước)
# ══════════════════════════════════════════════════════════════

def _find_pre_fork_deep(board, player, opp, cands, start_time, time_limit, depth=3):
    """
    Tìm nước A sao cho sau khi ta đánh A và opp phản ứng tốt nhất,
    ta vẫn có thể đạt fork trong depth nước tiếp theo.
    Depth=3: nhìn 3 nước của ta.
    """
    if time.time() - start_time > time_limit * 0.6:
        return None

    top = sorted(cands,
                 key=lambda rc: _threat_value_v2(board, rc[0], rc[1], player, 0.1),
                 reverse=True)[:12]

    def can_force_fork(b, p, o, remaining, t_start):
        if remaining <= 0:
            return False
        if time.time() - t_start > time_limit * 0.7:
            return False
        my_cands = _get_candidates(b, radius=2)
        for mr, mc in my_cands[:10]:
            if _is_fork(b, mr, mc, p):
                return True
            if _is_win(b, mr, mc, p):
                return True
        if remaining <= 1:
            return False
        # Đánh 1 nước, opp đánh tốt nhất, rồi kiểm tra lại
        for mr, mc in my_cands[:8]:
            b[mr][mc] = p
            o_cands = _get_candidates(b, radius=2)
            o_best = sorted(o_cands,
                            key=lambda rc: _threat_value_v2(b, rc[0], rc[1], o, 0),
                            reverse=True)[:5]
            all_good = True
            for or2, oc2 in o_best:
                b[or2][oc2] = o
                result = can_force_fork(b, p, o, remaining - 1, t_start)
                b[or2][oc2] = 0
                if not result:
                    all_good = False
                    break
            b[mr][mc] = 0
            if all_good and o_best:
                return True
        return False

    for r, c in top:
        board[r][c] = player
        opp_cands = _get_candidates(board, radius=2)[:10]
        fork_guaranteed = True
        for or2, oc2 in opp_cands:
            board[or2][oc2] = opp
            has_path = can_force_fork(board, player, opp, depth - 1, start_time)
            board[or2][oc2] = 0
            if not has_path:
                fork_guaranteed = False
                break
        board[r][c] = 0
        if fork_guaranteed and opp_cands:
            return r, c

    return None

def _find_pre_fork(board, player, opp, cands):
    """Phiên bản cũ (1 lớp) — dùng cho level 3."""
    top = sorted(cands,
                 key=lambda rc: _threat_value(board, rc[0], rc[1], player),
                 reverse=True)[:10]

    for r, c in top:
        board[r][c] = player
        opp_cands = _get_candidates(board, radius=2)[:12]
        fork_guaranteed = True
        for or2, oc2 in opp_cands:
            board[or2][oc2] = opp
            my_next = _get_candidates(board, radius=2)
            has_fork = any(_is_fork(board, nr, nc, player) for nr, nc in my_next)
            board[or2][oc2] = 0
            if not has_fork:
                fork_guaranteed = False
                break
        board[r][c] = 0
        if fork_guaranteed:
            return r, c

    best_pre = max(top,
                   key=lambda rc: _fork_score(board, rc[0], rc[1], player),
                   default=None)
    if best_pre and _fork_score(board, best_pre[0], best_pre[1], player) >= S3O * 2:
        return best_pre
    return None


# ══════════════════════════════════════════════════════════════
# CaroAI MAIN CLASS
# ══════════════════════════════════════════════════════════════

class CaroAI:
    """
    Mức 1 – Dễ       : greedy 1-ply, random top-3, không minimax.
    Mức 2 – Trung bình: depth-4, 1.0s, fork detection cơ bản.
    Mức 3 – Khó      : depth-7, 2.5s, pre-fork 1 lớp, VCF, aggr=1.25.
    Mức 4 – Ác mộng  : depth-10, 6.0s, VCF+VCT, pre-fork 3 lớp,
                        opening book, danger map, eval_v2, aggr=1.6.
                        Bước 20 vẫn tìm được double-fork liên tiếp.
    """

    _CFG = {
        1: dict(depth=1,  time=0.3, branch=5,  aggr=1.0,  radius=2),
        2: dict(depth=4,  time=1.0, branch=14, aggr=1.08, radius=2),
        3: dict(depth=7,  time=2.5, branch=20, aggr=1.25, radius=2),
        4: dict(depth=10, time=6.0, branch=26, aggr=1.60, radius=3),
    }

    def __init__(self, difficulty=3):
        self.difficulty     = max(1, min(4, difficulty))
        cfg                 = self._CFG[self.difficulty]
        self._max_depth     = cfg['depth']
        self._time_limit    = cfg['time']
        self._branch        = cfg['branch']
        self._aggr          = cfg['aggr']
        self._radius        = cfg['radius']
        self.nodes_searched = 0
        self.start_time     = time.time()
        self._tt            = {}
        self._killers       = [[] for _ in range(40)]
        self._history       = {}

    def best_move(self, board_obj, bot_player):
        self.nodes_searched = 0
        self.start_time     = time.time()
        self._tt.clear()
        self._history.clear()
        for km in self._killers: km.clear()

        board   = [row[:] for row in board_obj.cells]
        opp     = 3 - bot_player
        history = board_obj.history if hasattr(board_obj, 'history') else []

        # ── Nước đầu tiên: trung tâm ──
        if not history:
            return GRID // 2, GRID // 2

        # ── Opening book (level 3+) ──
        if self.difficulty >= 3:
            ob = _opening_book_move(board, bot_player, len(history))
            if ob:
                return ob

        cands = _get_candidates(board, radius=self._radius)

        # ── Instant win ──
        for r, c in cands:
            if _is_win(board, r, c, bot_player):
                return r, c

        # ── Block instant loss ──
        blk_list = [(r, c) for r, c in cands if _is_win(board, r, c, opp)]
        if blk_list:
            if self.difficulty >= 3:
                # Nếu ta có fork ngay + win → thắng luôn
                for fr, fc in cands:
                    if _is_fork(board, fr, fc, bot_player) and _is_win(board, fr, fc, bot_player):
                        return fr, fc
                # Nếu phải chặn nhiều hơn 1 điểm → đối phương sắp thắng, ta cần tấn công
                if len(blk_list) >= 2:
                    # Tìm nước nào chặn được nhiều nhất và tạo counter-threat
                    best_blk = max(blk_list,
                                   key=lambda rc: _threat_value_v2(board, rc[0], rc[1], bot_player, 0.2))
                    return best_blk
            return blk_list[0]

        # ── Level 1: easy mode ──
        if self.difficulty == 1:
            return self._easy(board, bot_player, cands)

        # ══ Level 4: VCF search ══
        if self.difficulty == 4:
            vcf = _vcf_search(board, bot_player, 12, self.start_time, self._time_limit)
            if vcf:
                return vcf
            # Block opp VCF
            opp_vcf = _vcf_search(board, opp, 10, self.start_time, self._time_limit)
            if opp_vcf:
                # Kiểm tra ta có fork ngay không trước khi chặn
                fork_list = [(r, c) for r, c in cands if _is_fork(board, r, c, bot_player)]
                if fork_list:
                    best_fork = max(fork_list,
                                    key=lambda rc: _fork_score(board, rc[0], rc[1], bot_player))
                    return best_fork
                return opp_vcf

        # ══ Level 3+: VCF lite ══
        if self.difficulty == 3:
            vcf = _vcf_search(board, bot_player, 8, self.start_time, self._time_limit)
            if vcf:
                return vcf

        # ── Fork attack (level 2+) ──
        fork_cands = [(r, c) for r, c in cands if _is_fork(board, r, c, bot_player)]
        if fork_cands:
            best = max(fork_cands,
                       key=lambda rc: _fork_score(board, rc[0], rc[1], bot_player)
                                      + _threat_value_v2(board, rc[0], rc[1], bot_player,
                                                         0.2 if self.difficulty == 4 else 0.0))
            return best

        # ── Block opponent fork (level 2+) ──
        opp_forks = [(r, c) for r, c in cands if _is_fork(board, r, c, opp)]
        if opp_forks:
            if self.difficulty >= 3:
                my_t4 = [(r, c) for r, c in cands if _is_threat4(board, r, c, bot_player)]
                if my_t4:
                    best_t4 = max(my_t4,
                                  key=lambda rc: _threat_value_v2(board, rc[0], rc[1], bot_player, 0.1))
                    return best_t4
            best = max(opp_forks,
                       key=lambda rc: _threat_value(board, rc[0], rc[1], bot_player))
            return best

        # ══ Level 4: VCT search ══
        if self.difficulty == 4:
            vct = _vct_search(board, bot_player, 8, self.start_time, self._time_limit)
            if vct:
                return vct

        # ── Pre-fork planning ──
        if self.difficulty == 4:
            pre = _find_pre_fork_deep(board, bot_player, opp, cands,
                                      self.start_time, self._time_limit, depth=3)
            if pre:
                return pre
        elif self.difficulty == 3:
            pre = _find_pre_fork(board, bot_player, opp, cands)
            if pre:
                return pre

        # ══ Level 4: Danger map — ưu tiên nước nguy hiểm nhất cho opp ══
        if self.difficulty == 4:
            danger_map = _build_danger_map(board, opp)
            scored_by_danger = sorted(
                cands,
                key=lambda rc: (
                    _threat_value_v2(board, rc[0], rc[1], bot_player, 0.25)
                    + danger_map.get(rc, 0) * 0.5
                ),
                reverse=True
            )
            top = scored_by_danger[:self._branch]
        else:
            scored = sorted(cands,
                            key=lambda rc: _threat_value(board, rc[0], rc[1], bot_player),
                            reverse=True)
            top = scored[:self._branch]

        best_r, best_c = top[0]

        # ── Iterative deepening minimax ──
        for depth in range(1, self._max_depth + 1):
            if time.time() - self.start_time > self._time_limit * 0.55:
                break
            br, bc = self._root(board, top, depth, bot_player, opp)
            best_r, best_c = br, bc

        return best_r, best_c

    def stats(self):
        e = max(time.time() - self.start_time, 0.001)
        return f"{self.nodes_searched:,} nodes | {int(self.nodes_searched/e):,}/s | {e:.2f}s"

    # ── Root search ───────────────────────────────────────────

    def _root(self, board, cands, depth, player, opp):
        best_score = -INF
        best_move  = cands[0]
        alpha      = -INF
        for r, c in cands:
            if time.time() - self.start_time > self._time_limit:
                break
            board[r][c] = player
            score = self._minimax(board, depth-1, alpha, INF, False, player, opp, 1)
            board[r][c] = 0
            self.nodes_searched += 1
            if score > best_score:
                best_score = score
                best_move  = (r, c)
            alpha = max(alpha, score)
        return best_move

    # ── Minimax + alpha-beta + enhancements ──────────────────

    def _minimax(self, board, depth, alpha, beta, is_max, bot, opp, ply):
        self.nodes_searched += 1

        if time.time() - self.start_time > self._time_limit:
            if self.difficulty == 4:
                return _eval_board_v2(board, bot, opp, self._aggr)
            return _eval_board(board, bot, opp, self._aggr)

        zh = _zhash(board)
        tt = self._tt.get(zh)
        if tt and tt[0] >= depth:
            _, flag, val = tt
            if flag == 0: return val
            if flag == 1: alpha = max(alpha, val)
            elif flag == 2: beta = min(beta, val)
            if alpha >= beta: return val

        if depth == 0:
            if self.difficulty == 4:
                return _eval_board_v2(board, bot, opp, self._aggr)
            return _eval_board(board, bot, opp, self._aggr)

        player = bot if is_max else opp
        enemy  = opp if is_max else bot

        tcands, tlv = _classify_candidates(board, player, enemy)

        if tlv == 3:
            cands = tcands[:5]
        elif tlv >= 1 and depth <= 2:
            cands = tcands[:10]
        else:
            raw = _get_candidates(board, radius=self._radius if depth >= 3 else 2)
            km  = self._killers[ply] if ply < len(self._killers) else []
            if self.difficulty == 4:
                raw.sort(key=lambda rc:
                         _threat_value_v2(board, rc[0], rc[1], player, 0.1)
                         + (800_000 if rc in km else 0)
                         + self._history.get(rc, 0),
                         reverse=True)
            else:
                raw.sort(key=lambda rc:
                         _threat_value(board, rc[0], rc[1], player)
                         + (800_000 if rc in km else 0)
                         + self._history.get(rc, 0),
                         reverse=True)
            # Level 4: giới hạn rộng hơn để tìm sâu hơn
            if self.difficulty == 4:
                lim = {10:4, 9:5, 8:6, 7:7, 6:8, 5:10, 4:12, 3:14, 2:18, 1:22}.get(depth, 12)
            else:
                lim = {7:5, 6:6, 5:8, 4:10, 3:12, 2:16, 1:20}.get(depth, 12)
            cands = raw[:lim]

        # Immediate win shortcut
        for r, c in cands:
            if _is_win(board, r, c, player):
                return (S5 + ply * 1000) * (1 if is_max else -1)

        # Level 3-4: nút max có fork ngay → return sớm
        if is_max and self.difficulty >= 3:
            for r, c in cands:
                if _is_fork(board, r, c, player):
                    fs = _fork_score(board, r, c, player)
                    threshold = S_D3 if self.difficulty == 3 else S3O * 3
                    if fs >= threshold:
                        return fs

        # Level 4: nút min có fork ngay → cũng xét (đối phương có fork là nguy hiểm)
        if not is_max and self.difficulty == 4:
            for r, c in cands:
                if _is_fork(board, r, c, player):
                    fs = _fork_score(board, r, c, player)
                    if fs >= S_D3:
                        return -fs

        best      = -INF if is_max else INF
        orig_alpha = alpha

        for r, c in cands:
            board[r][c] = player
            val = self._minimax(board, depth-1, alpha, beta, not is_max, bot, opp, ply+1)
            board[r][c] = 0

            if is_max:
                if val > best: best = val
                alpha = max(alpha, best)
            else:
                if val < best: best = val
                beta = min(beta, best)

            if beta <= alpha:
                km = self._killers[ply]
                if (r, c) not in km:
                    km.insert(0, (r, c))
                    if len(km) > 3: km.pop()
                self._history[(r, c)] = self._history.get((r, c), 0) + 2**depth
                break

            if time.time() - self.start_time > self._time_limit:
                break

        flag = 0 if orig_alpha < best < beta else (1 if best >= beta else 2)
        tt_limit = 200_000 if self.difficulty == 4 else 120_000
        if len(self._tt) < tt_limit:
            self._tt[zh] = (depth, flag, best)

        return best

    # ── Easy mode ─────────────────────────────────────────────

    def _easy(self, board, player, cands):
        scored = []
        for r, c in cands:
            board[r][c] = player
            s = sum(_score_line(_get_line(board, r, c, dr, dc), player) for dr, dc in DIRS)
            board[r][c] = 0
            scored.append((s, r, c))
        scored.sort(reverse=True)
        _, r, c = random.choice(scored[:3])
        return r, c
