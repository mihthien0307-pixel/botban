import os, sys, time, threading

TURN_TIMEOUT = 120

DIFFICULTY_NAMES = {
    1: "🟢 Dễ",
    2: "🟡 Trung bình",
    3: "🔴 Khó",
    4: "💀 Ác mộng",
}


def _load_module(mod_key, filename):
    m = sys.modules.get(mod_key)
    if m:
        return m
    import importlib.util
    _dir = os.path.dirname(os.path.abspath(__file__))
    _path = os.path.join(_dir, filename)
    spec = importlib.util.spec_from_file_location(mod_key, _path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mod_key] = mod
    spec.loader.exec_module(mod)
    return mod


def _get_Board():
    return _load_module("games.caro_engine.board", "board.py").Board

def _get_CaroAI():
    return _load_module("games.caro_engine.ai", "ai.py").CaroAI


class CaroSession:
    def __init__(self, user_id, thread_id, thread_type, difficulty,
                 msg_id=None, cli_msg_id=None):
        Board = _get_Board()
        CaroAI = _get_CaroAI()
        self.board = Board()
        self.ai = CaroAI(difficulty=difficulty)
        self.user_id = str(user_id)
        self.thread_id = str(thread_id)
        self.thread_type = thread_type
        self.msg_id = msg_id
        self.cli_msg_id = cli_msg_id
        self.last_active = time.time()
        self.difficulty = difficulty
        self.human_player = 1
        self.bot_player = 2
        self.is_user_turn = True
        self.move_count = 0

    def touch(self):
        self.last_active = time.time()

    def is_expired(self):
        return time.time() - self.last_active > TURN_TIMEOUT


class SessionManager:
    _lock = threading.Lock()
    _sessions = {}

    @classmethod
    def get(cls, user_id):
        return cls._sessions.get(str(user_id))

    @classmethod
    def create(cls, user_id, thread_id, thread_type, difficulty,
               msg_id=None, cli_msg_id=None):
        with cls._lock:
            sess = CaroSession(user_id, thread_id, thread_type, difficulty,
                               msg_id, cli_msg_id)
            cls._sessions[str(user_id)] = sess
            return sess

    @classmethod
    def remove(cls, user_id):
        with cls._lock:
            cls._sessions.pop(str(user_id), None)

    @classmethod
    def cleanup_expired(cls):
        with cls._lock:
            expired = [uid for uid, s in cls._sessions.items() if s.is_expired()]
            for uid in expired:
                cls._sessions.pop(uid, None)
        return expired
