"""
money.py  –  Quản lý ví tiền game cho zbot
Đặt tại: src/command/games/money.py

Lệnh người dùng:
  !money / !vitien          → xem số dư
  !money @tag               → xem số dư người khác
  !money daily              → điểm danh nhận tiền (1 lần/ngày)
  !money transfer @tag 50k  → chuyển tiền
  !money addme 100k         → tự thêm tiền cho chính mình (owner bot only)

Lệnh admin bot (permission >= 2):
  !money add @tag 100k      → cộng tiền
  !money sub @tag 100k      → trừ tiền
  !money set @tag 500k      → đặt số dư
  !money reset @tag         → reset về mặc định

Dùng chung wallet JSON với baucua.py tại data/config/baucua/
"""
from app.core.index import *
from app.module.commandLoader import removeMention
import os, json, re, threading, time
from datetime import datetime, date

# ── Hằng số ───────────────────────────────────────────────────────────────────
DATA_DIR      = "data/config/baucua"
INIT_BALANCE  = 500_000        # số dư khởi điểm
DAILY_REWARD  = 200_000        # nhận mỗi ngày
TRANSFER_FEE  = 0.02           # phí chuyển tiền 2%
MIN_TRANSFER  = 1_000

_lock = threading.Lock()
os.makedirs(DATA_DIR, exist_ok=True)

# ── Wallet helpers (dùng chung với baucua.py) ─────────────────────────────────
def _wallet_path(uid: str) -> str:
    return os.path.join(DATA_DIR, f"wallet_{uid}.json")

def _load_wallet(uid: str) -> dict:
    try:
        with open(_wallet_path(uid), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_wallet(uid: str, data: dict):
    with _lock:
        with open(_wallet_path(uid), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

def _get_balance(uid: str) -> int:
    return int(_load_wallet(uid).get("balance", INIT_BALANCE))

def _set_balance(uid: str, amount: int):
    w = _load_wallet(uid)
    w["balance"] = max(0, amount)
    _save_wallet(uid, w)

def _add_balance(uid: str, delta: int) -> int:
    w = _load_wallet(uid)
    new = max(0, int(w.get("balance", INIT_BALANCE)) + delta)
    w["balance"] = new
    _save_wallet(uid, w)
    return new

# ── Format ────────────────────────────────────────────────────────────────────
def _fmt(n: int) -> str:
    return f"{int(n):,}".replace(",", ".")

def _parse_amount(raw: str, balance: int) -> int | None:
    raw = raw.lower().strip()
    if raw in ("all", "allin"):
        return balance
    try:
        if raw.endswith("%"):
            return int(balance * float(raw[:-1]) / 100)
        if raw.endswith("b"):
            return int(float(raw[:-1]) * 1_000_000_000)
        if raw.endswith("m"):
            return int(float(raw[:-1]) * 1_000_000)
        if raw.endswith("k"):
            return int(float(raw[:-1]) * 1_000)
        return int(raw)
    except Exception:
        return None

# ── Daily ─────────────────────────────────────────────────────────────────────
def _can_claim_daily(uid: str) -> tuple[bool, str]:
    """Trả về (có thể nhận, thông báo nếu không)."""
    w = _load_wallet(uid)
    last = w.get("last_daily")
    if not last:
        return True, ""
    try:
        last_date = date.fromisoformat(last)
        if last_date >= date.today():
            return False, f"Đã điểm danh hôm nay rồi. Quay lại ngày mai nhé!"
    except Exception:
        pass
    return True, ""

def _do_claim_daily(uid: str) -> int:
    w = _load_wallet(uid)
    bal = int(w.get("balance", INIT_BALANCE))
    new = bal + DAILY_REWARD
    w["balance"] = new
    w["last_daily"] = date.today().isoformat()
    _save_wallet(uid, w)
    return new

# ── Command ───────────────────────────────────────────────────────────────────
def moneyCommand(self, message, data, userId, threadId, type):
    uid   = str(getattr(data, "uidFrom", userId) or userId)
    name  = str(getattr(data, "dName", "") or "Bạn")
    p     = getattr(self, "prefix", ".")
    content = removeMention(self, data).strip()
    content = re.sub(r"^[!./](?:money|vitien)\s*", "", content, flags=re.IGNORECASE).strip()

    # Lấy danh sách uid được mention (nếu có)
    mentioned_uids = extractUids(data)
    target_uid  = mentioned_uids[0] if mentioned_uids else None

    from api.util.Enum import ThreadType as _TT
    is_group = (type == _TT.GROUP)

    def reply(text: str):
        self.send(Message(text=text), threadId, type)

    def reply_style(text: str, color: str = "gr", title: str = ""):
        self.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title,
        )

    def reply_style_uid(text: str, color: str, title: str):
        self.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title, userId=userId,
        )

    def mention_reply(text: str, m_uid: str, m_name: str):
        if is_group:
            self.send(
                Message(text=text, mention=Mention(str(m_uid), length=len(m_name)+1, offset=0)),
                threadId, type,
            )
        else:
            self.send(Message(text=text), threadId, type)

    # Tách token đầu
    tokens = content.split()
    cmd = tokens[0].lower() if tokens else ""

    # ── Điểm danh ─────────────────────────────────────────────────────────────
    if cmd in ("daily", "diemdanh", "claim", "dd"):
        ok, msg = _can_claim_daily(uid)
        if not ok:
            reply(f"⏰ {msg}")
            return
        new_bal = _do_claim_daily(uid)
        reply_style(
            f"🎁 Nhận: +{_fmt(DAILY_REWARD)} VNĐ\n"
            f"💼 Số dư mới: {_fmt(new_bal)} VNĐ",
            color="gr", title="ĐIỂM DANH THÀNH CÔNG",
        )
        return

    # ── Tự add tiền cho chính mình (chỉ owner bot) ────────────────────────────
    if cmd in ("addme", "naptien", "napme"):
        # Chỉ owner bot (level >= 3: HIGH_ADMIN hoặc DEVELOPER) mới dùng được
        user_level = self.permissionLevel(str(userId), str(threadId))
        if user_level < 3:
            reply("❌ Lệnh này chỉ dành cho chủ bot (High Admin / Developer).")
            return

        amt_raw = tokens[1] if len(tokens) >= 2 else None
        if not amt_raw:
            reply(f"❌ Cú pháp: {p}money addme [số tiền]\nVí dụ: {p}money addme 500k")
            return

        my_bal = _get_balance(uid)
        amt = _parse_amount(amt_raw, my_bal)
        if amt is None or amt <= 0:
            reply(f"❌ Số tiền không hợp lệ: '{amt_raw}'")
            return

        new_bal = _add_balance(uid, amt)
        reply_style(
            f"💰 Đã nạp: +{_fmt(amt)} VNĐ\n"
            f"💼 Số dư mới: {_fmt(new_bal)} VNĐ",
            color="gr", title="NẠP TIỀN THÀNH CÔNG",
        )
        return

    # ── Chuyển tiền ───────────────────────────────────────────────────────────
    if cmd in ("transfer", "chuyen", "send", "ct"):
        if not target_uid:
            reply("❌ Cú pháp: !money transfer @người 50k")
            return
        if target_uid == uid:
            reply("❌ Không thể chuyển tiền cho chính mình.")
            return
        # Tìm số tiền trong tokens (bỏ token mention)
        amt_raw = None
        for t in tokens[1:]:
            if not t.startswith("@") and not re.match(r"^\d+$", t[:1] + "0") == None or re.match(r"^\d", t):
                if re.match(r"^\d", t) or t.lower() in ("all", "allin"):
                    amt_raw = t
                    break
        if not amt_raw:
            # thử lấy token cuối
            for t in reversed(tokens[1:]):
                if re.match(r"^[\d]", t) or t.lower() in ("all", "allin"):
                    amt_raw = t
                    break
        if not amt_raw:
            reply("❌ Cú pháp: !money transfer @người 50k")
            return
        my_bal = _get_balance(uid)
        amt = _parse_amount(amt_raw, my_bal)
        if amt is None or amt <= 0:
            reply(f"❌ Số tiền không hợp lệ: '{amt_raw}'")
            return
        if amt < MIN_TRANSFER:
            reply(f"❌ Chuyển tối thiểu {_fmt(MIN_TRANSFER)} VNĐ.")
            return
        fee = int(amt * TRANSFER_FEE)
        total_deduct = amt + fee
        if total_deduct > my_bal:
            reply(f"❌ Số dư không đủ (cần {_fmt(total_deduct)} VNĐ gồm phí {_fmt(fee)} VNĐ, bạn có {_fmt(my_bal)} VNĐ).")
            return
        new_my  = _add_balance(uid, -total_deduct)
        new_tgt = _add_balance(target_uid, amt)
        reply_style(
            f"💸 Gửi: {_fmt(amt)} VNĐ  |  Phí: {_fmt(fee)} VNĐ\n"
            f"💼 Số dư của bạn: {_fmt(new_my)} VNĐ",
            color="gr", title="CHUYỂN TIỀN THÀNH CÔNG",
        )
        return

    # ── Admin: add / sub / set / reset ────────────────────────────────────────
    if cmd in ("add", "sub", "set", "reset", "give", "take"):
        # Kiểm tra quyền admin bot (>= 2)
        user_level = self.permissionLevel(str(userId), str(threadId))
        if user_level < 2:
            reply("❌ Lệnh này chỉ dành cho Admin Bot.")
            return
        if not target_uid:
            reply(f"❌ Cú pháp: !money {cmd} @người [số tiền]")
            return
        tgt_bal = _get_balance(target_uid)

        if cmd == "reset":
            _set_balance(target_uid, INIT_BALANCE)
            reply(f"✅ Đã reset số dư về {_fmt(INIT_BALANCE)} VNĐ.")
            return

        # Cần số tiền
        amt_raw = tokens[-1] if len(tokens) >= 2 else None
        if not amt_raw or not re.match(r"^[\d]", amt_raw):
            reply(f"❌ Cú pháp: !money {cmd} @người [số tiền]")
            return
        amt = _parse_amount(amt_raw, tgt_bal)
        if amt is None or amt < 0:
            reply(f"❌ Số tiền không hợp lệ.")
            return

        if cmd in ("add", "give"):
            new_bal = _add_balance(target_uid, amt)
            reply(f"✅ Cộng {_fmt(amt)} VNĐ → số dư mới: {_fmt(new_bal)} VNĐ")
        elif cmd in ("sub", "take"):
            new_bal = _add_balance(target_uid, -amt)
            reply(f"✅ Trừ {_fmt(amt)} VNĐ → số dư mới: {_fmt(new_bal)} VNĐ")
        elif cmd == "set":
            _set_balance(target_uid, amt)
            reply(f"✅ Đặt số dư thành {_fmt(amt)} VNĐ.")
        return

    # ── Help ──────────────────────────────────────────────────────────────────
    if cmd in ("help", "huongdan", "hd", "?"):
        reply_style(
            f"{p}money               → Xem số dư\n"
            f"{p}money @ai           → Xem số dư người khác\n"
            f"{p}money daily         → Điểm danh (+{_fmt(DAILY_REWARD)} VNĐ/ngày)\n"
            f"{p}money transfer @ai 50k → Chuyển tiền (phí 2%)\n"
            f"{p}money addme 100k    → Tự nạp tiền (chỉ chủ bot)\n"
            f"\n👑 Admin bot:\n"
            f"{p}money add @ai 100k  → Cộng tiền\n"
            f"{p}money sub @ai 50k   → Trừ tiền\n"
            f"{p}money set @ai 1m    → Đặt số dư\n"
            f"{p}money reset @ai     → Reset về {_fmt(INIT_BALANCE)} VNĐ",
            color="yl", title="MONEY — HƯỚNG DẪN",
        )
        return

    # ── Xem số dư (mặc định) ──────────────────────────────────────────────────
    check_uid  = target_uid if target_uid else uid
    check_name = name if check_uid == uid else f"UID {check_uid}"
    bal = _get_balance(check_uid)

    # Kiểm tra daily còn không
    can_daily, _ = _can_claim_daily(uid) if check_uid == uid else (False, "")
    daily_hint = f"\n💡 Gõ {p}money daily để nhận thêm tiền!" if can_daily and check_uid == uid else ""

    if check_uid == uid:
        reply_style_uid(
            f"💰 Số dư: {_fmt(bal)} VNĐ{daily_hint}",
            color="gr", title="VÍ TIỀN GAME",
        )
    else:
        reply_style(
            f"💰 Số dư: {_fmt(bal)} VNĐ",
            color="gr", title=f"VÍ TIỀN — {check_name}",
        )


dependencies = {
    "name":        "money",
    "aliases":     ["vitien"],
    "permission":  0,
    "cooldown":    1,
    "description": "Quản lý ví tiền game – xem số dư, điểm danh, chuyển tiền, tự nạp (chủ bot)",
    "main":        moneyCommand,
}
