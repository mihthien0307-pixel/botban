"""
ckg.py – Rải link nhóm chính khi bot được tag trong bất kỳ nhóm nào.

Cú pháp:
  .ckg            — Xem trạng thái
  .ckg set now    — Set nhóm hiện tại làm nhóm chính
  .ckg init       — Gửi link đến tất cả nhóm ngay
  .ckg start      — Rải link (delay 3s/nhóm) dạng card
  .ckg preview    — Test gửi link vào nhóm này (card ảnh)
  .ckg stop       — Dừng rải
  .ckg clear      — Xoá nhóm chính
  .ckg list       — Danh sách nhóm đang bật/tắt rải
  .ckg rm <số>    — Tắt rải nhóm theo số thứ tự trong list
  .ckg add <số>   — Bật lại rải nhóm đã tắt

Listener (tự động):
  Khi CHỦ NHÓM hoặc PHÓ NHÓM tag bot → tag lại tên họ + card ảnh + link nhóm chính.
  Thành viên thường tag → bỏ qua.
  Mỗi nhóm chỉ trả 1 lần (anti-spam).
"""

from app.core.index import *
from api.util.msg import Message, Mention
from api.util.Enum import ThreadType
import time
import threading
import os
import requests

# ── Config ──────────────────────────────────────────────────────────────────────
_DELAY_PER_GROUP = 3
_IMG_CACHE_DIR   = "data/assets/cache/image/ckg"
os.makedirs(_IMG_CACHE_DIR, exist_ok=True)

# ── Anti-spam: mỗi nhóm chỉ trả link đúng 1 lần ───────────────────────────────
_replied_lock = threading.Lock()
_replied_set: set = set()   # (bot_uid, threadId_B) đã trả rồi

# ── Đang rải ────────────────────────────────────────────────────────────────────
_spreading: dict = {}
_spread_lock = threading.Lock()


# ══════════════════════════════════════════════════════════════════════════════
# Settings helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_ckg(uid: str) -> dict:
    return read_settings(uid).get("ckg", {})

def _save_ckg(uid: str, ckg: dict):
    s = read_settings(uid)
    s["ckg"] = ckg
    write_settings(uid, s)

def _get_main_group(uid: str) -> str:
    return _get_ckg(uid).get("mainGroup", "")

def _inc_sent(uid: str, n: int = 1):
    s = read_settings(uid)
    ckg = s.setdefault("ckg", {})
    ckg["sentCount"] = ckg.get("sentCount", 0) + n
    write_settings(uid, s)

def _inc_crossed(uid: str, n: int = 1):
    s = read_settings(uid)
    ckg = s.setdefault("ckg", {})
    ckg["crossedCount"] = ckg.get("crossedCount", 0) + n
    write_settings(uid, s)

def _reset_counts(uid: str):
    s = read_settings(uid)
    ckg = s.setdefault("ckg", {})
    ckg["sentCount"]    = 0
    ckg["crossedCount"] = 0
    write_settings(uid, s)

# ── Disabled groups (danh sách nhóm tắt rải) ────────────────────────────────
def _get_disabled_groups(uid: str) -> list:
    """Trả về list group_id đã bị tắt rải."""
    return list(_get_ckg(uid).get("disabledGroups", []))

def _set_disabled_groups(uid: str, lst: list):
    s = read_settings(uid)
    ckg = s.setdefault("ckg", {})
    ckg["disabledGroups"] = list(lst)
    write_settings(uid, s)


# ══════════════════════════════════════════════════════════════════════════════
# Group helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_all_group_ids(this) -> list:
    try:
        groups = this.fetchAllGroups()
        return [str(g) for g in (getattr(groups, "gridVerMap", None) or {}).keys()]
    except Exception:
        return []

def _get_group_info_raw(this, gid: str) -> dict:
    try:
        gi   = this.fetchGroupInfo(str(gid))
        info = getattr(gi, "gridInfoMap", {}) or {}
        g    = info.get(str(gid)) or {}
        return dict(g) if isinstance(g, dict) else {}
    except Exception:
        return {}

def _get_group_name(this, gid: str) -> str:
    info = _get_group_info_raw(this, gid)
    return str(info.get("name") or gid)

def _get_group_avatar_url(this, gid: str) -> str:
    try:
        gi   = this.fetchGroupInfo(str(gid))
        info = getattr(gi, "gridInfoMap", {}) or {}
        g    = info.get(str(gid)) or {}
        avt_raw  = g.get("avt", "")
        full_avt = g.get("fullAvt", "")
        raw = full_avt or avt_raw or g.get("avatar") or g.get("avatarUrl") or ""
    except Exception:
        return ""
    if not raw:
        return ""
    url = raw.split('?')[0]
    return url

def _get_group_link(this, gid: str) -> str:
    try:
        resp = this.getGroupLink(str(gid))
        if resp.get("error_code") == 0:
            d = resp.get("data", {})
            if isinstance(d, dict) and d.get("enabled", 1):
                return str(d.get("link", ""))
        return ""
    except Exception:
        return ""

def _is_admin_or_owner(this, userId: str, threadId: str) -> bool:
    """Kiểm tra userId có phải chủ nhóm hoặc phó nhóm không."""
    try:
        info = _get_group_info_raw(this, str(threadId))
        creator_id = str(info.get("creatorId", "") or "")
        admin_ids  = [str(x) for x in (info.get("adminIds") or [])]
        uid_str    = str(userId)
        return uid_str == creator_id or uid_str in admin_ids
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Image helpers
# ══════════════════════════════════════════════════════════════════════════════

def _utf16_len(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2

def _download_avatar(avatar_url: str, gid: str) -> str:
    if not avatar_url:
        return ""
    path = os.path.join(_IMG_CACHE_DIR, f"avt_{gid}.jpg")
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < 600:
            return path
        r = requests.get(avatar_url, timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200:
            with open(path, "wb") as f:
                f.write(r.content)
            return path
    except Exception as e:
        print(f"[ckg avt] gid={gid} Exception: {e}")
    return ""

def _build_msg(text: str, tag_uid: str = None, this=None):
    """Tạo Message với mention đúng UTF-16 offset + màu vàng cho @tag."""
    import json as _json
    if tag_uid and this:
        tag_name  = this.userName(tag_uid) or str(tag_uid)
        tag_str   = f"@{tag_name}"
        tag_len   = _utf16_len(tag_str)
        full_text = f"{tag_str}\n{text}"
        mention   = Mention(tag_uid, offset=0, length=tag_len)
        styles = [{"start": 0, "len": tag_len, "st": "c_f7b503,b"}]
        style_str = _json.dumps({"styles": styles, "ver": 0})
        return Message(text=full_text, mention=mention, style=style_str)
    return Message(text=text)

def _send_card_to_group(this, gid_dest: str, link: str, group_name: str,
                        avt_url: str, text: str, tag_uid: str = None) -> bool:
    """
    Gửi dạng CARD (sendLink với thumbnailUrl = URL ảnh) vào nhóm gid_dest.
    Nếu có tag_uid thì tag tên người đó vào desc.
    Fallback sang text nếu lỗi.
    """
    # Nếu có tag_uid, thêm tên vào đầu desc
    desc_text = text
    if tag_uid and this:
        tag_name = this.userName(tag_uid) or str(tag_uid)
        desc_text = f"✅ Trả: {tag_name}\n{text}"

    try:
        this.sendLink(
            linkUrl=link,
            title=group_name,
            threadId=str(gid_dest),
            type=ThreadType.GROUP,
            desc=desc_text,
            thumbnailUrl=avt_url if avt_url else None,
        )
        return True
    except Exception as e:
        print(f"[ckg] sendLink lỗi {gid_dest}: {e}")

    # Fallback: text thường
    try:
        msg = _build_msg(desc_text, tag_uid, this)
        this.send(msg, gid_dest, ThreadType.GROUP)
    except Exception as e2:
        print(f"[ckg] send text fallback lỗi {gid_dest}: {e2}")
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Reply helpers
# ══════════════════════════════════════════════════════════════════════════════

def _reply_ok(this, text, data, threadId, type, userId=None):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="CKG", userId=userId)

def _reply_warn(this, text, data, threadId, type, userId=None):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="CKG", userId=userId)

def _reply_err(this, text, data, threadId, type, userId=None):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="CKG", userId=userId)

def _reply_info(this, text, data, threadId, type, userId=None):
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="CKG", userId=userId)


# ══════════════════════════════════════════════════════════════════════════════
# Status & text builders
# ══════════════════════════════════════════════════════════════════════════════

def _status_text(uid: str, this=None) -> str:
    ckg     = _get_ckg(uid)
    mg      = ckg.get("mainGroup", "")
    mg_name = ckg.get("mainGroupName", "Chưa đặt") if mg else "Chưa đặt"
    sent    = ckg.get("sentCount", 0)
    crossed = ckg.get("crossedCount", 0)
    timer_m = ckg.get("timerMinutes", 0)
    disabled = _get_disabled_groups(uid)
    with _spread_lock:
        spreading = uid in _spreading
    p = getattr(this, "prefix", ".") if this else "."
    c = (getattr(this, "rawCommand", None) or getattr(this, "commandName", "ckg")) if this else "ckg"
    lines = [
        f"🏠 Nhóm chính: {mg_name}",
        f"📤 Đã gửi: {sent} nhóm | 🔁 Đã chéo: {crossed} nhóm",
        f"🚫 Nhóm tắt rải: {len(disabled)}",
    ]
    if timer_m:
        lines += [f"⏱ Tự rải: {timer_m} phút/lần"]
    if spreading:
        lines += ["🟢 Đang rải..."]
    lines += [
        "",
        f"{p}{c} set now      — set nhóm này làm nhóm chính",
        f"{p}{c} init         — gửi đến tất cả nhóm ngay",
        f"{p}{c} start        — rải link (delay 3s/nhóm)",
        f"{p}{c} preview      — test gửi vào nhóm này",
        f"{p}{c} list         — danh sách nhóm bật/tắt rải",
        f"{p}{c} rm <số>      — tắt rải nhóm theo số",
        f"{p}{c} add <số>     — bật lại rải nhóm đã tắt",
        f"{p}{c} timer 30m    — tự rải mỗi 30 phút",
        f"{p}{c} timer off    — tắt tự rải",
        f"{p}{c} stop         — dừng rải thủ công",
        f"{p}{c} clear        — xoá nhóm chính",
    ]
    return "\n".join(l for l in lines if l is not None)

def _build_ckg_text(main_name: str, link: str) -> str:
    return (f"↩️ Chéo tag trả nha.\n"
            f"👉 Tham gia: {main_name}\n"
            f"Tag = trả, phạm luật đừng kick tội iem=(\n"
            f"🏠 {main_name}\n"
            f"{link}")


# ══════════════════════════════════════════════════════════════════════════════
# List / rm / add helpers
# ══════════════════════════════════════════════════════════════════════════════

def _build_list_text(this, uid: str) -> str:
    """Tạo text danh sách nhóm đang bật/tắt rải."""
    all_gids  = _get_all_group_ids(this)
    main_gid  = _get_main_group(uid)
    disabled  = _get_disabled_groups(uid)
    lines     = ["📋 Danh sách nhóm rải:\n"]
    for i, gid in enumerate(all_gids, 1):
        if gid == main_gid:
            continue  # bỏ nhóm chính khỏi list
        name   = _get_group_name(this, gid)
        status = "🔴 (đã tắt rải nhóm này)" if gid in disabled else "🟢 (đang bật rải nhóm này)"
        lines.append(f"{i}. {name} {status}")
    if len(lines) == 1:
        lines.append("(Không có nhóm nào)")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# Spread worker  — dùng card (sendLink) thay vì ảnh thô
# ══════════════════════════════════════════════════════════════════════════════

def _spread_worker(this, main_gid: str, main_name: str, avt_url: str,
                   group_ids: list, stop_event: threading.Event,
                   uid: str,
                   src_thread=None, src_data=None, src_type=None):
    link = _get_group_link(this, main_gid)
    if not link:
        if src_thread:
            try:
                this.replyMessageStyle("❌ Không lấy được link nhóm chính.",
                                       src_data, src_thread, src_type,
                                       color="r", title="CKG")
            except Exception:
                pass
        with _spread_lock:
            _spreading.pop(uid, None)
        return

    text     = _build_ckg_text(main_name, link)
    disabled = _get_disabled_groups(uid)
    sent = fail = skipped = 0

    for gid in group_ids:
        if stop_event.is_set():
            break
        if gid == main_gid:
            continue
        if gid in disabled:
            skipped += 1
            continue
        try:
            _send_card_to_group(this, gid, link, main_name, avt_url, text, tag_uid=None)
            sent += 1
            _inc_sent(uid)
        except Exception as e:
            print(f"[ckg spread] {gid}: {e}")
            fail += 1
        time.sleep(_DELAY_PER_GROUP)

    with _spread_lock:
        _spreading.pop(uid, None)

    if src_thread:
        try:
            result = f"✅ Rải xong!\nĐã gửi: {sent} nhóm"
            if skipped:
                result += f"\nBỏ qua (tắt): {skipped} nhóm"
            if fail:
                result += f"\nThất bại: {fail} nhóm"
            this.replyMessageStyle(result, src_data, src_thread, src_type,
                                   color="gr", title="CKG")
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# Listener – tự trả khi bot bị tag (chỉ chủ/phó nhóm)
# ══════════════════════════════════════════════════════════════════════════════

def ckgListener(this, message, data, userId, threadId, type):
    """
    Khi bot bị @tag trong nhóm:
      → Chỉ trả nếu người tag là CHỦ NHÓM hoặc PHÓ NHÓM.
      → Gửi card (sendLink) kèm tên người tag vào nhóm chính.
      → Mỗi nhóm chỉ trả 1 lần.
    """
    if type != ThreadType.GROUP:
        return

    bot_uid = str(getattr(this, "uid", "") or "")

    if str(userId) == bot_uid:
        return

    # Kiểm tra bot có trong mentions không
    mentions = getattr(data, "mentions", None)
    if not mentions:
        return
    try:
        if isinstance(mentions, str):
            import json as _j
            mentions = _j.loads(mentions)
        tagged_uids = [str(m.get("uid", "")) for m in (mentions or [])
                       if m.get("uid") and str(m.get("uid")) != "-1"]
    except Exception:
        return

    if bot_uid not in tagged_uids:
        return

    # ── Chỉ xử lý nếu người tag là chủ hoặc phó nhóm ─────────────────────
    if not _is_admin_or_owner(this, str(userId), str(threadId)):
        # Thành viên thường → bỏ qua
        return

    # Lấy nhóm chính
    main_gid = _get_main_group(bot_uid)
    if not main_gid:
        return

    if str(threadId) == str(main_gid):
        return

    # Anti-spam
    reply_key = (bot_uid, str(threadId))
    with _replied_lock:
        if reply_key in _replied_set:
            return
        _replied_set.add(reply_key)

    def _auto_reply():
        ok = False
        try:
            # Lấy link nhóm B (nhóm đang bị tag)
            link_b = _get_group_link(this, str(threadId))
            if not link_b:
                with _replied_lock:
                    _replied_set.discard(reply_key)
                return

            name_b  = _get_group_name(this, str(threadId))
            avt_b   = _get_group_avatar_url(this, str(threadId))
            text_b  = _build_ckg_text(name_b, link_b)

            # Tên người tag
            tagger_name = this.userName(str(userId)) or str(userId)

            # desc bao gồm tên người tag
            desc_with_tag = f"✅ Trả: {tagger_name}\n{text_b}"

            # Gửi card về nhóm chính (A)
            this.sendLink(
                linkUrl=link_b,
                title=name_b,
                threadId=str(main_gid),
                type=ThreadType.GROUP,
                desc=desc_with_tag,
                thumbnailUrl=avt_b if avt_b else None,
            )
            ok = True
            _inc_crossed(bot_uid)

            # React ✅ vào tin nhắn tag để báo đã xử lý
            try:
                this.sendReaction(data, "✅", str(threadId), ThreadType.GROUP, 100000000)
            except Exception:
                pass
        except Exception as e:
            print(f"[ckg listener] Lỗi: {e}")
        finally:
            if not ok:
                with _replied_lock:
                    _replied_set.discard(reply_key)

    threading.Thread(target=_auto_reply, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
# Command handler
# ══════════════════════════════════════════════════════════════════════════════

def ckgCommand(this, message, data, userId, threadId, type):
    raw  = (getattr(message, "text", None) or "").strip()
    p    = getattr(this, "prefix", ".")
    c    = getattr(this, "rawCommand", "ckg")
    uid  = str(getattr(this, "uid", "") or "")

    stripped = raw
    if p and stripped.startswith(p):
        stripped = stripped[len(p):]
    parts = stripped.split()
    sub   = parts[1].lower() if len(parts) > 1 else ""
    sub3  = parts[2].lower() if len(parts) > 2 else ""

    # ── status ─────────────────────────────────────────────────────────────
    if not sub:
        return _reply_info(this, _status_text(uid, this), data, threadId, type, userId=userId)

    # ── set now ─────────────────────────────────────────────────────────────
    if sub == "set" and sub3 == "now":
        gname   = _get_group_name(this, str(threadId))
        avt_url = _get_group_avatar_url(this, str(threadId))
        ckg     = _get_ckg(uid)
        ckg["mainGroup"]     = str(threadId)
        ckg["mainGroupName"] = gname
        _save_ckg(uid, ckg)
        threading.Thread(target=_download_avatar,
                         args=(avt_url, str(threadId)), daemon=True).start()
        return _reply_ok(this, f"✅ Đã set [{gname}] làm nhóm chính!",
                         data, threadId, type, userId=userId)

    # ── clear ───────────────────────────────────────────────────────────────
    if sub == "clear":
        ckg = _get_ckg(uid)
        ckg.pop("mainGroup", None)
        ckg.pop("mainGroupName", None)
        _save_ckg(uid, ckg)
        return _reply_ok(this, "✅ Đã xoá nhóm chính.", data, threadId, type, userId=userId)

    # ── list ─────────────────────────────────────────────────────────────────
    if sub == "list":
        txt = _build_list_text(this, uid)
        return _reply_info(this, txt, data, threadId, type, userId=userId)

    # ── rm <số> ─────────────────────────────────────────────────────────────
    if sub == "rm":
        try:
            idx = int(sub3) - 1
        except (ValueError, TypeError):
            return _reply_warn(this, "⚠️ Dùng: .ckg rm <số thứ tự trong list>",
                               data, threadId, type, userId=userId)
        all_gids = _get_all_group_ids(this)
        main_gid = _get_main_group(uid)
        # Lọc bỏ nhóm chính để đánh số giống list
        target_gids = [g for g in all_gids if g != main_gid]
        if idx < 0 or idx >= len(target_gids):
            return _reply_warn(this, f"⚠️ Số không hợp lệ (1-{len(target_gids)}).",
                               data, threadId, type, userId=userId)
        gid_target = target_gids[idx]
        disabled   = _get_disabled_groups(uid)
        if gid_target in disabled:
            return _reply_warn(this, "⚠️ Nhóm này đã tắt rải rồi.",
                               data, threadId, type, userId=userId)
        disabled.append(gid_target)
        _set_disabled_groups(uid, disabled)
        name = _get_group_name(this, gid_target)
        return _reply_ok(this, f"🔴 Đã tắt rải nhóm: {name}",
                         data, threadId, type, userId=userId)

    # ── add <số> ─────────────────────────────────────────────────────────────
    if sub == "add":
        try:
            idx = int(sub3) - 1
        except (ValueError, TypeError):
            return _reply_warn(this, "⚠️ Dùng: .ckg add <số thứ tự trong list>",
                               data, threadId, type, userId=userId)
        all_gids = _get_all_group_ids(this)
        main_gid = _get_main_group(uid)
        target_gids = [g for g in all_gids if g != main_gid]
        if idx < 0 or idx >= len(target_gids):
            return _reply_warn(this, f"⚠️ Số không hợp lệ (1-{len(target_gids)}).",
                               data, threadId, type, userId=userId)
        gid_target = target_gids[idx]
        disabled   = _get_disabled_groups(uid)
        if gid_target not in disabled:
            return _reply_warn(this, "⚠️ Nhóm này chưa bị tắt rải.",
                               data, threadId, type, userId=userId)
        disabled.remove(gid_target)
        _set_disabled_groups(uid, disabled)
        name = _get_group_name(this, gid_target)
        return _reply_ok(this, f"🟢 Đã bật lại rải nhóm: {name}",
                         data, threadId, type, userId=userId)

    # ── Cần nhóm chính ──────────────────────────────────────────────────────
    main_gid  = _get_main_group(uid)
    if not main_gid:
        return _reply_err(this,
            f"❌ Chưa set nhóm chính!\nDùng  {p}{c} set now  trong nhóm muốn set.",
            data, threadId, type, userId=userId)
    main_name = _get_ckg(uid).get("mainGroupName") or _get_group_name(this, main_gid)

    # ── preview ─────────────────────────────────────────────────────────────
    if sub == "preview":
        link = _get_group_link(this, main_gid)
        if not link:
            return _reply_err(this, "❌ Không lấy được link nhóm chính.",
                              data, threadId, type, userId=userId)
        text    = _build_ckg_text(main_name, link)
        avt_url = _get_group_avatar_url(this, main_gid)
        try:
            this.sendReaction(data, "🔍", threadId, type, 100000000)
        except Exception:
            pass
        try:
            this.sendLink(
                linkUrl=link,
                title=main_name,
                threadId=str(threadId),
                type=ThreadType.GROUP,
                desc=text,
                thumbnailUrl=avt_url if avt_url else None,
            )
        except Exception as e:
            print(f"[ckg preview] sendLink lỗi: {e}")
        return

    # ── stop ────────────────────────────────────────────────────────────────
    if sub == "stop":
        with _spread_lock:
            ev = _spreading.pop(uid, None)
        if ev:
            ev.set()
            return _reply_ok(this, "⏹ Đã dừng rải link.", data, threadId, type, userId=userId)
        return _reply_warn(this, "⚠️ Không có tiến trình rải nào.",
                           data, threadId, type, userId=userId)

    # ── init (gửi ngay, no delay) — dạng card ───────────────────────────────
    if sub == "init":
        with _spread_lock:
            if uid in _spreading:
                return _reply_warn(this, "⚠️ Đang rải. Dùng .ckg stop trước.",
                                   data, threadId, type, userId=userId)

        gids     = _get_all_group_ids(this)
        avt_url  = _get_group_avatar_url(this, main_gid)
        disabled = _get_disabled_groups(uid)
        _reset_counts(uid)
        _reply_info(this,
            f"🚀 Đang gửi đến {len(gids)} nhóm (không delay, dạng card)...",
            data, threadId, type, userId=userId)

        def _init_worker():
            link = _get_group_link(this, main_gid)
            if not link:
                try:
                    this.replyMessageStyle("❌ Không lấy được link.",
                                           data, threadId, type,
                                           color="r", title="CKG")
                except Exception:
                    pass
                return
            text = _build_ckg_text(main_name, link)
            sent = fail = skipped = 0
            for gid in gids:
                if gid == main_gid:
                    continue
                if gid in disabled:
                    skipped += 1
                    continue
                try:
                    _send_card_to_group(this, gid, link, main_name, avt_url, text)
                    sent += 1
                    _inc_sent(uid)
                except Exception as e:
                    fail += 1
                    print(f"[ckg init] {gid}: {e}")
            try:
                msg = f"✅ Xong! Thành công: {sent}"
                if skipped:
                    msg += f" | Bỏ qua: {skipped}"
                if fail:
                    msg += f" | Thất bại: {fail}"
                this.replyMessageStyle(msg, data, threadId, type, color="gr", title="CKG")
            except Exception:
                pass

        threading.Thread(target=_init_worker, daemon=True).start()
        return

    # ── start (delay 3s/nhóm, dạng card) ────────────────────────────────────
    if sub == "start":
        with _spread_lock:
            if uid in _spreading:
                return _reply_warn(this, "⚠️ Đang rải rồi! Dùng .ckg stop để dừng.",
                                   data, threadId, type, userId=userId)
            stop_ev = threading.Event()
            _spreading[uid] = stop_ev

        gids    = _get_all_group_ids(this)
        avt_url = _get_group_avatar_url(this, main_gid)
        _reset_counts(uid)
        disabled = _get_disabled_groups(uid)
        active   = [g for g in gids if g != main_gid and g not in disabled]
        _reply_info(this,
            f"🚀 Bắt đầu rải đến {len(active)} nhóm (delay {_DELAY_PER_GROUP}s/nhóm, dạng card)...",
            data, threadId, type, userId=userId)

        threading.Thread(
            target=_spread_worker,
            args=(this, main_gid, main_name, avt_url,
                  gids, stop_ev, uid, threadId, data, type),
            daemon=True
        ).start()
        return

    # ── timer ───────────────────────────────────────────────────────────────
    if sub == "timer":
        val = sub3
        if val == "off":
            old = _timer_threads.pop(uid, None)
            if old:
                old.set()
            ckg = _get_ckg(uid)
            ckg["timerMinutes"] = 0
            _save_ckg(uid, ckg)
            return _reply_ok(this, "⏹ Đã tắt tự rải.", data, threadId, type, userId=userId)
        minutes = 0
        if val.endswith("h"):
            try: minutes = int(val[:-1]) * 60
            except: pass
        elif val.endswith("m"):
            try: minutes = int(val[:-1])
            except: pass
        if minutes <= 0:
            return _reply_warn(this,
                "⚠️ Dùng: .ckg timer 30m | .ckg timer 1h | .ckg timer off",
                data, threadId, type, userId=userId)
        ckg = _get_ckg(uid)
        ckg["timerMinutes"] = minutes
        _save_ckg(uid, ckg)
        _start_timer(this, uid, minutes)
        h = minutes // 60
        m = minutes % 60
        label = f"{h}h{m}m" if h else f"{m}m"
        return _reply_ok(this, f"⏱ Tự rải mỗi {label}. Dùng .ckg timer off để tắt.",
                         data, threadId, type, userId=userId)

    # ── unknown ──────────────────────────────────────────────────────────────
    return _reply_warn(this,
        f"Lệnh không hợp lệ.\n\n{_status_text(uid, this)}",
        data, threadId, type, userId=userId)


# ══════════════════════════════════════════════════════════════════════════════
# Timer worker – tự rải định kỳ (dạng card)
# ══════════════════════════════════════════════════════════════════════════════
_timer_threads: dict = {}

def _timer_worker(this, uid: str, stop_event: threading.Event):
    while not stop_event.is_set():
        ckg = _get_ckg(uid)
        minutes = ckg.get("timerMinutes", 0)
        if not minutes:
            break
        main_gid  = _get_main_group(uid)
        if not main_gid:
            break
        main_name = ckg.get("mainGroupName") or _get_group_name(this, main_gid)
        gids      = _get_all_group_ids(this)
        link      = _get_group_link(this, main_gid)
        if not link:
            # Không lấy được link → chờ rồi thử lại
            stop_event.wait(timeout=minutes * 60)
            continue
        avt_url  = _get_group_avatar_url(this, main_gid)
        text     = _build_ckg_text(main_name, link)
        disabled = _get_disabled_groups(uid)
        for gid in gids:
            if stop_event.is_set():
                break
            if gid == main_gid or gid in disabled:
                continue
            try:
                _send_card_to_group(this, gid, link, main_name, avt_url, text)
                _inc_sent(uid)
            except Exception as e:
                print(f"[ckg timer] {gid}: {e}")
            time.sleep(3)
        # Gửi xong → chờ interval rồi lặp lại
        stop_event.wait(timeout=minutes * 60)


def _start_timer(this, uid: str, minutes: int):
    old = _timer_threads.pop(uid, None)
    if old:
        old.set()
    if minutes <= 0:
        return
    ev = threading.Event()
    _timer_threads[uid] = ev
    threading.Thread(target=_timer_worker, args=(this, uid, ev), daemon=True).start()


dependencies = {
    "name":        "ckg",
    "permission":  2,
    "description": "Rải link nhóm chính (card ảnh) + tự trả khi chủ/phó nhóm tag bot",
    "cooldown":    3,
    "main":        ckgCommand,
}
