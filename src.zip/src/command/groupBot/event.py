from app.core.index import *
from src.services.pillow.eventCard import draw_event_card
from app.module.utils import _get_user_avatar
from PIL import Image
import os

def _get_thread_cfg(uid: str, threadId: str) -> dict:
    s = read_settings(uid)
    return s.get("eventConfig", {}).get(str(threadId), {})

def _save_thread_cfg(uid: str, threadId: str, cfg: dict):
    s = read_settings(uid)
    s.setdefault("eventConfig", {})[str(threadId)] = cfg
    write_settings(uid, s)

def _ok(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

def _err(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)

def _info(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="or", title="EVENT CONFIG", userId=userId)

def eventCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()

    if len(parts) < 2:
        cfg    = _get_thread_cfg(this.uid, threadId)
        status = "✅ ON" if cfg.get("eventOn", False) else "❌ OFF"
        return _info(
            this,
            f"Trạng thái event nhóm này: {status}\n\nDùng: {p}{c} on/off",
            data, threadId, type, userId,
        )

    sub = parts[1].lower()

    if sub in ("on", "off"):
        new_state = (sub == "on")
        cfg = _get_thread_cfg(this.uid, threadId)
        cfg["eventOn"] = new_state
        _save_thread_cfg(this.uid, threadId, cfg)
        return _ok(this,
                   f"Đã {'bật' if new_state else 'tắt'} event nhóm này.",
                   data, threadId, type, userId)

    # ── Quản lý welcome title ──────────────────────────────────────────────────
    if sub == "title":
        cfg = _get_thread_cfg(this.uid, threadId)

        # Xem title hiện tại
        if len(parts) == 2:
            current = cfg.get("welcomeTitle", "")
            if current:
                return _info(this,
                    f"📌 Welcome title hiện tại:\n{current}\n\nDùng:\n"
                    f"• {p}{c} title <nội dung>  → đặt title mới\n"
                    f"• {p}{c} title clear        → xóa title",
                    data, threadId, type, userId)
            else:
                return _info(this,
                    f"Chưa có welcome title.\n\nDùng: {p}{c} title <nội dung>",
                    data, threadId, type, userId)

        # Xóa title
        if parts[2].lower() == "clear":
            cfg.pop("welcomeTitle", None)
            _save_thread_cfg(this.uid, threadId, cfg)
            return _ok(this, "Đã xóa welcome title.", data, threadId, type, userId)

        # Đặt title mới (phần còn lại sau 'title')
        new_title = " ".join(parts[2:])
        cfg["welcomeTitle"] = new_title
        _save_thread_cfg(this.uid, threadId, cfg)
        return _ok(this,
            f"✅ Đã đặt welcome title:\n{new_title}\n\n"
            f"Khi có thành viên mới vào, bot sẽ gửi:\n{new_title}\n@tên_thành_viên",
            data, threadId, type, userId)

    return _err(this,
        f"Dùng:\n"
        f"• {p}{c} on/off              → bật/tắt event\n"
        f"• {p}{c} title <nội dung>    → đặt welcome title\n"
        f"• {p}{c} title               → xem title hiện tại\n"
        f"• {p}{c} title clear         → xóa welcome title",
        data, threadId, type, userId)

dependencies = {
    "name":        "event",
    "permission":  2,
    "description": "Bật/tắt thông báo event nhóm + cấu hình welcome title",
    "cooldown":    3,
    "main":        eventCommand,
}
