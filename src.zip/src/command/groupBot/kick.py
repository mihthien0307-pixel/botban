from app.core.index import *


def _clean_mem_ver_list(memVerList):
    out = []
    for x in memVerList or []:
        if not x:
            continue
        if isinstance(x, str):
            if x.endswith("_0"):
                x = x[:-2]
        out.append(str(x))
    seen = set()
    return [v for v in out if v not in seen and not seen.add(v)]


def _get_group_info(this, threadId):
    try:
        gi = this.fetchGroupInfo(threadId)
        gridInfoMap = getattr(gi, "gridInfoMap", None) or {}
        info = gridInfoMap.get(threadId) or gridInfoMap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}


def _get_admin_ids(info):
    for k in ("adminIds", "adminIdList", "admins", "adminList",
              "adminIdMap", "adminMap", "adminUidList", "adminUidMap"):
        if k not in info:
            continue
        v = info.get(k)
        if isinstance(v, dict):
            return [x for x in v.keys() if x]
        if isinstance(v, (list, tuple, set)):
            return [x for x in v if x]
        if isinstance(v, str):
            return [x for x in v.replace(" ", "").split(",") if x]
        return []
    return []


def _send_fail(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)


def _send_warn(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)


def _send_complete(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)


def kickCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) > 1 else ""

    is_help = sub in ("help", ":help")
    is_all  = sub == "all"

    if is_help or (not sub and not extractUids(data) and not getattr(data, "quote", None)):
        name = this.userName(userId)
        help_text = (
            f"Nhập Nội Dung Cần Thực Hiện\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} @{name}\n"
            f"      Kick thành viên được mention.\n\n"
            f"  📍 {p}{c} (reply tin nhắn)\n"
            f"      Kick người gửi tin nhắn đó.\n\n"
            f"  📍 {p}{c} all\n"
            f"      Kick toàn bộ thành viên (trừ admin, chủ nhóm, bot)."
        )
        return this.replyMessageStyle(help_text, data, threadId, type, color="or", title="CAUTION", userId=userId)

    if is_all:
        info       = _get_group_info(this, threadId)
        mem_list   = _clean_mem_ver_list(info.get("memVerList"))
        admin_ids  = {str(x) for x in _get_admin_ids(info) if x}
        creator_id = str(info.get("creatorId", "") or "")
        bot_id     = str(
            getattr(this, "uid", "")
            or getattr(getattr(this, "user", None), "id", "")
            or ""
        )

        protect = {str(userId), bot_id, creator_id} | admin_ids
        targets = [x for x in mem_list if x and x not in protect]

        if not targets:
            return _send_fail(this, "Không có thành viên nào để kick..!", data, threadId, type, userId)

        _send_complete(this, f"Đã kick {len(targets)} thành viên khỏi nhóm.", data, threadId, type, userId)
        this.kickUsers(targets, threadId)
        return

    uids  = extractUids(data) or []
    quote = getattr(data, "quote", None)

    targets = list(uids)
    if not targets and quote:
        oid = getattr(quote, "ownerId", None)
        if oid:
            targets = [oid]

    if not targets:
        return _send_warn(
            this,
            "Vui lòng mention hoặc reply tin nhắn của thành viên cần kick..!",
            data, threadId, type, userId,
        )

    seen, deduped = set(), []
    for x in targets:
        s = str(x)
        if s not in seen:
            seen.add(s); deduped.append(s)
    targets = deduped

    if not targets:
        return _send_fail(this, "Không có target hợp lệ..!", data, threadId, type, userId)

    _send_complete(this, f"Đã kick {len(targets)} thành viên khỏi nhóm.", data, threadId, type, userId)
    this.kickUsers(targets, threadId)


dependencies = {
    "name":        "kick",
    "permission":  1,
    "description": "Kick thành viên / kick all",
    "cooldown":    5,
    "main":        kickCommand,
}