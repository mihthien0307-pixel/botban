"""
leave.py – Lệnh rời nhóm / hàng loạt theo từ khoá.
Yêu cầu quyền HIGH_ADMIN (level 3).

Cú pháp:
  {prefix}leave                         → Rời nhóm hiện tại
  {prefix}leave all                     → Rời TẤT CẢ nhóm
  {prefix}leave -s "từ khoá"            → Rời các nhóm có tên chứa từ khoá
  {prefix}leave -s "kw1" "kw2"          → Nhiều từ khoá (OR)
  {prefix}leave -i "tên nhóm"           → Bỏ qua nhóm có tên chứa từ này
  {prefix}leave all -i "vip" "quan trọng"   → Rời tất cả, trừ nhóm chứa "vip"/"quan trọng"
  {prefix}leave :s-lockchat             → Rời các nhóm bị khoá chat
"""

from app.core.index import *
import unicodedata
import shlex
import re

# ── Unicode normaliser (bắt chữ in hoa box, small-cap…) ──────────────────────

def _norm_unicode(s: str) -> str:
    s = unicodedata.normalize("NFKC", str(s or ""))
    out = []
    for ch in s:
        try:
            name = unicodedata.name(ch)
        except ValueError:
            out.append(ch)
            continue
        if "SQUARED LATIN CAPITAL LETTER" in name or "NEGATIVE SQUARED LATIN CAPITAL LETTER" in name:
            out.append(name.split("LETTER ")[-1])
        elif "LATIN LETTER SMALL CAPITAL" in name:
            out.append(name.split("CAPITAL ")[-1].lower())
        else:
            out.append(ch)
    return unicodedata.normalize("NFC", "".join(out)).strip()


# ── Argument parser ───────────────────────────────────────────────────────────

def _parse_args(message):
    """
    Trả về (flags: set[str], search: list[str], ignore: list[str])
    flags có thể chứa: 'all', ':s-lockchat', '-s', '--search', '-i', '--ignore'
    """
    raw = (getattr(message, "text", None) or "").strip()
    try:
        tokens = shlex.split(raw)
    except Exception:
        tokens = raw.split()

    flags  = set()
    search = []
    ignore = []

    i = 1   # bỏ qua token[0] = tên lệnh
    while i < len(tokens):
        t  = tokens[i]
        tl = t.lower()

        if tl in ("all", ":s-lockchat"):
            flags.add(tl)
            i += 1
            continue

        if tl in ("-s", "--search"):
            flags.add(tl)
            # Gom tất cả token còn lại cho -s (dừng khi gặp flag khác)
            i += 1
            raw_rest = " ".join(tokens[i:]).strip()
            if raw_rest:
                quoted = re.findall(r'"([^"]+)"', raw_rest)
                if quoted:
                    search = [x.strip() for x in quoted if x.strip()]
                else:
                    search = [x.strip() for x in raw_rest.replace(",", " ").split() if x.strip()]
            i = len(tokens)   # đã xử lý hết
            continue

        if tl in ("-i", "--ignore"):
            flags.add(tl)
            i += 1
            while i < len(tokens):
                x  = tokens[i]
                xl = x.lower()
                if xl in ("-s", "--search", "-i", "--ignore", "all", ":s-lockchat"):
                    break
                ignore.append(x)
                i += 1
            continue

        i += 1

    return flags, search, ignore


# ── Helpers ───────────────────────────────────────────────────────────────────

def _send_ok(this, text, data, threadId, type):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="LEAVE")


def _send_warn(this, text, data, threadId, type):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="LEAVE")


def _send_fail(this, text, data, threadId, type):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="LEAVE")


def _leave(this, gid: str) -> bool:
    """Rời nhóm, xử lý cả trường hợp silent bắt buộc."""
    try:
        this.leaveGroup(gid, silent=True)
        return True
    except Exception:
        try:
            this.leaveGroup(gid, True)
            return True
        except Exception:
            return False


def _group_name_map(this, gids: list[str]) -> dict[str, str]:
    """Lấy tên của nhiều nhóm một lần, bỏ qua lỗi."""
    result = {}
    for gid in gids:
        try:
            gi   = this.fetchGroupInfo(gid)
            info = (getattr(gi, "gridInfoMap", None) or {})
            g    = info.get(gid) or info.get(str(gid)) or {}
            result[gid] = (g.get("name") or "") if isinstance(g, dict) else ""
        except Exception:
            result[gid] = ""
    return result


def _is_locked_chat(this, gid: str) -> bool:
    """Kiểm tra nhóm có đang khoá chat (lockSendMsg=1) không."""
    try:
        gi   = this.fetchGroupInfo(gid)
        info = (getattr(gi, "gridInfoMap", None) or {})
        g    = info.get(gid) or info.get(str(gid)) or {}
        if isinstance(g, dict):
            return (g.get("setting") or {}).get("lockSendMsg") == 1
    except Exception:
        pass
    return False


def _build_report(left: list, failed: list, names: dict) -> str:
    lines = [f"Rời thành công: {len(left)} nhóm"]
    if left:
        for g in left[:60]:
            lines.append(f"  ✅ {names.get(g, g)}")
        if len(left) > 60:
            lines.append(f"  … +{len(left) - 60} nhóm khác")

    if failed:
        lines.append(f"Thất bại: {len(failed)} nhóm")
        for g in failed[:30]:
            lines.append(f"  ❌ {names.get(g, g)}")
        if len(failed) > 30:
            lines.append(f"  … +{len(failed) - 30} nhóm khác")

    return "\n".join(lines)


# ── Command handler ───────────────────────────────────────────────────────────

def leaveGroupCommand(this, message, data, userId, threadId, type):
    flags, search, ignore = _parse_args(message)

    has_all    = "all" in flags
    has_search = "-s" in flags or "--search" in flags
    has_ignore = "-i" in flags or "--ignore" in flags
    has_lock   = ":s-lockchat" in flags

    search_kws = [_norm_unicode(x).casefold() for x in search if str(x or "").strip()]
    ignore_kws = [_norm_unicode(x).casefold() for x in ignore if str(x or "").strip()]

    # ── Chế độ hàng loạt (all / -s / -i / :s-lockchat) ──────────────────────
    if has_all or has_search or has_ignore or has_lock:

        if has_search and not search_kws and not has_all:
            return _send_fail(
                this,
                'Thiếu từ khoá tìm kiếm.\nVí dụ: .leave -s "tên nhóm"',
                data, threadId, type,
            )

        # Lấy danh sách tất cả nhóm bot đang ở
        try:
            all_groups = this.fetchAllGroups()
            gids       = [str(g) for g in (getattr(all_groups, "gridVerMap", None) or {}).keys()]
        except Exception as e:
            return _send_fail(this, f"Không lấy được danh sách nhóm: {e}", data, threadId, type)

        if not gids:
            return _send_warn(this, "Bot không ở trong nhóm nào.", data, threadId, type)

        names  = _group_name_map(this, gids)
        left   = []
        failed = []

        for gid in gids:
            name   = names.get(gid, "") or ""
            namecf = _norm_unicode(name).casefold()

            # Bỏ qua nếu tên khớp ignore
            if has_ignore and ignore_kws and any(k in namecf for k in ignore_kws):
                continue

            # Lọc theo từ khoá tìm kiếm
            if has_search and search_kws and not any(k in namecf for k in search_kws):
                continue

            # Lọc nhóm khoá chat
            if has_lock and not _is_locked_chat(this, gid):
                continue

            if _leave(this, gid):
                left.append(gid)
            else:
                failed.append(gid)

        report = _build_report(left, names=names, failed=failed)

        if failed:
            return _send_warn(this, report, data, threadId, type)
        return _send_ok(this, report, data, threadId, type)

    # ── Rời nhóm hiện tại ────────────────────────────────────────────────────
    _send_ok(this, "Tạm biệt! Bot đã rời nhóm.", data, threadId, type)
    _leave(this, threadId)


# ── dependencies ──────────────────────────────────────────────────────────────

dependencies = {
    "name":        "leave",
    "permission":  PermissionLevel.HIGH_ADMIN.value,   # level 3
    "description": "Rời nhóm hiện tại hoặc hàng loạt theo bộ lọc",
    "cooldown":    5,
    "alias":       ["leavegroup", "lg"],
    "noPrefix":    False,
    "main":        leaveGroupCommand,
}
