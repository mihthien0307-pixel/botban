from app.core.index import *
from api.util.Enum import PermissionLevel
from src.services.utils.jsonio import read_settings

import json
import os
import threading
import time
import logging

logger = logging.getLogger(__name__)

BASE_DIR    = "data/cache/mutegroup"
STATUS_PATH = os.path.join(BASE_DIR, "automute_status.json")
DATA_PATH   = os.path.join(BASE_DIR, "automute_data.json")

os.makedirs(BASE_DIR, exist_ok=True)

_json_lock = threading.Lock()

MAX_WORKERS   = 3        # Số thread tối đa gọi API cùng lúc (tránh spam → bị reset)
RETRY_TIMES   = 3        # Số lần retry khi bị ConnectionReset
RETRY_DELAY   = 2.0      # Giây chờ giữa các retry
REQUEST_DELAY = 0.4      # Giây delay giữa các request tuần tự


# ─── JSON helpers ──────────────────────────────────────────────────────────────

def _load(key: str):
    path = STATUS_PATH if key == "status" else DATA_PATH
    with _json_lock:
        if not os.path.exists(path):
            return {"enabled": False, "interval": 120} if key == "status" else []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"enabled": False, "interval": 120} if key == "status" else []


def _save(key: str, data):
    path = STATUS_PATH if key == "status" else DATA_PATH
    with _json_lock:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"[MuteGroup] Lỗi lưu JSON: {e}")


# ─── Mute API (có retry chống ConnectionReset) ────────────────────────────────

def _set_mute(client, group_id: str, is_mute: bool) -> bool:
    url    = "https://tt-profile-wpa.chat.zalo.me/api/social/profile/setmute"
    params = {"zpw_ver": 677, "zpw_type": 30}
    body   = {
        "toid":      str(group_id),
        "duration":  -1 if is_mute else 0,
        "action":    1  if is_mute else 3,
        "startTime": int(time.time()),
        "muteType":  2,
        "imei":      getattr(client, "_imei", "unknown"),
    }

    for attempt in range(1, RETRY_TIMES + 1):
        try:
            resp = client._post(url, params=params, data={"params": client._encode(body)})
            data = resp.json() if hasattr(resp, "json") else (
                json.loads(resp) if isinstance(resp, str) else resp
            )
            if data.get("error_code") == 0:
                return True
            # Server trả lỗi logic → không retry
            logger.warning(f"[MuteGroup] API lỗi code={data.get('error_code')} group={group_id}")
            return False
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError) as e:
            # Lỗi network tạm thời → retry
            logger.warning(f"[MuteGroup] Network error group={group_id} lần={attempt}: {e}")
            if attempt < RETRY_TIMES:
                time.sleep(RETRY_DELAY * attempt)
        except Exception as e:
            # RemoteDisconnected, timeout và các lỗi khác → retry nếu còn lượt
            err_name = type(e).__name__
            logger.warning(f"[MuteGroup] {err_name} group={group_id} lần={attempt}: {e}")
            if attempt < RETRY_TIMES:
                time.sleep(RETRY_DELAY * attempt)
            else:
                return False

    logger.error(f"[MuteGroup] Thất bại sau {RETRY_TIMES} lần retry: group={group_id}")
    return False


# ─── Bulk mute (giới hạn concurrent + delay) ──────────────────────────────────

def _bulk_mute(client, ids: list, is_mute: bool):
    ok_count   = 0
    fail_count = 0
    lock       = threading.Lock()
    semaphore  = threading.Semaphore(MAX_WORKERS)   # Chống spam API

    def _worker(gid):
        nonlocal ok_count, fail_count
        with semaphore:
            result = _set_mute(client, gid, is_mute)
            time.sleep(REQUEST_DELAY)               # Delay nhỏ sau mỗi request
        with lock:
            if result:
                ok_count += 1
            else:
                fail_count += 1

    threads = [threading.Thread(target=_worker, args=(gid,)) for gid in ids]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    return ok_count, fail_count


# ─── Auto-mute scheduler ───────────────────────────────────────────────────────

def _reschedule(client):
    status = _load("status")
    if not status.get("enabled", False):
        return
    interval = status.get("interval", 120)
    if hasattr(client, "_mutegroup_timer"):
        try:
            client._mutegroup_timer.cancel()
        except Exception:
            pass
    t = threading.Timer(interval, _auto_mute_task, args=(client,))
    t.daemon = True
    client._mutegroup_timer = t
    t.start()


def _auto_mute_task(client):
    if not _load("status").get("enabled", False):
        return
    try:
        muted   = _load("data")
        all_grp = client.fetchAllGroups()
        if not hasattr(all_grp, "gridVerMap"):
            return
        new_ids = [str(gid) for gid in all_grp.gridVerMap if str(gid) not in muted]
        if new_ids:
            for gid in new_ids:
                if _set_mute(client, gid, True) and gid not in muted:
                    muted.append(gid)
                time.sleep(REQUEST_DELAY)
            _save("data", muted)
    except Exception as e:
        logger.error(f"[MuteGroup] Auto-task error: {e}")
    finally:
        _reschedule(client)


# ─── Event hook: mute khi bot được thêm vào nhóm mới ─────────────────────────

def _on_event(client, event_data, event_type):
    if not _load("status").get("enabled", False):
        return
    thread_id = str(
        getattr(event_data, "groupId", None) or
        (event_data.get("thread_id") if isinstance(event_data, dict) else None) or
        ""
    )
    if not thread_id or thread_id == "None":
        return
    muted = _load("data")
    if thread_id not in muted:
        if _set_mute(client, thread_id, True):
            muted.append(thread_id)
            _save("data", list(set(muted)))
            logger.info(f"[MuteGroup] Tự động mute nhóm mới: {thread_id}")


# ─── Command handler ──────────────────────────────────────────────────────────

def mutegroup(self, message, data, userId, threadId, type):
    # Khởi scheduler lần đầu
    if not hasattr(self, "_mutegroup_started"):
        _reschedule(self)
        self._mutegroup_started = True

    p     = self.prefix
    c     = self.rawCommand
    parts = message.text.strip().split()
    cmd   = parts[1].lower() if len(parts) > 1 else ""

    # ── mtgroup all ────────────────────────────────────────────────────────
    if cmd == "all":
        self.replyMessageStyle(
            "Đang tiến hành tắt toàn bộ thông báo nhóm...",
            data, threadId, type,
            color="or", title="ĐANG XỬ LÝ", userId=userId,
        )
        all_grp = self.fetchAllGroups()
        if hasattr(all_grp, "gridVerMap"):
            ids = [str(gid) for gid in all_grp.gridVerMap]
            s, f = _bulk_mute(self, ids, True)
            _save("data", list(set(_load("data") + ids)))
            self.replyMessageStyle(
                f"Đã tắt thông báo thành công: {s} nhóm. Thất bại: {f} nhóm.",
                data, threadId, type,
                color="gr", title="HOÀN TẤT", userId=userId,
            )
        else:
            self.replyMessageStyle(
                "Không thể truy xuất danh sách nhóm.",
                data, threadId, type,
                color="r", title="LỖI", userId=userId,
            )

    # ── mtgroup unmute ─────────────────────────────────────────────────────
    elif cmd == "unmute":
        self.replyMessageStyle(
            "Đang bật lại toàn bộ thông báo nhóm...",
            data, threadId, type,
            color="or", title="ĐANG XỬ LÝ", userId=userId,
        )
        all_grp = self.fetchAllGroups()
        if hasattr(all_grp, "gridVerMap"):
            ids = [str(gid) for gid in all_grp.gridVerMap]
            s, f = _bulk_mute(self, ids, False)
            self.replyMessageStyle(
                f"Đã bật lại thông báo thành công: {s} nhóm. Thất bại: {f} nhóm.",
                data, threadId, type,
                color="gr", title="HOÀN TẤT", userId=userId,
            )
        else:
            self.replyMessageStyle(
                "Không thể truy xuất danh sách nhóm.",
                data, threadId, type,
                color="r", title="LỖI", userId=userId,
            )

    # ── mtgroup auto on/off ────────────────────────────────────────────────
    elif cmd == "auto":
        act    = parts[2].lower() if len(parts) > 2 else ""
        status = _load("status")
        if act == "on":
            status["enabled"] = True
            _save("status", status)
            _reschedule(self)
            self.replyMessageStyle(
                "Đã bật: Tự động tắt thông báo khi phát hiện nhóm mới.",
                data, threadId, type,
                color="gr", title="TRẠNG THÁI", userId=userId,
            )
        elif act == "off":
            status["enabled"] = False
            _save("status", status)
            if hasattr(self, "_mutegroup_timer"):
                try:
                    self._mutegroup_timer.cancel()
                except Exception:
                    pass
            self.replyMessageStyle(
                "Đã tắt chế độ tự động mute nhóm mới.",
                data, threadId, type,
                color="yl", title="TRẠNG THÁI", userId=userId,
            )
        else:
            self.replyMessageStyle(
                f"📍 Dùng: {p}{c} auto on | off",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

    # ── mtgroup on ─────────────────────────────────────────────────────────
    elif cmd == "on":
        if _set_mute(self, threadId, True):
            self.replyMessageStyle(
                "Đã tắt thông báo cho nhóm này.",
                data, threadId, type,
                color="gr", title="THÀNH CÔNG", userId=userId,
            )
        else:
            self.replyMessageStyle(
                "Không thể tắt thông báo nhóm.",
                data, threadId, type,
                color="r", title="THẤT BẠI", userId=userId,
            )

    # ── mtgroup off ────────────────────────────────────────────────────────
    elif cmd == "off":
        if _set_mute(self, threadId, False):
            self.replyMessageStyle(
                "Đã bật lại thông báo cho nhóm này.",
                data, threadId, type,
                color="gr", title="THÀNH CÔNG", userId=userId,
            )
        else:
            self.replyMessageStyle(
                "Không thể bật thông báo nhóm.",
                data, threadId, type,
                color="r", title="THẤT BẠI", userId=userId,
            )

    # ── help ───────────────────────────────────────────────────────────────
    else:
        self.replyMessageStyle(
            f"Các lệnh mtgroup:\n"
            f"• {p}{c} on/off  — Tắt/Bật thông báo nhóm hiện tại\n"
            f"• {p}{c} all     — Tắt thông báo toàn bộ nhóm\n"
            f"• {p}{c} unmute  — Bật lại thông báo toàn bộ nhóm\n"
            f"• {p}{c} auto on/off — Tự động mute khi vào nhóm mới",
            data, threadId, type,
            color="or", title="HƯỚNG DẪN", userId=userId,
        )


# ─── Event hook export ────────────────────────────────────────────────────────
mutegroup_on_event = _on_event


# ─── dependencies ─────────────────────────────────────────────────────────────
dependencies = {
    "name":        "mtgroup",
    "permission":  PermissionLevel.BOT_ADMIN.value,
    "cooldown":    5,
    "description": "Quản lý tắt/bật thông báo nhóm Zalo",
    "alias":       ["mutegroup"],
    "main":        mutegroup,
}
