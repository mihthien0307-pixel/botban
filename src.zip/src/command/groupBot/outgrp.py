"""
outgrp.py – Rời tất cả nhóm đang bị khoá chat, giữ lại nhóm mở chat.
Vị trí: src/command/groupBot/outgrp.py

Cú pháp:
  !outgrp           – Xem preview danh sách nhóm khoá (chưa rời)
  !outgrp confirm   – Thực sự rời hết nhóm khoá chat
  !outgrp -i <kw>   – Rời nhóm khoá, bỏ qua nhóm có tên chứa <kw>
"""

from app.core.index import *
import shlex
import time


# ── Helpers ───────────────────────────────────────────────────────────────────

def _send_ok(this, text, data, threadId, type):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="LEAVE LOCKED")


def _send_warn(this, text, data, threadId, type):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="LEAVE LOCKED")


def _send_err(this, text, data, threadId, type):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="LEAVE LOCKED")


def _get_all_groups(this) -> list[str]:
    try:
        groups = this.fetchAllGroups()
        return [str(g) for g in (getattr(groups, "gridVerMap", None) or {}).keys()]
    except Exception:
        return []


def _get_group_info(this, gid: str) -> dict:
    try:
        gi   = this.fetchGroupInfo(gid)
        info = getattr(gi, "gridInfoMap", {}) or {}
        g    = info.get(gid) or info.get(str(gid)) or {}
        return dict(g) if isinstance(g, dict) else {}
    except Exception:
        return {}


def _is_locked(info: dict) -> bool:
    """Trả về True nếu nhóm đang khoá chat (lockSendMsg == 1)."""
    setting = info.get("setting") or {}
    if not isinstance(setting, dict):
        return False
    return int(setting.get("lockSendMsg", 0) or 0) == 1


def _group_name(info: dict, gid: str) -> str:
    return str(info.get("name") or gid)


def _leave(this, gid: str) -> bool:
    try:
        this.leaveGroup(gid, silent=True)
        return True
    except Exception:
        try:
            this.leaveGroup(gid, True)
            return True
        except Exception:
            return False


def _parse_ignore(text: str) -> list[str]:
    """Trích từ khoá -i / --ignore từ chuỗi lệnh."""
    try:
        tokens = shlex.split(text or "")
    except Exception:
        tokens = (text or "").split()

    ignore = []
    i = 0
    while i < len(tokens):
        if tokens[i].lower() in ("-i", "--ignore") and i + 1 < len(tokens):
            i += 1
            while i < len(tokens) and not tokens[i].startswith("-"):
                ignore.append(tokens[i].casefold())
                i += 1
            continue
        i += 1
    return ignore


# ── Scan helper: lấy danh sách nhóm khoá + tên ───────────────────────────────

def _scan_locked(this, current_id: str, ignore_kws: list[str]):
    """
    Trả về (locked: list[(gid, name)], skipped_ignore: int, total: int)
    """
    gids = _get_all_groups(this)
    locked  = []
    skipped = 0

    for gid in gids:
        if gid == current_id:          # không rời nhóm đang dùng lệnh
            continue
        info = _get_group_info(this, gid)
        if not _is_locked(info):
            continue
        name = _group_name(info, gid)
        if ignore_kws and any(k in name.casefold() for k in ignore_kws):
            skipped += 1
            continue
        locked.append((gid, name))

    return locked, skipped, len(gids)


# ── Command handler ───────────────────────────────────────────────────────────

def outgrpCommand(this, message, data, userId, threadId, type):
    raw    = (getattr(message, "text", None) or "").strip()
    p      = getattr(this, "prefix", "")
    c      = getattr(this, "rawCommand", "outgrp")

    # Bỏ prefix + tên lệnh để lấy args
    stripped = raw
    if p and stripped.startswith(p):
        stripped = stripped[len(p):]
    parts    = stripped.split(None, 1)
    args_str = parts[1].strip() if len(parts) > 1 else ""

    ignore_kws = _parse_ignore(args_str)
    do_confirm = "confirm" in args_str.lower().split()

    # ── Quét nhóm khoá ───────────────────────────────────────────────────────
    locked, skipped, total = _scan_locked(this, threadId, ignore_kws)

    if not locked:
        msg = f"✨ Không có nhóm nào bị khoá chat trong {total} nhóm đang tham gia."
        if skipped:
            msg += f"\n(Bỏ qua {skipped} nhóm do filter -i)"
        return _send_ok(this, msg, data, threadId, type)

    # ── Preview (chưa confirm) ────────────────────────────────────────────────
    if not do_confirm:
        lines = [
            f"Tìm thấy {len(locked)} nhóm khoá chat / {total} nhóm:\n"
        ]
        for i, (gid, name) in enumerate(locked[:50], 1):
            lines.append(f"  {i}. {name}")
        if len(locked) > 50:
            lines.append(f"  … +{len(locked) - 50} nhóm khác")
        if skipped:
            lines.append(f"\n(Bỏ qua {skipped} nhóm do filter -i)")
        lines.append(f"\nGõ  {p}{c} confirm  để rời tất cả.")
        if ignore_kws:
            lines.append(f"(Filter -i đang áp dụng: {', '.join(ignore_kws)})")
        return _send_warn(this, "\n".join(lines), data, threadId, type)

    # ── Thực hiện rời ────────────────────────────────────────────────────────
    left   = []
    failed = []

    for gid, name in locked:
        if _leave(this, gid):
            left.append(name)
        else:
            failed.append(name)
        time.sleep(0.5)   # tránh spam API

    lines = [f"Rời thành công {len(left)}/{len(locked)} nhóm khoá chat:\n"]
    for n in left[:50]:
        lines.append(f"  ✅ {n}")
    if len(left) > 50:
        lines.append(f"  … +{len(left) - 50} nhóm khác")

    if failed:
        lines.append(f"\nThất bại {len(failed)} nhóm:")
        for n in failed[:20]:
            lines.append(f"  ❌ {n}")

    fn = _send_ok if not failed else _send_warn
    fn(this, "\n".join(lines), data, threadId, type)


# ── dependencies ──────────────────────────────────────────────────────────────

dependencies = {
    "name":        "outgrp",
    "permission":  3,
    "description": "Rời tất cả nhóm đang khoá chat, giữ lại nhóm mở",
    "cooldown":    10,

    "noPrefix":    False,
    "main":        outgrpCommand,
}
