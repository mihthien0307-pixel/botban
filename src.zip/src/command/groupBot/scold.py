from app.core.index import *
from src.services.utils.jsonio import read_settings, write_settings
from api.util.msg import Message, Mention
from api.util.Enum import ThreadType
import os, random, time, threading, json as _json

# ═══════════════════════════════════════════════════════════════════════════════
# scold.py  –  Chửi target với tùy chỉnh nâng cao (màu, bold, italic, size…)
# Câu chửi lấy từ file var trong data/config/scold/<tên_file>.txt
# Default file: data/config/chui.txt
# ═══════════════════════════════════════════════════════════════════════════════

_DEFAULT_TXT   = "data/config/chui.txt"
_SCOLD_DIR     = "data/config/scold"
_DEFAULT_DELAY = 1200   # ms

# ── Locks & anti-loop ─────────────────────────────────────────────────────────
_cooldown_lock  = threading.Lock()
_last_scold: dict = {}
_spam_loops: dict = {}
_spam_loops_lock = threading.Lock()

# ── Màu HEX chuẩn Zalo chấp nhận ─────────────────────────────────────────────
# Lấy từ color_map trong send.py — đây là các màu Zalo API thực sự hiển thị
_ZALO_COLORS = [
    "db342e",  # đỏ
    "f27806",  # cam
    "f7b503",  # vàng
    "15a85f",  # xanh lá
]

def _rand_hex() -> str:
    return random.choice(_ZALO_COLORS)

def _utf16_len(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2


# ── Build style JSON với màu Zalo chuẩn ──────────────────────────────────────

def _build_style_json(text: str, mode: str, tag_u16_len: int,
                      bold: bool = False, italic: bool = False,
                      underline: bool = False, strike: bool = False) -> str:
    """Tạo textProperties JSON tô màu câu chửi theo mode word/char/sentence.
    tag_u16_len: UTF-16 len của '@name' (không kể space sau tag).
    Zalo st format: 'c_HEX' hoặc kết hợp 'c_HEX,b,i,u,s,f_SIZE'
    """
    styles = []
    base   = tag_u16_len + 1  # +1 cho dấu cách sau @name

    def _st(hex_color=None) -> str:
        parts = []
        if hex_color:
            parts.append(f"c_{hex_color}")
        if bold:      parts.append("b")
        if italic:    parts.append("i")
        if underline: parts.append("u")
        if strike:    parts.append("s")
        return ",".join(parts)

    if mode == "char":
        pos = base
        for ch in text:
            clen = _utf16_len(ch)
            if ch.strip():   # bỏ qua space
                styles.append({"start": pos, "len": clen, "st": _st(_rand_hex())})
            pos += clen

    elif mode == "word":
        pos = base
        for word in text.split(" "):
            wlen = _utf16_len(word)
            if word:
                styles.append({"start": pos, "len": wlen, "st": _st(_rand_hex())})
            pos += wlen + 1   # +1 cho space giữa các từ

    elif mode == "sentence":
        full_len = _utf16_len(text)
        if full_len:
            styles.append({"start": base, "len": full_len, "st": _st(_rand_hex())})

    elif mode == "off":
        # Không tô màu nhưng vẫn apply bold/italic/underline/strike cho cả câu
        full_len = _utf16_len(text)
        if full_len:
            st = _st(None)
            if st:
                styles.append({"start": base, "len": full_len, "st": st})

    if not styles:
        return ""
    return _json.dumps({"styles": styles, "ver": 0})


# ── Spam loop ─────────────────────────────────────────────────────────────────

def _start_spam_loop(this, userId, threadId, tid, _unused_tcfg=None):
    key      = (str(this.uid), tid, str(userId))
    stop_evt = threading.Event()
    with _spam_loops_lock:
        old = _spam_loops.get(key)
        if old:
            old.set()
        _spam_loops[key] = stop_evt

    def _loop():
        while not stop_evt.is_set():
            delay_s = _DEFAULT_DELAY / 1000.0
            try:
                # Đọc config MỚI NHẤT mỗi vòng — nhận ngay khi user đổi màu/delay
                live = _get_tcfg(this.uid, tid)
                delay_s    = live.get("delay", _DEFAULT_DELAY) / 1000.0
                color_mode = live.get("colorMode", "off")
                bold       = live.get("bold", False)
                italic     = live.get("italic", False)
                underline  = live.get("underline", False)
                strike     = live.get("strike", False)

                name    = this.userName(userId) or str(userId)
                tag     = f"@{name}"
                tag_len = _utf16_len(tag)
                mention = Mention(userId, offset=0, length=tag_len)

                filepath = _varfile_path(this.uid, tid)
                cau_chui = _random_line(filepath)
                if not cau_chui:
                    time.sleep(delay_s)
                    continue

                full_text = f"{tag} {cau_chui}"

                has_style = bold or italic or underline or strike
                if color_mode != "off" or has_style:
                    style_json = _build_style_json(
                        cau_chui, color_mode, tag_len,
                        bold=bold, italic=italic,
                        underline=underline, strike=strike
                    )
                else:
                    style_json = ""

                msg = Message(text=full_text, mention=mention,
                              style=style_json if style_json else None)
                this.send(msg, threadId, ThreadType.GROUP)

            except Exception as e:
                print(f"[scold spam] {e}")

            # Chờ delay, check stop mỗi 0.5s
            for _ in range(max(1, int(delay_s / 0.5))):
                if stop_evt.is_set():
                    break
                time.sleep(0.5)

    threading.Thread(target=_loop, daemon=True).start()


def _stop_spam_loop(bot_uid, tid, user_id):
    key = (str(bot_uid), tid, str(user_id))
    with _spam_loops_lock:
        evt = _spam_loops.pop(key, None)
    if evt:
        evt.set()


# ── Shuffle queue per-file ────────────────────────────────────────────────────
_queue_cache: dict = {}

def _random_line(filepath: str) -> str:
    global _queue_cache
    try:
        entry = _queue_cache.setdefault(filepath, {"queue": [], "index": 0})
        if not entry["queue"] or entry["index"] >= len(entry["queue"]):
            with open(filepath, "r", encoding="utf-8") as f:
                lines = [l.strip() for l in f if l.strip()]
            if not lines:
                return ""
            random.shuffle(lines)
            entry["queue"] = lines
            entry["index"] = 0
        result = entry["queue"][entry["index"]]
        entry["index"] += 1
        return result
    except Exception as e:
        print(f"[scold] Lỗi đọc file {filepath}: {e}")
        return ""


# ── Scold dir ─────────────────────────────────────────────────────────────────
def _ensure_dir():
    os.makedirs(_SCOLD_DIR, exist_ok=True)


# ── Settings helpers ──────────────────────────────────────────────────────────

def _cfg(uid: str) -> dict:
    return read_settings(uid).get("scoldCfg", {})

def _save_cfg(uid: str, cfg: dict):
    s = read_settings(uid)
    s["scoldCfg"] = cfg
    write_settings(uid, s)

def _thread_cfg(uid: str, tid: str) -> dict:
    return _cfg(uid).get(str(tid), {})

def _save_thread_cfg(uid: str, tid: str, tcfg: dict):
    cfg = _cfg(uid)
    cfg[str(tid)] = tcfg
    _save_cfg(uid, cfg)

def _default_tcfg() -> dict:
    return {
        "targets":     [],
        "tagTargets":  [],
        "delay":       _DEFAULT_DELAY,
        "colorMode":   "off",   # off / word / char / sentence
        "bold":        False,
        "italic":      False,
        "underline":   False,
        "strike":      False,
        "randomSize":  False,
        "varFile":     None,
    }

def _get_tcfg(uid: str, tid: str) -> dict:
    base = _default_tcfg()
    base.update(_thread_cfg(uid, tid))
    return base

def _varfile_path(uid: str, tid: str) -> str:
    tcfg = _get_tcfg(uid, tid)
    vf   = tcfg.get("varFile")
    if vf:
        path = os.path.join(_SCOLD_DIR, f"{vf}.txt")
        if os.path.exists(path):
            return path
    return _DEFAULT_TXT

def _list_varfiles() -> list:
    _ensure_dir()
    return sorted(f[:-4] for f in os.listdir(_SCOLD_DIR) if f.endswith(".txt"))


# ── Cooldown ──────────────────────────────────────────────────────────────────

def _check_cooldown(uid: str, tid: str, user_id: str, delay_ms: int) -> float:
    key = (uid, tid, user_id)
    now = time.time()
    delay_s = delay_ms / 1000.0
    with _cooldown_lock:
        last = _last_scold.get(key)
        if last is None:
            _last_scold[key] = now
            return 0.0
        remain = delay_s - (now - last)
        if remain > 0:
            return remain
        _last_scold[key] = now
        return 0.0

def _reset_cooldown(uid: str, tid: str, user_id: str):
    with _cooldown_lock:
        _last_scold.pop((uid, tid, user_id), None)


# ── Listener ──────────────────────────────────────────────────────────────────

def scoldListener(this, message, data, userId, threadId, type):
    tid  = str(threadId)
    tcfg = _get_tcfg(this.uid, tid)

    tag_targets = tcfg.get("tagTargets", [])
    if not tag_targets or str(userId) not in tag_targets:
        return
    if str(userId) == str(getattr(this, "uid", "") or ""):
        return
    if (getattr(data, "msgType", "") or "") == "chat.reaction":
        return

    delay_ms = tcfg.get("delay", _DEFAULT_DELAY)
    if _check_cooldown(this.uid, tid, str(userId), delay_ms) > 0:
        return

    filepath = _varfile_path(this.uid, tid)
    cau_chui = _random_line(filepath)
    if not cau_chui:
        return

    name       = this.userName(userId) or str(userId)
    tag        = f"@{name}"
    tag_len    = _utf16_len(tag)
    mention    = Mention(userId, offset=0, length=tag_len)
    color_mode = tcfg.get("colorMode", "off")

    def _send():
        try:
            full_text  = f"{tag} {cau_chui}"
            style_json = ""
            has_style = any([tcfg.get("bold"), tcfg.get("italic"), tcfg.get("underline"), tcfg.get("strike")])
            if color_mode != "off" or has_style:
                style_json = _build_style_json(
                    cau_chui, color_mode, tag_len,
                    bold=tcfg.get("bold", False),
                    italic=tcfg.get("italic", False),
                    underline=tcfg.get("underline", False),
                    strike=tcfg.get("strike", False),
                )
            msg = Message(text=full_text, mention=mention,
                          style=style_json if style_json else None)
            this.send(msg, threadId, type)
        except Exception as e:
            print(f"[scold tag] {e}")

    threading.Thread(target=_send, daemon=True).start()


# ── Command ───────────────────────────────────────────────────────────────────

def scoldCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) > 1 else ""
    tid   = str(threadId)
    tcfg  = _get_tcfg(this.uid, tid)

    def ok(msg):
        this.replyMessageStyle(msg, data, threadId, type,
                               color="gr", title="SCOLD", userId=userId)
    def warn(msg):
        this.replyMessageStyle(msg, data, threadId, type,
                               color="yl", title="SCOLD", userId=userId)
    def err(msg):
        this.replyMessageStyle(msg, data, threadId, type,
                               color="r", title="SCOLD", userId=userId)

    # ── Bật scold khi .scold @mention (không có sub) ─────────────────────────
    if sub == "" and extractUids(data):
        uids = [u for u in extractUids(data) if str(u) != str(getattr(this, "uid", ""))]
        if uids:
            targets = list(tcfg.get("targets", []))
            for u in uids:
                if str(u) not in targets:
                    targets.append(str(u))
            tcfg["targets"] = targets
            _save_thread_cfg(this.uid, tid, tcfg)
            for u in uids:
                _start_spam_loop(this, u, threadId, tid)
            names = ", ".join(this.userName(u) or str(u) for u in uids)
            return ok(f"✅ Đã bật scold (spam) cho: {names}")

    # ── Help ──────────────────────────────────────────────────────────────────
    if sub in ("", "help", ":help"):
        vf = tcfg.get("varFile") or "(mặc định chui.txt)"
        return this.replyMessageStyle(
            f"📋 HƯỚNG DẪN SỬ DỤNG\n\n"
            f"✅ Spam liên tục: {p}{c} @mention\n"
            f"✅ Tag khi họ chat: {p}{c} tag @người\n"
            f"✅ Tha / tắt scold: {p}{c} tha [@người]\n"
            f"✅ Set delay: {p}{c} delay <250-10000>\n"
            f"✅ Màu: {p}{c} color word/char/sentence/off\n"
            f"✅ Đậm: {p}{c} bold on/off\n"
            f"✅ Nghiêng: {p}{c} italic on/off\n"
            f"✅ Gạch dưới: {p}{c} underline on/off\n"
            f"✅ Gạch ngang: {p}{c} strike on/off\n"
            f"✅ Xem cấu hình: {p}{c} config\n"
            f"✅ Xem file var: {p}{c} list\n"
            f"✅ Set file var: {p}{c} set <tên_file>\n"
            f"✅ Add file (reply): {p}{c} addfile <tên>\n"
            f"✅ Xóa file: {p}{c} delete <tên_file>\n"
            f"✅ Reset file mặc định: {p}{c} reset\n\n"
            f"📁 File hiện tại: {vf}\n"
            f"👥 Đang scold: {len(tcfg.get('targets',[]))} | Tag: {len(tcfg.get('tagTargets',[]))}",
            data, threadId, type, color="or", title="SCOLD", userId=userId
        )

    # ── Scold on @mention ─────────────────────────────────────────────────────
    if sub == "on" or (len(parts) >= 2 and "@" in text and sub not in (
        "tag","delay","color","bold","italic","underline","strike",
        "size","config","list","set","addfile","delete","reset","stop","tha"
    )):
        uids = extractUids(data)
        if not uids:
            return warn("Vui lòng @mention thành viên cần scold.")
        bot_id = str(getattr(this, "uid", "") or "")
        uids   = [u for u in uids if str(u) != bot_id]
        if not uids:
            return warn("Không có target hợp lệ.")
        targets = list(tcfg.get("targets", []))
        for u in uids:
            if str(u) not in targets:
                targets.append(str(u))
        tcfg["targets"] = targets
        _save_thread_cfg(this.uid, tid, tcfg)
        for u in uids:
            _start_spam_loop(this, u, threadId, tid)
        names = ", ".join(this.userName(u) or str(u) for u in uids)
        return ok(f"✅ Đã bật scold (spam) cho: {names}")

    # ── Tha / Stop ────────────────────────────────────────────────────────────
    if sub in ("stop", "tha"):
        uids  = extractUids(data)
        all_t = list(tcfg.get("targets", [])) + list(tcfg.get("tagTargets", []))
        if not all_t:
            return warn("Không có ai đang bị scold.")
        if not uids:
            old_targets = list(tcfg.get("targets", []))
            tcfg["targets"]    = []
            tcfg["tagTargets"] = []
            _save_thread_cfg(this.uid, tid, tcfg)
            for u in old_targets:
                _stop_spam_loop(this.uid, tid, u)
            return ok("✅ Đã tha toàn bộ.")
        for u in uids:
            _reset_cooldown(this.uid, tid, str(u))
            _stop_spam_loop(this.uid, tid, str(u))
        tcfg["targets"]    = [x for x in tcfg.get("targets",    []) if x not in [str(u) for u in uids]]
        tcfg["tagTargets"] = [x for x in tcfg.get("tagTargets", []) if x not in [str(u) for u in uids]]
        _save_thread_cfg(this.uid, tid, tcfg)
        names = ", ".join(this.userName(u) or str(u) for u in uids)
        return ok(f"✅ Đã tha: {names}")

    # ── Tag ───────────────────────────────────────────────────────────────────
    if sub == "tag":
        uids = extractUids(data)
        if not uids:
            return warn("Vui lòng @mention thành viên cần spam tag.")
        bot_id = str(getattr(this, "uid", "") or "")
        uids   = [u for u in uids if str(u) != bot_id]
        tag_targets = list(tcfg.get("tagTargets", []))
        for u in uids:
            if str(u) not in tag_targets:
                tag_targets.append(str(u))
        tcfg["tagTargets"] = tag_targets
        _save_thread_cfg(this.uid, tid, tcfg)
        names = ", ".join(this.userName(u) or str(u) for u in uids)
        return ok(f"✅ Đã bật spam tag cho: {names}")

    # ── Delay ─────────────────────────────────────────────────────────────────
    if sub == "delay":
        val = parts[2] if len(parts) > 2 else ""
        if not val.isdigit():
            return warn(f"Cú pháp: {p}{c} delay <250-10000>")
        ms = int(val)
        if not (250 <= ms <= 10000):
            return warn("Delay phải từ 250 đến 10000 ms.")
        tcfg["delay"] = ms
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Đã set delay: {ms}ms")

    # ── Color ─────────────────────────────────────────────────────────────────
    if sub == "color":
        mode = parts[2].lower() if len(parts) > 2 else ""
        if mode not in ("word", "char", "sentence", "off"):
            return this.replyMessageStyle(
                "Chọn chế độ màu:\n"
                "• word — mỗi từ 1 màu\n"
                "• char — mỗi ký tự 1 màu\n"
                "• sentence — 1 câu 1 màu\n"
                "• off — tắt màu\n"
                "🚨🚨🚨",
                data, threadId, type, color="or", title="SCOLD", userId=userId
            )
        tcfg["colorMode"] = mode
        _save_thread_cfg(this.uid, tid, tcfg)
        label = {"word": "mỗi từ 1 màu", "char": "mỗi ký tự 1 màu",
                 "sentence": "1 câu 1 màu", "off": "tắt màu"}.get(mode, mode)
        return ok(f"✅ Màu chữ: {label}")

    # ── Bold ──────────────────────────────────────────────────────────────────
    if sub == "bold":
        val = parts[2].lower() if len(parts) > 2 else ""
        if val not in ("on", "off"):
            return warn(f"Cú pháp: {p}{c} bold on/off")
        tcfg["bold"] = (val == "on")
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Đậm: {'bật' if tcfg['bold'] else 'tắt'}")

    # ── Italic ────────────────────────────────────────────────────────────────
    if sub == "italic":
        val = parts[2].lower() if len(parts) > 2 else ""
        if val not in ("on", "off"):
            return warn(f"Cú pháp: {p}{c} italic on/off")
        tcfg["italic"] = (val == "on")
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Nghiêng: {'bật' if tcfg['italic'] else 'tắt'}")

    # ── Underline ─────────────────────────────────────────────────────────────
    if sub == "underline":
        val = parts[2].lower() if len(parts) > 2 else ""
        if val not in ("on", "off"):
            return warn(f"Cú pháp: {p}{c} underline on/off")
        tcfg["underline"] = (val == "on")
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Gạch dưới: {'bật' if tcfg['underline'] else 'tắt'}")

    # ── Strike ────────────────────────────────────────────────────────────────
    if sub == "strike":
        val = parts[2].lower() if len(parts) > 2 else ""
        if val not in ("on", "off"):
            return warn(f"Cú pháp: {p}{c} strike on/off")
        tcfg["strike"] = (val == "on")
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Gạch ngang: {'bật' if tcfg['strike'] else 'tắt'}")

    # ── Random Size (giữ lại UI, không ảnh hưởng màu) ────────────────────────
    if sub == "size":
        val = parts[2].lower() if len(parts) > 2 else ""
        if val not in ("on", "off"):
            return warn(f"Cú pháp: {p}{c} size on/off")
        tcfg["randomSize"] = (val == "on")
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Size ngẫu nhiên: {'bật' if tcfg['randomSize'] else 'tắt'}")

    # ── Config ────────────────────────────────────────────────────────────────
    if sub == "config":
        vf          = tcfg.get("varFile") or "(mặc định chui.txt)"
        targets     = tcfg.get("targets",    [])
        tag_targets = tcfg.get("tagTargets", [])
        t_names  = ", ".join(this.userName(u) or u for u in targets)     or "Không có"
        tt_names = ", ".join(this.userName(u) or u for u in tag_targets) or "Không có"
        cm = {"off":"tắt","word":"theo từ","char":"theo ký tự","sentence":"theo câu"}.get(
            tcfg.get("colorMode", "off"), "tắt")
        return this.replyMessageStyle(
            f"⚙️ CẤU HÌNH SCOLD\n\n"
            f"📁 File var: {vf}\n"
            f"⏱ Delay: {tcfg.get('delay', _DEFAULT_DELAY)}ms\n"
            f"🎨 Màu: {cm}\n"
            f"𝐁 Đậm: {'✅' if tcfg.get('bold') else '❌'}\n"
            f"𝐼 Nghiêng: {'✅' if tcfg.get('italic') else '❌'}\n"
            f"U̲ Gạch dưới: {'✅' if tcfg.get('underline') else '❌'}\n"
            f"S̶ Gạch ngang: {'✅' if tcfg.get('strike') else '❌'}\n\n"
            f"👥 Scold ({len(targets)}): {t_names}\n"
            f"🏷 Spam tag ({len(tag_targets)}): {tt_names}",
            data, threadId, type, color="or", title="SCOLD", userId=userId
        )

    # ── List var files ────────────────────────────────────────────────────────
    if sub == "list":
        files = _list_varfiles()
        cur   = tcfg.get("varFile") or "(mặc định)"
        if not files:
            return warn(f"Chưa có file var nào. Dùng {p}{c} addfile <tên> để thêm.")
        lines = "\n".join(
            f"  {'→' if f == tcfg.get('varFile') else ' '} {i+1}. {f}"
            for i, f in enumerate(files)
        )
        return this.replyMessageStyle(
            f"📁 Danh sách file var ({len(files)} file):\n{lines}\n\nĐang dùng: {cur}",
            data, threadId, type, color="or", title="SCOLD", userId=userId
        )

    # ── Set var file ──────────────────────────────────────────────────────────
    if sub == "set":
        name = parts[2] if len(parts) > 2 else ""
        if not name:
            return warn(f"Cú pháp: {p}{c} set <tên_file>")
        path = os.path.join(_SCOLD_DIR, f"{name}.txt")
        if not os.path.exists(path):
            return err(f"File '{name}.txt' không tồn tại.")
        tcfg["varFile"] = name
        _queue_cache.pop(path, None)
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Đã set file var: {name}.txt")

    # ── Add var file ──────────────────────────────────────────────────────────
    if sub == "addfile":
        name = parts[2] if len(parts) > 2 else ""
        if not name:
            return warn(f"Cú pháp: {p}{c} addfile <tên> (reply vào tin nhắn chứa nội dung)")
        _ensure_dir()
        path         = os.path.join(_SCOLD_DIR, f"{name}.txt")
        replied_text = ""
        try:
            quote = getattr(data, "quote", None)
            if quote:
                replied_text = getattr(quote, "msg", "") or ""
        except Exception:
            pass
        if not replied_text:
            return warn("Vui lòng reply vào tin nhắn chứa nội dung (mỗi dòng 1 câu chửi).")
        with open(path, "w", encoding="utf-8") as f:
            f.write(replied_text)
        line_count = len([l for l in replied_text.splitlines() if l.strip()])
        return ok(f"✅ Đã lưu file '{name}.txt' ({line_count} câu)")

    # ── Delete var file ───────────────────────────────────────────────────────
    if sub == "delete":
        name = parts[2] if len(parts) > 2 else ""
        if not name:
            return warn(f"Cú pháp: {p}{c} delete <tên_file>")
        path = os.path.join(_SCOLD_DIR, f"{name}.txt")
        if not os.path.exists(path):
            return err(f"File '{name}.txt' không tồn tại.")
        os.remove(path)
        _queue_cache.pop(path, None)
        if tcfg.get("varFile") == name:
            tcfg["varFile"] = None
            _save_thread_cfg(this.uid, tid, tcfg)
        return ok(f"✅ Đã xóa file '{name}.txt'")

    # ── Reset ─────────────────────────────────────────────────────────────────
    if sub == "reset":
        tcfg["varFile"] = None
        _save_thread_cfg(this.uid, tid, tcfg)
        return ok("✅ Đã reset về file var mặc định (chui.txt)")

    return warn(f"Lệnh không hợp lệ. Dùng {p}{c} help.")


dependencies = {
    "name":        "scold",
    "permission":  2,
    "description": "Chửi target nâng cao: delay, màu, bold, italic, size, multi-file var",
    "cooldown":    2,
    "main":        scoldCommand,
    "listener":    scoldListener,
}
