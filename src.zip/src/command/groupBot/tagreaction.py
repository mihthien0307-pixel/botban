from app.core.index import *
import random

# ═══════════════════════════════════════════════════════════
# tagreaction.py – Tự thả reaction khi bị tag (@mention)
#
# Cách dùng:
#   tagreaction  →  lần 1: BẬT, lần 2: TẮT (toggle)
# ═══════════════════════════════════════════════════════════

# Toàn bộ icon Zalo + emoji unicode
ALL_REACTION_ICONS = [
    # Emoji unicode
    "❤️", "😆", "😍", "😮", "😢", "👍", "🎉", "🙌",
    "😂", "🥰", "😎", "😜", "🤩", "😭", "🔥", "💯",
    "🥳", "😘", "🤗", "😏", "😤", "🤣", "💪", "👏",
    # Zalo text icon
    ":~", ":b", ":')", "8-)", ":-((",
    ":$", ":3", ":z", ":((", "&-(",
    ":-h", ":p", ":d", ":o", ":(",
    ";-)", "--b", ":))", ":-*", ";p",
    ";-d", "/-showlove", ";d", ";o", ";g",
    "|-)", ":!", ":l", ":>", ":;",
    ";f", ":v", ":wipe", ":-dig", ":handclap",
    "b-)", ":-r", ":-<", ":-o", ";-s",
    ";?", ";-x", ":-f", "8*)", ";!",
    ";-!", ";xx", ":-bye", ">-|", "p-(",
    ":--|", ":q", "x-)", ":*", ";-a",
    "8*", ":|", ":x", ":t", ";-/",
    ":-l", "$-)", "/-li", "/-ok", "/-punch",
    "/-no",
]

# Số icon thả mỗi lần bị tag
REACTION_COUNT = 8


def _is_enabled(this) -> bool:
    return read_settings(this.uid).get("tagReactionEnabled", False)


# ── Lệnh toggle (chỉ gõ "tagreaction" là đủ) ────────────────

def tagReactionCommand(this, message, data, userId, threadId, type):
    s = read_settings(this.uid)

    # Toggle: BẬT → TẮT, TẮT → BẬT
    enabled = not s.get("tagReactionEnabled", False)
    s["tagReactionEnabled"] = enabled
    write_settings(this.uid, s)

    if enabled:
        msg_text = (
            "✅ Đã Bật thả reaction khi được tag!\n"
            "✅✅✅"
        )
        color = "gr"
    else:
        msg_text = (
            "❌ Đã Tắt thả reaction khi được tag!\n"
            "✅✅✅"
        )
        color = "r"

    this.replyMessageStyle(
        msg_text,
        data, threadId, type,
        color=color, title="SUCCESS", userId=userId,
    )


# ── Listener: gọi từ main.py trong onMessage ─────────────────
# Mỗi tin nhắn tới đều đi qua đây. Nếu tagreaction đang BẬT và
# tin nhắn có @tag chính mình (this.uid), bot sẽ tự thả reaction
# ngẫu nhiên 8 icon vào tin nhắn đó.

def tagReactionListener(this, message, data, userId, threadId, type):
    try:
        if not _is_enabled(this):
            return

        bot_id = str(getattr(this, "uid", "") or "")
        if not bot_id:
            return

        # Bỏ qua tin nhắn do chính bot gửi
        if str(userId) == bot_id:
            return

        tagged_uids = extractUids(data)
        if bot_id not in [str(u) for u in tagged_uids]:
            return

        # Chọn ngẫu nhiên 8 icon từ danh sách và thả reaction
        icons = random.sample(ALL_REACTION_ICONS, min(REACTION_COUNT, len(ALL_REACTION_ICONS)))
        for icon in icons:
            try:
                this.sendReaction(data, icon, threadId, type, 100000000)
            except Exception:
                pass

    except Exception as e:
        print(f"[tagreaction] Lỗi: {e}")


dependencies = {
    "name":        "tagreaction",
    "permission":  2,
    "description": "Bật/tắt tự thả reaction khi bị tag (@mention) – gõ lần 1 BẬT, lần 2 TẮT",
    "alias":       ["tagreact"],
    "cooldown":    1,
    "main":        tagReactionCommand,
}
