"""
capcut.py – Lệnh tìm & tải template CapCut cho zBot
Đặt file này vào: zbot/src/command/music/capcut.py
"""
import os
import re
import time
import uuid
import threading

from src.services.browserAPI.capcutApi import search_capcut
from src.services.pillow.capcutCard import draw_capcut_list, draw_capcut_card
from app.core.index import *

Timeout = 120   # giây chờ user chọn

CAPCUT_CAPTIONS = [
    "Sáng tạo không giới hạn với CapCut! 🎬",
    "Mỗi video là một câu chuyện chờ được kể. 🎞️",
    "Chỉnh sửa đỉnh cao, viral không cần cố. 🔥",
    "Template đẹp – video xịn – trending ngay! ✨",
    "Một template hay có thể thay đổi cả video. 🎥",
]
_cap_idx = 0

def _next_caption():
    global _cap_idx
    cap     = CAPCUT_CAPTIONS[_cap_idx % len(CAPCUT_CAPTIONS)]
    _cap_idx += 1
    return cap


# ── State management ──────────────────────────────────────────────────────────

def _state_key(self, userId):
    return f"{self.uid}_{userId}"

def _get_state(self, userId):
    if not hasattr(self, "_capcutStates"):
        self._capcutStates = {}
    return self._capcutStates.get(_state_key(self, userId))

def _set_state(self, userId, state):
    if not hasattr(self, "_capcutStates"):
        self._capcutStates = {}
    self._capcutStates[_state_key(self, userId)] = state

def _del_state(self, userId):
    if hasattr(self, "_capcutStates"):
        self._capcutStates.pop(_state_key(self, userId), None)


# ── Delete bot's list-image message ──────────────────────────────────────────

def _delete_list_msg(self, state):
    mid = state.get("msgId")
    cid = state.get("cliMsgId")
    tid = state.get("threadId")
    if not (mid and tid):
        return
    try:
        self.deleteMessage(mid, self.uid, cid, tid)
    except Exception:
        pass


# ── Countdown icon (giống zing) ───────────────────────────────────────────────

def _start_capcut_cooldown(self, MsgObj, ThreadId, ThreadType):
    """Đếm ngược icon 🕑 trên tin nhắn list, giống StartZingCooldown."""
    if not hasattr(self, "_capcutCooldown"):
        self._capcutCooldown = {}

    key = MsgObj.msgId
    self._capcutCooldown[key] = True

    msg = MessageObject(
        msgId=MsgObj.msgId,
        cliMsgId=MsgObj.clientId,
        msgType="webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not self._capcutCooldown.get(key):
                break
            self.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            self.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        self._capcutCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()


def _stop_capcut_cooldown(self, state):
    """Dừng countdown khi user đã chọn hoặc huỷ."""
    key = state.get("msgId")
    if hasattr(self, "_capcutCooldown") and key:
        self._capcutCooldown[key] = False


# ── Timeout loop ──────────────────────────────────────────────────────────────

def _init_timeout(self):
    def _loop():
        while True:
            now = time.time()
            if hasattr(self, "_capcutStates"):
                for key, state in list(self._capcutStates.items()):
                    if now - state["time"] > Timeout:
                        self._capcutStates.pop(key, None)
                        _stop_capcut_cooldown(self, state)
                        _delete_list_msg(self, state)
                        try:
                            self.sendMentionStyle(
                                "Hết thời gian chọn, hãy tìm lại nhé.",
                                state["userId"],
                                state["threadId"],
                                state["threadType"],
                            )
                        except Exception:
                            pass
            time.sleep(5)

    threading.Thread(target=_loop, daemon=True).start()


# ── Main command ──────────────────────────────────────────────────────────────

def CapcutCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Khởi timeout loop một lần
    if not getattr(self, "_capcutTimeoutStarted", False):
        self._capcutTimeoutStarted = True
        _init_timeout(self)

    Parts = MessageObj.text.strip().split()

    if len(Parts) < 2:
        return self.replyMessageStyle(
            f"Nhập từ khoá template cần tìm.\n"
            f"Ví dụ: {self.prefix}capcut Couple Chill",
            Data, ThreadId, ThreadType,
            color="or", title="CAPCUT", userId=UserId,
        )

    Arg   = " ".join(Parts[1:])
    State = _get_state(self, UserId)

    if Arg.strip().isdigit() and State:
        if time.time() - State["time"] > Timeout:
            _del_state(self, UserId)
            return self.sendMentionStyle(
                "Hết thời gian, hãy tìm lại.", UserId, ThreadId, ThreadType
            )

        num = int(Arg.strip())
        if num == 0:
            _stop_capcut_cooldown(self, State)
            _delete_list_msg(self, State)
            _del_state(self, UserId)
            return self.sendMentionStyle(
                "Đã huỷ tìm template.", UserId, ThreadId, ThreadType
            )

        templates = State["templates"]
        if num < 1 or num > len(templates):
            return

        _stop_capcut_cooldown(self, State)
        _delete_list_msg(self, State)
        _del_state(self, UserId)

        self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 10000000)
        threading.Thread(
            target=lambda: _send_template(self, Data, templates[num - 1], UserId, ThreadId, ThreadType),
            daemon=True,
        ).start()
        return

    # Tìm kiếm mới
    self.sendReaction(Data, "🎬", ThreadId, ThreadType, 10000000)
    query     = Arg
    templates = search_capcut(query)

    if not templates:
        return self.replyMessageStyle(
            f"Không tìm thấy template với từ khoá: {query}",
            Data, ThreadId, ThreadType,
            color="r", title="CAPCUT", userId=UserId,
        )

    # Vẽ card danh sách
    list_url  = None
    list_path = None
    try:
        os.makedirs("data/assets/cache/cards", exist_ok=True)
        list_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
        draw_capcut_list(templates, list_path)
        image_res = self._uploadImage(list_path, ThreadId, ThreadType)
        if isinstance(image_res, dict):
            list_url = image_res.get("normalUrl") or image_res.get("hdUrl")
        elif isinstance(image_res, str) and image_res.startswith("http"):
            list_url = image_res
    except Exception as e:
        print(f"[Capcut] card error: {e}")
    finally:
        if list_path and os.path.exists(list_path):
            try:
                os.remove(list_path)
            except Exception:
                pass

    name         = self.userName(UserId) or str(UserId)
    mention_text = f"@{name}"
    caption      = f"🎬 {mention_text} Gửi số (1-{len(templates)}) để tải • 0 để huỷ"

    if list_url:
        Msg = self.sendRemoteImage(
            list_url, ThreadId, ThreadType,
            width=2560, height=1440,          # khớp với kích thước mới
            message=Message(
                text=caption,
                mention=Mention(UserId, length=len(mention_text), offset=3),
            ),
        )
    else:
        lines = [f"🎬 Kết quả CapCut: \"{query}\"\n"]
        for i, t in enumerate(templates, 1):
            lines.append(f"{i}. {t.get('title', 'Unknown')}")
        lines.append("\n0. Huỷ")
        Msg = self.sendMentionStyle("\n".join(lines), UserId, ThreadId, ThreadType)

    _set_state(self, UserId, {
        "templates":  templates,
        "time":       time.time(),
        "msgId":      getattr(Msg, "msgId",    None),
        "cliMsgId":   getattr(Msg, "clientId", None),
        "threadId":   ThreadId,
        "threadType": ThreadType,
        "userId":     UserId,
    })

    # Bắt đầu countdown icon
    _start_capcut_cooldown(self, Msg, ThreadId, ThreadType)


# ── Reply handler ─────────────────────────────────────────────────────────────

def CapcutReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    State = _get_state(self, UserId)
    if not State or not Data.quote:
        return

    raw     = MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)
    cleaned = re.sub(r"@\S+", "", raw)
    m       = re.search(r"\b(\d+)\b", cleaned)
    if not m:
        return

    NumMsg = Message(text=f"{self.prefix}capcut {m.group(1)}")
    CapcutCommand(self, NumMsg, Data, UserId, ThreadId, ThreadType)


# ── Send selected template ────────────────────────────────────────────────────

def _send_template(self, Data, template, UserId, ThreadId, ThreadType):
    video_url = template.get("video_url")
    if not video_url:
        return self.replyMessageStyle(
            "Template này không có link video.",
            Data, ThreadId, ThreadType,
            color="r", title="CAPCUT", userId=UserId,
        )

    cover_url = template.get("cover_url", "")
    dur_ms    = template.get("duration", 0) or 0
    # sendRemoteVideo nhận duration tính bằng ms — KHÔNG chia 1000
    dur_sec   = dur_ms // 1000 if dur_ms > 1000 else dur_ms

    name         = self.userName(UserId) or str(UserId)
    mention_text = f"@{name}"
    caption_line = _next_caption()
    caption      = f"🎬 {mention_text} {caption_line}"

    # Vẽ canvas card rồi upload + gửi kèm caption mention
    card_path = None
    card_sent = False
    try:
        os.makedirs("data/assets/cache/cards", exist_ok=True)
        card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}_card.jpg"
        draw_capcut_card(template, card_path)

        image_res = self._uploadImage(card_path, ThreadId, ThreadType)
        image_url = None
        if isinstance(image_res, dict):
            image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
        elif isinstance(image_res, str) and image_res.startswith("http"):
            image_url = image_res

        if image_url:
            self.sendRemoteImage(
                image_url,
                ThreadId, ThreadType,
                width=2560, height=640,
                message=Message(
                    text=caption,
                    mention=Mention(UserId, length=len(mention_text), offset=3),
                ),
            )
            card_sent = True
    except Exception as e:
        print(f"[Capcut] canvas card error: {e}")
    finally:
        if card_path and os.path.exists(card_path):
            try:
                os.remove(card_path)
            except Exception:
                pass

    if not card_sent:
        self.send(
            Message(
                text=caption,
                mention=Mention(UserId, length=len(mention_text), offset=3),
            ),
            ThreadId, ThreadType,
        )

    # Gửi video — download trước rồi upload lên Zalo CDN
    try:
        import requests as _req
        vid_path = f"data/assets/cache/cards/{uuid.uuid4().hex}_capcut.mp4"
        os.makedirs(os.path.dirname(vid_path), exist_ok=True)

        # Download video với CapCut headers
        _cc_headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36",
            "Referer": "https://www.capcut.com/",
        }
        r = _req.get(video_url, headers=_cc_headers, stream=True, timeout=60)
        r.raise_for_status()
        with open(vid_path, "wb") as vf:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if chunk:
                    vf.write(chunk)

        # Upload lên Zalo CDN
        up = None
        try:
            up = self._uploadAttachment(vid_path, ThreadId, ThreadType)
        finally:
            try:
                os.remove(vid_path)
            except Exception:
                pass

        zalo_url = up.get("fileUrl") if up else None
        if not zalo_url:
            raise Exception("Upload video lên Zalo thất bại")

        self.sendRemoteVideo(
            zalo_url,
            thumbnailUrl=cover_url,
            duration=dur_ms,    # ms
            threadId=ThreadId,
            type=ThreadType,
            width=1080,
            height=1920,
            message=Message(text=""),
            ttl=3_600_000,
        )
    except Exception as e:
        print(f"[Capcut] send video error: {e}")
        self.replyMessageStyle(
            f"Không tải được video: {e}",
            Data, ThreadId, ThreadType,
            color="r", title="CAPCUT", userId=UserId,
        )

    self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100_000_000)


# ── dependencies ──────────────────────────────────────────────────────────────

dependencies = {
    "name":        "capcut",
    "alias":       ["cc", "template"],
    "permission":  0,
    "description": "Tìm & tải template CapCut",
    "cooldown":    5,
    "main":        CapcutCommand,
}
