"""
editvideo.py – Lệnh chỉnh sửa video cho zBot
Đặt file này vào: zbot/src/command/music/editvideo.py

Tính năng:
  - Cắt video theo thời gian        : .editvideo cut <start> <end>
  - Thay đổi tốc độ video           : .editvideo speed <0.5|1.5|2>
  - Thêm chữ lên video              : .editvideo text <nội dung chữ>
  - Xoay video                      : .editvideo rotate <90|180|270>
  - Lấy thumbnail (ảnh đại diện)    : .editvideo thumb
  - Giảm dung lượng (compress)      : .editvideo compress
  - Tách âm thanh khỏi video        : .editvideo audio
  - Debug cấu trúc data.quote       : .editvideo debug

Yêu cầu hệ thống:
  - ffmpeg (sudo apt install ffmpeg)
  - yt-dlp (pip install yt-dlp)
"""

import os
import re
import json
import time
import uuid
import shutil
import threading
import subprocess
import requests

from app.core.index import *

# ─── Hằng số ──────────────────────────────────────────────────────────────────

CACHE_DIR      = "data/assets/cache/video"
MAX_SIZE_MB    = 60
TIMEOUT_DL     = 120
TIMEOUT_FFMPEG = 180

HELP_TEXT = (
    "🎬 EDIT VIDEO\n"
    "─────────────────\n"
    "Reply vào video rồi dùng:\n"
    "• cut <start> <end>  – Cắt đoạn (VD: cut 0:10 0:45)\n"
    "• speed <x>          – Tốc độ (VD: speed 1.5 / speed 0.5)\n"
    "• text <nội dung>    – Thêm chữ (VD: text Xin chào)\n"
    "• rotate <góc>       – Xoay (90 / 180 / 270)\n"
    "• thumb              – Lấy ảnh thumbnail\n"
    "• compress           – Nén nhỏ dung lượng\n"
    "• audio              – Tách âm thanh ra file mp3\n"
    "• debug              – Xem cấu trúc data để fix lỗi\n"
    "─────────────────\n"
    "Hỗ trợ link TikTok, YouTube Shorts, Facebook."
)

# ─── Debug helper ─────────────────────────────────────────────────────────────

def _dump_obj(obj, depth=0, max_depth=4) -> str:
    """Chuyển object/dict thành string dễ đọc để debug."""
    if depth > max_depth:
        return "..."
    indent = "  " * depth
    if obj is None:
        return "None"
    if isinstance(obj, dict):
        if not obj:
            return "{}"
        lines = ["{"]
        for k, v in list(obj.items())[:20]:  # giới hạn 20 key
            val_str = _dump_obj(v, depth + 1, max_depth)
            lines.append(f"{indent}  {k!r}: {val_str}")
        lines.append(indent + "}")
        return "\n".join(lines)
    if isinstance(obj, (list, tuple)):
        if not obj:
            return "[]"
        lines = ["["]
        for i, v in enumerate(obj[:5]):  # giới hạn 5 phần tử
            lines.append(f"{indent}  [{i}] {_dump_obj(v, depth + 1, max_depth)}")
        if len(obj) > 5:
            lines.append(f"{indent}  ... ({len(obj)} items total)")
        lines.append(indent + "]")
        return "\n".join(lines)
    if isinstance(obj, str):
        s = obj[:200]
        return repr(s + ("..." if len(obj) > 200 else ""))
    # object có __dict__
    try:
        d = vars(obj)
        return f"<{type(obj).__name__}>\n" + _dump_obj(d, depth, max_depth)
    except Exception:
        return repr(obj)[:200]


def _debug_data(self, data, userId, threadId, threadType):
    """Gửi toàn bộ cấu trúc data.quote để debug."""
    lines = ["🔍 DEBUG DATA STRUCTURE\n"]

    # --- data.quote / reference / fallbacks ---
    q = getattr(data, "quote", None)
    lines.append(f"data.quote type: {type(q).__name__}")
    lines.append(_dump_obj(q, depth=0, max_depth=3))
    lines.append("")

    # --- Các fallback attrs ---
    for attr in ("reference", "msgSender", "replyTo", "quotedMsg", "forwardedMsg", "attach"):
        val = getattr(data, attr, "N/A")
        if val != "N/A":
            lines.append(f"data.{attr} type: {type(val).__name__}")
            lines.append(_dump_obj(val, depth=0, max_depth=2))
            lines.append("")

    # --- data.content ---
    c = getattr(data, "content", None)
    lines.append(f"data.content type: {type(c).__name__}")
    if isinstance(c, str):
        lines.append(repr(c[:300]))
    else:
        lines.append(_dump_obj(c, depth=0, max_depth=2))
    lines.append("")

    # --- data.msgType ---
    mt = getattr(data, "msgType", None)
    lines.append(f"data.msgType: {mt!r}")

    # --- data.reference ---
    ref = getattr(data, "reference", None)
    lines.append(f"data.reference: {_dump_obj(ref, depth=0, max_depth=1)}")

    full_text = "\n".join(lines)

    # Chia nhỏ nếu quá dài (Zalo giới hạn độ dài tin nhắn)
    chunk_size = 800
    chunks = [full_text[i:i+chunk_size] for i in range(0, len(full_text), chunk_size)]
    for i, chunk in enumerate(chunks[:4]):  # max 4 tin
        self.replyMessageStyle(
            chunk,
            data, threadId, threadType,
            color="or",
            title=f"DEBUG [{i+1}/{len(chunks)}]",
            userId=userId,
        )


# ─── Tiện ích ─────────────────────────────────────────────────────────────────

def _ensure_ffmpeg():
    return shutil.which("ffmpeg") is not None

def _ensure_ytdlp():
    return shutil.which("yt-dlp") is not None

def _tmp_path(ext="mp4"):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"ev_{uuid.uuid4().hex}.{ext}")

def _parse_time(t: str) -> float:
    t = t.strip()
    if ":" in t:
        parts = t.split(":")
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    return float(t)

def _run_ffmpeg(*args, timeout=TIMEOUT_FFMPEG):
    cmd = ["ffmpeg", "-y", *args]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stderr
    except subprocess.TimeoutExpired:
        return False, "ffmpeg timeout"
    except FileNotFoundError:
        return False, "ffmpeg không tìm thấy"

def _get_video_info(path):
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=width,height,duration",
             "-of", "csv=p=0", path],
            capture_output=True, text=True, timeout=15,
        )
        parts = r.stdout.strip().split(",")
        w   = int(parts[0]) if len(parts) > 0 and parts[0].isdigit() else 0
        h   = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
        dur = float(parts[2]) if len(parts) > 2 else 0.0
        return w, h, dur
    except Exception:
        return 0, 0, 0.0


# ─── Extract URL từ quote – hỗ trợ mọi kiểu tin nhắn Zalo ────────────────────

def _extract_url_deep(obj, depth=0) -> str | None:
    """
    Duyệt đệ quy object/dict để tìm URL video (.mp4, .mov, .webm)
    hoặc link TikTok/YouTube/Facebook.
    """
    if obj is None or depth > 6:
        return None

    VIDEO_DOMAINS = ["tiktok.com", "youtu", "facebook.com", "fb.watch",
                     "instagram.com", "capcut.com"]
    VIDEO_EXT     = re.compile(r"\.(mp4|mov|webm|mkv)(\?|$)", re.I)
    VIDEO_KEYS    = ["videoUrl", "href", "url", "fileUrl", "normalUrl",
                     "hdUrl", "src", "link", "streamUrl", "playUrl",
                     "shareUrl", "originUrl", "attachUrl", "thumbUrl"]
    # Zalo CDN domains (video upload trực tiếp)
    ZALO_CDN      = ["dlmd.me", "zdn.vn", "zalo.me", "zadn.vn", "zstatic.net"]

    def _is_video_url(u: str) -> bool:
        if not u or not isinstance(u, str):
            return False
        u = u.replace("\\/", "/")  # unescape nếu chưa qua json.loads
        if VIDEO_EXT.search(u):
            return True
        if any(d in u for d in VIDEO_DOMAINS) and u.startswith("http"):
            return True
        if any(d in u for d in ZALO_CDN) and u.startswith("http"):
            return True
        return False

    def _is_zalo_media_url(u: str) -> bool:
        """Nhận diện URL CDN Zalo (video upload) — không có extension .mp4."""
        if not u or not isinstance(u, str):
            return False
        u = u.replace("\\/", "/")
        return u.startswith("http") and any(d in u for d in ZALO_CDN)

    def _clean_url(u: str) -> str:
        return u.replace("\\/", "/") if u else u

    if isinstance(obj, str):
        return obj if _is_video_url(obj) else None

    if isinstance(obj, dict):
        # Ưu tiên các key rõ ràng trước
        for k in VIDEO_KEYS:
            v = obj.get(k)
            if v and isinstance(v, str):
                v_clean = _clean_url(v)
                if _is_video_url(v_clean) or _is_zalo_media_url(v_clean):
                    return v_clean
        # Parse trường 'attach' nếu là JSON string (Zalo video quote)
        attach = obj.get("attach")
        if attach and isinstance(attach, str):
            try:
                attach_data = json.loads(attach)
                r = _extract_url_deep(attach_data, depth + 1)
                if r:
                    return r
            except Exception:
                pass
        # Tìm đệ quy trong values
        for v in obj.values():
            if isinstance(v, (dict, list, str)):
                r = _extract_url_deep(v, depth + 1)
                if r:
                    return r
        return None

    if isinstance(obj, (list, tuple)):
        for item in obj:
            r = _extract_url_deep(item, depth + 1)
            if r:
                return r
        return None

    # Object thường (không phải dict/list/str)
    # Thử các key phổ biến trực tiếp
    for k in VIDEO_KEYS:
        v = getattr(obj, k, None)
        if v and isinstance(v, str):
            v_clean = _clean_url(v)
            if _is_video_url(v_clean) or _is_zalo_media_url(v_clean):
                return v_clean
    # Thử parse trường 'attach' nếu là JSON string (Zalo video quote)
    attach = getattr(obj, "attach", None)
    if attach and isinstance(attach, str):
        try:
            attach_data = json.loads(attach)
            r = _extract_url_deep(attach_data, depth + 1)
            if r:
                return r
        except Exception:
            pass
    # Thử __dict__
    try:
        return _extract_url_deep(vars(obj), depth + 1)
    except Exception:
        pass

    return None


def _get_video_from_data(self, data, threadId, threadType) -> tuple[str | None, str]:
    """
    Lấy URL video từ message data.
    Hỗ trợ: reply vào video upload, reply vào TikTok card, reply vào share link,
             gửi link trực tiếp trong text.
    Trả về (url, error_msg).
    """

    # ── 1. Kiểm tra data.quote (reply vào tin nhắn có video) ──────────────────
    q = getattr(data, "quote", None)

    # Fallback: một số Zalo SDK version dùng data.reference thay vì data.quote
    if q is None:
        q = getattr(data, "reference", None)
    # Fallback thêm: msgSender / replyTo / quotedMsg
    if q is None:
        for attr in ("msgSender", "replyTo", "quotedMsg", "forwardedMsg", "attach"):
            q = getattr(data, attr, None)
            if q is not None:
                logger.info(f"[editvideo] Found quote in data.{attr}")
                break

    if q:
        url = _extract_url_deep(q)
        if url:
            logger.info(f"[editvideo] Found video URL in quote: {url[:80]}")
            return url, ""

        # Nếu quote là dict thử lấy msgId để gọi API lấy nội dung gốc
        # (Zalo đôi khi không đính kèm URL trong quote, chỉ có msgId)
        q_dict = q if isinstance(q, dict) else (vars(q) if hasattr(q, "__dict__") else {})
        msg_id = q_dict.get("msgId") or q_dict.get("globalMsgId") or ""
        if msg_id:
            logger.info(f"[editvideo] quote has msgId={msg_id} but no video URL found directly")

    # ── 2. Kiểm tra data.content (attachment hoặc forward card) ───────────────
    c = getattr(data, "content", None)
    if c and not isinstance(c, str):
        url = _extract_url_deep(c)
        if url:
            logger.info(f"[editvideo] Found video URL in content: {url[:80]}")
            return url, ""

    # ── 2b. Nếu content là string, thử parse JSON (Zalo đôi khi encode JSON vào string) ──
    if isinstance(c, str) and c.strip().startswith("{"):
        try:
            c_parsed = json.loads(c)
            url = _extract_url_deep(c_parsed)
            if url:
                logger.info(f"[editvideo] Found video URL in content (JSON string): {url[:80]}")
                return url, ""
        except Exception:
            pass

    # ── 3. Tìm URL trong text của tin nhắn ────────────────────────────────────
    msg_text = c if isinstance(c, str) else ""
    if not msg_text:
        msg_text = str(getattr(data, "message", "") or "")
    if not msg_text and isinstance(c, dict):
        msg_text = c.get("content", "") or c.get("text", "") or ""

    VIDEO_DOMAINS = ["tiktok.com", "youtu", "facebook.com", "fb.watch",
                     "instagram.com", "capcut.com"]
    urls = re.findall(r"https?://\S+", str(msg_text))
    for u in urls:
        if any(d in u for d in VIDEO_DOMAINS):
            logger.info(f"[editvideo] Found video domain URL in text: {u[:80]}")
            return u, ""
        if re.search(r"\.(mp4|mov|webm)", u, re.I):
            logger.info(f"[editvideo] Found direct video URL in text: {u[:80]}")
            return u, ""

    # ── 4. Không tìm thấy – hướng dẫn người dùng debug ───────────────────────
    has_quote = q is not None
    return None, (
        "❌ Không tìm thấy video.\n"
        f"• Quote có tồn tại: {'✅' if has_quote else '❌'}\n"
        "• Dùng lệnh .editvideo debug (reply vào video) để xem cấu trúc data\n"
        "• Hoặc gửi kèm link TikTok/YouTube/Facebook trực tiếp"
    )


# ─── Download video ───────────────────────────────────────────────────────────

def _download_video_url(url: str, out_path: str) -> tuple[bool, str]:
    # Link .mp4/.mov trực tiếp → dùng requests
    if re.search(r"\.(mp4|mov|webm|mkv)(\?|$)", url, re.I):
        try:
            r = requests.get(url, stream=True, timeout=TIMEOUT_DL,
                             headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            size = 0
            with open(out_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=512 * 1024):
                    if chunk:
                        f.write(chunk)
                        size += len(chunk)
                        if size > MAX_SIZE_MB * 1024 * 1024:
                            return False, f"File quá lớn (>{MAX_SIZE_MB}MB)"
            return True, ""
        except Exception as e:
            return False, str(e)

    # Link trang TikTok/YouTube/FB → dùng yt-dlp
    if not _ensure_ytdlp():
        return False, "yt-dlp chưa cài (pip install yt-dlp)"
    try:
        cmd = [
            "yt-dlp",
            "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "--merge-output-format", "mp4",
            "--max-filesize", f"{MAX_SIZE_MB}M",
            "-o", out_path,
            "--no-playlist",
            url,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT_DL)
        if result.returncode != 0:
            return False, result.stderr[:400]
        if not os.path.exists(out_path):
            parent = os.path.dirname(out_path)
            files = sorted(
                [os.path.join(parent, f) for f in os.listdir(parent)],
                key=os.path.getmtime, reverse=True,
            )
            if files:
                os.rename(files[0], out_path)
        return os.path.exists(out_path), ""
    except subprocess.TimeoutExpired:
        return False, "yt-dlp timeout"
    except Exception as e:
        return False, str(e)


# ─── Các action xử lý video ───────────────────────────────────────────────────

def _action_cut(inp, start_s, end_s):
    out = _tmp_path("mp4")
    duration = end_s - start_s
    if duration <= 0:
        return None, "Thời gian kết thúc phải lớn hơn bắt đầu."
    ok, err = _run_ffmpeg(
        "-i", inp, "-ss", str(start_s), "-t", str(duration),
        "-c:v", "libx264", "-c:a", "aac", "-movflags", "+faststart", out,
    )
    return (out if ok else None), err

def _action_speed(inp, speed):
    out = _tmp_path("mp4")
    speed = max(0.25, min(4.0, speed))
    vf = f"setpts={1/speed:.4f}*PTS"
    if speed > 2.0:
        atempo = f"atempo=2.0,atempo={speed/2:.4f}"
    elif speed < 0.5:
        atempo = f"atempo=0.5,atempo={speed*2:.4f}"
    else:
        atempo = f"atempo={speed:.4f}"
    ok, err = _run_ffmpeg(
        "-i", inp,
        "-filter_complex", f"[0:v]{vf}[v];[0:a]{atempo}[a]",
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-c:a", "aac", out,
    )
    return (out if ok else None), err

def _action_text(inp, text, font_path=None):
    out = _tmp_path("mp4")
    escaped = text.replace("'", r"\'").replace(":", r"\:").replace("\\", r"\\")
    font_opt = f":fontfile='{font_path}'" if font_path and os.path.exists(font_path) else ""
    vf = (
        f"drawtext=text='{escaped}'{font_opt}"
        f":fontsize=48:fontcolor=white:borderw=3:bordercolor=black"
        f":x=(w-text_w)/2:y=30"
    )
    ok, err = _run_ffmpeg("-i", inp, "-vf", vf, "-c:v", "libx264", "-c:a", "copy", out)
    return (out if ok else None), err

def _action_rotate(inp, angle):
    out = _tmp_path("mp4")
    angle = angle % 360
    if angle == 90:   vf = "transpose=1"
    elif angle == 180: vf = "transpose=1,transpose=1"
    elif angle == 270: vf = "transpose=2"
    else: return None, f"Góc xoay không hợp lệ. Dùng 90, 180 hoặc 270."
    ok, err = _run_ffmpeg("-i", inp, "-vf", vf, "-c:v", "libx264", "-c:a", "copy", out)
    return (out if ok else None), err

def _action_thumb(inp, at_sec=1.0):
    out = _tmp_path("jpg")
    ok, err = _run_ffmpeg("-i", inp, "-ss", str(at_sec), "-vframes", "1", "-q:v", "2", out)
    return (out if ok else None), err

def _action_compress(inp):
    out = _tmp_path("mp4")
    ok, err = _run_ffmpeg(
        "-i", inp,
        "-vf", "scale='min(iw,1280)':'min(ih,720)':force_original_aspect_ratio=decrease",
        "-c:v", "libx264", "-crf", "28", "-preset", "fast",
        "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out,
    )
    return (out if ok else None), err

def _action_audio(inp):
    out = _tmp_path("mp3")
    ok, err = _run_ffmpeg("-i", inp, "-vn", "-c:a", "libmp3lame", "-q:a", "2", out)
    return (out if ok else None), err


# ─── Gửi kết quả ──────────────────────────────────────────────────────────────

def _send_video_via_forward(self, zalo_url, file_size, file_id, file_name, out_path, threadId, threadType, caption, duration_ms, w, h):
    """Gửi video dưới dạng file mp4 qua asyncfile/msg."""
    import hashlib as _hashlib
    from api.util.Enum import ThreadType

    if out_path and os.path.exists(out_path):
        with open(out_path, "rb") as f:
            fileChecksum = _hashlib.md5(f.read()).hexdigest()
    else:
        fileChecksum = _hashlib.md5(b"").hexdigest()

    params = {
        "zpw_ver": 645,
        "zpw_type": self.apiLogintype,
        "nretry": 0,
    }
    payload_params = {
        "fileId":      str(file_id),
        "checksum":    fileChecksum,
        "checksumSha": "",
        "extension":   "mp4",
        "totalSize":   file_size,
        "fileName":    file_name,
        "clientId":    int(time.time() * 1000),
        "fType":       1,
        "fileCount":   0,
        "fdata":       "{}",
        "fileUrl":     zalo_url,
        "zsource":     401,
        "ttl":         3_600_000,
    }
    if threadType == ThreadType.GROUP:
        url = "https://tt-files-wpa.chat.zalo.me/api/group/asyncfile/msg"
        payload_params["grid"] = str(threadId)
    else:
        url = "https://tt-files-wpa.chat.zalo.me/api/message/asyncfile/msg"
        payload_params["toid"] = str(threadId)
        payload_params["imei"] = self._imei

    payload = {"params": self._encode(payload_params)}
    resp = self._post(url, params=params, data=payload)
    result = resp.json()
    logger.info(f"[editvideo] asyncfile/msg response: {result}")
    return result.get("error_code") == 0


def _send_video(self, data, out_path, caption, userId, threadId, threadType):
    try:
        # Lấy thông tin video TRƯỚC KHI upload (finally block xóa file sau)
        w, h, dur = _get_video_info(out_path)
        duration_ms = int(dur * 1000) or 8000
        logger.info(f"[editvideo] video info: {w}x{h} dur={dur:.2f}s")

        up = self._uploadAttachment(out_path, threadId, threadType)
        logger.info(f"[editvideo] _uploadAttachment response: {up}")

        if not up or not isinstance(up, dict):
            raise Exception(f"Upload fail: {up}")

        zalo_url  = up.get("fileUrl", "")
        file_id   = up.get("fileId", 0)
        file_name = up.get("fileName", "video.mp4")
        file_size = up.get("totalSize", 0)

        if not zalo_url:
            raise Exception(f"Khong lay duoc fileUrl: {up}")

        # Gửi file mp4 qua asyncfile/msg
        sent = _send_video_via_forward(
            self, zalo_url, file_size, file_id, file_name, out_path,
            threadId, threadType, caption, duration_ms, w, h,
        )
        if sent:
            logger.info("[editvideo] Video sent OK")
            return

        # Fallback: sendRemoteFile
        logger.warning("[editvideo] asyncfile/msg fail, fallback sendRemoteFile")
        self.sendRemoteFile(
            zalo_url, threadId, threadType,
            fileName=file_name,
            fileSize=file_size,
        )
        logger.info("[editvideo] sendRemoteFile fallback OK")

    except Exception as e:
        import traceback
        logger.error(f"[editvideo] _send_video error: {e}\n{traceback.format_exc()}")
        self.replyMessageStyle(f"Gui video that bai: {e}", data, threadId, threadType,
                               color="r", title="EDIT VIDEO", userId=userId)
def _send_image(self, data, img_path, caption, userId, threadId, threadType):
    try:
        res = self._uploadImage(img_path, threadId, threadType)
        url = None
        if isinstance(res, dict):
            url = res.get("normalUrl") or res.get("hdUrl")
        elif isinstance(res, str) and res.startswith("http"):
            url = res
        if url:
            name = self.userName(userId) or str(userId)
            self.sendRemoteImage(
                url, threadId, threadType,
                message=Message(
                    text=f"@{name} {caption}",
                    mention=Mention(userId, length=len(f"@{name}"), offset=0),
                ),
            )
        else:
            raise Exception("Upload ảnh thất bại")
    except Exception as e:
        self.replyMessageStyle(f"Gửi ảnh thất bại: {e}", data, threadId, threadType,
                               color="r", title="EDIT VIDEO", userId=userId)

def _send_audio(self, data, mp3_path, caption, userId, threadId, threadType):
    try:
        self.sendLocalVoice(mp3_path, threadId, threadType)
    except Exception:
        try:
            up = self._uploadAttachment(mp3_path, threadId, threadType)
            zalo_url = up.get("fileUrl") if up else None
            if zalo_url:
                self.sendRemoteFile(zalo_url, threadId, threadType,
                                    message=Message(text=caption))
            else:
                raise Exception("Upload mp3 thất bại")
        except Exception as e:
            self.replyMessageStyle(f"Gửi audio thất bại: {e}", data, threadId, threadType,
                                   color="r", title="EDIT VIDEO", userId=userId)


# ─── Worker thread ────────────────────────────────────────────────────────────

def _worker(self, data, action, args, userId, threadId, threadType):
    inp_path = None
    out_path = None
    try:
        # 1. Lấy URL video
        video_url, err = _get_video_from_data(self, data, threadId, threadType)
        if not video_url:
            return self.replyMessageStyle(
                err, data, threadId, threadType,
                color="or", title="EDIT VIDEO", userId=userId,
            )

        logger.info(f"[editvideo] action={action} url={video_url[:80]}")

        # 2. Download
        self.replyMessageStyle(
            "⏳ Đang tải video về...",
            data, threadId, threadType,
            color="gr", title="EDIT VIDEO", userId=userId,
        )
        inp_path = _tmp_path("mp4")
        ok, err = _download_video_url(video_url, inp_path)
        if not ok or not os.path.exists(inp_path):
            return self.replyMessageStyle(
                f"❌ Tải video thất bại:\n{err}",
                data, threadId, threadType,
                color="r", title="EDIT VIDEO", userId=userId,
            )

        file_size_mb = os.path.getsize(inp_path) / (1024 * 1024)
        if file_size_mb > MAX_SIZE_MB:
            return self.replyMessageStyle(
                f"Video quá lớn ({file_size_mb:.1f}MB > {MAX_SIZE_MB}MB).",
                data, threadId, threadType,
                color="r", title="EDIT VIDEO", userId=userId,
            )

        # 3. Xử lý
        self.replyMessageStyle(
            f"🎬 Đang xử lý: {action}...",
            data, threadId, threadType,
            color="gr", title="EDIT VIDEO", userId=userId,
        )

        name = self.userName(userId) or str(userId)

        if action == "cut":
            start_s, end_s = args
            out_path, err = _action_cut(inp_path, start_s, end_s)
            if out_path:
                _send_video(self, data, out_path, f"✂️ @{name} Đã cắt {args[0]:.0f}s–{args[1]:.0f}s",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Cắt thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "speed":
            out_path, err = _action_speed(inp_path, args[0])
            if out_path:
                _send_video(self, data, out_path, f"⚡ @{name} Tốc độ x{args[0]}",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Đổi tốc độ thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "text":
            font_path = "assets/font/Goldman/Goldman-Bold.ttf"
            out_path, err = _action_text(inp_path, args[0], font_path)
            if out_path:
                _send_video(self, data, out_path, f"✏️ @{name} Chữ: {args[0]}",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Thêm chữ thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "rotate":
            out_path, err = _action_rotate(inp_path, args[0])
            if out_path:
                _send_video(self, data, out_path, f"🔄 @{name} Xoay {args[0]}°",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Xoay thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "thumb":
            out_path, err = _action_thumb(inp_path)
            if out_path:
                _send_image(self, data, out_path, "🖼️ Thumbnail video",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Lấy thumbnail thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "compress":
            out_path, err = _action_compress(inp_path)
            if out_path:
                sb = os.path.getsize(inp_path) / (1024 * 1024)
                sa = os.path.getsize(out_path) / (1024 * 1024)
                _send_video(self, data, out_path, f"📦 @{name} Nén: {sb:.1f}MB→{sa:.1f}MB",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Nén thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        elif action == "audio":
            out_path, err = _action_audio(inp_path)
            if out_path:
                _send_audio(self, data, out_path, f"🎵 @{name} Audio đã tách",
                            userId, threadId, threadType)
            else:
                self.replyMessageStyle(f"Tách audio thất bại:\n{err[:300]}", data, threadId, threadType,
                                       color="r", title="EDIT VIDEO", userId=userId)

        # Reaction thành công
        try:
            self.sendReaction(data, "/-ok", threadId, threadType, 100_000_000)
        except Exception:
            pass

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        logger.error(f"[editvideo] _worker exception: {e}\n{tb}")
        self.replyMessageStyle(
            f"❌ Lỗi không xác định:\n{e}\n\nDùng .editvideo debug để xem chi tiết.",
            data, threadId, threadType,
            color="r", title="EDIT VIDEO", userId=userId,
        )
    finally:
        for p in [inp_path, out_path]:
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass


# ─── Lệnh chính ───────────────────────────────────────────────────────────────

def EditVideoCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    # Kiểm tra ffmpeg
    if not _ensure_ffmpeg():
        return self.replyMessageStyle(
            "⚠️ ffmpeg chưa cài đặt trên server.\n"
            "Linux: sudo apt install ffmpeg\n"
            "Windows: choco install ffmpeg",
            Data, ThreadId, ThreadType,
            color="r", title="EDIT VIDEO", userId=UserId,
        )

    parts = MessageObj.text.strip().split(maxsplit=2)

    if len(parts) < 2:
        return self.replyMessageStyle(
            HELP_TEXT, Data, ThreadId, ThreadType,
            color="or", title="EDIT VIDEO", userId=UserId,
        )

    action = parts[1].lower().strip()

    # ── Debug mode: in ra toàn bộ cấu trúc data.quote ─────────────────────────
    if action == "debug":
        return _debug_data(self, Data, UserId, ThreadId, ThreadType)

    args = []

    if action == "cut":
        if len(parts) < 3:
            return self.replyMessageStyle("Thiếu thời gian. VD: .editvideo cut 0:10 0:45",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)
        time_parts = parts[2].split()
        if len(time_parts) < 2:
            return self.replyMessageStyle("Cần 2 mốc thời gian. VD: cut 0:10 0:45",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)
        try:
            args = [_parse_time(time_parts[0]), _parse_time(time_parts[1])]
        except ValueError:
            return self.replyMessageStyle("Định dạng thời gian sai. Dùng mm:ss hoặc giây.",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)

    elif action == "speed":
        if len(parts) < 3:
            return self.replyMessageStyle("Thiếu tốc độ. VD: .editvideo speed 1.5",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)
        try:
            speed = float(parts[2].strip())
            if not (0.25 <= speed <= 4.0):
                raise ValueError()
            args = [speed]
        except ValueError:
            return self.replyMessageStyle("Tốc độ phải từ 0.25 đến 4.0.",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)

    elif action == "text":
        if len(parts) < 3 or not parts[2].strip():
            return self.replyMessageStyle("Thiếu nội dung chữ. VD: .editvideo text Xin chào!",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)
        args = [parts[2].strip()]

    elif action == "rotate":
        if len(parts) < 3:
            return self.replyMessageStyle("Thiếu góc xoay. VD: .editvideo rotate 90",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)
        try:
            angle = int(parts[2].strip())
            if angle not in (90, 180, 270):
                raise ValueError()
            args = [angle]
        except ValueError:
            return self.replyMessageStyle("Góc xoay phải là 90, 180 hoặc 270.",
                                          Data, ThreadId, ThreadType, color="or",
                                          title="EDIT VIDEO", userId=UserId)

    elif action in ("thumb", "compress", "audio"):
        args = []

    elif action in ("help", "?"):
        return self.replyMessageStyle(HELP_TEXT, Data, ThreadId, ThreadType,
                                      color="gr", title="EDIT VIDEO", userId=UserId)
    else:
        return self.replyMessageStyle(
            f"Lệnh '{action}' không hợp lệ.\n{HELP_TEXT}",
            Data, ThreadId, ThreadType, color="or", title="EDIT VIDEO", userId=UserId,
        )

    # Chạy trong thread riêng để không block
    threading.Thread(
        target=_worker,
        args=(self, Data, action, args, UserId, ThreadId, ThreadType),
        daemon=True,
    ).start()


# ─── dependencies ─────────────────────────────────────────────────────────────

dependencies = {
    "name":        "editvideo",
    "alias":       ["ev", "edit", "video-edit"],
    "permission":  0,
    "description": "Chỉnh sửa video: cắt, tốc độ, chữ, xoay, thumb, nén, audio",
    "cooldown":    10,
    "noPrefix":    False,
    "is_main":     False,
    "main":        EditVideoCommand,
}
