import asyncio
import os
import re
import time
import threading
import subprocess
import requests

from src.services.pillow.tiktokCard import draw_tiktok_list
from app.module.utils import MediaCache
from app.core.index import *

Platf   = "tiktok"
Timeout = 120

# ── TikWM API ──────────────────────────────────────────────────────────────
TIKWM_BASE = "https://tikwm.com"

def _tikwm_headers():
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json, text/plain, */*",
        "Referer": TIKWM_BASE + "/",
        "Origin":  TIKWM_BASE,
    }

def _pick(d, *keys, default=None):
    cur = d
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur

def _fmt_num(n):
    try:
        n = int(n)
    except:
        return "0"
    if n >= 1_000_000_000:
        return f"{n/1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)

def _normalize_item(x):
    return {
        "id":   str(x.get("video_id") or x.get("id") or ""),
        "desc": x.get("title") or x.get("desc") or "",
        "stat": {
            "playCount":    int(x.get("play_count")    or x.get("playCount")    or 0),
            "diggCount":    int(x.get("digg_count")    or x.get("diggCount")    or 0),
            "commentCount": int(x.get("comment_count") or x.get("commentCount") or 0),
            "shareCount":   int(x.get("share_count")   or x.get("shareCount")   or 0),
        },
        "video": {
            "url":      x.get("play") or x.get("wmplay") or "",
            "cover":    x.get("cover") or x.get("origin_cover") or "",
            "duration": int((x.get("duration") or 0) * 1000) or 1000,
        },
        "author":  x.get("author") or {},
        "music": {
            "title":  _pick(x, "music_info", "title", default="") or x.get("music_title") or "",
            "url":    _pick(x, "music_info", "play",  default="") or x.get("music") or "",
            "cover":  _pick(x, "music_info", "cover", default="") or "",
            "author": _pick(x, "music_info", "author", default="") or "",
        },
    }

def _search_tiktok(keywords, limit=10):
    try:
        r = requests.post(
            f"{TIKWM_BASE}/api/feed/search",
            data={"keywords": keywords, "count": int(limit)},
            headers=_tikwm_headers(),
            timeout=20,
        )
        if r.status_code != 200:
            return []
        j = r.json()
        items = _pick(j, "data", "videos", default=None) or _pick(j, "data", default=[]) or []
        out = []
        for it in items:
            v = _normalize_item(it)
            if v["id"]:
                out.append(v)
            if len(out) >= limit:
                break
        return out
    except:
        return []

def _get_video_info(tiktok_url):
    try:
        r = requests.post(
            f"{TIKWM_BASE}/api/",
            data={"url": tiktok_url},
            headers=_tikwm_headers(),
            timeout=20,
        )
        if r.status_code != 200:
            return None
        j = r.json()
        d = j.get("data") or {}
        if not d:
            return None
        return {
            "id":   str(d.get("id") or d.get("aweme_id") or ""),
            "desc": d.get("title") or d.get("desc") or "",
            "author": {
                "uniqueId": _pick(d, "author", "unique_id", default="") or "",
                "nickname": _pick(d, "author", "nickname", default="") or "",
            },
            "music": {
                "title":  _pick(d, "music_info", "title",  default="") or "",
                "url":    _pick(d, "music_info", "play",   default="") or d.get("music") or "",
                "cover":  _pick(d, "music_info", "cover",  default="") or "",
                "author": _pick(d, "music_info", "author", default="") or "",
            },
            "video": {
                "noWatermarkUrl": d.get("hdplay") or d.get("play") or "",
                "url":            d.get("play") or "",
                "cover":          d.get("cover") or "",
                "duration":       int((d.get("duration") or 0) * 1000) or 1000,
            },
            "type": "video",
        }
    except:
        return None

def _make_tiktok_url(video_id):
    vid = str(video_id or "").strip()
    if not vid:
        return None
    if vid.startswith("http"):
        return vid
    return f"https://www.tiktok.com/@tiktok/video/{vid}"

def _retry_upload(fn, *args, retries=3, delay=2, **kwargs):
    """Gọi fn(*args, **kwargs) với retry khi gặp lỗi SSL/kết nối tạm thời."""
    import time as _time
    last_err = None
    for attempt in range(retries):
        try:
            result = fn(*args, **kwargs)
            if result:
                return result
        except Exception as e:
            err_str = str(e)
            is_transient = any(kw in err_str for kw in [
                "SSLError", "SSL", "EOF", "RemoteDisconnected",
                "Connection aborted", "ConnectionResetError",
                "Max retries exceeded", "timed out", "Timeout",
            ])
            last_err = e
            if is_transient and attempt < retries - 1:
                _time.sleep(delay * (attempt + 1))
                continue
            raise
    if last_err:
        raise last_err
    return None

def _download_file(url, out_path, timeout=180):
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    r = requests.get(url, stream=True, timeout=timeout,
                     headers={"User-Agent": "Mozilla/5.0"},
                     allow_redirects=True)
    r.raise_for_status()
    with open(out_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=256 * 1024):
            if chunk:
                f.write(chunk)
    return out_path

def _get_video_meta(file_path):
    try:
        p = subprocess.run(
            ["/usr/bin/ffmpeg", "-hide_banner", "-i", file_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        s = (p.stderr or "") + "\n" + (p.stdout or "")
    except:
        return {"duration": 0, "width": 1080, "height": 1920}

    dur = 0
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+)(?:\.(\d+))?", s)
    if m:
        h = int(m.group(1) or 0)
        mi = int(m.group(2) or 0)
        se = int(m.group(3) or 0)
        frac = m.group(4) or "0"
        ms = int(frac[:3].ljust(3, "0"))
        dur = (h * 3600 + mi * 60 + se) * 1000 + ms

    w, h2 = 1080, 1920
    for line in s.splitlines():
        if " Video:" in line:
            m2 = re.search(r"(\d{2,5})x(\d{2,5})", line)
            if m2:
                w  = int(m2.group(1))
                h2 = int(m2.group(2))
                break

    return {"duration": dur, "width": w, "height": h2}

# ── Helpers ────────────────────────────────────────────────────────────────
def _ensure_cache(this):
    if not getattr(this, "MediaCache", None):
        try:
            this.MediaCache = MediaCache()
        except:
            this.MediaCache = None

def _cache_get(cache, k, d=None):
    if not isinstance(cache, dict):
        return d
    v = cache.get(k)
    if v is not None:
        return v
    meta = cache.get("meta")
    if isinstance(meta, dict):
        v2 = meta.get(k)
        if v2 is not None:
            return v2
    return d

def _is_alive(this, url):
    try:
        return bool(url) and this.MediaCache and this.MediaCache.isAlive(url)
    except:
        return False

def _parse_args(this, text):
    s = str(text or "").strip()
    p = str(getattr(this, "prefix", "") or "")
    if p and s.startswith(p):
        s = s[len(p):].lstrip()
    cmd = str(getattr(this, "commandName", "") or getattr(this, "rawCommand", "") or "tiktok").strip().lower()
    if cmd and s.lower().startswith(cmd):
        s = s[len(cmd):].lstrip()
    return s

# ── Send Video ─────────────────────────────────────────────────────────────
def _send_video(this, data, item, threadId, type):
    _ensure_cache(this)
    vid = str(item.get("id") or "")
    cache = (this.MediaCache.get(Platf, vid) or {}) if this.MediaCache else {}

    file_url  = _cache_get(cache, "fileUrl")
    thumb_url = _cache_get(cache, "thumbnail")
    meta_w    = int(_cache_get(cache, "width",    1080) or 1080)
    meta_h    = int(_cache_get(cache, "height",   1920) or 1920)
    meta_dur  = int(_cache_get(cache, "duration", 0)    or 0)
    desc      = _cache_get(cache, "desc", "") or item.get("desc") or ""

    if file_url and not _is_alive(this, file_url):
        file_url = None

    if not file_url:
        tiktok_url = _make_tiktok_url(vid)
        info = _get_video_info(tiktok_url) if tiktok_url else None
        if not info or info.get("type") != "video":
            this.sendMentionStyle("Video không hợp lệ hoặc đây là ảnh", None, threadId, type)
            return

        v = info.get("video") or {}
        video_url = v.get("noWatermarkUrl") or v.get("url")
        if not video_url:
            this.sendMentionStyle("Không lấy được URL video", None, threadId, type)
            return

        thumb_url = v.get("cover") or ""
        desc      = info.get("desc") or item.get("desc") or ""

        os.makedirs("assets/cache", exist_ok=True)
        path = f"assets/cache/tk_{vid}_{int(time.time()*1000)}.mp4"
        try:
            _download_file(video_url, path, timeout=180)
        except:
            this.sendMentionStyle("Tải video thất bại", None, threadId, type)
            return

        meta   = _get_video_meta(path)
        meta_w = int(meta.get("width")    or 1080)
        meta_h = int(meta.get("height")   or 1920)
        meta_dur = int(meta.get("duration") or 0)

        up = None
        try:
            up = _retry_upload(this._uploadAttachment, path, threadId, type)
        finally:
            try:
                os.remove(path)
            except:
                pass

        file_url = up.get("fileUrl") if up else None
        if not file_url:
            this.sendMentionStyle("Upload video thất bại", None, threadId, type)
            return

        if this.MediaCache:
            this.MediaCache.set(
                Platf, vid,
                {"thumbnail": thumb_url, "width": meta_w, "height": meta_h,
                 "duration": meta_dur, "desc": desc},
                file_url,
            )

    this.sendReaction(data, "", threadId, type, -1)
    this.sendRemoteVideo(
        file_url,
        thumbnailUrl=thumb_url,
        duration=int(meta_dur or 0),
        threadId=threadId,
        type=type,
        width=int(meta_w or 1080),
        height=int(meta_h or 1920),
        message=Message(text=desc),
    )
    this.sendReaction(data, "/-ok", threadId, type, 100000000)

# ── Send Audio ─────────────────────────────────────────────────────────────
def _send_audio(this, data, item, threadId, type):
    _ensure_cache(this)
    vid = str(item.get("id") or "")
    cache = (this.MediaCache.get(Platf + "_audio", vid) or {}) if this.MediaCache else {}

    voice_url = _cache_get(cache, "fileUrl")
    card_hd   = _cache_get(cache, "cardHd")

    if voice_url and not _is_alive(this, voice_url):
        voice_url = None
    if card_hd and not _is_alive(this, card_hd):
        card_hd = None

    tiktok_url = _make_tiktok_url(vid)
    info = _get_video_info(tiktok_url) if tiktok_url else None
    if not info:
        this.sendMentionStyle("Không lấy được thông tin bài nhạc", None, threadId, type)
        return

    author      = _pick(info, "author", "nickname", default="") or _pick(info, "author", "uniqueId", default="") or "TikTok"
    music       = info.get("music") or {}
    audio_url   = music.get("url") or _pick(item, "music", "url", default="") or ""
    music_title = music.get("title") or _pick(item, "music", "title", default="") or "TikTok audio"
    cover       = music.get("cover") or _pick(item, "video", "cover", default="") or ""

    if not audio_url:
        this.sendMentionStyle("Không có audio URL", None, threadId, type)
        return

    if not card_hd:
        os.makedirs("assets/cache", exist_ok=True)
        img_path = f"assets/cache/tk_audio_{vid}_{int(time.time()*1000)}.png"
        try:
            from src.services.pillow.nhaccuatuiCard import draw_nhaccuatui_card
            draw_nhaccuatui_card({
                "title":  music_title,
                "artist": author,
                "cover":  cover,
            }, img_path)
        except:
            img_path = None

        if img_path and os.path.exists(img_path):
            up = _retry_upload(this._uploadImage, img_path, threadId, type)
            card_hd = (up.get("hdUrl") or up.get("normalUrl")) if isinstance(up, dict) else None
            try:
                os.remove(img_path)
            except:
                pass

    if not voice_url:
        os.makedirs("assets/cache", exist_ok=True)
        path = f"assets/cache/tk_audio_{vid}_{int(time.time()*1000)}.mp3"
        try:
            _download_file(audio_url, path, timeout=180)
        except:
            this.sendMentionStyle("Tải audio thất bại", None, threadId, type)
            return

        up = None
        try:
            up = _retry_upload(this._uploadAttachment, path, threadId, type)
        finally:
            try:
                os.remove(path)
            except:
                pass

        voice_url = up.get("fileUrl") if up else None
        if not voice_url:
            this.sendMentionStyle("Upload audio thất bại", None, threadId, type)
            return

        if this.MediaCache:
            this.MediaCache.set(
                Platf + "_audio", vid,
                {"cardHd": card_hd, "title": music_title, "artist": author, "cover": cover},
                voice_url,
            )

    this.sendReaction(data, "", threadId, type, -1)
    if card_hd:
        this.sendRemoteImage(card_hd, threadId, type, width=2048, height=622, message=Message(text=""))
    this.sendRemoteVoice(voice_url, threadId, type)
    this.sendReaction(data, "/-ok", threadId, type, 100000000)

# ── Parse reply select ─────────────────────────────────────────────────────
def _parse_select(text):
    s = (text or "").strip().lower()
    parts = s.split()
    if not parts or not parts[0].isdigit():
        return None
    n = int(parts[0])
    if n <= 0:
        return None
    audio = len(parts) >= 2 and parts[1] in ("a", "audio", "mp3", "sound")
    return n, audio

def _strip_mentions(message, data):
    text = message.text if isinstance(message, Message) else str(message or "")
    text = (text or "").strip()
    mentions = data.get("mentions") or []
    for m in sorted(mentions, key=lambda x: x.get("pos", 0), reverse=True):
        pos = m.get("pos", 0)
        ln  = m.get("len", 0)
        if pos >= 0 and ln > 0:
            text = text[:pos] + text[pos + ln:]
    return text.strip()

# ── Main Command ───────────────────────────────────────────────────────────
def TikTokCommand(this, message, data, userId, threadId, type):
    if not hasattr(this, "tiktokStates"):
        this.tiktokStates = {}
    _ensure_cache(this)

    arg = _parse_args(this, getattr(message, "text", message))
    if not arg:
        return this.sendMentionStyle(
            f"Dùng: {this.prefix}{this.rawCommand} <từ khóa> [số lượng]",
            userId, threadId, type,
        )

    parts = arg.split()
    limit = 10
    if parts and parts[-1].isdigit():
        limit = max(1, min(30, int(parts[-1])))
        arg = " ".join(parts[:-1]).strip() or arg

    items = _search_tiktok(arg, limit)
    if not items:
        return this.sendMentionStyle("Không tìm thấy video nào", userId, threadId, type)

    os.makedirs("assets/cache", exist_ok=True)
    img_path = f"assets/cache/tk_list_{userId}_{int(time.time()*1000)}.png"
    w_card, h_card = 2560, 1440

    try:
        draw_tiktok_list(items, img_path, title="Kết quả TikTok", subtitle="Reply số hoặc: 1 audio")
        try:
            from PIL import Image as _Im
            im = _Im.open(img_path)
            w_card, h_card = im.size
            im.close()
        except:
            pass
    except:
        img_path = None

    msg = None
    if img_path and os.path.exists(img_path):
        up = _retry_upload(this._uploadImage, img_path, threadId, type)
        hd = (up.get("hdUrl") or up.get("normalUrl")) if isinstance(up, dict) else None
        try:
            os.remove(img_path)
        except:
            pass
        if hd:
            msg = this.sendRemoteImage(
                hd,
                threadId, type,
                width=w_card, height=h_card,
                message=Message(text=""),
            )

    if not msg:
        lines = []
        for i, it in enumerate(items, 1):
            st = it.get("stat") or {}
            desc = (it.get("desc") or "")[:50]
            lines.append(f"{i:02d}. {desc} | ▶{_fmt_num(st.get('playCount',0))} ❤{_fmt_num(st.get('diggCount',0))}")
        msg = this.sendMentionStyle("\n".join(lines) + "\n\nReply số hoặc: 1 audio", userId, threadId, type)

    this.tiktokStates[userId] = {
        "items":    items,
        "time":     time.time(),
        "msgId":    getattr(msg, "msgId", None),
        "cliMsgId": getattr(msg, "clientId", None),
        "threadId": threadId,
        "typeGr":   type,
    }

# ── Reply Handler ──────────────────────────────────────────────────────────
def TikTokReply(this, message, data, userId, threadId, type):
    st = getattr(this, "tiktokStates", {}).get(userId)
    if not st:
        return
    if str(st.get("threadId")) != str(threadId):
        return

    if time.time() - st["time"] > Timeout:
        this.tiktokStates.pop(userId, None)
        this.sendMentionStyle("Hết thời gian chọn, hãy tìm lại", userId, threadId, type)
        return

    raw = message.text if isinstance(message, Message) else str(message or "")
    raw = str(raw or "").strip()

    p = str(getattr(this, "prefix", "") or "")
    if p and raw.startswith(p):
        return

    sel = _parse_select(_strip_mentions(message, data))
    if not sel:
        return

    n, audio = sel
    items = st.get("items") or []
    if n < 1 or n > len(items):
        return

    item     = items[n - 1]
    msgId    = st.get("msgId")
    cliMsgId = st.get("cliMsgId")
    this.tiktokStates.pop(userId, None)

    _ensure_cache(this)
    vid = str(item.get("id") or "")
    cache_key = Platf + ("_audio" if audio else "")
    cache = (this.MediaCache.get(cache_key, vid) or {}) if this.MediaCache else {}
    cached_ok = _is_alive(this, _cache_get(cache, "fileUrl"))

    wait_msg = None
    if not cached_ok:
        wait_msg = this.sendMentionStyle("Đang xử lý, vui lòng chờ...", userId, threadId, type)

    this.sendReaction(data, "🕑", threadId, type, 1000000023)

    def Run():
        try:
            if audio:
                _send_audio(this, data, item, threadId, type)
            else:
                _send_video(this, data, item, threadId, type)
        finally:
            if wait_msg:
                try:
                    this.deleteMessage(wait_msg.msgId, this.uid, wait_msg.clientId, threadId)
                except:
                    pass

    threading.Thread(target=Run, daemon=True).start()

    if msgId and cliMsgId:
        try:
            this.deleteMessage(msgId, this.uid, cliMsgId, threadId)
        except:
            pass

def InitTimeoutTikTok(this, interval=1):
    if not hasattr(this, "tiktokStates"):
        this.tiktokStates = {}

    def Loop():
        while True:
            now = time.time()
            for uid, st in list(this.tiktokStates.items()):
                if now - st["time"] > Timeout:
                    this.tiktokStates.pop(uid, None)
                    try:
                        this.deleteMessage(st["msgId"], this.uid, st["cliMsgId"], st["threadId"])
                    except:
                        pass
                    try:
                        this.sendMentionStyle("Hết giờ, hãy tìm lại", uid, st["threadId"], st["typeGr"])
                    except:
                        pass
            time.sleep(interval)

    threading.Thread(target=Loop, daemon=True).start()

dependencies = {
    "name":        "tiktok",
    "permission":  0,
    "cooldown":    5,
    "description": "Tìm & tải video/audio TikTok",
    "main":        TikTokCommand,
}
