import os
import re
import time
import uuid
import hmac
import hashlib
import threading
import asyncio
import requests
from urllib.parse import quote
from src.services.browserAPI.zingmp3Api import *
from src.services.pillow.zingCard import draw_zing_card
from src.services.pillow.zingListCard import draw_zing_list
from app.module.utils import MediaCache
from app.core.index import *

Platf = "zingmp3"
Timeout = 120
MUSIC_CAPTIONS = [
    "Âm nhạc là ngôn ngữ mà linh hồn dùng để nói chuyện với trái tim. 🎵",
    "Mỗi bài hát là một cuốn nhật ký không cần chữ viết. 🎶",
    "Có những điều không thể nói bằng lời, nhưng âm nhạc thì có thể. 🎼",
    "Âm nhạc chữa lành những vết thương mà lời nói không chạm tới được. 🎸",
    "Cuộc đời không có nhạc nền sẽ chỉ là một bộ phim câm. 🎹",
    "Hãy để âm thanh dẫn đường khi con tim lạc lối. 🎷",
    "Một giai điệu đúng lúc có thể thay đổi cả một ngày dài. 🎺",
    "Âm nhạc là khi ngôn ngữ kết thúc, cảm xúc bắt đầu. 🎻",
]

_caption_index = 0

def _next_caption():
    global _caption_index
    cap = MUSIC_CAPTIONS[_caption_index % len(MUSIC_CAPTIONS)]
    _caption_index += 1
    return cap

def _download_stream(stream_url, ext="mp3"):
    os.makedirs("data/assets/cache/voice", exist_ok=True)
    filePath = f"data/assets/cache/voice/{uuid.uuid4().hex}.{ext}"

    with requests.get(stream_url, stream=True, timeout=30) as r:
        r.raise_for_status()
        with open(filePath, "wb") as f:
            for chunk in r.iter_content(8192):
                if chunk:
                    f.write(chunk)

    return filePath

def _extract_number(text):
    cleaned = re.sub(r'@\S+', '', text)
    match = re.search(r'\b(\d+)\b', cleaned)
    if match:
        return match.group(1)
    return None

def _build_mention_caption(UserId, music_line):
    return f"@[{UserId}] {music_line}"

def HandleZingSend(self, Data, Song, ThreadId, ThreadType, UserId=None, LoadingMsgId=None, LoadingCliMsgId=None):
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    Sid = Song["id"]
    Cache = self.MediaCache.get(Platf, Sid)

    def _delete_loading():
        if LoadingMsgId and LoadingCliMsgId:
            try:
                self.deleteMessage(LoadingMsgId, self.uid, LoadingCliMsgId, ThreadId)
            except Exception:
                pass

    def _send_card_caption_and_voice(file_url):
        title   = Song.get("title", "Unknown")
        artist  = Song.get("artist", "Unknown")
        cover   = Song.get("cover", "")
        dur_raw = Song.get("duration", 0)

        card_path  = None
        image_url  = None
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_zing_card(
                {"cover": cover, "title": title, "artist": artist, "duration": dur_raw},
                card_path,
            )
            image_res = self._uploadImage(card_path, ThreadId, ThreadType)
            if isinstance(image_res, dict):
                image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
            elif isinstance(image_res, str) and image_res.startswith("http"):
                image_url = image_res
        except Exception as e:
            print(f"[ZingCard] draw/upload error: {e}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        _delete_loading()

        caption_line = _next_caption()
        if image_url:
            try:
                name         = self.userName(UserId) or str(UserId)
                mention_text = f"@{name}"
                caption      = f"🎵 {mention_text} {caption_line}"
                self.sendRemoteImage(
                    image_url,
                    ThreadId,
                    ThreadType,
                    width=2048,
                    height=622,
                    message=Message(
                        text=caption,
                        mention=Mention(UserId, length=len(mention_text), offset=3)
                    )
                )
            except Exception as e:
                print(f"[ZingCard] sendRemoteImage error: {e}")
        else:
            self.sendMentionStyle(caption_line, UserId, ThreadId, ThreadType)

        self.sendRemoteVoice(file_url, ThreadId, ThreadType)

    if Cache:
        FileUrl = Cache.get("fileUrl")
        if FileUrl and self.MediaCache.isAlive(FileUrl):
            try:
                self.sendReaction(Data, "", ThreadId, ThreadType, -1)
                _send_card_caption_and_voice(FileUrl)
                self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
                return
            except Exception:
                self.MediaCache.remove(Platf, Sid)

    stream = get_stream(Sid)
    if not stream or "data" not in stream:
        _delete_loading()
        self.sendMentionStyle("Không lấy được stream", UserId, ThreadId, ThreadType)
        return

    data = stream["data"]
    streamUrl = data.get("320")
    if streamUrl == "VIP" or not streamUrl:
        streamUrl = data.get("128")

    if not streamUrl:
        _delete_loading()
        self.sendMentionStyle("Không lấy được stream", UserId, ThreadId, ThreadType)
        return

    filePath = None
    try:
        filePath = _download_stream(streamUrl)

        upload = asyncio.run(
            self._uploadAttachmentAsync(filePath, ThreadId, ThreadType)
        )
    finally:
        if filePath:
            try:
                os.remove(filePath)
            except Exception:
                pass

    FileUrl = upload.get("fileUrl")
    if not FileUrl:
        _delete_loading()
        self.sendMentionStyle("Upload thất bại", UserId, ThreadId, ThreadType)
        return

    self.sendReaction(Data, "", ThreadId, ThreadType, -1)
    _send_card_caption_and_voice(FileUrl)
    self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)

    self.MediaCache.set(
        Platf,
        Sid,
        {
            "title":  Song.get("title"),
            "artist": Song.get("artist"),
            "cover":  Song.get("cover"),
        },
        FileUrl,
    )

def _fmt(t):
    t = int(t or 0)
    h, t = divmod(t, 3600)
    m, s = divmod(t, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def FormatZingList(self, Songs):
    lines = ["Chọn số để phát bài:\n"]
    for i, s in enumerate(Songs, 1):
        lines.append(
            f"{i}. {s['title']} - {s['artist']} - {_fmt(s['duration'])}"
        )
    lines.append("\n0. Huỷ")
    return "\n".join(lines)

def StartZingCooldown(self, MsgObj, ThreadId, ThreadType):
    if not hasattr(self, "_zingCooldown"):
        self._zingCooldown = {}

    key = MsgObj.msgId
    self._zingCooldown[key] = True

    msg = MessageObject(
        msgId=MsgObj.msgId,
        cliMsgId=MsgObj.clientId,
        msgType="webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not self._zingCooldown.get(key):
                break
            self.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            self.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        self._zingCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()

def ZingCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    from api.util.Enum import ThreadType as _TT
    if ThreadType == _TT.USER:
        return self.sendMentionStyle(
            "Tính năng nghe nhạc chỉ dùng được trong nhóm. Hãy sử dụng ở những nhóm có bot và gọi lại ở đó nhé! 🎵",
            UserId,
            ThreadId,
            ThreadType,
        )

    Parts = MessageObj.text.strip().split()
    if len(Parts) < 2:
        return self.sendMentionStyle(
            f"📍Please enter the keyword for the song you want to search for on ZingMp3.",
            UserId,
            ThreadId,
            ThreadType,
        )

    Arg = " ".join(Parts[1:])
    State = self.zingStates.get(UserId)

    if Arg.strip().isdigit() and State:
        if time.time() - State["time"] > Timeout:
            self.zingStates.pop(UserId, None)
            return self.sendMentionStyle("Selection expired", UserId, ThreadId, ThreadType)

        Num = int(Arg.strip())
        if Num == 0:
            key = State.get("msgId")
            if hasattr(self, "_zingCooldown") and key:
                self._zingCooldown[key] = False
            self.zingStates.pop(UserId, None)
            return

        Songs = State["songs"]
        if Num < 1 or Num > len(Songs):
            return

        key = State.get("msgId")
        if hasattr(self, "_zingCooldown") and key:
            self._zingCooldown[key] = False

        Song = Songs[Num - 1]
        self.zingStates.pop(UserId, None)

        LoadingMsg = self.sendMentionStyle(
            f'⏳ Wait, im trying to download...',
            UserId,
            ThreadId,
            ThreadType,
        )
        LoadingMsgId = getattr(LoadingMsg, "msgId",    None)
        LoadingCliId = getattr(LoadingMsg, "clientId", None)

        self.sendReaction(Data, "🕑", ThreadId, ThreadType, 1000000023)
        threading.Thread(
            target=lambda: HandleZingSend(
                self, Data, Song, ThreadId, ThreadType,
                UserId=UserId,
                LoadingMsgId=LoadingMsgId,
                LoadingCliMsgId=LoadingCliId,
            ),
            daemon=True,
        ).start()
        return

    res = search_songv2(Arg)

    if not res or res.get("err") != 0:
        return self.sendMentionStyle("Search failed", UserId, ThreadId, ThreadType)

    data = res.get("data") or {}
    songs_raw = data.get("songs") or []

    Songs = []
    for s in songs_raw:
        if s.get("streamingStatus") != 1:
            continue

        Songs.append({
            "id":       s.get("encodeId"),
            "title":    s.get("title"),
            "artist":   s.get("artistsNames", "Unknown"),
            "duration": s.get("duration", 0),
            # Lấy thumbnail để vẽ card
            "cover":    s.get("thumbnailM") or s.get("thumbnail") or "",
        })

    Songs = Songs[:10]

    if not Songs:
        return self.sendMentionStyle("No result", UserId, ThreadId, ThreadType)

    list_path = None
    list_url  = None
    try:
        os.makedirs("data/assets/cache/cards", exist_ok=True)
        list_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
        draw_zing_list(Songs, list_path, keyword=Arg)
        image_res = self._uploadImage(list_path, ThreadId, ThreadType)
        if isinstance(image_res, dict):
            list_url = image_res.get("normalUrl") or image_res.get("hdUrl")
        elif isinstance(image_res, str) and image_res.startswith("http"):
            list_url = image_res
    except Exception as e:
        print(f"[ZingList] canvas error: {e}")
    finally:
        if list_path and os.path.exists(list_path):
            try:
                os.remove(list_path)
            except Exception:
                pass

    if list_url:
        name         = self.userName(UserId) or str(UserId)
        mention_text = f"@{name}"
        caption      = f"🎵 {mention_text} Chọn số để phát • reply 0 để huỷ"
        Msg = self.sendRemoteImage(
            list_url,
            ThreadId,
            ThreadType,
            width=2560,
            height=1440,
            message=Message(
                text=caption,
                mention=Mention(UserId, length=len(mention_text), offset=3)
            )
        )
    else:
        Msg = self.sendMentionStyle(
            FormatZingList(self, Songs),
            UserId,
            ThreadId,
            ThreadType,
        )

    self.zingStates[UserId] = {
        "songs":    Songs,
        "time":     time.time(),
        "msgId":    getattr(Msg, "msgId", None),
        "cliMsgId": getattr(Msg, "clientId", None),
        "threadId": ThreadId,
        "typeGr":   ThreadType,
    }

    StartZingCooldown(self, Msg, ThreadId, ThreadType)

def ZingReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    State = self.zingStates.get(UserId)
    if not State:
        return

    RawText = MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)

    NumStr = _extract_number(RawText)
    if not NumStr or not Data.quote:
        return

    NumMessage = Message(text=f"{self.prefix}zing {NumStr}")
    ZingCommand(self, NumMessage, Data, UserId, ThreadId, ThreadType)

    try:
        self.deleteMessage(
            State["msgId"],
            self.uid,
            State["cliMsgId"],
            ThreadId,
        )
    except Exception:
        pass

def InitTimeoutZing(self, Interval=1):
    def Loop():
        while True:
            Now = time.time()
            for Uid, State in list(self.zingStates.items()):
                if Now - State["time"] > Timeout:
                    self.zingStates.pop(Uid, None)
                    try:
                        self.deleteMessage(
                            State["msgId"],
                            self.uid,
                            State["cliMsgId"],
                            State["threadId"],
                        )
                    except Exception:
                        pass
                    self.sendMentionStyle(
                        "Timed out, please search again",
                        Uid,
                        State["threadId"],
                        State["typeGr"],
                    )
            time.sleep(Interval)

    threading.Thread(target=Loop, daemon=True).start()

dependencies = {
    "name": "zing",
    "permission": 0,
    "cooldown": 5,
    "description": "Songs on ZingMP3",
    "main": ZingCommand,
}