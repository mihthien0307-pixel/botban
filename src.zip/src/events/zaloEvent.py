from api.app.event import GroupEventType
from api.util.msg import Message, Mention
from api.util.Enum import ThreadType
from src.services.utils.jsonio import read_settings, write_settings
from src.services.pillow.eventCard import draw_event_card
from app.module.utils import _get_user_avatar
from PIL import Image
import os

SETTING_LABELS = {
    "blockName":        ("bật",   "tắt",  "chặn đổi tên nhóm"),
    "signAdminMsg":     ("bật",   "tắt",  "đánh dấu tin nhắn admin"),
    "addMemberOnly":    ("bật",   "tắt",  "chế độ chỉ admin được thêm thành viên"),
    "setTopicOnly":     ("bật",   "tắt",  "chế độ chỉ admin được đổi chủ đề"),
    "enableMsgHistory": ("bật",   "tắt",  "lịch sử trò chuyện"),
    "joinAppr":         ("bật",   "tắt",  "duyệt thành viên"),
    "lockCreatePost":   ("khóa",  "mở",   "đăng bài"),
    "lockCreatePoll":   ("chặn",  "mở",   "tạo bình chọn"),
    "lockSendMsg":      ("khóa",  "mở",   "trò chuyện"),
    "lockViewMember":   ("ẩn",    "mở",   "danh sách thành viên"),
}

from src.command.antimanager.antiadd import antiAdd
from src.command.antimanager.antikickall import antiKickAll

def _cfg(uid, threadId: str) -> dict:
    s = read_settings(uid)
    return s.get("eventConfig", {}).get(threadId, {})

def _get_setting_store(uid):
    s     = read_settings(uid)
    store = s.get("groupSettingState", {})
    return s, (store if isinstance(store, dict) else {})

def _save_setting_store(uid, s: dict, store: dict):
    s["groupSettingState"] = store
    write_settings(uid, s)

def _find_changed(old: dict, new: dict):
    for key in SETTING_LABELS:
        if int(old.get(key, 0) or 0) != int(new.get(key, 0) or 0):
            return key, int(new.get(key, 0) or 0)
    return None, None

def _member_info(members: list) -> tuple:
    if not members:
        return "", "", ""
    m = members[0]
    if not isinstance(m, dict):
        m = getattr(m, "__dict__", {})
    return (
        str(m.get("id",     "") or ""),
        str(m.get("dName",  "") or ""),
        str(m.get("avatar", "") or ""),
    )

def _get_group_member_count(self, groupId: str) -> int:
    try:
        info  = self.fetchGroupInfo(str(groupId))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g     = gdata.get(str(groupId)) or {}
        return int(g.get("totalMember") or g.get("memberCount") or 0)
    except Exception:
        return 0

def _send_card(self, groupId: str, data: dict, mode: str, caption_msg=None):
    import time as _t, uuid as _uuid
    uid_tag = _uuid.uuid4().hex[:8]
    path = f"data/assets/cache/image/event_{groupId}_{mode}_{uid_tag}.jpg"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        draw_event_card(data, path, mode=mode)

        if not os.path.exists(path):
            print(f"[zaloEvent._send_card] draw_event_card failed: {path} not created")
            return

        upload = None
        for _i in range(3):
            try:
                if not os.path.exists(path):
                    print(f"[zaloEvent._send_card] upload {_i+1}/3: {path} not found, skipping retry")
                    break
                upload = self._uploadImage(path, groupId, ThreadType.GROUP)
                break
            except Exception as e:
                print(f"[zaloEvent._send_card] upload {_i+1}/3: {e}")
                if _i < 2: _t.sleep(2)
        if not upload:
            return

        image_hd = upload.get("hdUrl") or upload.get("normalUrl")
        if not image_hd:
            return

        with Image.open(path) as img:
            w, h = img.size

        for _i in range(3):
            try:
                self.sendRemoteImage(
                    image_url=image_hd,
                    threadId=groupId,
                    type=ThreadType.GROUP,
                    width=w,
                    height=h,
                    message=caption_msg,   # ← caption + mention đi kèm ảnh
                    ttl=86000000,
                )
                break
            except Exception as e:
                print(f"[zaloEvent._send_card] send {_i+1}/3: {e}")
                if _i < 2: _t.sleep(2)
    except Exception as e:
        print(f"[zaloEvent._send_card] mode={mode} error: {e}")
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

def InitTimeoutMenu(self, interval=1):
    pass  # không còn dùng timeout menu ở đây

def ZaloEventHandle(self, eventData, eventType):
    groupId   = str(getattr(eventData, "groupId",   "") or "")
    groupName = str(getattr(eventData, "groupName", "") or "")
    sourceId  = str(getattr(eventData, "sourceId",  "") or "")
    members   = getattr(eventData, "updateMembers", []) or []
    setting   = getattr(eventData, "groupSetting",  {}) or {}
    if not isinstance(setting, dict):
        setting = {}

    if not groupId:
        return

    # ── Anti functions chạy độc lập, không phụ thuộc vào eventConfig ──
    if eventType == GroupEventType.JOIN:
        antiAdd(self, eventData)
    elif eventType == GroupEventType.BLOCK_MEMBER:
        antiKickAll(self, eventData, is_block=True)
    elif eventType == GroupEventType.REMOVE_MEMBER:
        antiKickAll(self, eventData, is_block=False)

    cfg = _cfg(self.uid, groupId)
    if not cfg or not cfg.get("eventOn", False):
        return

    import time as _t
    actorName        = self.userName(sourceId) if sourceId else ""
    actorAvatar      = _get_user_avatar(self, sourceId) if sourceId else ""
    uid, name, avatar = _member_info(members)
    count            = _get_group_member_count(self, groupId)
    grp              = self.userName(self.uid)

    import datetime as _dt
    _now = _dt.datetime.now().strftime("%H:%M  %d/%m/%Y")

    def _card_data(member_name, member_avatar, sub="", by=""):
        return {
            "name":         member_name,
            "avatar_url":   member_avatar,
            "member_count": count,
            "group_name":   groupName or grp,
            "sub":          sub,
            "timestamp":    _now,
            "by_name":      by or member_name,
        }

    def _send_all(mode, sub="", by=""):
        import time as _t2
        for i, m in enumerate(members if members else [{}]):
            if i > 0:
                _t2.sleep(1.0)
            _, mn, ma = _member_info([m])
            _send_card(self, groupId, _card_data(mn, ma, sub, by=by or mn), mode=mode)

    # ── Join / Leave / Kick / Block ─────────────────────────────────────────
    if eventType == GroupEventType.JOIN:
        welcome_title = cfg.get("welcomeTitle", "")
        import time as _t2
        for i, m in enumerate(members if members else [{}]):
            if i > 0:
                _t2.sleep(1.0)
            mid, mn, ma = _member_info([m])
            # Build caption kèm mention để gửi cùng ảnh
            caption_msg = None
            if mid:
                if welcome_title:
                    msg_text = f"{welcome_title}\n@{mn}"
                else:
                    msg_text = f"@{mn}"
                offset  = len(msg_text) - len(mn) - 1
                mention = Mention(uid=mid, length=len(mn) + 1, offset=offset)
                caption_msg = Message(text=msg_text, mention=mention)
            _send_card(
                self, groupId,
                _card_data(mn, ma, sub="Was invited to join", by=actorName),
                mode="welcome",
                caption_msg=caption_msg,
            )

    elif eventType == GroupEventType.LEAVE:
        _send_all("leave", sub="Đã rời khỏi nhóm")

    elif eventType == GroupEventType.BLOCK_MEMBER:
        _send_all("kick_block", sub="Was blocked from group", by=actorName)

    elif eventType == GroupEventType.REMOVE_MEMBER:
        _send_all("kick", sub="Was removed from group", by=actorName)

    elif eventType == GroupEventType.ADD_ADMIN:
        _send_all("add_admin", sub="Được thăng lên Admin", by=actorName)

    elif eventType == GroupEventType.REMOVE_ADMIN:
        _send_all("remove_admin", sub="Đã bị hạ quyền Admin", by=actorName)

    # ── Update group info (tên nhóm / avatar nhóm) ─────────────────────────
    elif eventType == GroupEventType.UPDATE:
        newName = str(getattr(eventData, "groupName", "") or "")
        newAvt  = str(getattr(eventData, "avt", "") or "")
        if newName:
            sub = f"Đổi tên nhóm → {newName}"
        elif newAvt:
            sub = "Đổi ảnh đại diện nhóm"
        else:
            sub = "Cập nhật thông tin nhóm"
        _send_card(self, groupId, _card_data(actorName, actorAvatar, sub, by=actorName), mode="update")

    # ── Join request ────────────────────────────────────────────────────────
    elif eventType == GroupEventType.JOIN_REQUEST:
        _send_card(self, groupId, _card_data(name, avatar, f"Xin vào nhóm {groupName}", by=name), mode="join_request")

    # ── New link ────────────────────────────────────────────────────────────
    elif eventType == GroupEventType.NEW_LINK:
        newLink = str(getattr(eventData, "link", "") or "")
        sub = f"Link mới: {newLink}" if newLink else "Tạo link mời mới"
        _send_card(self, groupId, _card_data(actorName, actorAvatar, sub, by=actorName), mode="new_link")

    # ── Update setting ──────────────────────────────────────────────────────
    elif eventType == GroupEventType.UPDATE_SETTING:
        if not setting:
            return

        s, store   = _get_setting_store(self.uid)
        oldSetting = store.get(groupId, {})
        oldSetting = oldSetting if isinstance(oldSetting, dict) else {}

        if not oldSetting:
            store[groupId] = dict(setting)
            _save_setting_store(self.uid, s, store)
            return

        changedKey, changedValue = _find_changed(oldSetting, setting)
        store[groupId] = dict(setting)
        _save_setting_store(self.uid, s, store)

        if not changedKey:
            return

        onText, offText, label = SETTING_LABELS[changedKey]
        action = onText if changedValue else offText
        sub    = f"{action.capitalize()} {label}"
        _send_card(self, groupId, _card_data(actorName, actorAvatar, sub, by=actorName), mode="update_setting")
