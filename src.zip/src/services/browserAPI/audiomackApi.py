from app.core.index import *

def oauth():
    return OAuth1("audiomack-web","bd8a07e9f23fbe9d808646b730f89b8e",nonce=''.join(random.choice(string.ascii_letters + string.digits) for _ in range(32)),timestamp=str(int(time.time())),signature_method="HMAC-SHA1")
def search_song(q):
    r = requests.get("https://api.audiomack.com/v1/search",params={"q": q,"show": "songs","limit": 10,"page": 1,"sort": "popular"},auth=oauth(),timeout=10)
    r.raise_for_status()
    out = []
    for i in r.json().get("results", []):
        if i.get("type") == "song" and not i.get("geo_restricted"):
            # print(i)
            out.append({
                "id": i.get("id"),
                "title": i.get("title"),
                "link": i.get("links", {}).get("self"),
                "artist": i.get("artist"),
                "thumb": i.get("image"),
                "thumb2": i.get("uploader", {}).get("image"),
                "duration": i.get("duration"),
                "like": i.get("stats", {}).get("favorites-raw", 0),
                "listen": i.get("stats", {}).get("plays-raw", 0),
                "comment": i.get("stats", {}).get("comments", 0),
            })
    return out
def download(song):
    url = r = requests.get(f"https://api.audiomack.com/v1/music/play/{song['id']}",params={"environment": "desktop-web","hq": "true","section": song["link"].split("song/", 1)[1]},auth=oauth(),timeout=15).json().get("signedUrl")
    if not url:return None

    path = f"./data/assets/cache/{song['id']}.mp3"
    with requests.get(url, stream=True) as r, open(path, "wb") as f:
        for c in r.iter_content(524288):
            f.write(c)
    return path