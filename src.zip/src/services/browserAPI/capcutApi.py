"""
capcutApi.py – CapCut template search API
Đặt file này vào: zbot/src/services/browserAPI/capcutApi.py
"""
import requests

BASE_URL    = "https://edit-api-sg.capcut.com"
SEARCH_PATH = "/lv/v1/cc_web/replicate/search_templates"
MAX_RESULTS = 10

_HEADERS = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9,vi;q=0.8",
    "app-sdk-version": "48.0.0",
    "appvr": "5.8.0",
    "content-type": "application/json",
    "device-time": "1734146729",
    "lan": "vi-VN",
    "loc": "va",
    "origin": "https://www.capcut.com",
    "pf": "7",
    "priority": "u=1, i",
    "referer": "https://www.capcut.com/",
    "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": '"Android"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "sign": "8c69245fb9e23bbe2401518a277ef9d4",
    "sign-ver": "1",
    "user-agent": (
        "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Mobile Safari/537.36"
    ),
}


def search_capcut(query: str, limit: int = MAX_RESULTS) -> list:
    """Tìm kiếm template CapCut, trả về list dict template."""
    try:
        payload = {
            "cc_web_version": 0,
            "count": limit,
            "cursor": "0",
            "enter_from": "workspace",
            "query": query,
            "scene": 1,
            "sdk_version": "86.0.0",
            "search_version": 2,
        }
        resp = requests.post(
            f"{BASE_URL}{SEARCH_PATH}",
            json=payload,
            headers=_HEADERS,
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json().get("data", {}).get("video_templates", [])
    except Exception as e:
        print(f"[capcutApi] search error: {e}")
        return []
