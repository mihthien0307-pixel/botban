import os
import re
import time
import requests

NctApiBase      = "https://graph.nhaccuatui.com/api/v1"
SearchSongPath  = "/search/song"
DetailSongTpl   = "/song/detail/{SongKey}"
TimeoutSec      = 15
UserAgent       = "Mozilla/5.0"
CacheDir        = "data/assets/cache/voice"

def _norm(s):
    return (s or "").strip()

def _now_ms():
    return int(time.time() * 1000)

def _headers():
    return {"User-Agent": UserAgent, "Accept": "application/json,*/*"}

def _get(path, params=None):
    p = _norm(path)
    if not p.startswith("/"):
        p = "/" + p
    r = requests.get(
        f"{NctApiBase}{p}",
        params=params or {},
        headers=_headers(),
        timeout=TimeoutSec,
    )
    r.raise_for_status()
    return r.json()

def _pick_by_type(items, t, field):
    if not items:
        return ""
    st = str(t)
    for i in items:
        if str(i.get("type")) == st:
            return _norm(i.get(field))
    return ""

def _song_lite(x):
    streams = (x or {}).get("streamURL") or []
    key     = _norm((x or {}).get("key"))
    return {
        "id":       key or None,
        "key":      key or None,
        "title":    _norm((x or {}).get("name"))   or None,
        "artist":   _norm((x or {}).get("artistName")) or None,
        "cover":    _norm((x or {}).get("image"))  or None,
        "duration": int((x or {}).get("duration") or 0),
        "stream": {
            "128":      _pick_by_type(streams, 128,       "stream") or None,
            "320":      _pick_by_type(streams, 320,       "stream") or None,
            "lossless": _pick_by_type(streams, "lossless","stream") or None,
        },
        "download": {
            "128":      _pick_by_type(streams, 128,       "download") or None,
            "320":      _pick_by_type(streams, 320,       "download") or None,
            "lossless": _pick_by_type(streams, "lossless","download") or None,
        },
        "previewUrl": _pick_by_type(streams, 128, "stream") or None,
    }

def _song_detail(d):
    streams = (d or {}).get("streamURL") or []
    key     = _norm((d or {}).get("key"))
    base    = _song_lite(d)
    base.update({
        "id":    key or None,
        "key":   key or None,
        "title": _norm((d or {}).get("name")) or None,
        "stream": {
            "128":      _pick_by_type(streams, 128,       "stream") or None,
            "320":      _pick_by_type(streams, 320,       "stream") or None,
            "lossless": _pick_by_type(streams, "lossless","stream") or None,
        },
        "download": {
            "128":      _pick_by_type(streams, 128,       "download") or None,
            "320":      _pick_by_type(streams, 320,       "download") or None,
            "lossless": _pick_by_type(streams, "lossless","download") or None,
        },
    })
    return base

def nct_resolve(song_key):
    k = _norm(song_key)
    if not k:
        return None
    try:
        j = _get(DetailSongTpl.format(SongKey=k), params={
            "isDailyMix": "false",
            "key":        k,
            "timestamp":  _now_ms(),
        })
        d = (j or {}).get("data") or {}
        return _song_detail(d) if d else None
    except Exception:
        return None

def nct_search(q, limit=10):
    qq = _norm(q)
    if not qq:
        return []
    try:
        j = _get(SearchSongPath, params={
            "keyword":   qq,
            "pageindex": 1,
            "pagesize":  max(1, int(limit)),
            "correct":   "false",
            "timestamp": _now_ms(),
        })
        songs = ((j or {}).get("data") or {}).get("songs") or []
        return [_song_lite(x) for x in songs]
    except Exception:
        return []

def _safe_name(s):
    s = _norm(s)
    s = re.sub(r'[\\/:*?"<>|\n\r\t]+', "_", s)
    s = re.sub(r'\s+', " ", s).strip()
    return s[:100] if s else "nct"

def _best_url(song):
    d = (song or {}).get("download") or {}
    s = (song or {}).get("stream")   or {}
    for k in ("lossless", "320", "128"):
        u = (d.get(k) or "").strip()
        if u:
            return u
    for k in ("lossless", "320", "128"):
        u = (s.get(k) or "").strip()
        if u:
            return u
    u = (song or {}).get("previewUrl") or ""
    return u.strip() or ""

def _ext_from_url(url):
    u = (url or "").split("?", 1)[0]
    m = re.search(r'\.([a-zA-Z0-9]{2,5})$', u)
    if not m:
        return "mp3"
    e = m.group(1).lower()
    return e if e in ("mp3", "m4a", "aac", "ogg", "wav", "flac") else "mp3"

NctPageBase    = "https://www.nhaccuatui.com"
NctPageHeaders = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    "Accept-Language": "vi-VN,vi;q=0.9",
}

def nct_get_lyric(song_key, link_share=None):
    """Scrape lyric từ trang bài hát NCT (lyrics-box div).
    Truyền link_share nếu đã có sẵn để tránh gọi thêm API.
    Trả về string lyric hoặc '' nếu không có."""
    k = _norm(song_key)
    if not k and not link_share:
        return ""

    # Lấy link_share nếu chưa có
    if not link_share:
        try:
            j    = _get(f"/song/detail/{k}", params={"isDailyMix": "false", "key": k, "timestamp": _now_ms()})
            link_share = _norm(((j or {}).get("data") or {}).get("linkShare"))
        except Exception:
            pass
    if not link_share:
        return ""

    try:
        r    = requests.get(link_share, headers=NctPageHeaders, timeout=TimeoutSec)
        html = r.text

        start = html.find('class="lyrics-box"')
        if start == -1:
            return ""

        # Đếm độ sâu <div> để tìm </div> đóng đúng cặp
        tag_start = html.rfind('<div', 0, start)
        depth, i, end = 0, tag_start, -1
        while i < len(html):
            o = html.find('<div',  i)
            c = html.find('</div>', i)
            if o == -1:
                o = len(html)
            if c == -1:
                break
            if o < c:
                depth += 1
                i = o + 4
            else:
                depth -= 1
                if depth == 0:
                    end = c
                    break
                i = c + 6

        if end == -1:
            return ""

        raw   = html[tag_start:end]
        raw   = re.sub(r'<br\s*/?>', '\n', raw, flags=re.I)
        text  = re.sub(r'<[^>]+>', '', raw)
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        return "\n".join(lines)
    except Exception:
        return ""


def nct_download(song, out_dir=CacheDir):
    os.makedirs(out_dir, exist_ok=True)

    url = _best_url(song)
    if not url:
        sid = (song or {}).get("id") or (song or {}).get("key") or ""
        if sid:
            resolved = nct_resolve(sid)
            if resolved:
                url = _best_url(resolved)
    if not url:
        return None

    ext  = _ext_from_url(url)
    sid  = (song or {}).get("id") or (song or {}).get("key") or str(_now_ms())
    path = os.path.join(out_dir, f"nct_{sid}_{_now_ms()}.{ext}")

    h = _headers()
    h["Accept"] = "*/*"
    try:
        r = requests.get(url, headers=h, timeout=TimeoutSec, stream=True, allow_redirects=True)
        if r.status_code != 200:
            return None
        total = 0
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if chunk:
                    total += len(chunk)
                    f.write(chunk)
        if total < 4096:
            os.remove(path)
            return None
        return path
    except Exception:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        return None        