/**
 * drawTopChat.js — Vẽ card BXH Tương Tác theo thiết kế mới (dark navy, list rows)
 *
 * Cách dùng (gọi từ Python qua subprocess):
 *   node drawTopChat.js '<json_payload>'
 *
 * json_payload = {
 *   "entries": [
 *     {
 *       "rank": 1,
 *       "name": "...",
 *       "avatar": "https://...",
 *       "count": 48,
 *       "rank_icon": "/abs/path/icon.png",
 *       "rank_name": "Bạch Kim III",
 *       "rank_stars": 1,
 *       "rank_max_stars": 5
 *     }, ...
 *   ],
 *   "title": "BXH TƯƠNG TÁC HÔM NAY",
 *   "subtitle": "BUILD JS",
 *   "out_path": "data/assets/cache/image/topchat_xxx.jpg",
 *   "font_dir": "/abs/path/zbot/assets/font"
 * }
 */

const { createCanvas, loadImage, registerFont } = require('canvas');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

// ── Đọc payload ─────────────────────────────────────────────────────────────
const payload = JSON.parse(process.argv[2]);
const entries = payload.entries || [];
const title   = payload.title    || 'BXH TƯƠNG TÁC HÔM NAY';
const subtitle = payload.subtitle || 'BUILD JS';
const outPath  = payload.out_path;
const fontDir  = payload.font_dir;

// ── Kích thước ───────────────────────────────────────────────────────────────
const W          = 1060;
const PAD_X      = 28;
const PAD_TOP    = 36;
const HEADER_H   = 110;   // trophy + title + subtitle
const ROW_H      = 108;
const ROW_GAP    = 10;
const ROW_RADIUS = 16;
const AV_SIZE    = 72;
const FOOTER_H   = 52;

// ── Màu sắc ──────────────────────────────────────────────────────────────────
const BG_TOP    = '#1a2340';
const BG_BOT    = '#141a30';
const ROW_BG    = '#1f2d50';
const ROW_BG_H  = '#243260'; // hover (không dùng nhưng giữ để dễ tuỳ chỉnh)
const BORDER_C  = '#2e3f6e';

const GOLD    = '#f5c518';
const SILVER  = '#c0c0c0';
const BRONZE  = '#cd7f32';
const CYAN    = '#00e5ff';
const WHITE   = '#ffffff';
const GREY    = '#8899bb';
const RANK_GOLD_TEXT  = '#ffd700';
const RANK_NAME_GOLD  = '#f5c518';
const RANK_NAME_WHITE = '#ffffff';
const MSG_COLOR = '#8899bb';

// ── Font ──────────────────────────────────────────────────────────────────────
function registerFonts() {
  const dir = path.join(fontDir, 'Opensans', 'static', 'Opensans');
  const boldFile   = path.join(dir, 'OpenSans-Bold.ttf');
  const regularFile = path.join(dir, 'OpenSans-Regular.ttf');
  if (fs.existsSync(boldFile))    registerFont(boldFile,    { family: 'OpenSans', weight: 'bold' });
  if (fs.existsSync(regularFile)) registerFont(regularFile, { family: 'OpenSans', weight: 'normal' });
}

function font(size, bold = false) {
  return `${bold ? 'bold ' : ''}${size}px OpenSans`;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function safeText(text) {
  if (text === undefined || text === null) return '?';
  return String(text)
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F1E0}-\u{1F1FF}\uFE0F]/gu, '')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .replace(/[✗×✕]/g, '')   // bỏ ký hiệu ✗
    .trim() || '?';
}

function measureW(ctx, text, f) {
  ctx.font = f;
  return ctx.measureText(text).width;
}

function fitText(ctx, text, f, maxw) {
  if (measureW(ctx, text, f) <= maxw) return text;
  const ell = '…';
  const ew  = measureW(ctx, ell, f);
  let out = '';
  for (const ch of text) {
    if (measureW(ctx, out + ch, f) > maxw - ew) break;
    out += ch;
  }
  return out + ell;
}

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + r, y,     r);
  ctx.closePath();
}

function roundRect(ctx, x, y, w, h, r, fill, stroke, lw = 1) {
  if (w <= 0 || h <= 0) return;
  roundRectPath(ctx, x, y, w, h, r);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function hqUrl(url) {
  if (!url) return url;
  url = url.replace(/[?&]w=\d+/g, '').replace(/[?&]h=\d+/g, '')
           .replace(/[?&]s=\d+/g, '').replace(/[?&]size=\d+/g, '')
           .replace(/\/w\d+\//, '/w2048/');
  return url.replace(/[?&]+$/, '');
}

function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 6000 }, (res) => {
      if (res.statusCode && res.statusCode >= 400) { res.resume(); return reject(new Error(`HTTP ${res.statusCode}`)); }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('timeout')));
  });
}

async function fetchAvatar(url, size) {
  if (!url) return null;
  try {
    const buf = await fetchBuffer(hqUrl(url));
    const img = await loadImage(buf);
    const s  = Math.min(img.width, img.height);
    const sx = (img.width - s) / 2;
    const sy = (img.height - s) / 2;
    const cv = createCanvas(size, size);
    const cx = cv.getContext('2d');
    cx.save();
    cx.beginPath();
    cx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
    cx.clip();
    cx.drawImage(img, sx, sy, s, s, 0, 0, size, size);
    cx.restore();
    return cv;
  } catch { return null; }
}

function placeholderAvatar(size, rank) {
  const palette = ['#7844a0', '#5a3c96', '#46327a'];
  const cv = createCanvas(size, size);
  const cx = cv.getContext('2d');
  cx.fillStyle = palette[Math.min(rank - 1, palette.length - 1)];
  cx.beginPath(); cx.arc(size/2, size/2, size/2, 0, Math.PI*2); cx.fill();
  cx.fillStyle = 'rgba(255,255,255,0.7)';
  cx.font = font(Math.floor(size/2), true);
  cx.textAlign = 'center'; cx.textBaseline = 'middle';
  cx.fillText('?', size/2, size/2);
  return cv;
}

async function loadIcon(p, size) {
  if (!p || !fs.existsSync(p)) return null;
  try {
    const img = await loadImage(p);
    const cv  = createCanvas(size, size);
    const cx  = cv.getContext('2d');
    cx.drawImage(img, 0, 0, size, size);
    return cv;
  } catch { return null; }
}

// ── Vẽ sao ────────────────────────────────────────────────────────────────────
function drawStars(ctx, x, y, filled, total, starSize = 20) {
  const gap = 4;
  for (let i = 0; i < total; i++) {
    ctx.fillStyle = i < filled ? GOLD : 'rgba(255,255,255,0.18)';
    drawStar(ctx, x + i * (starSize + gap) + starSize / 2, y + starSize / 2, starSize / 2 * 0.9, starSize / 2 * 0.42);
  }
  return total * (starSize + gap) - gap;
}

function drawStar(ctx, cx, cy, outerR, innerR) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const r   = i % 2 === 0 ? outerR : innerR;
    const ang = (Math.PI / 5) * i - Math.PI / 2;
    const px  = cx + r * Math.cos(ang);
    const py  = cy + r * Math.sin(ang);
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
}

// ── Vẽ trophy emoji text ──────────────────────────────────────────────────────
function drawTrophy(ctx, cx, y, size) {
  // Vẽ hình cúp đơn giản bằng canvas shape
  ctx.fillStyle = GOLD;
  // body
  const bw = size * 0.55;
  const bh = size * 0.55;
  const bx = cx - bw / 2;
  const by = y;
  roundRectPath(ctx, bx, by, bw, bh, size * 0.1);
  ctx.fill();
  // handles trái phải
  ctx.strokeStyle = GOLD; ctx.lineWidth = size * 0.07;
  ctx.beginPath();
  ctx.arc(bx,       by + bh * 0.35, size * 0.14, Math.PI * 0.5, Math.PI * 1.5); ctx.stroke();
  ctx.beginPath();
  ctx.arc(bx + bw,  by + bh * 0.35, size * 0.14, -Math.PI * 0.5, Math.PI * 0.5); ctx.stroke();
  // stem
  ctx.fillStyle = GOLD;
  ctx.fillRect(cx - size * 0.07, by + bh, size * 0.14, size * 0.15);
  // base
  ctx.fillRect(cx - size * 0.22, by + bh + size * 0.15, size * 0.44, size * 0.09);
}

// ── Nền ───────────────────────────────────────────────────────────────────────
function makeBg(ctx, w, h) {
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, BG_TOP);
  grad.addColorStop(1, BG_BOT);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // subtle radial blob
  const blobs = [
    { cx: 0.5, cy: 0.08, r: 0.35, c: 'rgba(0,200,255,0.04)' },
    { cx: 0.1, cy: 0.5,  r: 0.3,  c: 'rgba(100,80,200,0.05)' },
    { cx: 0.9, cy: 0.7,  r: 0.3,  c: 'rgba(0,150,200,0.04)' },
  ];
  for (const b of blobs) {
    const bx = b.cx * w; const by = b.cy * h; const br = b.r * w;
    const g2 = ctx.createRadialGradient(bx, by, 0, bx, by, br);
    g2.addColorStop(0, b.c); g2.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g2;
    ctx.fillRect(0, 0, w, h);
  }
}

// ── Vẽ một row ───────────────────────────────────────────────────────────────
async function drawRow(ctx, x, y, w, entry) {
  const rank   = entry.rank;
  const isTop3 = rank <= 3;

  // Background row
  roundRect(ctx, x, y, w, ROW_H, ROW_RADIUS, ROW_BG, BORDER_C, 1.5);

  // ── Rank number (trái) ──
  const rankColors = { 1: GOLD, 2: SILVER, 3: GOLD };
  const rankColor  = rankColors[rank] || WHITE;
  const rankW      = 68;
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle    = rankColor;
  ctx.font         = font(rank <= 3 ? 28 : 24, true);
  ctx.fillText(`#${rank}`, x + rankW / 2, y + ROW_H / 2);

  // ── Divider ──
  ctx.fillStyle = BORDER_C;
  ctx.fillRect(x + rankW, y + 16, 1.5, ROW_H - 32);

  // ── Avatar ──
  const avX  = x + rankW + 18;
  const avY  = y + (ROW_H - AV_SIZE) / 2;
  let avImg  = await fetchAvatar(entry.avatar, AV_SIZE);
  if (!avImg) avImg = placeholderAvatar(AV_SIZE, rank);

  // viền avatar: vàng cho top3, xanh dương mờ cho còn lại
  if (isTop3) {
    const borderColor = rank === 1 ? GOLD : rank === 2 ? SILVER : BRONZE;
    ctx.save();
    ctx.beginPath();
    ctx.arc(avX + AV_SIZE/2, avY + AV_SIZE/2, AV_SIZE/2 + 3, 0, Math.PI*2);
    ctx.strokeStyle = borderColor; ctx.lineWidth = 3; ctx.stroke();
    ctx.restore();
  }
  ctx.drawImage(avImg, avX, avY);

  // ── Tên + tin nhắn ──
  const nameX  = avX + AV_SIZE + 18;
  const maxNameW = w - nameX - 260 - x;

  const nameRaw = safeText(entry.name);
  const nameF   = font(22, true);
  const nameStr = fitText(ctx, nameRaw, nameF, maxNameW);

  const msgStr  = `${Number(entry.count).toLocaleString('vi-VN')} tin nhắn`;
  const msgF    = font(17, false);

  const totalTxtH = 22 * 1.25 + 8 + 17 * 1.25;
  const txtY = y + (ROW_H - totalTxtH) / 2;

  ctx.textAlign    = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle    = WHITE;
  ctx.font         = nameF;
  ctx.fillText(nameStr, nameX, txtY);

  ctx.fillStyle = MSG_COLOR;
  ctx.font      = msgF;
  ctx.fillText(msgStr, nameX, txtY + 22 * 1.25 + 8);

  // ── Rank icon + rank name + stars (phải) ──
  const rightW   = 240;
  const rightX   = x + w - rightW - 12;
  const ICON_SZ  = 46;

  const iconImg = await loadIcon(entry.rank_icon, ICON_SZ);
  if (iconImg) {
    const ix = rightX;
    const iy = y + (ROW_H - ICON_SZ) / 2;
    ctx.drawImage(iconImg, ix, iy);
  }

  // rank name
  const rnX = rightX + ICON_SZ + 10;
  const rankName = safeText(entry.rank_name || '');
  if (rankName && rankName !== '?') {
    const isGoldRank = rankName.toLowerCase().includes('vàng') || rankName.toLowerCase().includes('bạch kim');
    ctx.fillStyle    = isGoldRank ? RANK_NAME_GOLD : RANK_NAME_WHITE;
    ctx.font         = font(17, true);
    ctx.textAlign    = 'left';
    ctx.textBaseline = 'top';
    const rnY = y + (ROW_H / 2) - 24;
    ctx.fillText(fitText(ctx, rankName, ctx.font, rightW - ICON_SZ - 14), rnX, rnY);

    // stars
    const filled  = entry.rank_stars     || 0;
    const total   = entry.rank_max_stars || 5;
    drawStars(ctx, rnX, rnY + 28, filled, total, 18);
  }
}

// ── Main ─────────────────────────────────────────────────────────────────────
(async () => {
  registerFonts();

  const n      = entries.length;
  const INNER_W = W - PAD_X * 2;
  const H       = PAD_TOP + HEADER_H + (n > 0 ? n * ROW_H + (n - 1) * ROW_GAP + 24 : 24) + FOOTER_H;

  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  makeBg(ctx, W, H);

  // ── Header ──
  const headCX = W / 2;
  let headY    = PAD_TOP;

  // Trophy trái + phải
  const TROPHY_SZ = 42;
  drawTrophy(ctx, headCX - 200, headY + 4, TROPHY_SZ);
  drawTrophy(ctx, headCX + 200, headY + 4, TROPHY_SZ);

  // Title
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'top';
  ctx.fillStyle    = CYAN;
  ctx.font         = font(36, true);
  ctx.fillText(safeText(title), headCX, headY + 2);
  headY += 48;

  // Subtitle
  ctx.fillStyle = GOLD;
  ctx.font      = font(22, true);
  ctx.fillText(safeText(subtitle), headCX, headY);
  headY += 40;

  // Separator
  ctx.fillStyle = 'rgba(255,255,255,0.08)';
  ctx.fillRect(PAD_X, headY + 4, INNER_W, 1.5);

  // ── Rows ──
  let rowY = PAD_TOP + HEADER_H + 14;
  for (let i = 0; i < n; i++) {
    await drawRow(ctx, PAD_X, rowY, INNER_W, entries[i]);
    rowY += ROW_H + ROW_GAP;
  }

  // ── Footer timestamp ──
  const now   = new Date();
  const pad2  = v => String(v).padStart(2, '0');
  const ts    = `Cập nhật: ${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())} ${pad2(now.getDate())}/${pad2(now.getMonth()+1)}/${now.getFullYear()}`;
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle    = GREY;
  ctx.font         = font(15, false);
  ctx.fillText(ts, W / 2, rowY + 18);

  const outDir = path.dirname(outPath);
  if (outDir && !fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const buf = canvas.toBuffer('image/jpeg', { quality: 0.95 });
  fs.writeFileSync(outPath, buf);

  process.stdout.write(`${W} ${H}`);
})().catch(err => {
  process.stderr.write(String(err && err.stack ? err.stack : err));
  process.exit(1);
});
