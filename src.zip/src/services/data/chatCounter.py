"""
chatCounter.py  –  Đếm & lưu tin nhắn theo group và global
Data structure:
  config/chat_count/group_{threadId}.json
    { "userId": { "name": "...", "avatar": "...", "count": N }, ... }

  config/chat_count/global.json
    { "threadId": { "name": "...", "avatar": "...", "count": N }, ... }

Key của global LUÔN là threadId (string).
Không dùng fallback theo name để tránh tạo entry trùng khi đổi tên nhóm.
"""

import os, json, threading, time
from pathlib import Path

_DATA_DIR = Path("data/config/chat_count")
_lock     = threading.Lock()

# ── Multibot dedup ────────────────────────────────────────────────────────────
_seen_msgs: set  = set()
_BUCKET_SEC: int = 2


def _msg_key(userId: str, threadId: str) -> tuple:
    bucket = int(time.time() / _BUCKET_SEC)
    return (str(userId), str(threadId), bucket)


def _path_group(threadId: str) -> Path:
    return _DATA_DIR / f"group_{threadId}.json"

def _path_global() -> Path:
    return _DATA_DIR / "global.json"

def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def record_message(userId: str, threadId: str,
                   user_name: str    = "",
                   user_avatar: str  = "",
                   group_name: str   = "",
                   group_avatar: str = ""):
    """
    Gọi mỗi khi có tin nhắn mới trong group.
    - Cộng count cho user trong group đó.
    - Cộng count cho group trong global.
    - Key global LUÔN là threadId — không bao giờ tạo entry trùng.
    - Dedup multibot: cùng (userId, threadId, 2s-bucket) chỉ ghi 1 lần.
    """
    key = _msg_key(userId, threadId)
    tid = str(threadId)
    uid = str(userId)

    with _lock:
        # ── Multibot dedup ────────────────────────────────────────────
        if key in _seen_msgs:
            return
        _seen_msgs.add(key)
        now_bucket = int(time.time() / _BUCKET_SEC)
        stale = {k for k in _seen_msgs if now_bucket - k[2] > 5}
        _seen_msgs.difference_update(stale)

        # ── Per-group ─────────────────────────────────────────────────
        gp = _load(_path_group(tid))
        if uid not in gp:
            gp[uid] = {"name": user_name, "avatar": user_avatar, "count": 0}
        else:
            if user_name:   gp[uid]["name"]   = user_name
            if user_avatar: gp[uid]["avatar"] = user_avatar
        gp[uid]["count"] += 1
        _save(_path_group(tid), gp)

        # ── Global — key luôn là threadId ─────────────────────────────
        gl = _load(_path_global())
        if tid not in gl:
            gl[tid] = {"name": group_name, "avatar": group_avatar, "count": 0}
        else:
            if group_name:   gl[tid]["name"]   = group_name
            if group_avatar: gl[tid]["avatar"] = group_avatar
        gl[tid]["count"] += 1
        _save(_path_global(), gl)


def get_top_group(threadId: str, n: int = 15) -> list:
    """
    Trả list top N user trong group, sorted by count desc.
    Mỗi item: { userId, name, avatar, count, rank }
    """
    data = _load(_path_group(str(threadId)))
    rows = [{"userId": uid, **info} for uid, info in data.items()]
    rows.sort(key=lambda x: x["count"], reverse=True)
    for i, r in enumerate(rows[:n]):
        r["rank"] = i + 1
    return rows[:n]


def get_top_global(n: int = 15) -> list:
    """
    Trả list top N group theo tổng tin nhắn, sorted by count desc.
    Mỗi item: { groupId, name, avatar, count, rank }
    """
    data = _load(_path_global())
    # Bỏ qua entry không có tên (data cũ bị lỗi)
    rows = [
        {"groupId": gid, **info}
        for gid, info in data.items()
        if info.get("name", "").strip()
    ]
    rows.sort(key=lambda x: x["count"], reverse=True)
    for i, r in enumerate(rows[:n]):
        r["rank"] = i + 1
    return rows[:n]


def cleanup_global():
    """
    Dọn global.json:
    1. Xóa entry không có tên (name='').
    2. Gộp entry trùng tên vào threadId xuất hiện đầu tiên
       (xử lý data cũ bị tạo nhiều key cho cùng 1 nhóm).
    Trả về số entry đã xóa/gộp.
    """
    with _lock:
        gl = _load(_path_global())
        before = len(gl)

        # Bước 1: xóa entry rỗng tên
        gl = {k: v for k, v in gl.items() if v.get("name", "").strip()}

        # Bước 2: gộp entry trùng tên — giữ key có count cao nhất
        by_name: dict = {}   # name → key giữ lại
        merged:  dict = {}

        for k, v in gl.items():
            name = v.get("name", "")
            if name in by_name:
                keep = by_name[name]
                merged[keep]["count"] += v.get("count", 0)
                if v.get("avatar"):
                    merged[keep]["avatar"] = v["avatar"]
            else:
                by_name[name] = k
                merged[k] = dict(v)

        _save(_path_global(), merged)
        return before - len(merged)
