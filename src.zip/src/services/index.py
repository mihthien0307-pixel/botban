from app.login.client import *
from app.core.index import *

def restart_single_bot(bot):
    username  = bot.get("username")
    author_id = str(bot.get("author_id"))
    imei      = bot.get("imei")
    cookies   = bot.get("session_cookies")
    prefix    = bot.get("prefix", "?")
    is_main   = bot.get("is_main_bot", False)
    status    = bot.get("status", False)

    target = None
    if is_main and 'mainclient' in globals():
        target = mainclient
    elif author_id in clientlist:
        target = clientlist[author_id]

    if target:
        try:
            target._should_reconnect = False
            if hasattr(target, "ping_interval") and target.ping_interval:
                target.ping_interval.cancel()
            if hasattr(target, "ws") and target.ws:
                target.ws.close()
            if hasattr(target, "bools"):
                target.bools.shutdown(wait=False)
            target.listening = False
        except Exception:
            pass
        # Xoá khỏi clientlist để tránh conflict
        if not is_main:
            clientlist.pop(author_id, None)
        # Đợi WebSocket đóng hẳn trước khi tạo mới
        time.sleep(3)

    run_bot(imei, cookies, prefix, is_main, username, author_id, status)


def shutdown_single_bot(bot):
    username = bot.get("username")
    author_id = str(bot.get("author_id"))
    is_main = bot.get("is_main_bot", False)
    target = None
    if is_main and 'mainclient' in globals():
        target = mainclient
    elif author_id in clientlist:
        target = clientlist[author_id]
    if target and hasattr(target, "stop_listening"):
        try:
            target.stop_listening()
            time.sleep(0.8)
        except Exception as e:
            logger.warning(f"Lỗi stop bot {username}: {e}")

def resolve_bot(self, bots, parts, data):
    uids = extractUids(data)
    if uids:
        uid = str(uids[0])
        for bot in bots:
            if str(bot.get("botId")) == uid:
                return bot

    if len(parts) >= 3 and parts[2].isdigit():
        idx = int(parts[2]) - 1
        bot_list = [b for b in bots if not b.get("is_main_bot")]
        if 0 <= idx < len(bot_list):
            return bot_list[idx]

    if len(parts) >= 3:
        key = parts[2].lower()
        for bot in bots:
            if bot.get("username", "").lower() == key:
                return bot

    return None

def findBotId(bots, uid):
    for bot in bots:
        if str(bot.get("botId")) == str(uid):
            return bot
    return None


def findBot(self, bots, parts, data):
    uids = extractUids(data)
    if uids:
        uid = str(uids[0])
        return findBotId(bots, uid)
    if len(parts) >= 3 and parts[2].isdigit():
        idx = int(parts[2]) - 1
        if 0 <= idx < len(bots):
            return bots[idx]

    return None

def getTargetBots(self, bots, parts, data):
    targets = []

    uids = extractUids(data)
    if uids:
        for uid in uids:
            bot = findBotId(bots, uid)
            if bot and bot not in targets:
                targets.append(bot)
        return targets

    if len(parts) >= 3 and parts[2].isdigit():
        bot = findBotId(bots, parts[2])
        if bot:
            return [bot]

    bot = findBot(self, bots, parts, data)
    if bot:
        return [bot]

    return []