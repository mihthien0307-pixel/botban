from ..utils.jsonio import *
import json
import os
import threading

_BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
_TEMP_STORAGE = os.path.join(_BASE_DIR, "..", "..", "..", "data", "config", "tempStorage.json")

# ── Temp storage helpers ──────────────────────────────────────────────────────

def _load_temp() -> dict:
    try:
        with open(_TEMP_STORAGE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_temp(data: dict) -> None:
    try:
        os.makedirs(os.path.dirname(_TEMP_STORAGE), exist_ok=True)
        with open(_TEMP_STORAGE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"[BNTF] _save_temp LỖI: {e}")

def save_restart_thread(threadId) -> None:
    data = _load_temp()
    data["restartThread"] = str(threadId)
    _save_temp(data)

def doneRestart(self) -> None:
    data = _load_temp()
    threadId = data.pop("restartThread", None)
    if threadId:
        _save_temp(data)
        try:
            from api.util.Enum import ThreadType
            from api.util.msg import Message, MultiMsgStyle

            title_text = "SYSTEM"
            body_text  = "Khởi động lại hoàn tất!\nBot đã hoạt động trở lại!\n✅✅✅"
            full_text  = title_text + "\n" + body_text

            def _utf16_len(s): return len(s.encode("utf-16-le")) // 2

            title_len = _utf16_len(title_text)
            body_len  = _utf16_len(body_text)
            styles = [
                {"start": 0,              "len": title_len, "st": "b"},
                {"start": 0,              "len": title_len, "st": "c_15a85f"},
                {"start": title_len + 1,  "len": body_len,  "st": "f_14"},
            ]
            style = str(MultiMsgStyle(styles))

            self.sendMessage(
                Message(text=full_text, style=style),
                threadId,
                ThreadType.GROUP,
            )
        except Exception as e:
            import traceback
            print(f"[doneRestart] LỖI gửi message: {e}\n{traceback.format_exc()}")

# ── Portal — dùng shared memory trong cùng process, không cần HTTP server ─────
# Tất cả bot (main + con) chạy trong cùng 1 Python process nên dùng biến
# module-level + Event là đủ, tránh hoàn toàn vấn đề timeout mạng.

_portal_lock  = threading.Lock()
_portal_ready = threading.Event()   # được set() khi main bot đã publish xong
_portal_data: dict = {}             # {"main_phone": "...", "main_name": "..."}


def _publish_portal(self):
    """Gọi bởi main bot: lấy phone rồi lưu vào shared dict và báo ready."""
    global _portal_data

    phone = ""
    name  = str(self.bot)
    try:
        info    = self.fetchAccountInfo()
        profile = getattr(info, "profile", None) or info
        if isinstance(profile, dict):
            phone = str(profile.get("phoneNumber") or profile.get("phone") or "")
            name  = profile.get("displayName") or profile.get("zaloName") or name
        else:
            phone = str(getattr(profile, "phoneNumber", "") or getattr(profile, "phone", "") or "")
            name  = getattr(profile, "displayName", name) or getattr(profile, "zaloName", name) or name
    except Exception as e:
        logger.warning(f"[Portal] Không lấy được phone từ fetchAccountInfo: {e}")

    with _portal_lock:
        _portal_data = {"main_phone": phone, "main_name": name}

    _portal_ready.set()  # báo cho tất cả bot con đang chờ

    if phone:
        logger.info(f"[Portal] Main bot [{name}] đã publish phone={phone}.")
    else:
        logger.warning(f"[Portal] Main bot [{name}]: không lấy được số điện thoại — phone ẩn hoặc API lỗi.")

# ── initAdmin ─────────────────────────────────────────────────────────────────

def initAdmin(self):
    settings = read_settings(self.uid)

    if getattr(self, "is_main_bot", False):
        # Main bot: publish phone vào shared memory ngay lập tức
        dev_list = settings.setdefault("developerAdmin", [])
        if self.uid not in dev_list:
            dev_list.insert(0, self.uid)
            write_settings(self.uid, settings)
        _publish_portal(self)
    else:
        # Bot con: add chính nó vào highAdmin + adminBot
        high_bot_admin = settings.get("highAdmin", [])
        if self.uid not in high_bot_admin:
            high_bot_admin.append(self.uid)
            settings["highAdmin"] = high_bot_admin
            write_settings(self.uid, settings)

        settings = read_settings(self.uid)
        admin_bot = settings.get("adminBot", [])
        if self.uid not in admin_bot:
            admin_bot.append(self.uid)
            settings["adminBot"] = admin_bot
            write_settings(self.uid, settings)

        # Nếu đã resolve main bot rồi thì bỏ qua
        settings = read_settings(self.uid)
        if settings.get("main_protected_admins"):
            return

        # Chạy resolve trong thread riêng để không block khởi động bot con
        threading.Thread(
            target=_resolve_main_uid,
            args=(self,),
            daemon=True,
            name=f"portal-resolve-{self.bot}"
        ).start()


def _resolve_main_uid(self, wait_timeout: float = 60.0):
    """
    Chờ main bot publish phone vào shared memory rồi resolve UID.
    Không dùng HTTP — không bao giờ timeout do network.
    """
    import time

    logger.info(f"[Portal] Bot con {self.bot}: đang chờ main bot publish...")

    # Chờ tối đa wait_timeout giây để main bot gọi _publish_portal
    got = _portal_ready.wait(timeout=wait_timeout)
    if not got:
        logger.error(f"[Portal] Bot con {self.bot}: main bot chưa publish sau {wait_timeout:.0f}s — bỏ qua.")
        return

    with _portal_lock:
        portal = dict(_portal_data)

    main_phone = str(portal.get("main_phone", "")).strip()
    main_name  = portal.get("main_name", "main bot")

    if not main_phone:
        logger.warning(f"[Portal] Bot con {self.bot}: main bot ẩn số điện thoại — không thể resolve UID.")
        return

    # ── Bước 2: fetchPhoneNumber → lấy UID trong session của bot con ──────────
    main_uid_local = None
    try:
        result = self.fetchPhoneNumber(main_phone)
        if result:
            def _get(obj, *keys):
                for k in keys:
                    if obj is None:
                        return None
                    obj = obj.get(k) if isinstance(obj, dict) else getattr(obj, k, None)
                return obj

            main_uid_local = (
                _get(result, "userId")
                or _get(result, "uid")
                or _get(result, "info", "userId")
                or _get(result, "profile", "userId")
                or _get(result, "data", "userId")
                or _get(result, "data", "uid")
                or _get(result, "data", "info", "userId")
            )
            if main_uid_local:
                main_uid_local = str(main_uid_local)
    except Exception as e:
        logger.warning(f"[Portal] fetchPhoneNumber({main_phone}) lỗi: {e}")

    if not main_uid_local:
        logger.error(
            f"[Portal] Bot con {self.bot}: fetchPhoneNumber không trả về userId. "
            f"Dùng lệnh prefix+uid trong chat để kiểm tra UID của main bot thủ công."
        )
        return

    # ── Bước 3: lưu vào settings ──────────────────────────────────────────────
    settings = read_settings(self.uid)

    dev_list = settings.setdefault("developerAdmin", [])
    if main_uid_local not in dev_list:
        dev_list.insert(0, main_uid_local)

    sub_high = settings.setdefault("highAdmin", [])
    if main_uid_local not in sub_high:
        sub_high.insert(0, main_uid_local)

    settings["main_protected_admins"] = [main_uid_local]
    write_settings(self.uid, settings)

    logger.info(f"[Portal] Bot con {self.bot}: đã resolve UID main bot [{main_name}] = {main_uid_local} → Developer (cấp 4).")

# ── Permission helpers ────────────────────────────────────────────────────────

def isAdminGroup(self, userId, threadId) -> bool:
    setting = read_settings(self.uid)
    gradmin = setting.get("groupAdmin", {})
    if isinstance(gradmin, dict):
        return userId in gradmin.get(str(threadId), [])
    return userId in gradmin

def isAdminHigh(self, userId) -> bool:
    setting = read_settings(self.uid)
    return userId in setting.get("highAdmin", [])

def isAdminBot(self, userId) -> bool:
    setting = read_settings(self.uid)
    return userId in setting.get("adminBot", [])

def admin_of_bot(self, threadId, userId):
    return (
        isAdminHigh(self, userId)
        or isAdminBot(self, userId)
        or isAdminGroup(self, userId, threadId)
    )
