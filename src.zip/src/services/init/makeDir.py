import os

def getDir() -> None:
    dirs = (
        "data/assets/cache/image",
        "data/assets/cache/video",
        "data/assets/cache/gif",
        "data/config/command"
    )

    for path in dirs:
        os.makedirs(path, exist_ok=True)

getDir()