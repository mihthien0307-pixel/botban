"""
capcutCard.py – Vẽ danh sách template CapCut
Style: giống ZingMP3 – featured card trái + grid 2 cột phải
Output: JPEG (path trả về từ draw_capcut_list)
Đặt file này vào: zbot/src/services/pillow/capcutCard.py
"""
import os
import random
import threading
import requests
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

# ── Font paths ────────────────────────────────────────────────────────────────
_ASSET_FONT = Path(__file__).resolve().parents[3] / "assets" / "font"
_FONT_BOLD  = str(_ASSET_FONT / "Opensans" / "static" / "OpenSans_Condensed-Bold.ttf")
_FONT_REG   = str(_ASSET_FONT / "Opensans" / "static" / "OpenSans_Condensed-Regular.ttf")


def _font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont:
    path = _FONT_BOLD if bold else _FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


# ── Canvas constants ──────────────────────────────────────────────────────────
W, H = 2560, 1440
PAD  = 60

# Colours
GRAD_TL        = (8,  12, 20)
GRAD_TR        = (20, 10, 35)
GRAD_BL        = (10, 20, 30)
GRAD_BR        = (25, 15, 40)
CC_CYAN        = (0, 255, 200)
CC_CYAN_A      = (0, 255, 200, 255)
CC_PURPLE      = (120, 40, 220)
C_FEAT_TITLE   = (255, 255, 255)
C_FEAT_SUB     = (180, 220, 255)
C_FEAT_STATS   = (200, 200, 200)
C_FEAT_DUR     = (0, 220, 180)
C_TITLE        = (235, 235, 245)
C_STATS        = (160, 170, 200)
C_CARD_BG      = (255, 255, 255, 18)
C_CARD_BORDER  = (255, 255, 255, 45)
ARTIST_LIFT    = 18

_mask_cache: dict = {}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_bg() -> Image.Image:
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), GRAD_TL)
    c.putpixel((1, 0), GRAD_TR)
    c.putpixel((0, 1), GRAD_BL)
    c.putpixel((1, 1), GRAD_BR)
    bg = c.resize((W, H), Image.BILINEAR).convert("RGBA")
    # mesh glow overlay
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    palette = [
        (0, 255, 200, 120),
        (100, 50, 255, 100),
        (0, 100, 200, 80),
    ]
    rng = random.Random(42)
    for _ in range(8):
        cx = int(rng.uniform(0, W))
        cy = int(rng.uniform(0, H))
        r  = int(min(W, H) * rng.uniform(0.25, 0.55))
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rng.choice(palette))
    layer = layer.filter(ImageFilter.GaussianBlur(radius=int(H * 0.10)))
    return Image.alpha_composite(bg, layer)


def _rounded_mask(w: int, h: int, r: int, aa: int = 4) -> Image.Image:
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w * aa, h * aa
        mr = int(min(r, w // 2, h // 2) * aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]


def _solid_card(canvas: Image.Image, box: tuple, radius: int = 22):
    x1, y1, x2, y2 = box
    bw, bh = x2 - x1, y2 - y1
    layer = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    mask  = _rounded_mask(bw, bh, radius)
    fill  = Image.new("RGBA", (bw, bh), C_CARD_BG)
    layer.paste(fill, (0, 0), mask)
    ImageDraw.Draw(layer).rounded_rectangle(
        (0, 0, bw - 1, bh - 1), radius, outline=C_CARD_BORDER, width=2
    )
    canvas.alpha_composite(layer, (x1, y1))


def _glass_card_feat(canvas: Image.Image, box: tuple,
                     radius: int = 36, alpha: int = 30, blur: int = 20):
    x1, y1, x2, y2 = box
    bw, bh = x2 - x1, y2 - y1
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle(
        (x1 + 6, y1 + 6, x2 + 6, y2 + 6), radius, fill=(0, 0, 0, 45)
    )
    canvas.alpha_composite(sh.filter(ImageFilter.GaussianBlur(12)))
    region  = canvas.crop(box)
    blurred = region.filter(ImageFilter.GaussianBlur(blur))
    overlay = Image.new("RGBA", (bw, bh), (255, 255, 255, alpha))
    merged  = Image.alpha_composite(blurred, overlay)
    mask    = _rounded_mask(bw, bh, radius)
    canvas.paste(merged, (x1, y1), mask)
    bd = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(bd).rounded_rectangle(box, radius, outline=(*CC_CYAN, 80), width=3)
    canvas.alpha_composite(bd)


def _load_cover(url: str, size: tuple) -> Image.Image:
    blank = Image.new("RGBA", size, (20, 20, 30, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        resp = requests.get(url, timeout=8)
        img  = Image.open(BytesIO(resp.content)).convert("RGBA")
        w0, h0 = img.size
        s    = min(w0, h0)
        img  = img.crop(((w0 - s) // 2, (h0 - s) // 2, (w0 + s) // 2, (h0 + s) // 2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank


def _sanitize(text: str) -> str:
    """Remove newlines/carriage returns that cause textlength() to crash."""
    return str(text or "").replace("\r\n", " ").replace("\n", " ").replace("\r", " ").strip()


def _fit(draw: ImageDraw.ImageDraw, text: str, font, max_w: int) -> str:
    text = _sanitize(text)
    if draw.textlength(text, font=font) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell


def _fmt(n: int) -> str:
    n = int(n or 0)
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _draw_small_card(canvas, tpls, idx, cx1, cy1, cx2, cy2,
                     covers, THUMB, f_title, f_stats, ip=28):
    ROW_H = cy2 - cy1
    _solid_card(canvas, (cx1, cy1, cx2, cy2), radius=22)

    th_y = cy1 + (ROW_H - THUMB) // 2
    canvas.paste(covers[idx], (cx1 + ip, th_y),
                 _rounded_mask(THUMB, THUMB, 14))

    # Index badge
    d = ImageDraw.Draw(canvas)
    f_idx = _font(int(THUMB * 0.28), bold=True)
    badge_size = int(THUMB * 0.42)
    bx = cx1 + ip - badge_size // 2 + 4
    by = cy1 + ip // 2
    d.rounded_rectangle([bx, by, bx + badge_size, by + badge_size],
                        radius=10, fill=(0, 255, 200, 200))
    idx_s = str(idx + 1)
    d.text((bx + badge_size // 2 - d.textlength(idx_s, font=f_idx) // 2, by + 4),
           idx_s, font=f_idx, fill=(0, 0, 0))

    tpl = tpls[idx]
    tx  = cx1 + ip + THUMB + ip
    mw  = cx2 - ip - tx

    title_str = _fit(d, tpl.get("title", "No Title"), f_title, mw)
    play  = _fmt(tpl.get("play_amount",  0))
    like  = _fmt(tpl.get("like_count",   0))
    usage = _fmt(tpl.get("usage_amount", 0))
    stats_str = f"👁 {play}   ❤ {like}   🔥 {usage}"

    title_h = int(f_title.getbbox("Ay")[3] - f_title.getbbox("Ay")[1])
    stats_h = int(f_stats.getbbox("Ay")[3] - f_stats.getbbox("Ay")[1])
    total_h = title_h + 14 + stats_h
    ty      = cy1 + (ROW_H - total_h) // 2

    d.text((tx, ty),             title_str, font=f_title, fill=C_TITLE)
    d.text((tx, ty + title_h + 14), stats_str, font=f_stats, fill=C_STATS)


# ── Main list draw ────────────────────────────────────────────────────────────

def draw_capcut_list(templates: list, out_path: str) -> str:
    """
    Vẽ danh sách template CapCut kiểu ZingMP3:
    - Bài 1: featured card lớn bên trái (thumbnail + info)
    - Bài 2-10: grid 2 cột bên phải (thumbnail nhỏ + title + stats)
    Output: JPEG 2560×1440
    """
    templates = templates[:10]
    n = len(templates)

    FEAT_CARD_W = int(W * 0.265)
    FEAT_COVER  = FEAT_CARD_W - PAD * 2
    THUMB       = 130
    GRID_X      = PAD + FEAT_CARD_W + PAD
    GRID_W      = W - GRID_X - PAD
    COL_GAP     = PAD
    COL_W       = (GRID_W - COL_GAP) // 2
    ROWS        = 5
    CARD_GAP    = 22
    ROW_H       = (H - PAD * 2 - CARD_GAP * (ROWS - 1)) // ROWS

    # ── Fetch all covers in parallel ──────────────────────────────────────────
    covers = [None] * n

    def _fetch(i, url, sz):
        covers[i] = _load_cover(url, sz)

    threads = []
    for i, tpl in enumerate(templates):
        sz = (FEAT_COVER, FEAT_COVER) if i == 0 else (THUMB, THUMB)
        t  = threading.Thread(target=_fetch, args=(i, tpl.get("cover_url", ""), sz), daemon=True)
        threads.append(t)
        t.start()
    for t in threads:
        t.join(timeout=10)

    # ── Background ────────────────────────────────────────────────────────────
    canvas = _make_bg()

    # ── Featured card (index 0) ───────────────────────────────────────────────
    fx1, fy1 = PAD, PAD
    fx2, fy2 = PAD + FEAT_CARD_W, H - PAD
    _glass_card_feat(canvas, (fx1, fy1, fx2, fy2), radius=36, alpha=30, blur=20)

    cov_x = fx1 + PAD
    cov_y = fy1 + PAD
    canvas.paste(covers[0], (cov_x, cov_y),
                 _rounded_mask(FEAT_COVER, FEAT_COVER, 24))

    d = ImageDraw.Draw(canvas)

    f_feat_num    = _font(int(H * 0.032), bold=True)
    f_feat_title  = _font(int(H * 0.048), bold=True)
    f_feat_stats  = _font(int(H * 0.028), bold=False)
    f_feat_dur    = _font(int(H * 0.028), bold=False)

    mw_feat       = FEAT_CARD_W - PAD * 2
    feat_text_top = cov_y + FEAT_COVER + int(PAD * 0.7)

    # "1." badge
    d.text((cov_x, feat_text_top), "1.", font=f_feat_num, fill=CC_CYAN)
    ty = feat_text_top + int(H * 0.032) + 12

    # Title (2 lines)
    title0 = _sanitize(templates[0].get("title", "No Title"))
    words, lines, cur = title0.split(), [], ""
    for word in words:
        test = (cur + " " + word).strip()
        if d.textlength(test, font=f_feat_title) <= mw_feat:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    lines = lines[:2]
    if len(lines) == 2:
        last = lines[-1]
        while d.textlength(last + "...", font=f_feat_title) > mw_feat and last:
            last = last[:-1]
        lines[-1] = last + "..."
    for line in lines:
        d.text((cov_x, ty), line, font=f_feat_title, fill=C_FEAT_TITLE)
        ty += int(H * 0.048) + 8

    # Stats
    ty += 10
    play0  = _fmt(templates[0].get("play_amount",  0))
    like0  = _fmt(templates[0].get("like_count",   0))
    usage0 = _fmt(templates[0].get("usage_amount", 0))
    dur0   = templates[0].get("duration", 0) or 0
    dur0_s = dur0 // 1000 if dur0 > 1000 else dur0
    d.text((cov_x, ty), f"⏱  {dur0_s}s", font=f_feat_dur, fill=C_FEAT_DUR)
    ty += int(H * 0.028) + 8
    d.text((cov_x, ty), f"👁 {play0}   ❤ {like0}   🔥 {usage0}",
           font=f_feat_stats, fill=C_FEAT_STATS)

    # ── Small cards (index 1 to n-1) ─────────────────────────────────────────
    f_title = _font(int(ROW_H * 0.20), bold=True)
    f_stats = _font(int(ROW_H * 0.15), bold=False)

    for idx in range(1, n):
        col = (idx - 1) % 2
        row = (idx - 1) // 2
        cx1 = GRID_X + col * (COL_W + COL_GAP)
        cy1 = PAD + row * (ROW_H + CARD_GAP)
        cx2 = cx1 + COL_W
        cy2 = cy1 + ROW_H
        _draw_small_card(canvas, templates, idx,
                         cx1, cy1, cx2, cy2,
                         covers, THUMB, f_title, f_stats)

    # ── Header overlay (top-right) ────────────────────────────────────────────
    hdr_txt = "CAPCUT TEMPLATE"
    sub_txt = f"Tìm thấy {n} kết quả"
    f_hdr   = _font(int(H * 0.038), bold=True)
    f_sub   = _font(int(H * 0.022), bold=False)
    # Draw top-right corner header
    hdr_x = GRID_X + GRID_W - int(d.textlength(hdr_txt, font=f_hdr))
    d.text((hdr_x, PAD // 2), hdr_txt, font=f_hdr, fill=CC_CYAN)
    sub_x = GRID_X + GRID_W - int(d.textlength(sub_txt, font=f_sub))
    d.text((sub_x, PAD // 2 + int(H * 0.040)), sub_txt,
           font=f_sub, fill=(200, 200, 200))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=92, optimize=True)
    return out_path


# ── Hằng số màu dùng trong draw_capcut_card ──────────────────────────────────
GRAD_TL_CARD = (8,  12, 20)
C_FEAT_DUR   = (0, 220, 180)
C_FEAT_STATS2 = (200, 200, 200)


def _load_cover_card(url: str, size: tuple) -> Image.Image:
    w, h = size
    placeholder = Image.new("RGBA", (w, h), (20, 20, 30, 255))
    if not url:
        return placeholder
    try:
        resp  = requests.get(url, timeout=6)
        img   = Image.open(BytesIO(resp.content)).convert("RGBA")
        md    = min(img.size)
        left  = (img.width  - md) // 2
        top   = (img.height - md) // 2
        img   = img.crop((left, top, left + md, top + md))
        return img.resize((w, h), Image.LANCZOS)
    except Exception:
        return placeholder


def _add_noise(img, amount=10):
    w, h = img.size
    noise = Image.effect_noise((w, h), amount).convert("L")
    noise = Image.merge("RGBA", (noise, noise, noise, Image.new("L", (w, h), 50)))
    return Image.alpha_composite(img.convert("RGBA"), noise)


def _mesh_gradient_card(w, h, seed=0):
    base  = Image.new("RGBA", (w, h), (*GRAD_TL_CARD, 255))
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d     = ImageDraw.Draw(layer)
    palette = [
        (0, 255, 200, 180), (100, 50, 255, 180),
        (0, 100, 200, 150), (80, 0, 180, 140),
    ]
    rng = random.Random(seed & 0xFFFFFFFF)
    for _ in range(8):
        cx_ = int(rng.uniform(0, w))
        cy_ = int(rng.uniform(0, h))
        r_  = int(min(w, h) * rng.uniform(0.3, 0.7))
        d.ellipse([cx_ - r_, cy_ - r_, cx_ + r_, cy_ + r_], fill=rng.choice(palette))
    layer  = layer.filter(ImageFilter.GaussianBlur(radius=int(h * 0.12)))
    canvas = Image.alpha_composite(base, layer)
    return _add_noise(canvas, amount=12)


# ── Single template card ──────────────────────────────────────────────────────

def draw_capcut_card(template: dict, out_path: str) -> str:
    """
    Vẽ card 1 template theo kiểu TikTok: thumbnail trái + info phải.
    Output: JPEG 2560×640
    """
    CW, CH  = 2560, 640
    IP      = 50
    THUMB_W = 480
    THUMB_H = CH - IP * 2

    canvas = _mesh_gradient_card(CW, CH, seed=hash(template.get("title", "")) & 0xFFFFFFFF)

    # Thumbnail
    thumb = _load_cover_card(template.get("cover_url", ""), (THUMB_W, THUMB_H))
    mask  = _rounded_mask(THUMB_W, THUMB_H, 28)
    layer_t = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    layer_t.paste(thumb, (IP, IP), mask)
    canvas = Image.alpha_composite(canvas, layer_t)

    # Thumbnail border
    bd = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    ImageDraw.Draw(bd).rounded_rectangle(
        [IP, IP, IP + THUMB_W, IP + THUMB_H],
        radius=28, outline=CC_CYAN_A, width=3,
    )
    canvas = Image.alpha_composite(canvas, bd)

    d = ImageDraw.Draw(canvas)

    # HD badge
    f_hd = _font(36, bold=True)
    d.rounded_rectangle([IP + 10, IP + 10, IP + 90, IP + 62],
                        radius=10, fill=(0, 0, 0, 180))
    d.text((IP + 20, IP + 14), "HD", font=f_hd, fill=CC_CYAN)

    # Text area
    tx   = IP + THUMB_W + IP * 2
    t_mw = CW - tx - IP

    title   = _sanitize(template.get("title", "Unknown"))
    dur_ms  = template.get("duration", 0) or 0
    dur_sec = dur_ms // 1000 if dur_ms > 1000 else dur_ms
    play    = _fmt(template.get("play_amount",  0))
    like    = _fmt(template.get("like_count",   0))
    usage   = _fmt(template.get("usage_amount", 0))
    link    = template.get("template_url", "")

    f_title = _font(int(CH * 0.115), bold=True)
    f_meta  = _font(int(CH * 0.072), bold=False)
    f_stats = _font(int(CH * 0.065), bold=False)
    f_link  = _font(int(CH * 0.055), bold=False)

    def fit(text, font, max_w):
        text = _sanitize(text)
        if d.textlength(text, font=font) <= max_w:
            return text
        ell  = "..."
        room = max_w - d.textlength(ell, font=font)
        out  = ""
        for ch in text:
            if d.textlength(out + ch, font=font) > room:
                break
            out += ch
        return out + ell

    # Title (2 lines)
    words, lines, cur = title.split(), [], ""
    for word in words:
        test = (cur + " " + word).strip()
        if d.textlength(test, font=f_title) <= t_mw:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    lines = lines[:2]
    if len(lines) == 2:
        last = lines[-1]
        while d.textlength(last + "...", font=f_title) > t_mw and last:
            last = last[:-1]
        lines[-1] = last + "..."

    lh_title = int(f_title.getbbox("Ay")[3] - f_title.getbbox("Ay")[1])
    lh_meta  = int(f_meta.getbbox("Ay")[3]  - f_meta.getbbox("Ay")[1])
    lh_stats = int(f_stats.getbbox("Ay")[3] - f_stats.getbbox("Ay")[1])
    lh_link  = int(f_link.getbbox("Ay")[3]  - f_link.getbbox("Ay")[1])
    GAP = 22

    total_h = (
        len(lines) * lh_title + (len(lines) - 1) * (GAP // 2)
        + GAP + lh_meta
        + GAP + lh_stats
        + GAP + lh_link
    )
    ty = (CH - total_h) // 2

    for line in lines:
        d.text((tx, ty), line, font=f_title, fill=(255, 255, 255))
        ty += lh_title + GAP // 2

    ty += GAP // 2
    d.text((tx, ty), f"⏱  {dur_sec}s", font=f_meta, fill=C_FEAT_DUR)
    ty += lh_meta + GAP

    d.text((tx, ty), f"👁  {play}    ❤  {like}    🔥  {usage}",
           font=f_stats, fill=C_FEAT_STATS2)
    ty += lh_stats + GAP

    if link:
        d.text((tx, ty), fit(link, f_link, t_mw), font=f_link, fill=CC_CYAN)

    # CapCut badge
    f_badge   = _font(int(CH * 0.07), bold=True)
    badge_txt = "CapCut"
    bw2 = int(d.textlength(badge_txt, font=f_badge)) + 36
    bx  = CW - IP - bw2
    by  = CH - IP - int(CH * 0.115)
    d.rounded_rectangle([bx, by, bx + bw2, by + int(CH * 0.11)],
                        radius=14, fill=(*CC_PURPLE, 220))
    d.text((bx + 18, by + 8), badge_txt, font=f_badge, fill=(255, 255, 255))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=92, optimize=True)
    return out_path
