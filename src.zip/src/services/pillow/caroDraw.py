import os, uuid
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

CELL   = 68
PAD    = 24
SIZE   = 16

BOARD_PX = CELL * SIZE
W        = BOARD_PX + PAD * 2
H        = BOARD_PX + PAD * 2

BG_TOP    = (180, 140,  85)   # nâu gỗ
BG_BOT    = (160, 120,  65)
GRID_LINE = (100,  72,  30, 160)   # đường kẻ nâu đậm
CELL_EVEN = (240, 215, 168, 255)   # ô sáng – be/cát
CELL_ODD  = (218, 190, 138, 255)   # ô tối – nâu nhạt
CLR_X     = ( 55,  85, 160)        # X xanh navy
CLR_O     = (190,  35,  35)        # O đỏ đậm
CLR_LAST  = (255, 215,   0)        # highlight ô cuối – vàng gold
CLR_NUM   = ( 90,  65,  30)        # số – nâu tối
CLR_HEAD  = (255, 245, 220)
CLR_SUB   = (210, 185, 140)

_ASSET  = Path(__file__).resolve().parents[3] / "assets" / "font"
_OSANS  = _ASSET / "Opensans" / "static"
F_BOLD  = str(_OSANS / "OpenSans_Condensed-Bold.ttf")
F_REG   = str(_OSANS / "OpenSans_Condensed-Regular.ttf")

_font_cache: dict = {}
_bg_cache: Image.Image | None = None


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (size, bold)
    if key not in _font_cache:
        path = F_BOLD if bold else F_REG
        try:
            _font_cache[key] = ImageFont.truetype(path, size)
        except Exception:
            _font_cache[key] = ImageFont.load_default()
    return _font_cache[key]


def _make_bg() -> Image.Image:
    global _bg_cache
    if _bg_cache is None:
        strip = Image.new("RGBA", (1, 2))
        strip.putpixel((0, 0), (*BG_TOP, 255))
        strip.putpixel((0, 1), (*BG_BOT, 255))
        _bg_cache = strip.resize((W, H), Image.BILINEAR)
    return _bg_cache.copy()


def draw_caro_board(
    cells,
    out_path: str,
    *,
    last_r: int = -1,
    last_c: int = -1,
    move_num: int = 0,
    difficulty: int = 3,
    extra: str = "",
    difficulty_names: dict = None,
    win_line: list = None,
    last_player: int = 0,
) -> str:
    if difficulty_names is None:
        difficulty_names = {1: "🟢 Dễ", 2: "🟡 TB", 3: "🔴 Khó", 4: "💀 Ác mộng"}

    win_set   = set(map(tuple, win_line)) if win_line else set()
    CLR_WIN_X = ( 30, 160,  60)   # xanh lá đậm như ảnh
    CLR_WIN_O = ( 30, 160,  60)
    clr_win   = CLR_WIN_X if last_player == 1 else CLR_WIN_O

    img = _make_bg()
    d   = ImageDraw.Draw(img, "RGBA")

    f_num   = _font(20)
    f_extra = _font(34, bold=False)

    BOARD_X = PAD
    BOARD_Y = PAD

    d.rounded_rectangle(
        (BOARD_X - 8, BOARD_Y - 8,
         BOARD_X + BOARD_PX + 8, BOARD_Y + BOARD_PX + 8),
        radius=14,
        fill=(195, 162, 105, 255),
        outline=(100, 70, 30, 255), width=4,
    )

    for r in range(SIZE):
        for c in range(SIZE):
            x0 = BOARD_X + c * CELL
            y0 = BOARD_Y + r * CELL
            x1 = x0 + CELL
            y1 = y0 + CELL

            shade = CELL_EVEN if (r + c) % 2 == 0 else CELL_ODD
            d.rectangle((x0, y0, x1 - 1, y1 - 1), fill=shade)

            val     = cells[r][c]
            is_last = (r == last_r and c == last_c)
            is_win  = (r, c) in win_set

            cx = x0 + CELL // 2
            cy = y0 + CELL // 2

            if is_last:
                # nền vàng gold cho ô vừa đánh
                d.rectangle((x0 + 1, y0 + 1, x1 - 2, y1 - 2),
                             fill=(*CLR_LAST, 180))

            if val == 1:
                R  = CELL // 2 - 10
                d.line((cx - R, cy - R, cx + R, cy + R), fill=CLR_X, width=6)
                d.line((cx + R, cy - R, cx - R, cy + R), fill=CLR_X, width=6)
            elif val == 2:
                R  = CELL // 2 - 9
                d.ellipse((cx - R, cy - R, cx + R, cy + R),
                           outline=CLR_O, width=6)
            else:
                n   = r * SIZE + c + 1
                txt = str(n)
                bw  = d.textlength(txt, font=f_num)
                d.text((cx - bw / 2, cy - 10), txt, font=f_num, fill=CLR_NUM)

    for i in range(SIZE + 1):
        lx = BOARD_X + i * CELL
        ly = BOARD_Y + i * CELL
        d.line((lx, BOARD_Y, lx, BOARD_Y + BOARD_PX), fill=GRID_LINE, width=1)
        d.line((BOARD_X, ly, BOARD_X + BOARD_PX, ly), fill=GRID_LINE, width=1)

    # Vẽ đường kẻ nối tâm các ô thắng
    if win_set:
        pts = sorted(win_set)
        r0, c0 = pts[0]
        r1, c1 = pts[-1]
        x_start = BOARD_X + c0 * CELL + CELL // 2
        y_start = BOARD_Y + r0 * CELL + CELL // 2
        x_end   = BOARD_X + c1 * CELL + CELL // 2
        y_end   = BOARD_Y + r1 * CELL + CELL // 2
        d.line((x_start, y_start, x_end, y_end), fill=clr_win, width=6)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, "JPEG", quality=88)
    return out_path


def make_board_image(cells, out_dir="data/assets/cache/cards", **kwargs) -> str:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"caro_{uuid.uuid4().hex}.jpg")
    draw_caro_board(cells, path, **kwargs)
    return path