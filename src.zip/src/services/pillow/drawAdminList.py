import os, threading
import requests
from io import BytesIO
from pathlib import Path
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, PAD = 1536, 768, 48

# BG: teal/purple nhạt mờ kiểu Zing
BG_TL      = ( 32,  48,  72)
BG_TR      = ( 48,  36,  72)
BG_BL      = ( 22,  38,  60)
BG_BR      = ( 38,  26,  58)

GLASS_FILL = (255, 255, 255, 28)
C_TITLE    = (246, 248, 255, 255)
C_SUB      = (188, 196, 220, 255)
C_DIM      = (150, 158, 186, 255)

FONT_DIR = Path("assets/font")
_fcache: dict = {}


def _font(size, bold=False):
    key = (size, bold)
    if key in _fcache:
        return _fcache[key]
    candidates = (
        [FONT_DIR / "Goldman" / "Goldman-Bold.ttf",
         FONT_DIR / "Opensans" / "static" / "Opensans" / "OpenSans-Bold.ttf"]
        if bold else
        [FONT_DIR / "Opensans" / "static" / "Opensans" / "OpenSans-Regular.ttf"]
    )
    for p in candidates:
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


@lru_cache(maxsize=64)
def _round_mask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w, h), r, fill=255)
    return m


def _fit(d, text, font, max_w):
    text = str(text or "")
    if d.textlength(text, font=font) <= max_w:
        return text
    ell  = "..."
    room = max_w - d.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if d.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell


def _load_image(url, size):
    wd, hd = int(size[0]), int(size[1])
    blank  = Image.new("RGBA", (wd, hd), (24, 26, 34, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        return img.resize((wd, hd), Image.LANCZOS)
    except Exception:
        return blank


def _make_bg():
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), BG_TL)
    c.putpixel((1, 0), BG_TR)
    c.putpixel((0, 1), BG_BL)
    c.putpixel((1, 1), BG_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _glass(img, box, radius):
    x1, y1, x2, y2 = map(int, box)
    bw, bh = x2 - x1, y2 - y1
    blur   = 26

    sh_size = (bw + blur * 4, bh + blur * 4)
    sh_mask = Image.new("L", sh_size, 0)
    ImageDraw.Draw(sh_mask).rounded_rectangle(
        (blur*2, blur*2, blur*2+bw, blur*2+bh), radius, fill=255
    )
    sh_mask = sh_mask.filter(ImageFilter.GaussianBlur(blur))
    sh_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh_layer.paste(Image.new("RGBA", sh_size, (0, 0, 0, 90)),
                   (x1 - blur*2, y1 - blur*2 + 10), sh_mask)
    img.alpha_composite(sh_layer)

    blurred = img.crop((x1, y1, x2, y2)).filter(ImageFilter.GaussianBlur(24)).convert("RGBA")
    layer   = Image.alpha_composite(blurred, Image.new("RGBA", (bw, bh), GLASS_FILL))
    img.paste(layer, (x1, y1), _round_mask(bw, bh, radius))


def draw_admin_list(*, owner, admins, out_path,
                   title="Admins", sub_title="", source="Group",
                   items_per_page=10):
    owner  = owner or {}
    admins = [x for x in list(admins or []) if isinstance(x, dict)]

    # Bỏ owner khỏi admins list (tránh hiện 2 lần)
    owner_name = owner.get("name", "")
    admins = [a for a in admins if a.get("name") != owner_name or a.get("role") != owner.get("role")]

    img = _make_bg()
    _glass(img, (PAD, PAD, W - PAD, H - PAD), 44)

    left_w = 420
    gap    = 26
    inner  = 26
    lx1 = PAD + inner;  ly1 = PAD + inner
    lx2 = lx1 + left_w; ly2 = H - PAD - inner
    rx1 = lx2 + gap;    ry1 = ly1
    rx2 = W - PAD - inner; ry2 = ly2

    _glass(img, (lx1, ly1, lx2, ly2), 44)
    d = ImageDraw.Draw(img)

    big_thumb = 320
    thumb_x   = lx1 + (left_w - big_thumb) // 2
    thumb_y   = ly1 + 28

    av_owner = _load_image(
        owner.get("avatar") or owner.get("avatarUrl") or owner.get("thumb") or "",
        (big_thumb, big_thumb)
    )
    img.paste(av_owner, (thumb_x, thumb_y), _round_mask(big_thumb, big_thumb, 44))

    f_name_big = _font(40, bold=True)
    f_role_big = _font(26)

    tx = lx1 + 26
    ty = thumb_y + big_thumb + 22
    d.text((tx, ty),      _fit(d, owner.get("name", "Unknown"), f_name_big, left_w - 52), font=f_name_big, fill=C_TITLE)
    d.text((tx, ty + 52), _fit(d, owner.get("role", "Owner"),   f_role_big, left_w - 52), font=f_role_big, fill=C_SUB)

    f_badge = _font(26, bold=True)
    badge_text = "Admin Manager"
    bw_px = int(d.textlength(badge_text, font=f_badge) + 72)
    bh_px = 56
    bx1   = lx1 + (left_w - bw_px) // 2
    by1   = ly2 - 26 - bh_px
    _glass(img, (bx1, by1, bx1 + bw_px, by1 + bh_px), 28)
    d = ImageDraw.Draw(img)
    d.text((bx1 + 36, by1 + 14), badge_text, font=f_badge, fill=(255, 255, 255, 245))

    # Fetch admin avatars parallel
    items   = admins[:int(items_per_page or 10)]
    thumb_s = 76
    av_list = [None] * len(items)
    def _fetch(i, url):
        av_list[i] = _load_image(url, (thumb_s, thumb_s))
    threads = []
    for i, a in enumerate(items):
        url = a.get("avatar") or a.get("avatarUrl") or a.get("thumb") or ""
        t   = threading.Thread(target=_fetch, args=(i, url), daemon=True)
        threads.append(t); t.start()
    for t in threads:
        t.join(timeout=10)

    cols   = 2
    rows   = 5
    area_w = rx2 - rx1 - 36
    area_h = ry2 - ry1 - 36
    cgap   = 26
    rgap   = 18
    col_w  = (area_w - (cols - 1) * cgap) // cols
    row_h  = max(104, min((area_h - (rows - 1) * rgap) // rows, 126))
    thumb_mask = _round_mask(thumb_s, thumb_s, 22)

    f_row_name = _font(34, bold=True)
    f_row_meta = _font(22)
    f_idx      = _font(22)

    for i, a in enumerate(items):
        c  = i // rows
        r  = i  % rows
        x1 = rx1 + 18 + c * (col_w + cgap)
        y1 = ry1 + 18 + r * (row_h + rgap)
        x2 = x1 + col_w
        y2 = y1 + row_h

        _glass(img, (x1, y1, x2, y2), 26)
        d = ImageDraw.Draw(img)

        ix = x1 + 20
        iy = y1 + (row_h - thumb_s) // 2
        if av_list[i]:
            img.paste(av_list[i], (ix, iy), thumb_mask)

        tx2   = ix + thumb_s + 18
        max_w = x2 - tx2 - 20

        d.text((tx2, y1 + 18),      _fit(d, a.get("name", "Unknown"),                 f_row_name, max_w), font=f_row_name, fill=C_TITLE)
        d.text((tx2, y1 + 18 + 46), _fit(d, a.get("role") or a.get("uid") or "Admin", f_row_meta, max_w), font=f_row_meta, fill=C_SUB)

        idx_str = str(i + 1)
        iw = int(d.textlength(idx_str, font=f_idx))
        d.text((x2 - 16 - iw, y2 - 38), idx_str, font=f_idx, fill=C_DIM)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.save(out_path, "PNG")
    return out_path, W, H