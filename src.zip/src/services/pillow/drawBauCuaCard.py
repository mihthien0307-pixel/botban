"""
drawBauCuaCard.py  –  Vẽ ảnh kết quả bầu cua bằng Pillow
Đặt tại: src/services/pillow/drawBauCuaCard.py
"""
import os
import time
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

# ── Đường dẫn (relative từ cwd = thư mục gốc zbot) ───────────────────────────
FONT_DIR  = Path("assets/font")

# Hỗ trợ cả hai tên thư mục
_ASSET_DIR = None
for _c in ("baucua", "baucua_images"):
    _p = Path("assets") / _c
    if _p.is_dir():
        _ASSET_DIR = _p
        break
if _ASSET_DIR is None:
    _ASSET_DIR = Path("assets/baucua")

CACHE_DIR = Path("data/assets/cache/cards")

SYMBOL_ICON = {
    "bau": "bau.png", "cua": "cua.png", "tom": "tom.png",
    "ca":  "ca.png",  "ga":  "ga.png",  "nai": "nai.png",
}
LABEL_NAMES = {
    "bau": "Bau", "cua": "Cua", "tom": "Tom",
    "ca":  "Ca",  "ga":  "Ga",  "nai": "Nai",
}

# ── Font helper ───────────────────────────────────────────────────────────────
def _load_font(size, bold=False):
    candidates = []
    if bold:
        candidates += [
            FONT_DIR / "Sarabun" / "Sarabun-Bold.ttf",
            FONT_DIR / "Opensans" / "OpenSans-Bold.ttf",
        ]
    candidates += [
        FONT_DIR / "Sarabun" / "Sarabun-Regular.ttf",
        FONT_DIR / "Opensans" / "OpenSans-Regular.ttf",
        FONT_DIR / "delaone.ttf",
        FONT_DIR / "cool.ttf",
    ]
    for p in candidates:
        if p.exists():
            try:
                return ImageFont.truetype(str(p), size)
            except Exception:
                pass
    return ImageFont.load_default()

# ── Main ──────────────────────────────────────────────────────────────────────
def make_baucua_result_image(result):
    """result: list 3 key, vd ['bau','cua','tom']. Trả về path PNG."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    CELL_W  = 320
    CELL_H  = 320
    PAD     = 20
    TITLE_H = 58
    LABEL_H = 44
    BORDER  = 7

    W = CELL_W * 3 + PAD * 4
    H = TITLE_H + CELL_H + PAD * 2 + LABEL_H

    img  = Image.new("RGB", (W, H), (22, 22, 38))
    draw = ImageDraw.Draw(img)

    # Gradient nền
    for y in range(H):
        t = y / H
        draw.line([(0, y), (W, y)],
                  fill=(int(22+18*t), int(22+8*t), int(38+22*t)))

    font_title = _load_font(34, bold=True)
    font_label = _load_font(28, bold=True)

    # Tiêu đề
    title = "KET QUA BAU CUA"
    try:
        tw = int(draw.textlength(title, font=font_title))
    except Exception:
        tw = len(title) * 21
    draw.text(((W - tw) // 2, (TITLE_H - 34) // 2),
              title, font=font_title, fill=(255, 210, 0))

    for i, key in enumerate(result):
        x = PAD + i * (CELL_W + PAD)
        y = TITLE_H + PAD

        # Viền vàng
        draw.rounded_rectangle(
            [x, y, x + CELL_W, y + CELL_H],
            radius=20, outline=(255, 200, 0), width=BORDER,
        )

        # Ảnh icon
        icon_path = _ASSET_DIR / SYMBOL_ICON.get(key, "bau.png")
        if icon_path.exists():
            try:
                inner   = CELL_W - BORDER * 2 - 12
                px      = x + BORDER + 6
                py      = y + BORDER + 6
                raw     = Image.open(str(icon_path))
                resized = raw.resize((inner, inner), Image.LANCZOS)

                if resized.mode == "RGBA":
                    bg = Image.new("RGB", (inner, inner), (255, 255, 255))
                    bg.paste(resized, (0, 0), mask=resized.split()[3])
                    img.paste(bg, (px, py))
                elif resized.mode == "RGB":
                    img.paste(resized, (px, py))
                else:
                    img.paste(resized.convert("RGB"), (px, py))
            except Exception as e:
                print(f"[BauCua] icon error '{key}': {e}")

        # Label
        lbl = LABEL_NAMES.get(key, key.upper())
        try:
            lw = int(draw.textlength(lbl, font=font_label))
        except Exception:
            lw = len(lbl) * 18
        draw.text(
            (x + (CELL_W - lw) // 2, y + CELL_H + 6),
            lbl, font=font_label, fill=(190, 205, 255),
        )

    out = CACHE_DIR / f"baucua_{int(time.time()*1000)}.png"
    img.save(str(out), "PNG")
    return str(out)
