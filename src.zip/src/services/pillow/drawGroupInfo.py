"""
drawGroupInfo.py – Vẽ ảnh thông tin nhóm.
Style: dark navy gradient, group avatar, settings ON/OFF, admin grid trong card lớn.
QR code nhóm ở góc trên phải.
"""

import os, threading, math, re
import requests
from io import BytesIO
from pathlib import Path
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont

W   = 1100
PAD = 40

# ── Palette (dark navy – khớp ảnh mẫu) ──────────────────────────────────
BG_TOP     = (8, 12, 28)
BG_BOT     = (14, 20, 42)
CARD_FILL  = (255, 255, 255, 18)
CARD_EDGE  = (255, 255, 255, 32)
CELL_FILL  = (255, 255, 255, 14)
CELL_EDGE  = (255, 255, 255, 25)

C_WHITE    = (255, 255, 255)
C_DIM      = (150, 162, 192)
C_SECTION  = (190, 200, 225)
C_ON       = (255, 195, 0)      # vàng gold – ON
C_OFF      = (90, 105, 135)     # xám – OFF

# Fonts
_ROOT  = Path(__file__).resolve().parents[3]
_FD    = _ROOT / "assets" / "font"
_PATHS = {
    "bold":    [_FD/"Goldman"/"Goldman-Bold.ttf", _FD/"Sarabun"/"Sarabun-ExtraBold.ttf"],
    "semi":    [_FD/"Sarabun"/"Sarabun-ExtraBold.ttf"],
    "regular": [_FD/"Sarabun"/"Sarabun-Regular.ttf"],
}
_fc: dict = {}

def _f(size, style="regular"):
    k = (size, style)
    if k in _fc: return _fc[k]
    for p in _PATHS.get(style, _PATHS["regular"]):
        if Path(p).exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fc[k] = f; return f
            except: pass
    f = ImageFont.load_default(); _fc[k] = f; return f

def _tw(d, t, f):
    bb = d.textbbox((0,0), t, font=f); return bb[2]-bb[0]
def _th(d, t, f):
    bb = d.textbbox((0,0), t, font=f); return bb[3]-bb[1]
def _fit(d, t, f, mw):
    while len(t)>1 and _tw(d, t+"…", f)>mw: t=t[:-1]
    return t if _tw(d, t, f)<=mw else t+"…"

@lru_cache(maxsize=32)
def _circle(sz):
    m = Image.new("L",(sz,sz),0)
    ImageDraw.Draw(m).ellipse((0,0,sz-1,sz-1), fill=255)
    return m

@lru_cache(maxsize=32)
def _rrect_mask(w, h, r):
    m = Image.new("L",(w,h),0)
    ImageDraw.Draw(m).rounded_rectangle((0,0,w-1,h-1), radius=r, fill=255)
    return m

def _fetch(url, size):
    if not url: return None
    try:
        r = requests.get(url, timeout=7)
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        return img.resize((size,size), Image.LANCZOS)
    except: return None

def _placeholder(size, label="?"):
    img = Image.new("RGBA",(size,size),(42,50,72,255))
    d   = ImageDraw.Draw(img)
    f   = _f(size//3, "semi")
    ch  = label[:1].upper()
    tw  = _tw(d,ch,f); th = _th(d,ch,f)
    d.text(((size-tw)//2,(size-th)//2), ch, font=f, fill=(180,192,225,255))
    return img

def _draw_card(img, x1, y1, x2, y2, r=16, fill=None, edge=None):
    ov = Image.new("RGBA", img.size, (0,0,0,0))
    ImageDraw.Draw(ov).rounded_rectangle(
        (x1,y1,x2,y2), radius=r,
        fill=fill or CARD_FILL,
        outline=edge or CARD_EDGE,
        width=1
    )
    img.alpha_composite(ov)

def _clean_url(url):
    if not url: return ""
    url = re.sub(r'[?&][whs]=\d+', '', url)
    url = re.sub(r'[?&]size=\d+', '', url)
    url = re.sub(r'/w\d+/', '/w2048/', url)
    return url.rstrip('?&')

def _gradient_bg(W, H):
    from PIL import ImageFilter
    # Nền navy đậm
    img = Image.new("RGBA", (W, H), (8, 10, 26, 255))

    # Lớp glow 1: xanh cyan mạnh – góc trên trái
    g1 = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d1 = ImageDraw.Draw(g1)
    cx1, cy1, r1 = int(W * 0.15), int(H * 0.25), 350
    for i in range(r1, 0, -2):
        a = int(110 * (i / r1) ** 1.5)
        d1.ellipse((cx1-i, cy1-i, cx1+i, cy1+i), fill=(0, 180, 255, a))
    g1 = g1.filter(ImageFilter.GaussianBlur(80))
    img = Image.alpha_composite(img, g1)

    # Lớp glow 2: hồng/tím – góc dưới phải
    g2 = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d2 = ImageDraw.Draw(g2)
    cx2, cy2, r2 = int(W * 0.88), int(H * 0.72), 300
    for i in range(r2, 0, -2):
        a = int(100 * (i / r2) ** 1.5)
        d2.ellipse((cx2-i, cy2-i, cx2+i, cy2+i), fill=(200, 50, 220, a))
    g2 = g2.filter(ImageFilter.GaussianBlur(70))
    img = Image.alpha_composite(img, g2)

    return img

def _fetch_qr(qr_url: str, size: int, avatar_url: str = "") -> Image.Image | None:
    url_to_encode = qr_url if qr_url else "https://zalo.me"
    try:
        import qrcode as _qr
        qr = _qr.QRCode(
            error_correction=_qr.constants.ERROR_CORRECT_H,
            box_size=8, border=2
        )
        qr.add_data(url_to_encode)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color=(10, 10, 20), back_color=(255, 255, 255)).convert("RGBA")
        return qr_img.resize((size, size), Image.LANCZOS)
    except Exception:
        return None

def _draw_qr(img: Image.Image, qr_img: Image.Image, size: int, pad: int):
    """Dán QR vào góc trên phải với viền trắng bo tròn."""
    W_img  = img.width
    QR_PAD = 8
    border_sz = size + QR_PAD * 2

    ov  = Image.new("RGBA", img.size, (0,0,0,0))
    bx1 = W_img - pad - border_sz
    by1 = pad
    ImageDraw.Draw(ov).rounded_rectangle(
        (bx1, by1, bx1+border_sz, by1+border_sz),
        radius=12,
        fill=(255,255,255,230),
    )
    img.alpha_composite(ov)

    qr_x = bx1 + QR_PAD
    qr_y = by1 + QR_PAD
    mask = _rrect_mask(size, size, 6)
    img.paste(qr_img, (qr_x, qr_y), mask)

# ═══════════════════════════════════════════════════════════════════════════
def draw_group_info(
    group_name: str,
    member_count: int,
    group_avatar_url: str,
    settings: dict,
    admins: list,
    out_path: str,
    qr_url: str = "",
) -> tuple:

    COLS      = 4
    CGAP      = 10
    CELL_H    = 76
    ADM_AV    = 48
    GRP_AV_SZ = 120
    QR_SZ     = 130

    inner_w = W - PAD*2
    CELL_W  = (inner_w - (COLS-1)*CGAP) // COLS

    n_rows = math.ceil(len(admins)/COLS) if admins else 0

    HDR_H      = 270
    STG_H      = 186
    ADM_HDR_H  = 50
    RGAP       = 10
    ADM_GRID_H = n_rows*(CELL_H+RGAP)-RGAP if n_rows else 0
    ADM_CARD_PAD = 16
    ADM_CARD_H = ADM_HDR_H + ADM_CARD_PAD + ADM_GRID_H + ADM_CARD_PAD if admins else 0

    H = PAD + HDR_H + PAD + STG_H + PAD + ADM_CARD_H + PAD*2

    img = _gradient_bg(W, H)

    # ── Fetch avatars + QR parallel ────────────────────────────────────────
    grp_av = [None]
    adm_av = [None]*len(admins)
    qr_res = [None]

    def _fg(): grp_av[0] = _fetch(_clean_url(group_avatar_url), GRP_AV_SZ) or _placeholder(GRP_AV_SZ, group_name)
    def _fa(i,u,n): adm_av[i] = _fetch(_clean_url(u), ADM_AV) or _placeholder(ADM_AV, n)
    def _fq(): qr_res[0] = _fetch_qr(qr_url, QR_SZ, _clean_url(group_avatar_url))

    ts = [
        threading.Thread(target=_fg, daemon=True),
        threading.Thread(target=_fq, daemon=True),
    ]
    for i,a in enumerate(admins):
        ts.append(threading.Thread(target=_fa, args=(i, a.get("avatar",""), a.get("name","?")), daemon=True))
    for t in ts: t.start()
    for t in ts: t.join(timeout=20)

    # ── QR code – góc trên phải (vẽ trước header) ───────────────────────────
    if qr_res[0]:
        _draw_qr(img, qr_res[0], QR_SZ, PAD)

    d = ImageDraw.Draw(img)

    # ── HEADER: avatar + tên + members ────────────────────────────────────
    av_y = PAD + 10
    av_x = (W - GRP_AV_SZ) // 2

    BORD   = 5
    ring_sz = GRP_AV_SZ + BORD*2
    ring   = Image.new("RGBA",(ring_sz,ring_sz),(255,255,255,60))
    img.paste(ring, (av_x-BORD, av_y-BORD), _circle(ring_sz))
    img.paste(grp_av[0], (av_x, av_y), _circle(GRP_AV_SZ))

    f_gn = _f(30, "bold")
    gn   = _fit(d, group_name, f_gn, W-PAD*4)
    gnw  = _tw(d, gn, f_gn)
    gnh  = _th(d, gn, f_gn)
    d.text(((W-gnw)//2, av_y+GRP_AV_SZ+18), gn, font=f_gn, fill=C_WHITE)

    f_mc  = _f(20, "regular")
    mtxt  = f"{member_count} members"
    mw    = _tw(d, mtxt, f_mc)
    mh    = _th(d, mtxt, f_mc)
    my    = av_y + GRP_AV_SZ + 18 + gnh + 14
    mx    = (W - mw) // 2
    bpad  = 14
    _draw_card(img, mx-bpad, my-6, mx+mw+bpad, my+mh+6, r=12)
    d = ImageDraw.Draw(img)
    d.text((mx, my), mtxt, font=f_mc, fill=C_DIM)

    # ── SETTINGS CARD ─────────────────────────────────────────────────────
    sy  = PAD + HDR_H
    sx1 = PAD; sx2 = W-PAD
    _draw_card(img, sx1, sy, sx2, sy+STG_H, r=18)
    d = ImageDraw.Draw(img)

    f_st = _f(19, "semi")
    stxt = "SETTINGS"
    stw  = _tw(d, stxt, f_st)
    d.text(((W-stw)//2, sy+14), stxt, font=f_st, fill=C_SECTION)

    # Settings – 3 cột x 3 hàng, khớp ảnh mẫu
    SETTING_LABELS = [
        ("lockSendMsg",      "Lock Chat"),
        ("enableMsgHistory", "Approval"),
        ("addMemberOnly",    "Admin Add"),
        ("blockName",        "Admin Topic"),
        ("blockName",        "Lock Name"),
        ("lockCreatePost",   "Lock Post"),
        ("lockCreatePoll",   "Lock Poll"),
        ("lockViewMember",   "Lock Member"),
        ("signAdminMsg",     "Sign Admin"),
    ]

    f_sv  = _f(19, "semi")
    f_sl  = _f(19, "semi")
    SCOLS = 3
    srows = math.ceil(len(SETTING_LABELS)/SCOLS)
    scol_w = (sx2-sx1) // SCOLS
    srow_h = (STG_H-48) // srows

    for idx,(key,label) in enumerate(SETTING_LABELS):
        sc = idx%SCOLS; sr = idx//SCOLS
        try: is_on = int(settings.get(key,0)) != 0
        except: is_on = bool(settings.get(key, False))
        on_txt = "ON" if is_on else "OFF"
        on_col = C_ON if is_on else C_OFF

        cx  = sx1 + sc*scol_w + scol_w//2
        cy3 = sy + 48 + sr*srow_h

        otw = _tw(d, on_txt, f_sv)
        ltw = _tw(d, label,  f_sl)
        tot = otw + 6 + ltw
        lx  = cx - tot//2

        d.text((lx,       cy3), on_txt, font=f_sv, fill=on_col)
        d.text((lx+otw+6, cy3), label,  font=f_sl, fill=C_WHITE)

    # ── ADMINS — 1 card lớn bọc toàn bộ ──────────────────────────────────
    ady = sy + STG_H + PAD

    if admins:
        adm_card_x1 = PAD
        adm_card_y1 = ady
        adm_card_x2 = W-PAD
        adm_card_y2 = ady + ADM_CARD_H
        _draw_card(img, adm_card_x1, adm_card_y1, adm_card_x2, adm_card_y2, r=18)
        d = ImageDraw.Draw(img)

        f_at = _f(19, "semi")
        atxt = f"OWNER & ADMINS ({len(admins)})"
        atw  = _tw(d, atxt, f_at)
        d.text(((W-atw)//2, ady+14), atxt, font=f_at, fill=C_SECTION)

        f_an = _f(19, "semi")
        f_ar = _f(15, "regular")

        grid_x0 = PAD + ADM_CARD_PAD
        grid_y0 = ady + ADM_HDR_H + ADM_CARD_PAD
        grid_w  = W - PAD*2 - ADM_CARD_PAD*2
        CELL_W2 = (grid_w - (COLS-1)*CGAP) // COLS

        for i,a in enumerate(admins):
            col = i%COLS; row = i//COLS
            cx3 = grid_x0 + col*(CELL_W2+CGAP)
            cy3 = grid_y0 + row*(CELL_H+RGAP)

            _draw_card(img, cx3, cy3, cx3+CELL_W2, cy3+CELL_H, r=12,
                       fill=CELL_FILL, edge=CELL_EDGE)
            d = ImageDraw.Draw(img)

            avx = cx3 + 12
            avy = cy3 + (CELL_H-ADM_AV)//2
            if adm_av[i]:
                img.paste(adm_av[i], (avx,avy), _circle(ADM_AV))

            tx   = avx + ADM_AV + 12
            maxw = CELL_W2 - ADM_AV - 30
            nm   = _fit(d, a.get("name","Unknown"), f_an, maxw)
            rl   = a.get("role","")
            nnh  = _th(d, nm, f_an)
            nrh  = _th(d, rl, f_ar) if rl else 0
            toth = nnh + (6+nrh if rl else 0)
            ty3  = cy3 + (CELL_H-toth)//2

            d.text((tx, ty3),       nm, font=f_an, fill=C_WHITE)
            if rl:
                d.text((tx, ty3+nnh+6), rl, font=f_ar, fill=C_DIM)

    # ── Save ──────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, "PNG")
    return out_path, W, H
