from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, time, random
try:
    from fontTools.ttLib import TTFont as _TTFont
    _HAS_FONTTOOLS = True
except ImportError:
    _HAS_FONTTOOLS = False

W, H   = 1686, 861
PAD    = 40
RADIUS = 28
FONT_DIR = Path("assets/font")
_glyph_cache: dict[str, set] = {} 

def _get_cmap(path: str) -> set:
    if path in _glyph_cache:
        return _glyph_cache[path]
    if not _HAS_FONTTOOLS:
        _glyph_cache[path] = set()
        return _glyph_cache[path]
    try:
        tt = _TTFont(path, fontNumber=0)
        cmap = set()
        for table in tt['cmap'].tables:
            cmap.update(table.cmap.keys())
        _glyph_cache[path] = cmap
    except Exception:
        _glyph_cache[path] = set()
    return _glyph_cache[path]

def _font_covers(path: str, text: str) -> bool:
    if not _HAS_FONTTOOLS:
        return True
    cmap = _get_cmap(path)
    if not cmap:
        return True  
    for ch in text:
        cp = ord(ch)
        if cp > 0x20 and cp not in cmap: 
            return False
    return True

def _candidates(bold: bool) -> list[Path]:
    names_bold   = ["Sarabun-Bold.ttf",    "NotoSans-Bold.ttf",   "DejaVuSans-Bold.ttf"]
    names_normal = ["Sarabun-Regular.ttf", "NotoSans-Regular.ttf","DejaVuSans.ttf"]
    names = names_bold if bold else names_normal

    dirs = [
        FONT_DIR / "Sarabun",
        FONT_DIR / "NotoSans",
        FONT_DIR / "DejaVu",
        FONT_DIR,
        Path("/usr/share/fonts/truetype/dejavu"),
        Path("/usr/share/fonts/truetype/noto"),
    ]
    out = []
    for name in names:
        for base in dirs:
            p = base / name
            if p.exists():
                out.append(p)
    return out

def _font(sz: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    for p in _candidates(bold):
        try:
            return ImageFont.truetype(str(p), sz)
        except Exception:
            pass
    return ImageFont.load_default()

def _font_for(sz: int, text: str, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = _candidates(bold)

    for p in candidates:
        if _font_covers(str(p), text):
            try:
                return ImageFont.truetype(str(p), sz)
            except Exception:
                pass

    noto_name = "NotoSans-Bold.ttf" if bold else "NotoSans-Regular.ttf"
    for base in (FONT_DIR / "NotoSans",
                 Path("/usr/share/fonts/truetype/noto")):
        p = base / noto_name
        if p.exists():
            try:
                return ImageFont.truetype(str(p), sz)
            except Exception:
                pass

    for p in candidates:
        try:
            return ImageFont.truetype(str(p), sz)
        except Exception:
            pass

    return ImageFont.load_default()

def _font_display(sz: int, text: str = "") -> ImageFont.FreeTypeFont:
    display_paths = [
        FONT_DIR / "Goldman" / "Goldman-Bold.ttf",
        FONT_DIR / "Sarabun" / "Sarabun-ExtraBold.ttf",
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ]
    for p in display_paths:
        if p.exists():
            if not text or _font_covers(str(p), text):
                try:
                    return ImageFont.truetype(str(p), sz)
                except Exception:
                    pass

    return _font_for(sz, text, bold=True)

def _rrect(base, box, r, fill=None, outline=None, outline_w=1):
    x1, y1, x2, y2 = box
    w, h = x2-x1, y2-y1
    if w <= 0 or h <= 0: return
    layer = Image.new("RGBA", (w, h), (0,0,0,0))
    d = ImageDraw.Draw(layer)
    if fill:    d.rounded_rectangle((0, 0, w-1, h-1), r, fill=fill)
    if outline: d.rounded_rectangle((0, 0, w-1, h-1), r, outline=outline, width=outline_w)
    base.alpha_composite(layer, (x1, y1))

def _rect(base, box, fill):
    x1, y1, x2, y2 = box
    w, h = x2-x1, y2-y1
    if w <= 0 or h <= 0: return
    base.alpha_composite(Image.new("RGBA", (w, h), fill), (x1, y1))

def _fit(d, text, font, maxw):
    text = str(text)
    if d.textlength(text, font=font) <= maxw: return text
    ell = "…"
    mw2 = maxw - d.textlength(ell, font=font)
    out = ""
    for ch in text:
        if d.textlength(out+ch, font=font) <= mw2: out += ch
        else: break
    return out + ell

def _wrap(d, text, font, maxw, maxlines=5):
    words = str(text or "").split()
    lines, cur = [], ""
    for word in words:
        test = (cur+" "+word).strip()
        if d.textlength(test, font=font) <= maxw: cur = test
        else:
            if cur: lines.append(cur)
            cur = word
            if len(lines) >= maxlines: break
    if cur and len(lines) < maxlines: lines.append(cur)
    if lines: lines[-1] = _fit(d, lines[-1], font, maxw)
    return lines

def _make_bg(w, h, seed=7):
    rng = random.Random(seed)
    img = Image.new("RGBA", (w, h), (72, 48, 100, 255))
    blobs = [
        (0.15, 0.3,  0.45, 0.6,  (110, 65, 140), 150),
        (0.85, 0.7,  0.40, 0.55, (140, 65, 110), 140),
        (0.5,  0.5,  0.35, 0.45, (85,  55, 120), 110),
        (0.1,  0.85, 0.30, 0.40, (160, 75, 125), 100),
        (0.9,  0.1,  0.28, 0.35, (95,  55, 150),  90),
    ]
    for cx_f, cy_f, rx_f, ry_f, col, alpha in blobs:
        cx = int(cx_f * w) + rng.randint(-15, 15)
        cy = int(cy_f * h) + rng.randint(-10, 10)
        rx, ry = int(rx_f * w), int(ry_f * h)
        blob = Image.new("RGBA", (w, h), (0,0,0,0))
        ImageDraw.Draw(blob).ellipse((cx-rx, cy-ry, cx+rx, cy+ry), fill=(*col, alpha))
        img.alpha_composite(blob.filter(ImageFilter.GaussianBlur(rng.randint(50, 80))))
    grain = Image.new("RGBA", (w, h), (0,0,0,0))
    rng2 = random.Random(55)
    for _ in range(12000):
        gx, gy = rng2.randint(0, w-1), rng2.randint(0, h-1)
        grain.putpixel((gx, gy), (255, 255, 255, rng2.randint(1, 5)))
    img.alpha_composite(grain)
    return img

def _make_avatar_rect(raw_img, max_w, max_h, r=20):
    iw, ih = raw_img.size
    ratio  = min(max_w / iw, max_h / ih)
    nw, nh = int(iw * ratio), int(ih * ratio)
    av = raw_img.convert("RGBA").resize((nw, nh), Image.LANCZOS)
    mask = Image.new("L", (nw, nh), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, nw-1, nh-1), r, fill=255)
    out = Image.new("RGBA", (nw, nh), (0,0,0,0))
    out.paste(av, mask=mask)
    return out, nw, nh

def _custom_rrect(base, box, r,
                  tl=True, tr=True, bl=True, br=True,
                  fill=None, outline=None, outline_w=1):
    x1, y1, x2, y2 = box
    bw, bh = x2-x1, y2-y1
    if bw <= 0 or bh <= 0: return

    layer = Image.new("RGBA", (bw, bh), (0,0,0,0))
    ld    = ImageDraw.Draw(layer)

    col = fill or (0,0,0,0)

    if fill:
        ld.rounded_rectangle((0, 0, bw-1, bh-1), r, fill=col)
        if not tl: ld.rectangle((0,      0,      r, r),       fill=col)
        if not tr: ld.rectangle((bw-1-r, 0,      bw-1, r),    fill=col)
        if not bl: ld.rectangle((0,      bh-1-r, r, bh-1),    fill=col)
        if not br: ld.rectangle((bw-1-r, bh-1-r, bw-1, bh-1), fill=col)

    if outline:
        lw = outline_w
        c  = outline
        tx1 = r if tl else 0
        tx2 = bw-1-r if tr else bw-1
        ld.line([(tx1, 0), (tx2, 0)], fill=c, width=lw)
        bx1 = r if bl else 0
        bx2 = bw-1-r if br else bw-1
        ld.line([(bx1, bh-1), (bx2, bh-1)], fill=c, width=lw)
        ly1 = r if tl else 0
        ly2 = bh-1-r if bl else bh-1
        ld.line([(0, ly1), (0, ly2)], fill=c, width=lw)
        ry1 = r if tr else 0
        ry2 = bh-1-r if br else bh-1
        ld.line([(bw-1, ry1), (bw-1, ry2)], fill=c, width=lw)
        if tl: ld.arc((0, 0, r*2, r*2), 180, 270, fill=c, width=lw)
        if tr: ld.arc((bw-1-r*2, 0, bw-1, r*2), 270, 360, fill=c, width=lw)
        if bl: ld.arc((0, bh-1-r*2, r*2, bh-1), 90, 180, fill=c, width=lw)
        if br: ld.arc((bw-1-r*2, bh-1-r*2, bw-1, bh-1), 0, 90, fill=c, width=lw)

    base.alpha_composite(layer, (x1, y1))

def _draw_info_grid(img, fields, x, y, w, h, outer_r=20, gap=4):
    ROWS, COLS = 5, 2
    label_f = _font(16)
    value_f = _font(28, True)
    d = ImageDraw.Draw(img, "RGBA")

    cell_w = (w - gap*(COLS-1)) // COLS
    cell_h = (h - gap*(ROWS-1)) // ROWS

    CELL_BG = (38, 32, 52, 100)

    for i, (label, value) in enumerate(fields):
        col = i % COLS
        row = i // COLS
        cx  = x + col*(cell_w+gap)
        cy  = y + row*(cell_h+gap)
        cw, ch = cell_w, cell_h

        is_top    = (row == 0)
        is_bottom = (row == ROWS-1)
        is_left   = (col == 0)
        is_right  = (col == COLS-1)

        layer = Image.new("RGBA", (cw, ch), (0,0,0,0))
        ld    = ImageDraw.Draw(layer)
        ld.rounded_rectangle((0, 0, cw-1, ch-1), outer_r, fill=CELL_BG)
        sq = CELL_BG
        if not (is_top    and is_left):  ld.rectangle((0,       0,        outer_r,   outer_r),   fill=sq)
        if not (is_top    and is_right): ld.rectangle((cw-1-outer_r, 0,   cw-1,      outer_r),   fill=sq)
        if not (is_bottom and is_left):  ld.rectangle((0,       ch-1-outer_r, outer_r, ch-1),    fill=sq)
        if not (is_bottom and is_right): ld.rectangle((cw-1-outer_r, ch-1-outer_r, cw-1, ch-1), fill=sq)
        img.alpha_composite(layer, (cx, cy))

        lf = _font_for(16, label)
        d.text((cx+16, cy+12), label, font=lf, fill=(145, 140, 165, 255))
        vf  = _font_for(28, str(value), bold=True)
        val = _fit(d, value, vf, cw-28)
        d.text((cx+16, cy+32), val, font=vf, fill=(242, 240, 250, 255))

    _rrect(img, (x, y, x+w, y+h), outer_r, outline=(255,255,255,20), outline_w=1)

def _draw_info_grid_with_header(img, name, subtitle, fields, x, y, w, h, outer_r=20, gap=4):
    ROWS      = 6       
    COLS      = 2
    label_f   = _font(15)
    value_f   = _font(26, True)
    sub_f     = _font(26)
    d         = ImageDraw.Draw(img, "RGBA")

    cell_h = (h - gap*(ROWS-1)) // ROWS
    cell_w = (w - gap*(COLS-1)) // COLS

    CELL_BG  = (38, 32, 52, 100)
    HEAD_BG  = (30, 25, 44,  90)

    hx = x
    hy = y
    hw = w
    hh = cell_h

    hlayer = Image.new("RGBA", (hw, hh), (0,0,0,0))
    hld    = ImageDraw.Draw(hlayer)
    hld.rounded_rectangle((0, 0, hw-1, hh-1), outer_r, fill=HEAD_BG)
    hld.rectangle((0,      hh-1-outer_r, outer_r,   hh-1), fill=HEAD_BG)
    hld.rectangle((hw-1-outer_r, hh-1-outer_r, hw-1, hh-1), fill=HEAD_BG)
    img.alpha_composite(hlayer, (hx, hy))
    name_f    = _font_display(58, name)
    name_y_off = hh // 2 - 48
    d.text((hx+20+2, hy+name_y_off+2), name, font=name_f, fill=(0,0,0,60))
    d.text((hx+20,   hy+name_y_off),   name, font=name_f, fill=(255,255,255,255))

    sub_ff = _font_for(26, subtitle)
    sub_y_off = name_y_off + 66
    d.text((hx+22, hy+sub_y_off), subtitle, font=sub_ff, fill=(150,145,172,200))

    _rect(img, (hx+20, hy+hh-2, hx+hw-20, hy+hh-1), (255,255,255,18))

    for i, (label, value) in enumerate(fields):
        col = i % COLS
        row = (i // COLS) + 1  
        cx = x + col*(cell_w+gap)
        cy = y + row*(cell_h+gap)
        cw, ch = cell_w, cell_h
        is_bottom = (row == ROWS-1)
        is_left   = (col == 0)
        is_right  = (col == COLS-1)
        layer = Image.new("RGBA", (cw, ch), (0,0,0,0))
        ld    = ImageDraw.Draw(layer)
        ld.rounded_rectangle((0, 0, cw-1, ch-1), outer_r, fill=CELL_BG)
        sq = CELL_BG
        ld.rectangle((0,            0, outer_r,         outer_r), fill=sq)
        ld.rectangle((cw-1-outer_r, 0, cw-1,            outer_r), fill=sq)
        if not (is_bottom and is_left):  ld.rectangle((0,            ch-1-outer_r, outer_r,   ch-1), fill=sq)
        if not (is_bottom and is_right): ld.rectangle((cw-1-outer_r, ch-1-outer_r, cw-1,      ch-1), fill=sq)
        img.alpha_composite(layer, (cx, cy))
        lf = _font_for(15, label)
        d.text((cx+14, cy+10), label, font=lf, fill=(145,140,165,255))
        vf  = _font_for(26, str(value), bold=True)
        val = _fit(d, value, vf, cw-24)
        d.text((cx+14, cy+28), val, font=vf, fill=(242,240,250,255))
    _rrect(img, (x, y, x+w, y+h), outer_r, outline=(255,255,255,20), outline_w=1)

def draw_user_info(profile: dict, out_path: str, bg_seed: int | None = None):
    img = _make_bg(W, H, seed=bg_seed if bg_seed is not None else random.randint(0,999))
    d   = ImageDraw.Draw(img, "RGBA")

    CARD_X1, CARD_Y1 = PAD, PAD
    CARD_X2, CARD_Y2 = W-PAD, H-PAD

    _rrect(img, (CARD_X1, CARD_Y1, CARD_X2, CARD_Y2), RADIUS,
           fill=(28, 24, 38, 120))
    _rrect(img, (CARD_X1, CARD_Y1, CARD_X2, CARD_Y2), RADIUS,
           outline=(255,255,255,25), outline_w=1)

    LP_W  = 470
    LP_X1 = CARD_X1
    LP_X2 = CARD_X1 + LP_W
    LP_Y1 = CARD_Y1
    LP_Y2 = CARD_Y2
    LP_H  = LP_Y2 - LP_Y1

    lp_layer = Image.new("RGBA", (LP_W, LP_H), (0,0,0,0))
    ld = ImageDraw.Draw(lp_layer)
    ld.rounded_rectangle((0, 0, LP_W-1, LP_H-1), RADIUS, fill=(32, 27, 45, 110))
    ld.rectangle((LP_W-1-RADIUS, 0,      LP_W-1, RADIUS),          fill=(32, 27, 45, 110))
    ld.rectangle((LP_W-1-RADIUS, LP_H-1-RADIUS, LP_W-1, LP_H-1),   fill=(32, 27, 45, 110))
    img.alpha_composite(lp_layer, (LP_X1, LP_Y1))

    _rect(img, (LP_X2-1, LP_Y1+RADIUS, LP_X2, LP_Y2-RADIUS), (255,255,255,10))

    badge_f   = _font(15, True)
    BADGE_H   = 28
    BADGE_GAP = 10
    cap_font  = _font(19)
    LINE_H    = 27
    CAP_MARGIN = 14

    status_text = str(profile.get("status","") or "")

    AV_PAD   = 16
    AV_SIZE  = LP_W - AV_PAD * 2
    AX = LP_X1 + AV_PAD
    AY = LP_Y1 + AV_PAD

    avatar_url = profile.get("avatar", "")
    av_placed  = False
    actual_av_h = AV_SIZE

    if avatar_url:
        try:
            resp = requests.get(avatar_url, timeout=8, headers={"User-Agent":"Mozilla/5.0"})
            raw  = Image.open(BytesIO(resp.content))
            av_img, av_w, av_h = _make_avatar_rect(raw, AV_SIZE, AV_SIZE, r=18)
            ax_off = AX + (AV_SIZE - av_w) // 2
            img.alpha_composite(av_img, (ax_off, AY))
            actual_av_h = av_h
            av_placed = True
        except Exception:
            pass

    if not av_placed:
        ph = Image.new("RGBA", (AV_SIZE, AV_SIZE), (0,0,0,0))
        dph = ImageDraw.Draw(ph)
        dph.rounded_rectangle((0, 0, AV_SIZE-1, AV_SIZE-1), 18, fill=(55,48,72,255))
        dph.text((AV_SIZE//2, AV_SIZE//2), "?", font=_font(90, True),
                 fill=(160,155,185,180), anchor="mm")
        img.alpha_composite(ph, (AX, AY))

    plats = ["MOBILE", "WEB", "PC"]
    active_set = set()
    if profile.get("isActive"):    active_set.add("MOBILE")
    if profile.get("isActiveWeb"): active_set.add("WEB")
    if profile.get("isActivePC"):  active_set.add("PC")

    badge_y = AY + actual_av_h + 12

    total_bw = sum(int(d.textlength(p, font=badge_f))+30 for p in plats)
    total_bw += (len(plats)-1)*BADGE_GAP
    bx = LP_X1 + (LP_W - total_bw) // 2

    for pname in plats:
        fw = int(d.textlength(pname, font=badge_f)) + 30
        is_act = pname in active_set
        fc = (65, 60, 88, 200) if is_act else (48, 43, 65, 170)
        tc = (240, 238, 255, 255) if is_act else (185, 180, 210, 230)
        _rrect(img, (bx, badge_y, bx+fw, badge_y+BADGE_H), BADGE_H//2, fill=fc)
        _rrect(img, (bx, badge_y, bx+fw, badge_y+BADGE_H), BADGE_H//2,
               outline=(255,255,255,28), outline_w=1)
        d.text((bx+fw//2, badge_y+BADGE_H//2), pname, font=badge_f, fill=tc, anchor="mm")
        bx += fw + BADGE_GAP

    CAP_X1    = LP_X1 + CAP_MARGIN
    CAP_X2    = LP_X2 - CAP_MARGIN
    cap_top   = badge_y + BADGE_H + 10
    cap_iw    = CAP_X2 - CAP_X1 - 24
    avail_h   = LP_Y2 - cap_top - CAP_MARGIN
    max_lines = max(1, min(20, (avail_h - 16) // LINE_H))
    CAP_R     = 14

    display_text = status_text if status_text else "No description provided."
    no_desc      = not status_text

    cap_font_status = _font_for(19, display_text)
    lines   = _wrap(d, display_text, cap_font_status, cap_iw, max_lines)
    block_h = len(lines) * LINE_H
    cap_h   = avail_h
    CAP_Y2  = cap_top + cap_h
    _custom_rrect(img, (CAP_X1, cap_top, CAP_X2, CAP_Y2),
                  CAP_R, tl=True, tr=True, bl=True, br=False,
                  fill=(20, 16, 32, 110))
    _custom_rrect(img, (CAP_X1, cap_top, CAP_X2, CAP_Y2),
                  CAP_R, tl=True, tr=True, bl=True, br=False,
                  outline=(255,255,255,22), outline_w=1)

    txt_col = (130, 125, 155, 180) if no_desc else (205, 200, 225, 215)
    ty = cap_top + max(10, (cap_h - block_h) // 2)
    for ln in lines:
        lw = d.textlength(ln, font=cap_font_status)
        tx = CAP_X1 + (cap_iw - lw) // 2 + 12
        d.text((tx, ty), ln, font=cap_font_status, fill=txt_col)
        ty += LINE_H

    RP_X1  = LP_X2 + 10
    RP_Y1  = CARD_Y1
    RP_X2  = CARD_X2
    RP_Y2  = CARD_Y2
    RP_R   = 28

    rp_layer = Image.new("RGBA", (RP_X2-RP_X1, RP_Y2-RP_Y1), (0,0,0,0))
    rld = ImageDraw.Draw(rp_layer)
    rld.rounded_rectangle((0, 0, RP_X2-RP_X1-1, RP_Y2-RP_Y1-1), RP_R,
                           fill=(22, 18, 34, 100))
    rld.rectangle((0, 0, RP_R, RP_R), fill=(22, 18, 34, 100))
    rld.rectangle((0, RP_Y2-RP_Y1-1-RP_R, RP_R, RP_Y2-RP_Y1-1), fill=(22, 18, 34, 100))
    img.alpha_composite(rp_layer, (RP_X1, RP_Y1))
    _rrect(img, (RP_X1, RP_Y1, RP_X2, RP_Y2), RP_R,
           outline=(255,255,255,18), outline_w=1)

    RW  = RP_X2 - RP_X1
    INN = 22
    gender_map = {0: "Nam", 1: "Nữ", 2: "Khác"}
    last_ts = profile.get("lastActionTime", 0)
    if last_ts:
        diff = int(time.time()) - last_ts // 1000
        if   diff <    120: act = "Vừa Mới Truy Cập"
        elif diff <   3600: act = f"{diff//60} phút trước"
        elif diff <  86400: act = f"{diff//3600} giờ trước"
        else:               act = f"{diff//86400} ngày trước"
    else:
        act = "Không rõ"

    biz     = profile.get("bizPkg") or {}
    biz_lbl = (biz.get("label") or {}).get("VI","") or "Kinh Doanh"
    created = profile.get("createdTs", 0)
    ct_str  = (time.strftime("%H:%M:%S %d/%m/%Y", time.localtime(created))
               if created else "N/A")

    name = profile.get("displayName") or profile.get("zaloName") or "Unknown"

    fields = [
        ("ID Tài Khoản",      str(profile.get("userId",      "N/A"))),
        ("USERNAME",           str(profile.get("username",    "N/A"))),
        ("Giới Tính",          gender_map.get(profile.get("gender"), "N/A")),
        ("Loại Tài Khoản",     biz_lbl),
        ("Hoạt Động",          act),
        ("Số Điện Thoại",      str(profile.get("phoneNumber","") or "Không Công Khai")),
        ("Tình Trạng",         "Bình Thường" if profile.get("accountStatus",0)==0 else "Bị Khoá"),
        ("Kiểu Tài Khoản",     "Mặc Định"    if profile.get("user_mode",0)==0     else "Doanh Nghiệp"),
        ("Sinh Nhật",          str(profile.get("sdob","N/A") or "N/A")),
        ("Ngày Tạo Tài Khoản", ct_str),
    ]

    GY      = RP_Y1 + INN
    avail_g = RP_Y2 - GY - INN
    grid_w  = RW - INN * 2
    grid_x  = RP_X1 + INN

    _draw_info_grid_with_header(img, name, "Information", fields,
                                x=grid_x, y=GY,
                                w=grid_w, h=avail_g,
                                outer_r=18, gap=4)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=97)
    return W, H

if __name__ == "__main__":
    import sys

    sample = {
        "userId":         "844971946085382397",
        "username":       "t_m7caia0ge9",
        "displayName":    "Nguyễn Ngọc Ánh",
        "zaloName":       "Nguyễn Ngọc Ánh",
        "gender":         0,
        "sdob":           "26/04/2000",
        "phoneNumber":    "",
        "accountStatus":  0,
        "user_mode":      0,
        "bizPkg":         {"label": {"VI": "Kinh Doanh"}},
        "lastActionTime": int(time.time()*1000) - 10000,
        "createdTs":      1752233447,
        "isActive":       False,
        "isActiveWeb":    False,
        "isActivePC":     False,
        "status":         "Mối tình này không công khai Yêu mập mờ không tương lai",
        "avatar":         sys.argv[1] if len(sys.argv) > 1 else "",
    }

    out = "output/previewUser.jpg"
    w, h = draw_user_info(sample, out, bg_seed=7)
    print(f"📍Saved {out} ({w}×{h})")