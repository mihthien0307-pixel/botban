"""
drawLoveCard.py  v4  (emoji-free fix)
Layout:
  - Nền gradient hồng/tím + bokeh
  - Avatar tròn 2 bên, tim + sparkle ở giữa
  - Tên 2 người ngay dưới avatar
  - Panel dưới:
      Dòng 1 (1 hàng ngang):  <số ngày>  ngày  * yeu nhau  | 25/05/2026
      Dòng 2: câu chúc random lãng mạn
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, random

W, H     = 1200, 500
FONT_DIR = Path("data/assets/font")

GRAD_LEFT   = (175, 35,  115)
GRAD_RIGHT  = (75,  18,  155)
PINK        = (255, 160, 210, 255)
WHITE       = (255, 255, 255, 255)
WHITE_DIM   = (255, 255, 255, 215)
WHITE_FAINT = (255, 255, 255, 105)
SHADOW      = (0,   0,   0,   120)

# Bỏ hoàn toàn emoji trong quotes - dùng text thuần
QUOTES = [
    "Moi ngay ben nhau la mot ngay hanh phuc",
    "Yeu em hon ca hom qua, it hon ngay mai",
    "Cam on em da xuat hien trong cuoc doi anh",
    "Tinh yeu khong tinh bang thoi gian, ma bang khoanh khac",
    "Mai yeu nhau that nhieu nha",
    "Hanh phuc la moi sang thuc day thay co nhau",
    "Em la ly do anh mim cuoi moi ngay",
    "Chuc hai dua mai yeu nhau nhu ngay dau",
]

# Quotes tiếng Việt không emoji (fallback sang ASCII nếu font không hỗ trợ)
QUOTES_VN = [
    "Moi ngay ben nhau la mot ngay hanh phuc",
    "Yeu em hon ca hom qua, it hon ngay mai",
    "Cam on em da xuat hien trong cuoc doi anh",
    "Tinh yeu khong tinh bang thoi gian, ma bang khoanh khac",
    "Mai yeu nhau that nhieu nha",
    "Hanh phuc la moi sang thuc day thay co nhau",
    "Em la ly do anh mim cuoi moi ngay",
    "Chuc hai dua mai yeu nhau nhu ngay dau",
]


# ── Font ──────────────────────────────────────────────────────────────────────
def _load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    names_b = ["Sarabun-Bold.ttf", "Goldman-Bold.ttf", "OpenSans-Bold.ttf", "cool.ttf", "michroma.ttf"]
    names_r = ["Sarabun-Regular.ttf", "Goldman-Regular.ttf", "OpenSans-Regular.ttf", "zendot.ttf"]
    dirs    = [FONT_DIR/"Sarabun", FONT_DIR/"Goldman",
               FONT_DIR/"Opensans"/"static"/"Opensans", FONT_DIR]
    for name in (names_b if bold else names_r):
        for d in dirs:
            p = d / name
            if p.exists():
                try: return ImageFont.truetype(str(p), size)
                except: pass
    for p in FONT_DIR.rglob("*.ttf"):
        try: return ImageFont.truetype(str(p), size)
        except: pass
    return ImageFont.load_default()


def _measure(font, text: str):
    bb = font.getbbox(text)
    return bb[2]-bb[0], bb[3]-bb[1]


def _draw_cx(draw, font, text, cx, y, fill=WHITE, sh=SHADOW, off=3):
    w, _ = _measure(font, text)
    x = cx - w//2
    draw.text((x+off, y+off), text, font=font, fill=sh)
    draw.text((x, y),         text, font=font, fill=fill)


def _draw_left(draw, font, text, x, y, fill=WHITE, sh=SHADOW, off=3):
    draw.text((x+off, y+off), text, font=font, fill=sh)
    draw.text((x, y),         text, font=font, fill=fill)


# ── Background ────────────────────────────────────────────────────────────────
def _make_bg(seed=0):
    img = Image.new("RGBA", (W, H))
    d   = ImageDraw.Draw(img)
    for x in range(W):
        t   = x/W
        col = tuple(int(GRAD_LEFT[i]*(1-t)+GRAD_RIGHT[i]*t) for i in range(3))
        d.line([(x,0),(x,H)], fill=col+(255,))
    rng   = random.Random(seed)
    bokeh = Image.new("RGBA", (W,H), (0,0,0,0))
    bd    = ImageDraw.Draw(bokeh)
    for _ in range(55):
        bx=rng.randint(0,W); by=rng.randint(0,H)
        br=rng.randint(10,52); ba=rng.randint(14,48)
        bd.ellipse([bx-br,by-br,bx+br,by+br], fill=(255,210,240,ba))
    bokeh = bokeh.filter(ImageFilter.GaussianBlur(radius=13))
    return Image.alpha_composite(img, bokeh)


# ── Masks ─────────────────────────────────────────────────────────────────────
def _circle_mask(size):
    m = Image.new("L",(size*4,size*4),0)
    ImageDraw.Draw(m).ellipse([0,0,size*4-1,size*4-1],fill=255)
    return m.resize((size,size),Image.LANCZOS)


def _rrect_mask(w,h,r):
    m = Image.new("L",(w*4,h*4),0)
    ImageDraw.Draw(m).rounded_rectangle([0,0,w*4-1,h*4-1],r*4,fill=255)
    return m.resize((w,h),Image.LANCZOS)


# ── Avatar ────────────────────────────────────────────────────────────────────
def _load_avatar(url, size):
    if url:
        try:
            r   = requests.get(url.strip(), timeout=8, headers={"User-Agent":"Mozilla/5.0"})
            img = Image.open(BytesIO(r.content)).convert("RGBA").resize((size,size),Image.LANCZOS)
            out = Image.new("RGBA",(size,size),(0,0,0,0))
            out.paste(img, mask=_circle_mask(size))
            return out
        except: pass
    ph = Image.new("RGBA",(size,size),(0,0,0,0))
    ImageDraw.Draw(ph).ellipse([0,0,size-1,size-1],fill=(140,70,175,255))
    return ph


# ── Heart (vẽ bằng shape, không dùng emoji) ───────────────────────────────────
def _draw_heart(canvas, cx, cy, size=58):
    layer = Image.new("RGBA", canvas.size, (0,0,0,0))
    hd    = ImageDraw.Draw(layer)
    s=size; s2=s//2; s4=s//4
    hd.ellipse([cx-s2-s4, cy-s2, cx+s4,      cy+s4], fill=(255,70,120,245))
    hd.ellipse([cx-s4,    cy-s2, cx+s2+s4,   cy+s4], fill=(255,70,120,245))
    hd.polygon([(cx-s2-s4+2, cy+s4//2),(cx+s2+s4-2, cy+s4//2),(cx,cy+s)],
               fill=(255,70,120,245))
    layer = layer.filter(ImageFilter.GaussianBlur(radius=1))
    canvas.alpha_composite(layer)


# ── Sparkle line ──────────────────────────────────────────────────────────────
def _sparkle_line(canvas, x1, x2, y):
    layer = Image.new("RGBA", canvas.size, (0,0,0,0))
    ld    = ImageDraw.Draw(layer)
    ld.line([(x1,y),(x2,y)], fill=(255,200,235,65), width=2)
    rng = random.Random(99)
    for _ in range(14):
        sx=rng.randint(x1,x2); sy=y+rng.randint(-7,7); sr=rng.randint(2,5)
        ld.ellipse([sx-sr,sy-sr,sx+sr,sy+sr], fill=(255,240,255,rng.randint(65,165)))
    canvas.alpha_composite(layer)


# ── Panel ─────────────────────────────────────────────────────────────────────
def _draw_panel(canvas, x, y, w, h, r=22, alpha=42):
    bg   = Image.new("RGBA",(w,h),(255,255,255,alpha))
    mask = _rrect_mask(w,h,r)
    out  = Image.new("RGBA",(w,h),(0,0,0,0))
    out.paste(bg, mask=mask)
    canvas.alpha_composite(out,(x,y))


# ── Vẽ icon trái tim nhỏ bằng shape (thay 💖) ────────────────────────────────
def _draw_small_heart(canvas, x, y, size=18):
    layer = Image.new("RGBA", canvas.size, (0,0,0,0))
    hd    = ImageDraw.Draw(layer)
    s=size; s2=s//2; s4=s//4
    hd.ellipse([x-s4,    y,      x+s4,    y+s2], fill=(255,120,180,240))
    hd.ellipse([x+s4,    y,      x+s2+s4, y+s2], fill=(255,120,180,240))
    hd.polygon([(x-s4+1, y+s4),(x+s2+s4-1, y+s4),(x+s4, y+s)],
               fill=(255,120,180,240))
    canvas.alpha_composite(layer)


# ── Vẽ icon lịch nhỏ bằng shape (thay 📅) ────────────────────────────────────
def _draw_small_cal(draw, x, y, size=20):
    w2 = size; h2 = size - 2
    draw.rounded_rectangle([x, y+2, x+w2, y+h2+2], radius=3,
                           outline=(255,200,240,200), width=2, fill=(255,255,255,30))
    draw.line([(x+4, y+2),(x+4, y-2)], fill=(255,200,240,200), width=2)
    draw.line([(x+w2-4, y+2),(x+w2-4, y-2)], fill=(255,200,240,200), width=2)
    draw.line([(x, y+7),(x+w2, y+7)], fill=(255,200,240,180), width=1)


# ── Main ──────────────────────────────────────────────────────────────────────
def draw_love_card(
    name1, name2, date_str, days, days_label,
    avatar1_url="", avatar2_url="",
    title="THONG TIN NGAY YEU",
    out_path="data/assets/cache/image/love_card.jpg",
    seed=0,
):
    canvas   = _make_bg(seed)
    d        = ImageDraw.Draw(canvas)
    CENTER_X = W // 2

    # ── Fonts ────────────────────────────────────────────────────────────────
    f_title  = _load_font(24)
    f_name   = _load_font(44, bold=True)
    f_num    = _load_font(58, bold=True)   # số ngày
    f_inline = _load_font(30, bold=False)  # text inline
    f_quote  = _load_font(26)

    # ── Layout ───────────────────────────────────────────────────────────────
    AV_SIZE   = 170
    AV_BORDER = 5
    AV_Y      = 38
    AV_LX     = W//4 - AV_SIZE//2
    AV_RX     = W*3//4 - AV_SIZE//2
    mid_y     = AV_Y + AV_SIZE//2

    # ── Title (bỏ emoji, dùng text thuần) ────────────────────────────────────
    # Xoá emoji khỏi title nếu có
    clean_title = ""
    for ch in title:
        if ord(ch) < 0x2500:  # giữ lại ASCII + Latin + tiếng Việt
            clean_title += ch
    clean_title = clean_title.strip() or "THONG TIN NGAY YEU"
    _draw_cx(d, f_title, clean_title, CENTER_X, 12, fill=WHITE_FAINT)

    # ── Avatar rings ─────────────────────────────────────────────────────────
    rs = AV_SIZE + AV_BORDER*2
    for ax in [AV_LX-AV_BORDER, AV_RX-AV_BORDER]:
        ring = Image.new("RGBA", canvas.size, (0,0,0,0))
        ImageDraw.Draw(ring).ellipse(
            [ax, AV_Y-AV_BORDER, ax+rs, AV_Y-AV_BORDER+rs],
            fill=(255,255,255,75))
        canvas.alpha_composite(ring)

    # ── Avatars ───────────────────────────────────────────────────────────────
    canvas.alpha_composite(_load_avatar(avatar1_url, AV_SIZE), (AV_LX, AV_Y))
    canvas.alpha_composite(_load_avatar(avatar2_url, AV_SIZE), (AV_RX, AV_Y))

    # ── Sparkle + heart ───────────────────────────────────────────────────────
    _sparkle_line(canvas, AV_LX+AV_SIZE+8, AV_RX-8, mid_y)
    _draw_heart(canvas, CENTER_X, mid_y-32, size=58)

    # ── Tên 2 người (strip emoji) ─────────────────────────────────────────────
    def _strip_emoji(s):
        return "".join(ch for ch in s if ord(ch) < 0x2500).strip()

    name_y = AV_Y + AV_SIZE + 10
    _draw_cx(d, f_name, _strip_emoji(name1), W//4,    name_y, fill=WHITE)
    _draw_cx(d, f_name, _strip_emoji(name2), W*3//4,  name_y, fill=WHITE)

    # ── Panel dưới ───────────────────────────────────────────────────────────
    HEART_W  = 24   # width dành cho icon tim nhỏ
    CAL_W    = 26   # width dành cho icon lịch nhỏ
    GAP_ICON = 6

    days_str       = str(days)
    unit_str       = " ngay"
    love_text      = "  yeu nhau"
    date_text      = f"  {date_str}"

    num_w,  num_h  = _measure(f_num,    days_str)
    unit_w, unit_h = _measure(f_inline, unit_str)
    love_w, love_h = _measure(f_inline, love_text)
    date_w, date_h = _measure(f_inline, date_text)

    row_w = num_w + unit_w + GAP_ICON + HEART_W + love_w + GAP_ICON + CAL_W + date_w
    ROW_H = max(num_h, unit_h)

    rng_q  = random.Random(seed + 1)
    quote  = rng_q.choice(QUOTES_VN)
    q_w, q_h = _measure(f_quote, quote)

    PAD_TB  = 18
    GAP     = 10
    P_H     = PAD_TB + ROW_H + GAP + q_h + PAD_TB
    P_Y     = H - P_H - 14
    P_X     = 50
    P_W     = W - 100

    _draw_panel(canvas, P_X, P_Y, P_W, P_H, r=24, alpha=44)

    # ── Dòng 1: số ngày | ngày | [tim] yeu nhau | [cal] 25/05/2026 ──────────
    row_start_x = CENTER_X - row_w // 2
    baseline_y  = P_Y + PAD_TB
    num_y       = baseline_y
    small_y     = baseline_y + num_h - unit_h

    # số ngày (lớn, trắng)
    _draw_left(d, f_num, days_str, row_start_x, num_y, fill=WHITE)
    cx = row_start_x + num_w

    # " ngay" (hồng)
    _draw_left(d, f_inline, unit_str, cx, small_y, fill=PINK)
    cx += unit_w + GAP_ICON

    # icon tim nhỏ vẽ bằng shape
    heart_y = small_y + unit_h//2 - 9
    _draw_small_heart(canvas, cx, heart_y, size=18)
    cx += HEART_W

    # " yeu nhau" (trắng mờ)
    _draw_left(d, f_inline, love_text, cx, small_y, fill=WHITE_DIM)
    cx += love_w + GAP_ICON

    # icon lịch nhỏ vẽ bằng shape
    cal_y = small_y + unit_h//2 - 9
    _draw_small_cal(d, cx, cal_y, size=20)
    cx += CAL_W

    # " 25/05/2026" (trắng mờ)
    _draw_left(d, f_inline, date_text, cx, small_y, fill=WHITE_DIM)

    # ── Dòng 2: câu chúc ─────────────────────────────────────────────────────
    quote_y = P_Y + PAD_TB + ROW_H + GAP
    _draw_cx(d, f_quote, quote, CENTER_X, quote_y, fill=WHITE_FAINT)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=93)
    return out_path, W, H
