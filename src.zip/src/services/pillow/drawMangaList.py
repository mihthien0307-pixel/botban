"""
src/services/pillow/drawMangaList.py
Canvas vẽ danh sách truyện tranh – style tối giống drawModList.
"""

import os
import threading
import requests
from io import BytesIO
from pathlib import Path
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ─── Kích thước canvas ──────────────────────────────────────────────────────
W, H, PAD = 1536, 900, 40

# ─── Bảng màu (dark-navy glassmorphism) ─────────────────────────────────────
BG_TL = (14, 22, 46)
BG_TR = (22, 14, 54)
BG_BL = (10, 18, 38)
BG_BR = (20, 12, 48)

C_TITLE  = (246, 248, 255, 255)
C_SUB    = (160, 200, 255, 255)
C_DIM    = (110, 140, 190, 255)
C_ACCENT = (80,  200, 255, 255)
C_ORANGE = (255, 160,  60, 255)
C_GREEN  = (80,  220, 130, 255)
C_PINK   = (255, 120, 180, 255)

FONT_DIR = Path("assets/font")
_fcache: dict = {}


# ─── Font helpers ────────────────────────────────────────────────────────────
def _font(size: int, bold: bool = False):
    key = (size, bold)
    if key in _fcache:
        return _fcache[key]
    candidates = (
        [
            FONT_DIR / "Goldman" / "Goldman-Bold.ttf",
            FONT_DIR / "Opensans" / "static" / "OpenSans_Condensed-Bold.ttf",
        ]
        if bold else
        [
            FONT_DIR / "Opensans" / "static" / "OpenSans_Condensed-Regular.ttf",
            FONT_DIR / "MJLeQuarte-Regular.ttf",
        ]
    )
    for p in candidates:
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


@lru_cache(maxsize=64)
def _round_mask(w: int, h: int, r: int):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w, h), r, fill=255)
    return m


def _fit(d: ImageDraw.Draw, text: str, font, max_w: float) -> str:
    text = str(text or "")
    if d.textlength(text, font=font) <= max_w:
        return text
    ell  = "…"
    room = max_w - d.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if d.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell


# ─── Background & glass ──────────────────────────────────────────────────────
def _make_bg() -> Image.Image:
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), BG_TL)
    c.putpixel((1, 0), BG_TR)
    c.putpixel((0, 1), BG_BL)
    c.putpixel((1, 1), BG_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _glass(img: Image.Image, box, radius: int, alpha: int = 22):
    x1, y1, x2, y2 = map(int, box)
    bw, bh = x2 - x1, y2 - y1
    if bw <= 0 or bh <= 0:
        return
    blur = 20
    sh_size = (bw + blur * 4, bh + blur * 4)
    sh_mask = Image.new("L", sh_size, 0)
    ImageDraw.Draw(sh_mask).rounded_rectangle(
        (blur * 2, blur * 2, blur * 2 + bw, blur * 2 + bh), radius, fill=255
    )
    sh_mask = sh_mask.filter(ImageFilter.GaussianBlur(blur))
    sh_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh_layer.paste(
        Image.new("RGBA", sh_size, (0, 0, 0, 80)),
        (x1 - blur * 2, y1 - blur * 2 + 8),
        sh_mask,
    )
    img.alpha_composite(sh_layer)
    blurred = (
        img.crop((x1, y1, x2, y2))
        .filter(ImageFilter.GaussianBlur(18))
        .convert("RGBA")
    )
    layer = Image.alpha_composite(
        blurred, Image.new("RGBA", (bw, bh), (255, 255, 255, alpha))
    )
    img.paste(layer, (x1, y1), _round_mask(bw, bh, radius))


# ─── Tải thumbnail truyện ────────────────────────────────────────────────────
def _load_thumb(url: str, size: tuple) -> Image.Image:
    wd, hd = int(size[0]), int(size[1])
    blank  = Image.new("RGBA", (wd, hd), (30, 40, 80, 255))
    d2     = ImageDraw.Draw(blank)
    # placeholder icon
    cx, cy = wd // 2, hd // 2
    d2.rectangle((cx - 18, cy - 26, cx + 18, cy + 26), fill=(60, 80, 140, 200))
    d2.rectangle((cx - 14, cy - 22, cx + 14, cy + 22), fill=(40, 55, 100, 180))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        # Crop trung tâm cho đúng tỉ lệ
        iw, ih = img.size
        ratio  = max(wd / iw, hd / ih)
        nw, nh = int(iw * ratio), int(ih * ratio)
        img    = img.resize((nw, nh), Image.LANCZOS)
        left   = (nw - wd) // 2
        top    = (nh - hd) // 2
        img    = img.crop((left, top, left + wd, top + hd))
        return img
    except Exception:
        return blank


# ─── Hàm chính ───────────────────────────────────────────────────────────────
def draw_manga_list(
    *,
    keyword: str,
    items: list,
    out_path: str,
) -> tuple:
    """
    items: list of dict {
        "title": str,
        "author": str,          # optional
        "status": str,          # optional  (e.g. "Đang tiến hành")
        "thumb": str,           # URL ảnh bìa
        "genres": str,          # optional  (e.g. "Hành động, Phiêu lưu")
    }
    Trả về (out_path, W, H)
    """
    items   = items or []
    visible = items[:10]

    img = _make_bg()

    # ── Khung ngoài ─────────────────────────────────────────────────────────
    _glass(img, (PAD, PAD, W - PAD, H - PAD), 44)

    inner = 20
    hdr_h = 100
    hx1 = PAD + inner
    hy1 = PAD + inner
    hx2 = W - PAD - inner
    hy2 = PAD + inner + hdr_h

    # ── Header ──────────────────────────────────────────────────────────────
    _glass(img, (hx1, hy1, hx2, hy2), 30, alpha=35)
    d = ImageDraw.Draw(img)

    f_big   = _font(52, bold=True)
    f_sub   = _font(26)
    f_count = _font(30, bold=True)

    title_txt = f"📚 Tìm truyện: {keyword}"
    sub_txt   = f"Tìm thấy {len(items)} kết quả  •  Nhập số 1–{min(len(items),10)} để đọc"
    count_txt = f"{len(items)} truyện"

    d.text((hx1 + 24, hy1 + 12), title_txt, font=f_big, fill=C_TITLE)
    d.text((hx1 + 24, hy1 + 68), sub_txt,   font=f_sub,  fill=C_SUB)
    ctw = int(d.textlength(count_txt, font=f_count))
    d.text((hx2 - ctw - 20, hy1 + 32), count_txt, font=f_count, fill=C_ACCENT)

    line_y = hy2 + 4
    d.rounded_rectangle((hx1, line_y, hx1 + 320, line_y + 3), 2, fill=C_ACCENT)

    # ── Lưới card ───────────────────────────────────────────────────────────
    cy1    = hy2 + 14
    cy2    = H - PAD - inner
    area_w = hx2 - hx1
    area_h = cy2 - cy1

    cols   = 5
    rows   = 2
    cgap   = 12
    rgap   = 10

    card_w = (area_w - (cols - 1) * cgap) // cols
    card_h = (area_h - (rows - 1) * rgap) // rows

    thumb_w = card_w - 20
    thumb_h = int(card_h * 0.58)
    t_mask  = _round_mask(thumb_w, thumb_h, 12)

    # Tải thumbnail song song
    av_list = [None] * len(visible)

    def _fetch(i: int, url: str):
        av_list[i] = _load_thumb(url, (thumb_w, thumb_h))

    threads = []
    for i, item in enumerate(visible):
        t = threading.Thread(
            target=_fetch, args=(i, item.get("thumb", "")), daemon=True
        )
        threads.append(t)
        t.start()
    for t in threads:
        t.join(timeout=8)

    f_num    = _font(22, bold=True)
    f_name   = _font(22, bold=True)
    f_meta   = _font(18)
    f_status = _font(17)

    for i, item in enumerate(visible):
        col = i % cols
        row = i // cols
        x1  = hx1 + col * (card_w + cgap)
        y1  = cy1 + row * (card_h + rgap)
        x2  = x1 + card_w
        y2  = y1 + card_h

        _glass(img, (x1, y1, x2, y2), 16, alpha=28)
        d = ImageDraw.Draw(img)

        # Thumbnail
        tx = x1 + 10
        ty = y1 + 8
        if av_list[i]:
            img.paste(av_list[i], (tx, ty), t_mask)

        # Số thứ tự badge
        badge_txt = str(i + 1)
        bw2 = int(d.textlength(badge_txt, font=f_num)) + 16
        bh2 = 28
        d.rounded_rectangle((x1 + 8, y1 + 6, x1 + 8 + bw2, y1 + 6 + bh2), 8,
                             fill=(0, 0, 0, 160))
        d.text((x1 + 8 + 8, y1 + 6 + 3), badge_txt, font=f_num, fill=C_ACCENT)

        # Text bên dưới thumbnail
        text_y = ty + thumb_h + 6
        max_tw = card_w - 16

        title = _fit(d, item.get("title", "?"), f_name, max_tw)
        d.text((tx, text_y), title, font=f_name, fill=C_TITLE)
        text_y += 26

        author = item.get("author", "")
        if author:
            d.text((tx, text_y), _fit(d, f"✍ {author}", f_meta, max_tw),
                   font=f_meta, fill=C_SUB)
            text_y += 22

        status = item.get("status", "")
        if status:
            sc = C_GREEN if "đang" in status.lower() else C_PINK
            d.text((tx, text_y), _fit(d, status, f_status, max_tw),
                   font=f_status, fill=sc)

    # ── Thông báo nếu còn thêm ──────────────────────────────────────────────
    if len(items) > 10:
        f_more = _font(24)
        d = ImageDraw.Draw(img)
        d.text((hx1 + 8, cy2 - 28),
               f"+ {len(items) - 10} truyện khác…  (nhập số để đọc)",
               font=f_more, fill=C_ORANGE)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.save(out_path, "PNG")
    return out_path, W, H
