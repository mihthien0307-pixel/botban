import os, threading
import requests
from io import BytesIO
from pathlib import Path
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, PAD = 1536, 860, 44

BG_TL      = ( 18,  28,  52)
BG_TR      = ( 28,  18,  60)
BG_BL      = ( 12,  22,  44)
BG_BR      = ( 24,  14,  52)

GLASS_FILL = (255, 255, 255, 22)
C_TITLE    = (246, 248, 255, 255)
C_SUB      = (160, 200, 255, 255)
C_DIM      = (110, 140, 190, 255)
C_ACCENT   = ( 80, 200, 255, 255)
C_ORANGE   = (255, 160,  60, 255)

FONT_DIR = Path("assets/font")
_fcache: dict = {}


def _emoji_font(size):
    key = ("emoji", size)
    if key in _fcache:
        return _fcache[key]
    for name in ("emoji.ttf", "emoji2.ttf", "emoji3.ttf", "emoji5.ttf"):
        p = FONT_DIR / name
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fcache[key] = f
                return f
            except Exception:
                pass
    return _font(size, bold=False)


def _font(size, bold=False):
    key = (size, bold)
    if key in _fcache:
        return _fcache[key]
    candidates = (
        [FONT_DIR / "Goldman" / "Goldman-Bold.ttf",
         FONT_DIR / "Opensans" / "static" / "Opensans" / "OpenSans-Bold.ttf"]
        if bold else
        [FONT_DIR / "Opensans" / "static" / "Opensans" / "OpenSans-Regular.ttf",
         FONT_DIR / "Sarabun" / "Sarabun-Regular.ttf"]
    )
    for p in candidates:
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), size)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


@lru_cache(maxsize=64)
def _round_mask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w, h), r, fill=255)
    return m


def _fit(d, text, font, max_w):
    text = str(text or "")
    if d.textlength(text, font=font) <= max_w:
        return text
    ell  = "..."
    room = max_w - d.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if d.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell


def _load_avatar(url, size):
    wd, hd = int(size[0]), int(size[1])
    blank  = Image.new("RGBA", (wd, hd), (30, 40, 70, 255))
    d2 = ImageDraw.Draw(blank)
    cx, cy = wd // 2, hd // 2
    r2 = min(wd, hd) // 4
    d2.ellipse((cx - r2, cy - r2 - 4, cx + r2, cy + r2 - 4), fill=(80, 100, 160, 200))
    d2.ellipse((cx - r2 * 2, cy + r2 - 2, cx + r2 * 2, cy + r2 * 3), fill=(80, 100, 160, 200))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        return img.resize((wd, hd), Image.LANCZOS)
    except Exception:
        return blank


def _make_bg():
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), BG_TL)
    c.putpixel((1, 0), BG_TR)
    c.putpixel((0, 1), BG_BL)
    c.putpixel((1, 1), BG_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _glass(img, box, radius, alpha=22):
    x1, y1, x2, y2 = map(int, box)
    bw, bh = x2 - x1, y2 - y1
    if bw <= 0 or bh <= 0:
        return
    blur = 20
    sh_size = (bw + blur * 4, bh + blur * 4)
    sh_mask = Image.new("L", sh_size, 0)
    ImageDraw.Draw(sh_mask).rounded_rectangle(
        (blur*2, blur*2, blur*2+bw, blur*2+bh), radius, fill=255
    )
    sh_mask = sh_mask.filter(ImageFilter.GaussianBlur(blur))
    sh_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh_layer.paste(Image.new("RGBA", sh_size, (0, 0, 0, 80)),
                   (x1 - blur*2, y1 - blur*2 + 8), sh_mask)
    img.alpha_composite(sh_layer)
    blurred = img.crop((x1, y1, x2, y2)).filter(ImageFilter.GaussianBlur(18)).convert("RGBA")
    layer   = Image.alpha_composite(blurred, Image.new("RGBA", (bw, bh), (255, 255, 255, alpha)))
    img.paste(layer, (x1, y1), _round_mask(bw, bh, radius))


def draw_mod_list(*, title, subtitle, items, out_path, mode="fr"):
    """
    items: list of dict {"name": str, "sub": str, "avatar": str (optional)}
    mode : "fr" | "grp"
    """
    items = items or []
    img   = _make_bg()
    _glass(img, (PAD, PAD, W - PAD, H - PAD), 44)

    inner = 22
    hdr_h = 110
    hx1, hy1 = PAD + inner, PAD + inner
    hx2, hy2 = W - PAD - inner, PAD + inner + hdr_h
    _glass(img, (hx1, hy1, hx2, hy2), 32, alpha=35)

    d = ImageDraw.Draw(img)
    f_big    = _font(54, bold=True)
    f_sub    = _font(28)
    f_count  = _font(32, bold=True)
    f_emoji  = _emoji_font(52)

    icon      = "👥" if mode == "fr" else ("🏠" if mode == "grp" else "🚫")
    count_txt = f"{len(items)} mục"

    # Vẽ icon emoji bằng font emoji riêng, sau đó vẽ title bằng Goldman
    icon_x = hx1 + 28
    icon_y = hy1 + 16
    d.text((icon_x, icon_y), icon, font=f_emoji, fill=C_TITLE)
    icon_w = int(d.textlength(icon, font=f_emoji)) + 14
    d.text((icon_x + icon_w, icon_y), title, font=f_big, fill=C_TITLE)
    d.text((hx1 + 28, hy1 + 72), subtitle, font=f_sub, fill=C_SUB)
    ctw = int(d.textlength(count_txt, font=f_count))
    d.text((hx2 - ctw - 24, hy1 + 38), count_txt, font=f_count, fill=C_ACCENT)

    line_y = hy2 + 6
    aw = min(icon_w + int(d.textlength(title, font=f_big)) + 20, hx2 - hx1)
    d.rounded_rectangle((hx1, line_y, hx1 + aw, line_y + 4), 2, fill=C_ACCENT)

    cy1     = hy2 + 18
    cy2     = H - PAD - inner
    area_w  = hx2 - hx1
    area_h  = cy2 - cy1
    visible = items[:20]
    cols    = 4
    rows    = 5
    cgap    = 14
    rgap    = 12
    card_w  = (area_w - (cols - 1) * cgap) // cols
    card_h  = (area_h - (rows - 1) * rgap) // rows
    thumb_s = min(card_h - 30, 64)
    t_mask  = _round_mask(thumb_s, thumb_s, 16)

    av_list = [None] * len(visible)
    def _fetch(i, url):
        av_list[i] = _load_avatar(url, (thumb_s, thumb_s))
    threads = []
    for i, item in enumerate(visible):
        t = threading.Thread(target=_fetch, args=(i, item.get("avatar") or ""), daemon=True)
        threads.append(t); t.start()
    for t in threads:
        t.join(timeout=8)

    f_name = _font(26, bold=True)
    f_meta = _font(20)
    f_idx  = _font(18)

    for i, item in enumerate(visible):
        col = i % cols
        row = i // cols
        x1  = hx1 + col * (card_w + cgap)
        y1  = cy1  + row * (card_h + rgap)
        x2  = x1 + card_w
        y2  = y1 + card_h

        _glass(img, (x1, y1, x2, y2), 20, alpha=28)
        d = ImageDraw.Draw(img)

        ax = x1 + 10
        ay = y1 + (card_h - thumb_s) // 2
        if av_list[i]:
            img.paste(av_list[i], (ax, ay), t_mask)

        tx    = ax + thumb_s + 10
        max_w = x2 - tx - 10
        d.text((tx, y1 + 10),      _fit(d, item.get("name", "?"),  f_name, max_w), font=f_name, fill=C_TITLE)
        d.text((tx, y1 + 10 + 34), _fit(d, item.get("sub",  ""),   f_meta, max_w), font=f_meta, fill=C_SUB)

        idx_str = str(i + 1)
        iw = int(d.textlength(idx_str, font=f_idx))
        d.text((x2 - iw - 8, y2 - 26), idx_str, font=f_idx, fill=C_DIM)

    if len(items) > 20:
        f_more = _font(26)
        d.text((hx1 + 10, cy2 - 30), f"+ {len(items) - 20} mục khác...", font=f_more, fill=C_ORANGE)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.save(out_path, "PNG")
    return out_path, W, H
