"""
src/services/pillow/drawStatusCard.py
Nền mesh gradient: 2 góc xanh navy/teal, giữa tím, góc còn lại tím đậm.
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, math

W, H     = 1280, 720
FONT_DIR = Path("assets/font")


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = (
        [FONT_DIR / "Sarabun" / "Sarabun-Bold.ttf",
         FONT_DIR / "Goldman" / "Goldman-Bold.ttf"]
        if bold else
        [FONT_DIR / "Sarabun" / "Sarabun-Regular.ttf",
         FONT_DIR / "Sarabun" / "Sarabun-Light.ttf",
         FONT_DIR / "Goldman" / "Goldman-Regular.ttf"]
    )
    for p in candidates:
        if p.exists():
            try:
                return ImageFont.truetype(str(p), size)
            except Exception:
                pass
    return ImageFont.load_default()


def _lerp(a, b, t):
    return a + (b - a) * t


def _lerp_color(c1, c2, t):
    return tuple(int(_lerp(c1[i], c2[i], t)) for i in range(3))


def _make_bg(w: int, h: int) -> Image.Image:
    """
    Mesh gradient 4 điểm (giống ảnh mẫu):
      TL = tím đậm        TR = xanh navy
      BL = xanh teal      BR = tím đậm/navy
    Thêm glow tím ở giữa.
    """
    # Màu 4 góc lấy trực tiếp từ ảnh mẫu
    TL = (72,  30, 100)   # tím đậm
    TR = (25,  45, 100)   # xanh navy
    BL = (20,  55,  90)   # xanh teal
    BR = (55,  20,  90)   # tím navy

    img = Image.new("RGB", (w, h))
    px  = img.load()

    for y in range(h):
        yr = y / (h - 1)
        for x in range(w):
            xr = x / (w - 1)

            # Bilinear interpolation 4 góc
            top    = _lerp_color(TL, TR, xr)
            bot    = _lerp_color(BL, BR, xr)
            base   = _lerp_color(top, bot, yr)

            # Glow tím nhạt ở giữa (ellipse)
            dx    = (xr - 0.52) * 1.4
            dy    = (yr - 0.48) * 1.8
            dist  = math.sqrt(dx * dx + dy * dy)
            glow  = max(0.0, 1.0 - dist)
            glow  = glow * glow * 55   # quadratic falloff, intensity

            r = min(255, base[0] + int(glow * 0.9))
            g = min(255, base[1] + int(glow * 0.0))
            b = min(255, base[2] + int(glow * 1.2))

            px[x, y] = (r, g, b)

    # Blur mạnh để mượt như ảnh mẫu
    img = img.filter(ImageFilter.GaussianBlur(radius=60))
    return img


def _wrap(draw, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for word in words:
        test = (cur + " " + word).strip()
        if draw.textbbox((0, 0), test, font=font)[2] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [text]


def _fetch_avatar(url: str, size: int):
    try:
        resp = requests.get(url, timeout=8)
        resp.raise_for_status()
        av   = Image.open(BytesIO(resp.content)).convert("RGBA")
        av   = av.resize((size, size), Image.LANCZOS)
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
        av.putalpha(mask)
        return av
    except Exception:
        return None


def draw_status_card(status_text, user_name, avatar_url, out_path):
    img  = _make_bg(W, H).convert("RGBA")
    draw = ImageDraw.Draw(img, "RGBA")

    font_status = _font(74)
    font_name   = _font(32)

    # ── Chữ status căn GIỮA ─────────────────────────────────────────────────
    lines   = _wrap(draw, status_text, font_status, W - 200)
    lh      = 74 + 14
    total_h = len(lines) * lh
    start_y = (H - total_h) // 2 - 30

    for i, line in enumerate(lines):
        bbox   = draw.textbbox((0, 0), line, font=font_status)
        text_w = bbox[2] - bbox[0]
        x      = (W - text_w) // 2
        y      = start_y + i * lh
        draw.text((x + 2, y + 2), line, font=font_status, fill=(0, 0, 0, 80))
        draw.text((x, y), line, font=font_status, fill=(255, 255, 255, 245))

    # ── Avatar + Tên GÓC DƯỚI TRÁI ───────────────────────────────────────────
    av_size = 56
    pad_x   = 30
    pad_y   = 24
    row_y   = H - av_size - pad_y

    av_placed = False
    if avatar_url:
        av = _fetch_avatar(avatar_url, size=av_size)
        if av:
            img.paste(av, (pad_x, row_y), av)
            av_placed = True

    if not av_placed:
        draw.ellipse(
            [(pad_x, row_y), (pad_x + av_size, row_y + av_size)],
            fill=(80, 60, 140, 220),
        )

    name_x = pad_x + av_size + 12
    name_y = row_y + (av_size - 34) // 2
    draw.text((name_x + 1, name_y + 1), user_name, font=font_name, fill=(0, 0, 0, 100))
    draw.text((name_x, name_y), user_name, font=font_name, fill=(255, 255, 255, 230))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, "JPEG", quality=95)
    return W, H
