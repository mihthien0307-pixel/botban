"""
drawTopChat.py  –  Vẽ card Top Chat (v3 – fix theo ảnh thực)
Layout GIỮ NGUYÊN như ảnh mẫu:
  • Header: tiêu đề căn giữa
  • Top 1-3: 3 card vuông to xếp ngang, avatar fill phía trên bo góc,
             tên+rank+count bên dưới (fix tràn, nền mờ glassmorphism)
             Góc text chia 3 dòng cách nhau bằng spacing (không kẻ rắn)
  • Top 4-15: rows 3 cột, avatar tròn trái, tên+sub phải
             Cách nhau bằng spacing line nhẹ
  • Background: gradient tím → đỏ tím + blur blobs
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, math, re, unicodedata, logging

FONT_DIR = Path("assets/font")

# ── Canvas constants ──────────────────────────────────────────────────────────
TOP3_CARD_W = 320
TOP3_CARD_H = 390
ROW_H       = 90
ROW_AV      = 66
PAD         = 28
GAP         = 14
COLS        = 3
RADIUS      = 20

# ── Màu ───────────────────────────────────────────────────────────────────────
C_NAME    = (255, 255, 255)
C_RANK    = (220, 200, 255)
C_COUNT   = (200, 185, 245)
C_WHITE_A = (255, 255, 255, 230)
C_WHITE_L = (255, 255, 255,  40)
C_SEP     = (255, 255, 255,  28)   # đường spacing nhẹ giữa các dòng

# Nền glassmorphism – mờ nhìn thấy bg xuyên qua
C_TOP1_BG = ( 80,  50, 120, 185)
C_TOP2_BG = ( 70,  45, 110, 170)
C_TOP3_BG = ( 60,  40, 100, 155)
C_ROW_BG  = ( 50,  35,  90, 155)
C_BORDER  = (255, 255, 255,  40)


# ══════════════════════════════════════════════════════════════════════════════
#  FONT LOADER
# ══════════════════════════════════════════════════════════════════════════════
_fcache: dict = {}

def _font(sz: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (sz, bold)
    if key in _fcache:
        return _fcache[key]
    # Dùng OpenSans có sẵn trong assets/font/Opensans/static/Opensans/
    opensans_dir = FONT_DIR / "Opensans" / "static" / "Opensans"
    prefer_bold = ["OpenSans-Bold.ttf", "OpenSans-ExtraBold.ttf", "OpenSans-SemiBold.ttf"]
    prefer_reg  = ["OpenSans-Regular.ttf", "OpenSans-Medium.ttf", "OpenSans-Light.ttf"]
    names = prefer_bold if bold else prefer_reg
    for name in names:
        p = opensans_dir / name
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), sz)
                _fcache[key] = f
                return f
            except Exception:
                pass
    # Fallback: quét toàn bộ font trong thư mục
    for ext in ("*.ttf", "*.otf"):
        for p in sorted(FONT_DIR.rglob(ext)):
            try:
                f = ImageFont.truetype(str(p), sz)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


# ══════════════════════════════════════════════════════════════════════════════
#  EMOJI / TEXT SAFETY
# ══════════════════════════════════════════════════════════════════════════════
_EMOJI_RE = re.compile(
    "["
    "\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF"
    "\U0001F1E0-\U0001F1FF\U00002500-\U00002BEF\U00002702-\U000027B0"
    "\U000024C2-\U0001F251\U0001f926-\U0001f937\U00010000-\U0010ffff"
    "\u2640-\u2642\u2600-\u2B55\u200d\u23cf\u23e9\u231a\ufe0f\u3030"
    "]+",
    flags=re.UNICODE,
)

def _safe_text(text: str) -> str:
    text = _EMOJI_RE.sub("", str(text))
    text = "".join(
        ch for ch in text
        if unicodedata.category(ch) not in ("Cc", "Cf") or ch in ("\n", "\t")
    ).strip()
    return text or "?"


# ══════════════════════════════════════════════════════════════════════════════
#  TEXT MEASUREMENT
# ══════════════════════════════════════════════════════════════════════════════
def _tw(d, text: str, font) -> int:
    try:
        bb = d.textbbox((0, 0), text, font=font)
        return max(0, bb[2] - bb[0])
    except Exception:
        try:
            return max(0, int(d.textlength(text, font=font)))
        except Exception:
            return len(text) * getattr(font, "size", 12) // 2

def _th(d, text: str, font) -> int:
    try:
        bb = d.textbbox((0, 0), text, font=font)
        return max(1, bb[3] - bb[1])
    except Exception:
        return getattr(font, "size", 12)

def _fit(d, text: str, font, maxw: int) -> str:
    if _tw(d, text, font) <= maxw:
        return text
    ell = "…"
    ew  = _tw(d, ell, font)
    out = ""
    for ch in text:
        if _tw(d, out + ch, font) > maxw - ew:
            break
        out += ch
    return out + ell

def _auto_fit(d, text: str, max_sz: int, min_sz: int, bold: bool, maxw: int):
    for sz in range(max_sz, min_sz - 1, -1):
        f = _font(sz, bold)
        if _tw(d, text, f) <= maxw:
            return text, f
    f = _font(min_sz, bold)
    return _fit(d, text, f, maxw), f


# ══════════════════════════════════════════════════════════════════════════════
#  DRAWING HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _rrect(base: Image.Image, box, r, fill=None, outline=None, lw=1):
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    if w <= 0 or h <= 0:
        return
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    if fill:
        d.rounded_rectangle((0, 0, w-1, h-1), r, fill=fill)
    if outline:
        d.rounded_rectangle((0, 0, w-1, h-1), r, outline=outline, width=lw)
    base.alpha_composite(layer, (x1, y1))

def _hline(base: Image.Image, x1: int, x2: int, y: int, color=C_SEP):
    """Vẽ đường kẻ ngang mờ nhẹ làm spacing giữa các dòng text."""
    layer = Image.new("RGBA", (x2 - x1, 1), color)
    base.alpha_composite(layer, (x1, y))

def _hq_url(url: str) -> str:
    if not url:
        return url
    url = re.sub(r'[?&]w=\d+', '', url)
    url = re.sub(r'[?&]h=\d+', '', url)
    url = re.sub(r'[?&]s=\d+', '', url)
    url = re.sub(r'[?&]size=\d+', '', url)
    url = re.sub(r'/w\d+/', '/w2048/', url)
    return url.rstrip('?&')

def _fetch_avatar(url: str, size: int, circle: bool = False) -> "Image.Image | None":
    if not url:
        return None
    try:
        resp = requests.get(_hq_url(url), timeout=6,
                            headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        raw = Image.open(BytesIO(resp.content)).convert("RGBA")
        iw, ih = raw.size
        s   = min(iw, ih)
        raw = raw.crop(((iw-s)//2, (ih-s)//2, (iw+s)//2, (ih+s)//2))
        raw = raw.resize((size, size), Image.LANCZOS)
        mask = Image.new("L", (size, size), 0)
        if circle:
            ImageDraw.Draw(mask).ellipse((0, 0, size-1, size-1), fill=255)
        else:
            ImageDraw.Draw(mask).rounded_rectangle(
                (0, 0, size-1, size-1), RADIUS, fill=255)
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        out.paste(raw, mask=mask)
        return out
    except Exception:
        return None

def _load_rank_icon(path: str, size: int) -> "Image.Image | None":
    """Load icon rank từ file PNG, resize về size×size, giữ RGBA."""
    if not path or not os.path.isfile(path):
        return None
    try:
        img = Image.open(path).convert("RGBA").resize((size, size), Image.LANCZOS)
        return img
    except Exception:
        return None


def _placeholder(size: int, circle: bool, rank: int) -> Image.Image:
    palette = [(120, 80, 180), (90, 60, 150), (70, 50, 130)]
    col = palette[min(rank - 1, len(palette) - 1)]
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d   = ImageDraw.Draw(img)
    if circle:
        d.ellipse((0, 0, size-1, size-1), fill=(*col, 220))
    else:
        d.rounded_rectangle((0, 0, size-1, size-1), RADIUS, fill=(*col, 220))
    d.text((size//2, size//2), "?",
           font=_font(size//2, True),
           fill=(255, 255, 255, 160), anchor="mm")
    return img

def _make_bg(w: int, h: int) -> Image.Image:
    img = Image.new("RGBA", (w, h), (90, 45, 130, 255))
    for y in range(h):
        t = y / h
        col = (int(90+60*t), int(45-10*t), int(130-20*t), 255)
        img.alpha_composite(Image.new("RGBA", (w, 1), col), (0, y))
    import random
    rng = random.Random(42)
    blobs = [
        (0.15, 0.25, 0.40, 0.45, (140, 60, 170), 80),
        (0.85, 0.65, 0.35, 0.40, (170, 50, 120), 70),
        (0.50, 0.50, 0.30, 0.35, (110, 55, 155), 60),
    ]
    for cx_f, cy_f, rx_f, ry_f, col, alpha in blobs:
        cx = int(cx_f * w) + rng.randint(-10, 10)
        cy = int(cy_f * h) + rng.randint(-8, 8)
        rx, ry = int(rx_f * w), int(ry_f * h)
        blob = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ImageDraw.Draw(blob).ellipse((cx-rx, cy-ry, cx+rx, cy+ry), fill=(*col, alpha))
        img.alpha_composite(blob.filter(ImageFilter.GaussianBlur(50)))
    return img


# ══════════════════════════════════════════════════════════════════════════════
#  TOP-3 CARD (giữ layout avatar fill trên, text bên dưới)
#  Fix: nền mờ glassmorphism, text area chia spacing line, count không tràn
# ══════════════════════════════════════════════════════════════════════════════
def _draw_top3_card(canvas: Image.Image, x: int, y: int, entry: dict):
    cw, ch = TOP3_CARD_W, TOP3_CARD_H
    rank   = entry["rank"]
    bg_map = {1: C_TOP1_BG, 2: C_TOP2_BG, 3: C_TOP3_BG}
    bg     = bg_map.get(rank, C_TOP3_BG)

    # Card background mờ (glassmorphism) + border nhẹ
    _rrect(canvas, (x, y, x+cw, y+ch), RADIUS, fill=bg)
    _rrect(canvas, (x, y, x+cw, y+ch), RADIUS, outline=C_BORDER, lw=2)

    # Avatar fill phía trên card
    av_size = cw - 20
    av_img  = _fetch_avatar(entry.get("avatar", ""), av_size, circle=False)
    if av_img is None:
        av_img = _placeholder(av_size, False, rank)

    # Mask bo góc trên, thẳng góc dưới
    mask = Image.new("L", (av_size, av_size), 0)
    md   = ImageDraw.Draw(mask)
    md.rounded_rectangle((0, 0, av_size-1, av_size-1), RADIUS, fill=255)
    md.rectangle((0, av_size-RADIUS-1, RADIUS, av_size-1), fill=255)
    md.rectangle((av_size-RADIUS-1, av_size-RADIUS-1, av_size-1, av_size-1), fill=255)
    av_out = Image.new("RGBA", (av_size, av_size), (0, 0, 0, 0))
    av_out.paste(av_img, mask=mask)
    canvas.alpha_composite(av_out, (x + 10, y + 10))

    # ── Text area bên dưới avatar ─────────────────────────────────────
    d    = ImageDraw.Draw(canvas, "RGBA")
    tx   = x + 14
    maxw = cw - 28     # chiều rộng tối đa cho text

    # Tính toán vùng text (từ dưới avatar đến hết card)
    av_bottom = y + 10 + av_size
    text_area_h = (y + ch) - av_bottom - 10   # chiều cao còn lại

    # 3 dòng: tên / rank / count — chia đều với spacing lines
    fn_name  = None
    name_raw = _safe_text(entry.get("name", "?"))

    # Tính các font size trước
    # Dòng 1: Tên (bold, auto-shrink 22→11)
    # Dòng 2: "Top N" (size 15)
    # Dòng 3: count (auto-shrink 15→10 để không tràn)
    fr   = _font(15)
    rlbl = f"Top {rank}"

    cnt_raw = f"{entry['count']:,} Tin Nhắn"
    # Auto shrink count text để không bao giờ tràn
    cnt_txt, fc = _auto_fit(d, cnt_raw, 15, 10, bold=False, maxw=maxw)

    # Auto shrink tên
    name_txt, fn = _auto_fit(d, name_raw, 22, 11, bold=True, maxw=maxw)

    nh = _th(d, name_txt, fn)
    rh = _th(d, rlbl,     fr)
    ch_cnt = _th(d, cnt_txt, fc)

    # Tổng chiều cao 3 dòng
    SPACING = 6   # khoảng cách giữa các dòng
    total_text_h = nh + SPACING + rh + SPACING + ch_cnt

    # Căn giữa dọc trong vùng text
    ty = av_bottom + (text_area_h - total_text_h) // 2
    if ty < av_bottom + 6:
        ty = av_bottom + 6

    # Vẽ dòng 1: Tên
    d.text((tx, ty), name_txt, font=fn, fill=C_NAME)

    # Spacing line nhẹ sau tên
    sep_y1 = ty + nh + SPACING // 2
    _hline(canvas, x + 10, x + cw - 10, sep_y1)

    # Vẽ dòng 2: Rank
    d.text((tx, ty + nh + SPACING), rlbl, font=fr, fill=C_RANK)

    # Spacing line nhẹ sau rank
    sep_y2 = ty + nh + SPACING + rh + SPACING // 2
    _hline(canvas, x + 10, x + cw - 10, sep_y2)

    # Vẽ dòng 3: Count
    d.text((tx, ty + nh + SPACING + rh + SPACING), cnt_txt, font=fc, fill=C_COUNT)

    # ── Icon rank góc trên-phải card ──────────────────────────────────
    ICON_SZ = 72
    icon_img = _load_rank_icon(entry.get("rank_icon"), ICON_SZ)
    if icon_img:
        ix = x + cw - ICON_SZ - 6
        iy = y + 6
        canvas.alpha_composite(icon_img, (ix, iy))


# ══════════════════════════════════════════════════════════════════════════════
#  SMALL ROW (top 4-15) — giữ layout, thêm spacing lines
# ══════════════════════════════════════════════════════════════════════════════
def _draw_row(canvas: Image.Image, x: int, y: int, w: int, entry: dict):
    rh = ROW_H
    _rrect(canvas, (x, y, x+w, y+rh), RADIUS, fill=C_ROW_BG)
    _rrect(canvas, (x, y, x+w, y+rh), RADIUS, outline=C_BORDER, lw=1)

    # Avatar tròn
    av_img = _fetch_avatar(entry.get("avatar", ""), ROW_AV, circle=True)
    if av_img is None:
        av_img = _placeholder(ROW_AV, True, entry["rank"])
    av_x = x + 12
    av_y = y + (rh - ROW_AV) // 2
    canvas.alpha_composite(av_img, (av_x, av_y))

    d    = ImageDraw.Draw(canvas, "RGBA")
    tx   = av_x + ROW_AV + 12
    maxw = x + w - tx - 10

    # Tên (bold, auto-shrink 20→11)
    name_raw = _safe_text(entry.get("name", "?"))
    name, fn = _auto_fit(d, name_raw, 20, 11, bold=True, maxw=maxw)
    nh = _th(d, name, fn)

    # Sub: "Top N  •  X Tin Nhắn" — auto shrink để không tràn
    fr      = _font(14)
    sub_raw = f"Top {entry['rank']}  •  {entry['count']:,} Tin Nhắn"
    sub, fs = _auto_fit(d, sub_raw, 14, 9, bold=False, maxw=maxw)
    sh = _th(d, sub, fs)

    # Spacing line nhẹ giữa tên và sub
    SPACING = 5
    total   = nh + SPACING + sh
    by      = y + (rh - total) // 2

    d.text((tx, by), name, font=fn, fill=C_NAME)

    # Spacing line
    _hline(canvas, tx, x + w - 8, by + nh + SPACING // 2)

    d.text((tx, by + nh + SPACING), sub, font=fs, fill=C_COUNT)

    # ── Icon rank bên phải row ────────────────────────────────────────
    ICON_SZ = 52
    icon_img = _load_rank_icon(entry.get("rank_icon"), ICON_SZ)
    if icon_img:
        ix = x + w - ICON_SZ - 8
        iy = y + (rh - ICON_SZ) // 2
        canvas.alpha_composite(icon_img, (ix, iy))


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
#  ENGINE JS (node-canvas) — vẽ song song bằng Node.js
# ══════════════════════════════════════════════════════════════════════════════
import json
import shutil
import subprocess

try:
    _PROJECT_ROOT = Path(__file__).resolve().parents[3]  # zbot/
    _JS_SCRIPT = _PROJECT_ROOT / "src" / "services" / "canvas" / "drawTopChat.js"
    _FONT_DIR = _PROJECT_ROOT / "assets" / "font"
except Exception:
    _PROJECT_ROOT = None
    _JS_SCRIPT = None
    _FONT_DIR = FONT_DIR


def draw_top_chat_js(entries: list, out_path: str,
                      title: str = "TOP CHAT") -> tuple:
    """
    Vẽ card Top Chat bằng node-canvas (gọi sang script JS qua subprocess).
    Trả về (width, height) như draw_top_chat (bản Pillow).

    Raises:
        RuntimeError: nếu thiếu `node` hoặc script JS lỗi.
    """
    node_bin = shutil.which("node")
    if not node_bin:
        raise RuntimeError("Không tìm thấy lệnh 'node' trong PATH.")
    if not _JS_SCRIPT or not _JS_SCRIPT.is_file():
        raise RuntimeError(f"Không tìm thấy script JS: {_JS_SCRIPT}")

    out_dir = os.path.dirname(out_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    payload = {
        "entries": entries or [],
        "title": title,
        "out_path": out_path,
        "font_dir": str(_FONT_DIR),
    }

    proc = subprocess.run(
        [node_bin, str(_JS_SCRIPT), json.dumps(payload, ensure_ascii=False)],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"drawTopChat.js lỗi: {proc.stderr.strip()}")

    out = proc.stdout.strip().split()
    if len(out) != 2:
        raise RuntimeError(f"drawTopChat.js trả về không hợp lệ: {proc.stdout!r}")
    return int(out[0]), int(out[1])


def draw_top_chat_auto(entries: list, out_path: str,
                        title: str = "TOP CHAT",
                        engine: str = "py") -> tuple:
    """
    Vẽ card Top Chat, chọn engine:
      - engine="py" (mặc định): dùng Pillow (draw_top_chat)
      - engine="js": dùng node-canvas (draw_top_chat_js), tự fallback
        về Pillow nếu Node/script lỗi.
    """
    engine = (engine or "py").lower()
    if engine == "js":
        try:
            return draw_top_chat_js(entries, out_path, title)
        except Exception as exc:
            logging.getLogger(__name__).warning(
                "[drawTopChat] JS engine lỗi (%s), fallback sang Pillow.", exc
            )
    return draw_top_chat(entries, out_path, title)


def draw_top_chat(entries: list, out_path: str,
                  title: str = "TOP CHAT") -> tuple:
    if not entries:
        entries = []

    top3 = entries[:3]
    rest = entries[3:]

    HEADER_H  = 70
    top3_row_h = TOP3_CARD_H if top3 else 0
    top3_row_w = len(top3) * TOP3_CARD_W + max(0, len(top3) - 1) * GAP

    ROW_W    = TOP3_CARD_W * 3 + GAP * 2
    cell_w   = (ROW_W - GAP * (COLS - 1)) // COLS
    rest_rows = math.ceil(len(rest) / COLS) if rest else 0
    rest_h    = rest_rows * ROW_H + max(0, rest_rows - 1) * GAP

    W = PAD * 2 + ROW_W
    H = (PAD
         + HEADER_H + GAP
         + top3_row_h + (GAP if top3_row_h else 0)
         + rest_h
         + PAD)

    canvas = _make_bg(W, H)
    d      = ImageDraw.Draw(canvas, "RGBA")

    # Header
    title_safe = _safe_text(title)
    fh  = _font(32, True)
    tw  = _tw(d, title_safe, fh)
    d.text(((W - tw) // 2, PAD + 16), title_safe, font=fh, fill=C_WHITE_A)
    _rrect(canvas,
           (PAD, PAD + HEADER_H - 4, W - PAD, PAD + HEADER_H),
           2, fill=C_WHITE_L)

    # Top 3
    y_top3  = PAD + HEADER_H + GAP
    x_start = PAD + (ROW_W - top3_row_w) // 2
    for i, entry in enumerate(top3):
        cx = x_start + i * (TOP3_CARD_W + GAP)
        _draw_top3_card(canvas, cx, y_top3, entry)

    # Rows top 4-15
    y_rest = y_top3 + (TOP3_CARD_H + GAP if top3 else 0)
    for i, entry in enumerate(rest):
        col = i % COLS
        row = i // COLS
        rx  = PAD + col * (cell_w + GAP)
        ry  = y_rest + row * (ROW_H + GAP)
        _draw_row(canvas, rx, ry, cell_w, entry)

    out_dir = os.path.dirname(out_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=95)
    return W, H