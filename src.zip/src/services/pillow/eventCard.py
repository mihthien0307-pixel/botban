from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
from pathlib import Path
import requests, os, datetime, random

W, H      = 1280, 400

# ── Welcome messages ngẫu nhiên (không cần API key) ──────────────────────────
_WELCOME_MSGS = [
    "Chào mừng bạn đến với nhóm! 🎉",
    "Rất vui khi có bạn ở đây! 👋",
    "Chào mừng thành viên mới! 🥳",
    "Hy vọng bạn vui vẻ ở đây nhé! 😄",
    "Có thêm người rồi, vui quá! 🎊",
    "Chào bạn mới! Cùng vui nha! 🌟",
    "Hân hạnh chào đón bạn! 💫",
    "Nhóm thêm thành viên xịn rồi! 🔥",
    "Welcome aboard! Chào mừng bạn! 🚀",
    "Vào nhóm rồi, cùng quẩy thôi! 🎶",
]

def _welcome_msg() -> str:
    return random.choice(_WELCOME_MSGS)

_FONT_DIR = Path("assets/font")

_font_cache: dict = {}
def _font(rel, size):
    key = (rel, size)
    if key not in _font_cache:
        _font_cache[key] = ImageFont.truetype(str(_FONT_DIR / rel), size)
    return _font_cache[key]

def _f_group():   return _font("Sarabun/Sarabun-Regular.ttf", 26)
def _f_name():    return _font("Opensans/static/Opensans/OpenSans-ExtraBold.ttf", 68)
def _f_sub():     return _font("Sarabun/Sarabun-Bold.ttf", 32)
def _f_sub2():    return _font("Sarabun/Sarabun-Regular.ttf", 26)
def _f_time():    return _font("Sarabun/Sarabun-Regular.ttf", 23)
def _f_badge():   return _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 22)
def _f_avbadge(): return _font("Opensans/static/Opensans/OpenSans-Bold.ttf", 22)
def _f_welcome(): return _font("Sarabun/Sarabun-Regular.ttf", 24)

_EMOJI_PATH = str(_FONT_DIR / "emoji2.ttf")
_ef_cache: dict = {}
_tofu_cache: dict = {}

def _efont(size):
    if not os.path.exists(_EMOJI_PATH): return None
    if size not in _ef_cache:
        try: _ef_cache[size] = ImageFont.truetype(_EMOJI_PATH, size)
        except: _ef_cache[size] = None
    return _ef_cache[size]

def _is_tofu(font, ch):
    try:
        k = id(font)
        if k not in _tofu_cache:
            bb = font.getbbox("\uFFFD")
            _tofu_cache[k] = (bb[2]-bb[0], bb[3]-bb[1])
        bb = font.getbbox(ch)
        return (bb[2]-bb[0], bb[3]-bb[1]) == _tofu_cache[k]
    except: return False

def _draw_text(draw, xy, text, font, fill):
    ef = _efont(font.size)
    x, y = xy
    for ch in text:
        gf = ef if (ef and _is_tofu(font, ch)) else font
        draw.text((x, y), ch, font=gf, fill=fill)
        try:
            bb = gf.getbbox(ch); x += bb[2]-bb[0]
        except: x += gf.size

def _measure(font, text):
    bb = font.getbbox(text)
    return bb[2]-bb[0], bb[3]-bb[1], bb[0], bb[1]

def _tw(font, text): return _measure(font, text)[0]

# ── Rounded rect mask ─────────────────────────────────────────────────────────
_mask_cache: dict = {}
def _rrect_mask(w, h, r, aa=4):
    key = (w, h, r)
    if key not in _mask_cache:
        m = Image.new("L", (w*aa, h*aa), 0)
        ImageDraw.Draw(m).rounded_rectangle((0,0,w*aa-1,h*aa-1), r*aa, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]

def _paste_rounded(canvas, img, pos, r):
    img  = img.convert("RGBA")
    mask = _rrect_mask(img.width, img.height, r)
    out  = Image.new("RGBA", img.size, (0,0,0,0))
    out.paste(img, mask=mask)
    canvas.alpha_composite(out, pos)

def _load_avatar(url, size):
    if url:
        try:
            r   = requests.get(url.strip(), timeout=4, headers={"User-Agent":"Mozilla/5.0"})
            img = Image.open(BytesIO(r.content)).convert("RGBA")
            iw, ih = img.size
            s = min(iw, ih)
            img = img.crop(((iw-s)//2,(ih-s)//2,(iw+s)//2,(ih+s)//2))
            return img.resize((size, size), Image.LANCZOS)
        except: pass
    # fallback avatar xám
    fb = Image.new("RGBA", (size, size), (180, 185, 200, 255))
    # vẽ silhouette đơn giản
    d  = ImageDraw.Draw(fb)
    cx, cy = size//2, size//2
    # đầu
    hr = size//5
    d.ellipse((cx-hr, cy//2-hr, cx+hr, cy//2+hr), fill=(220,222,230,255))
    # thân
    bw = size//3
    d.ellipse((cx-bw, cy+size//8, cx+bw, cy+size//2+size//5), fill=(220,222,230,255))
    return fb

# ── Gradient background ───────────────────────────────────────────────────────
def _gradient(w, h, stops):
    n   = len(stops)-1
    row = bytearray(w*4)
    for x in range(w):
        t   = x/(w-1)*n
        idx = min(int(t), n-1)
        loc = t-idx
        c0, c1 = stops[idx], stops[idx+1]
        for i in range(3):
            row[x*4+i] = int(c0[i]*(1-loc)+c1[i]*loc)
        row[x*4+3] = 255
    return Image.frombytes("RGBA", (w, h), bytes(row)*h)

_MODES = {
    "welcome":        {"bg":[(18,22,40),(45,28,72),(68,32,95)],        "accent":(0,185,225),      "badge_text":"WELCOME",   "av_badge_text":"Welcome"},
    "leave":          {"bg":[(22,22,34),(42,42,58),(58,58,76)],        "accent":(110,112,135),    "badge_text":"GOODBYE",   "av_badge_text":"Goodbye"},
    "kick":           {"bg":[(40,12,12),(70,18,26),(95,22,34)],        "accent":(218,40,40),      "badge_text":"REMOVED",   "av_badge_text":"Removed"},
    "kick_block":     {"bg":[(40,12,12),(70,18,26),(95,22,34)],        "accent":(218,40,40),      "badge_text":"BLOCKED",   "av_badge_text":"Blocked"},
    "add_admin":      {"bg":[(12,28,60),(16,54,95),(20,74,128)],       "accent":(30,148,235),     "badge_text":"PROMOTED",  "av_badge_text":"Admin+"},
    "remove_admin":   {"bg":[(40,22,10),(72,44,15),(95,60,18)],        "accent":(208,118,18),     "badge_text":"DEMOTED",   "av_badge_text":"Demoted"},
    "update":         {"bg":[(12,26,58),(18,48,92),(26,64,120)],       "accent":(40,128,210),     "badge_text":"UPDATED",   "av_badge_text":"Update"},
    "update_setting": {"bg":[(22,15,50),(46,30,82),(62,42,110)],       "accent":(132,80,210),     "badge_text":"SETTINGS",  "av_badge_text":"Setting"},
    "join_request":   {"bg":[(12,38,28),(18,72,50),(22,95,68)],        "accent":(30,188,108),     "badge_text":"REQUEST",   "av_badge_text":"Request"},
    "new_link":       {"bg":[(18,20,60),(36,32,102),(50,42,130)],      "accent":(80,85,230),      "badge_text":"NEW LINK",  "av_badge_text":"New Link"},
}

_bg_cache: dict = {}
def _get_bg(mode):
    if mode not in _bg_cache:
        _bg_cache[mode] = _gradient(W, H, _MODES.get(mode, _MODES["welcome"])["bg"])
    return _bg_cache[mode].copy()

def _badge(canvas, text, color, right_x, y):
    f = _f_badge()
    tw, th, tlo, tto = _measure(f, text)
    px, py = 20, 8
    bw, bh = tw+px*2, th+py*2
    img = Image.new("RGBA", (bw, bh), (0,0,0,0))
    ImageDraw.Draw(img).rounded_rectangle((0,0,bw-1,bh-1), bh//2, fill=(*color,255))
    ImageDraw.Draw(img).text((px-tlo, py-tto), text, font=f, fill=(255,255,255,255))
    canvas.alpha_composite(img, (right_x-bw, y))

def _av_badge(canvas, text, color, cx, bottom_y):
    f = _f_avbadge()
    tw, th, tlo, tto = _measure(f, text)
    px, py = 20, 8
    bw, bh = tw+px*2, th+py*2
    img = Image.new("RGBA", (bw, bh), (0,0,0,0))
    ImageDraw.Draw(img).rounded_rectangle((0,0,bw-1,bh-1), bh//2, fill=(*color,255))
    ImageDraw.Draw(img).text((px-tlo, py-tto), text, font=f, fill=(255,255,255,255))
    canvas.alpha_composite(img, (cx-bw//2, bottom_y-bh+10))


def draw_event_card(data: dict, out_path: str, mode: str = "welcome") -> str:
    cfg    = _MODES.get(mode, _MODES["welcome"])
    accent = cfg["accent"]
    canvas = _get_bg(mode)
    d      = ImageDraw.Draw(canvas)

    # ── Welcome message ngẫu nhiên ───────────────────────────────────────────
    ai_msg = ""
    if mode == "welcome":
        ai_msg = _welcome_msg()


    # ── Layout constants ──────────────────────────────────────────────────────
    CM   = 40   # margin ngang
    CMY  = 32   # margin dọc
    CP   = 24
    CR   = 22

    # Card bounds
    cx1, cy1 = CM, CMY
    cx2, cy2 = W-CM, H-CMY
    cw, ch   = cx2-cx1, cy2-cy1

    # ── Outer card ───────────────────────────────────────────────────────────
    card = Image.new("RGBA", (cw, ch), (0,0,0,0))
    ImageDraw.Draw(card).rounded_rectangle(
        (0,0,cw-1,ch-1), CR, fill=(255,255,255,25))
    canvas.alpha_composite(card, (cx1, cy1))

    # ── 4 tia góc card màu trắng ─────────────────────────────────────────────
    CL = 28   # chiều dài tia góc
    CT = 2    # độ dày
    corners = [
        # top-left
        [(cx1+CR, cy1, cx1+CR+CL, cy1), (cx1, cy1+CR, cx1, cy1+CR+CL)],
        # top-right
        [(cx2-CR, cy1, cx2-CR-CL, cy1), (cx2, cy1+CR, cx2, cy1+CR+CL)],
        # bottom-left
        [(cx1+CR, cy2, cx1+CR+CL, cy2), (cx1, cy2-CR, cx1, cy2-CR-CL)],
        # bottom-right
        [(cx2-CR, cy2, cx2-CR-CL, cy2), (cx2, cy2-CR, cx2, cy2-CR-CL)],
    ]
    for lines in corners:
        for line in lines:
            d.line(line, fill=(255,255,255,160), width=CT)

    # ── Pre-measure text để tính tổng chiều cao block ────────────────────────
    gf   = _f_group();  gt   = data.get("group_name","")
    nf   = _f_name();   ntxt_raw = data.get("name","")
    sf   = _f_sub();    sub  = data.get("sub","")
    sf2  = _f_sub2()
    by   = data.get("actor_name","") or data.get("by_name","")
    wf   = _f_welcome()

    gw, gh, glo, gto = _measure(gf, gt)

    TR_tmp = cx2 - CP
    ax_tmp = cx1 + CP
    # tạm tính TX để biết maxw
    AV_tmp = int((ch - CP*2) * 0.88)
    TX_tmp = ax_tmp + AV_tmp + 3 + CP + 8
    maxw   = TR_tmp - TX_tmp - 8

    ntxt = ntxt_raw
    while ntxt and _tw(nf, ntxt) > maxw:
        ntxt = ntxt[:-1]
    if ntxt != ntxt_raw:
        ntxt = ntxt.rstrip() + "…"
    nw, nh, nlo, nto = _measure(nf, ntxt)

    sh = _measure(sf, sub)[1]  if sub else 0
    s2h_by = _measure(sf2, f"By {by}")[1] if by else 0
    wh = _measure(wf, ai_msg)[1] if ai_msg else 0

    GAP = 4
    total_text_h = gh + GAP + nh + (GAP + sh if sub else 0) + (GAP + s2h_by if by else 0) + (GAP + wh if ai_msg else 0)

    # Avatar size = tổng chiều cao text block (để bằng nhau)
    AV   = max(total_text_h, int((ch - CP*2) * 0.75))
    AV   = min(AV, ch - CP*2)   # không vượt card
    AV_R = 16
    BRD  = 3

    # Căn giữa dọc cả block (avatar + text) trong card
    content_h = max(AV, total_text_h)
    top_y     = cy1 + (ch - content_h) // 2
    # Đảm bảo không bị quá sát mép
    top_y     = max(top_y, cy1 + CP)

    ax = cx1 + CP
    ay = top_y  # avatar bắt đầu từ top của content block

    # ── Vẽ avatar ────────────────────────────────────────────────────────────
    brd_img = Image.new("RGBA", (AV+BRD*2, AV+BRD*2), (0,0,0,0))
    ImageDraw.Draw(brd_img).rounded_rectangle(
        (0,0,AV+BRD*2-1,AV+BRD*2-1), AV_R+3, fill=(*accent,200))
    canvas.alpha_composite(brd_img, (ax-BRD, ay-BRD))

    av = _load_avatar(data.get("avatar_url",""), AV)
    _paste_rounded(canvas, av, (ax, ay), AV_R)

    _av_badge(canvas, cfg["av_badge_text"], accent, ax + AV//2, ay + AV)

    # ── Đường kẻ dọc giữa avatar và text (ngắn bằng avatar) ─────────────────
    vline_x      = ax + AV + BRD + CP // 2 + 2
    vline_top    = ay
    vline_bottom = ay + AV
    # vẽ gradient dọc: fade in → sáng giữa → fade out
    for i in range(vline_top, vline_bottom + 1):
        t     = (i - vline_top) / max(vline_bottom - vline_top, 1)
        alpha = int(180 * (1 - abs(t * 2 - 1) ** 1.5))
        mix   = 1 - abs(t * 2 - 1)
        r2 = min(255, accent[0] + int((255 - accent[0]) * mix))
        g2 = min(255, accent[1] + int((255 - accent[1]) * mix))
        b2 = min(255, accent[2] + int((255 - accent[2]) * mix))
        d.line((vline_x, i, vline_x, i), fill=(r2, g2, b2, alpha), width=1)

    # ── Text area — căn giữa dọc theo avatar ─────────────────────────────────
    TX  = vline_x + CP // 2 + 6
    TR  = cx2 - CP
    # text bắt đầu từ giữa card dọc — căn theo toàn bộ ch
    TT  = cy1 + (ch - total_text_h) // 2

    # badge góc phải trên của card (không phụ thuộc vào TT)
    _badge(canvas, cfg["badge_text"], accent, cx2 - CP, cy1 + CP - 4)

    # group name — bắt đầu từ TT đã căn giữa
    gw, gh, glo, gto = _measure(gf, gt)
    d.text((TX-glo, TT-gto), gt, font=gf, fill=(175,178,208,185))

    # đường kẻ ngang dưới tên nhóm (ngắn bằng chiều rộng text)
    line_y  = TT + gh + 4
    line_x2 = TX + gw + 40  # chút padding sau tên nhóm
    for i in range(TX, line_x2 + 1):
        t     = (i - TX) / max(line_x2 - TX, 1)
        alpha = int(180 * (1 - t ** 1.5))
        mix   = 1 - t
        r2 = min(255, accent[0] + int((255 - accent[0]) * mix * 0.6))
        g2 = min(255, accent[1] + int((255 - accent[1]) * mix * 0.6))
        b2 = min(255, accent[2] + int((255 - accent[2]) * mix * 0.6))
        d.line((i, line_y, i, line_y), fill=(r2, g2, b2, alpha), width=1)

    # name
    ny = line_y + GAP + 2
    _draw_text(d, (TX-nlo, ny-nto), ntxt, nf, (255,255,255,255))

    # sub
    sy = ny + nh + GAP
    if sub:
        sw, sh, slo, sto = _measure(sf, sub)
        _draw_text(d, (TX-slo, sy-sto), sub, sf, (*accent, 230))
        sy += sh + GAP

    # By actor
    if by:
        by_txt = f"By {by}"
        s2w, s2h, s2lo, s2to = _measure(sf2, by_txt)
        _draw_text(d, (TX-s2lo, sy-s2to), by_txt, sf2, (168,172,205,200))
        sy += s2h + GAP

    # sub2
    sub2 = data.get("sub2","")
    if sub2:
        s2w,s2h,s2lo,s2to = _measure(sf2, sub2)
        _draw_text(d, (TX-s2lo, sy-s2to), sub2, sf2, (168,172,205,200))
        sy += s2h + GAP

    # welcome msg
    if ai_msg:
        ww, wh, wlo, wto = _measure(wf, ai_msg)
        _draw_text(d, (TX-wlo, sy-wto), ai_msg, wf, (*accent, 200))

    # bottom: time | by name
    tf    = _f_time()
    bot_y = cy2 - CP + 8
    ts    = datetime.datetime.now().strftime("%H:%M  %d/%m/%Y")
    tw2,th2,tl2,tt2 = _measure(tf, ts)
    d.text((TX-tl2, bot_y-th2-tt2), ts, font=tf, fill=(138,142,172,165))

    if by:
        bt = f"by {by}"
        bw2,bh2,bl2,bt2 = _measure(tf, bt)
        d.text((TR-bw2-bl2, bot_y-bh2-bt2), bt, font=tf, fill=(138,142,172,165))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=93)
    return out_path
