"""
mybotDraw.py – Canvas cho lệnh .mybot
Style: dark navy + purple gradient, glow effects, glassmorphism cards.
Tác giả: zBot | emoji font: assets/font/emoji.ttf
"""

import os, math
from pathlib import Path
from io import BytesIO
import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter
try:
    from fontTools.ttLib import TTFont as _TTFont
except Exception:
    _TTFont = None

# ── Canvas ───────────────────────────────────────────────────────────────────
W = 1200
H = 900  # default, bị ghi đè động trong _new_canvas(h)

# ── Palette ──────────────────────────────────────────────────────────────────
# Background gradient navy → dark purple
BG_TOP    = (10, 14, 35)
BG_MID    = (14, 12, 32)
BG_BOT    = (8,  10, 28)

# Rainbow top bar
RAINBOW = [
    (255, 60, 120), (255, 130, 40), (240, 215, 30),
    (50, 210, 80),  (40, 185, 255), (110, 70, 255), (195, 50, 255),
]

# Glow colours
GLOW_PURPLE = (100, 60, 200)
GLOW_CYAN   = (20, 180, 200)

# Header title — cyan gradient
TITLE_COLORS = [
    (70, 255, 215), (75, 248, 205), (80, 240, 195),
    (85, 232, 185), (75, 220, 170), (70, 208, 160),
]
C_SUBTITLE  = (75, 175, 255)

# Card
GLASS_BG    = (255, 255, 255, 18)
GLASS_EDGE  = (255, 255, 255, 38)
INNER_BG    = (255, 255, 255, 8)

# Section accents
ACCENT = {
    "pink":   (235, 55, 135),
    "blue":   (55, 135, 255),
    "cyan":   (35, 205, 195),
    "orange": (255, 185, 35),
    "purple": (160, 75, 255),
}

# Text
C_WHITE     = (255, 255, 255)
C_DIM       = (175, 185, 210)
C_BULLET    = (50, 215, 130)
C_CMD       = (220, 225, 245)   # command part
C_DESC      = (155, 165, 195)   # description part after ":"
C_FOOTER    = (120, 105, 195)

# Icon btn
BTN_BG      = (45, 50, 72, 210)

# ── Fonts ─────────────────────────────────────────────────────────────────────
_ROOT     = Path(__file__).resolve().parents[3]
_FD       = _ROOT / "assets" / "font"

_PATHS = {
    "title":    str(_FD / "Goldman" / "Goldman-Bold.ttf"),
    "bold":     str(_FD / "Sarabun" / "Sarabun-ExtraBold.ttf"),
    "regular":  str(_FD / "Sarabun" / "Sarabun-Regular.ttf"),
    "emoji":    str(_FD / "emoji.ttf"),
}
_fc: dict = {}

def _f(size: int, style: str = "regular") -> ImageFont.FreeTypeFont:
    k = (size, style)
    if k in _fc:
        return _fc[k]
    path = _PATHS.get(style, _PATHS["regular"])
    try:
        f = ImageFont.truetype(path, size)
    except Exception:
        f = ImageFont.load_default()
    _fc[k] = f
    return f

def _tw(d, text, font):
    bb = d.textbbox((0, 0), text, font=font)
    return bb[2] - bb[0]

def _th(d, text, font):
    bb = d.textbbox((0, 0), text, font=font)
    return bb[3] - bb[1]

# ── Font cmap (lọc ký tự lạ gây ô vuông □) ─────────────────────────────────────
_cmap_cache: dict = {}

def _font_cmap(path: str):
    if path in _cmap_cache:
        return _cmap_cache[path]
    cmap = None
    if _TTFont is not None:
        try:
            tt = _TTFont(path, lazy=True, fontNumber=0)
            cmap = set()
            for table in tt["cmap"].tables:
                cmap.update(table.cmap.keys())
        except Exception:
            cmap = None
    _cmap_cache[path] = cmap
    return cmap

def _sanitize_text(text, style: str = "bold") -> str:
    """Bỏ các ký tự (emoji/symbol lạ) mà font không có glyph → tránh hiện ô vuông □."""
    if not text:
        return text
    path = _PATHS.get(style, _PATHS["regular"])
    cmap = _font_cmap(path)
    if cmap is None:
        return text
    out = []
    for ch in text:
        cp = ord(ch)
        if ch.isspace() or cp in cmap:
            out.append(ch)
    cleaned = "".join(out).strip()
    return cleaned or text

# ── Background ────────────────────────────────────────────────────────────────

def _make_bg(h: int) -> Image.Image:
    img = Image.new("RGBA", (W, h), (0, 0, 0, 255))
    px = img.load()

    # Smooth 3-stop vertical gradient
    for y in range(h):
        t = y / h
        if t < 0.5:
            s = t * 2
            r = int(BG_TOP[0] + (BG_MID[0] - BG_TOP[0]) * s)
            g = int(BG_TOP[1] + (BG_MID[1] - BG_TOP[1]) * s)
            b = int(BG_TOP[2] + (BG_MID[2] - BG_TOP[2]) * s)
        else:
            s = (t - 0.5) * 2
            r = int(BG_MID[0] + (BG_BOT[0] - BG_MID[0]) * s)
            g = int(BG_MID[1] + (BG_BOT[1] - BG_MID[1]) * s)
            b = int(BG_MID[2] + (BG_BOT[2] - BG_MID[2]) * s)
        for x in range(W):
            px[x, y] = (r, g, b, 255)

    # Big radial glow — bottom left purple
    glow1 = Image.new("RGBA", (W, h), (0, 0, 0, 0))
    ImageDraw.Draw(glow1).ellipse(
        (-200, h // 2, W // 2, h + 200),
        fill=(*GLOW_PURPLE, 38)
    )
    img.alpha_composite(glow1.filter(ImageFilter.GaussianBlur(160)))

    # Top right cyan glow
    glow2 = Image.new("RGBA", (W, h), (0, 0, 0, 0))
    ImageDraw.Draw(glow2).ellipse(
        (W // 2, -200, W + 200, h // 2),
        fill=(*GLOW_CYAN, 28)
    )
    img.alpha_composite(glow2.filter(ImageFilter.GaussianBlur(180)))

    # Subtle vignette — darken edges
    vign = Image.new("RGBA", (W, h), (0, 0, 0, 0))
    for i in range(80):
        alpha = int(80 * (1 - i / 80) ** 2)
        vd = ImageDraw.Draw(vign)
        vd.rectangle((i, i, W - i - 1, h - i - 1), outline=(0, 0, 0, alpha))
    img.alpha_composite(vign)

    return img

def _rainbow_bar(img: Image.Image, bar_h: int = 5):
    layer = Image.new("RGBA", (W, bar_h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    n = len(RAINBOW) - 1
    seg = W / n
    for i in range(n):
        x0, x1 = int(i * seg), int((i + 1) * seg) + 1
        c0, c1 = RAINBOW[i], RAINBOW[i + 1]
        for x in range(x0, min(x1, W)):
            t = (x - x0) / max(x1 - x0, 1)
            r = int(c0[0] + (c1[0] - c0[0]) * t)
            g = int(c0[1] + (c1[1] - c0[1]) * t)
            b = int(c0[2] + (c1[2] - c0[2]) * t)
            d.line([(x, 0), (x, bar_h - 1)], fill=(r, g, b, 255))
    # Glow below bar
    glow = layer.filter(ImageFilter.GaussianBlur(4))
    img.alpha_composite(glow, (0, 0))
    img.alpha_composite(layer, (0, 0))

# ── Glass helpers ─────────────────────────────────────────────────────────────

def _glass(img: Image.Image, x1, y1, x2, y2, r=20,
           fill=GLASS_BG, edge=GLASS_EDGE, shadow=True):
    cw, ch = x2 - x1, y2 - y1
    if cw <= 0 or ch <= 0:
        return

    # Drop shadow
    if shadow:
        sh = Image.new("RGBA", (cw + 40, ch + 40), (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle(
            (20, 20, cw + 19, ch + 19), r + 4, fill=(0, 0, 0, 60)
        )
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(18)),
                            (x1 - 20, y1 - 20))

    # Glass fill
    layer = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    dl = ImageDraw.Draw(layer)
    dl.rounded_rectangle((0, 0, cw - 1, ch - 1), r, fill=fill)
    dl.rounded_rectangle((0, 0, cw - 1, ch - 1), r,
                          outline=edge, width=1)

    # Inner top highlight (subtle)
    hl = Image.new("RGBA", (cw, 3), (0, 0, 0, 0))
    ImageDraw.Draw(hl).line([(r, 0), (cw - r, 0)], fill=(255, 255, 255, 28))
    layer.alpha_composite(hl, (0, 1))

    img.alpha_composite(layer, (x1, y1))

def _accent_bar(img: Image.Image, x, y1, y2, color, w=4, r=3):
    # Glow
    gw = Image.new("RGBA", (w + 12, y2 - y1), (0, 0, 0, 0))
    ImageDraw.Draw(gw).rectangle((0, 0, w + 11, y2 - y1 - 1),
                                  fill=(*color, 40))
    img.alpha_composite(gw.filter(ImageFilter.GaussianBlur(6)), (x - 4, y1))
    # Bar
    bar = Image.new("RGBA", (w, y2 - y1), (0, 0, 0, 0))
    ImageDraw.Draw(bar).rounded_rectangle(
        (0, 0, w - 1, y2 - y1 - 1), r, fill=(*color, 255)
    )
    img.alpha_composite(bar, (x, y1))

def _circle_btn(img: Image.Image, cx, cy, rad, symbol, fg=(190, 195, 220),
                glow_color=None):
    sz = rad * 2
    layer = Image.new("RGBA", (sz + 20, sz + 20), (0, 0, 0, 0))
    dl = ImageDraw.Draw(layer)
    # Glow ring
    if glow_color:
        dl.ellipse((4, 4, sz + 15, sz + 15), outline=(*glow_color, 55), width=2)
    # Button body
    dl.ellipse((10, 10, sz + 9, sz + 9), fill=BTN_BG)
    # Symbol
    fe = _f(rad - 2, "emoji")
    bb = dl.textbbox((0, 0), symbol, font=fe)
    tw_ = bb[2] - bb[0]; th_ = bb[3] - bb[1]
    tx = 10 + rad - tw_ // 2
    ty = 10 + rad - th_ // 2 - 2
    dl.text((tx, ty), symbol, font=fe, fill=(*fg, 245))
    img.alpha_composite(layer, (cx - rad - 10, cy - rad - 10))

# ── Header ────────────────────────────────────────────────────────────────────

def _draw_header(img: Image.Image, d: ImageDraw.ImageDraw,
                 title: str, subtitle: str) -> int:
    PAD = 52
    hx1, hy1 = PAD, 48
    hx2, hy2 = W - PAD, 230

    _glass(img, hx1, hy1, hx2, hy2, r=22,
           fill=(255, 255, 255, 16), edge=(255, 255, 255, 42))

    mid_y = (hy1 + hy2) // 2

    # ⚡ left button  
    _circle_btn(img, hx1 + 55, mid_y, 34, "⚡",
                fg=(220, 220, 230), glow_color=(100, 120, 200))
    # 👑 right button
    _circle_btn(img, hx2 - 55, mid_y, 34, "👑",
                fg=(180, 80, 220), glow_color=(140, 60, 200))

    # Title — Goldman Bold, per-char color
    ft = _f(70, "title")
    title_up = title.upper()
    tw_total = _tw(d, title_up, ft)
    tx = (W - tw_total) // 2
    ty = hy1 + 20

    # Cyan glow behind title
    glow_t = Image.new("RGBA", (W, 100), (0, 0, 0, 0))
    ImageDraw.Draw(glow_t).text(
        (tx, ty), title_up, font=ft, fill=(60, 220, 200, 80)
    )
    img.alpha_composite(glow_t.filter(ImageFilter.GaussianBlur(12)), (0, 0))

    # Draw chars with gradient
    cx_ = tx
    for i, ch in enumerate(title_up):
        col = TITLE_COLORS[min(i, len(TITLE_COLORS) - 1)]
        d.text((cx_, ty), ch, font=ft, fill=(*col, 255))
        cx_ += _tw(d, ch, ft)

    # Subtitle
    fs = _f(28, "regular")
    sw = _tw(d, subtitle, fs)
    d.text(((W - sw) // 2, ty + 84), subtitle,
           font=fs, fill=(*C_SUBTITLE, 220))

    # Divider line
    sep_y = hy2 + 16
    div = Image.new("RGBA", (W - PAD * 2 - 20, 1), (0, 0, 0, 0))
    ImageDraw.Draw(div).line([(0, 0), (W - PAD * 2 - 21, 0)],
                              fill=(255, 255, 255, 30))
    img.alpha_composite(div, (PAD + 10, sep_y))

    return hy2 + 32

# ── Section card ──────────────────────────────────────────────────────────────

def _draw_section(img: Image.Image, d: ImageDraw.ImageDraw,
                  y_start: int, icon: str, title: str,
                  items: list[tuple], accent_key: str) -> int:
    """
    items: list of (cmd_part, desc_part) tuples
    e.g. (".mybot qrlogin", "Đăng nhập bằng mã QR")
    """
    PAD_X  = 52
    IL     = 28          # indent left inside card
    LINE_H = 54
    V_TOP  = 22
    V_BOT  = 18
    ICON_SZ  = 34
    TITLE_SZ = 33
    CMD_SZ   = 26

    accent_color = ACCENT.get(accent_key, ACCENT["blue"])
    card_h = V_TOP + ICON_SZ + 18 + len(items) * LINE_H + V_BOT

    x1, y1 = PAD_X, y_start
    x2, y2 = W - PAD_X, y1 + card_h

    _glass(img, x1, y1, x2, y2, r=16,
           fill=(255, 255, 255, 14), edge=(255, 255, 255, 32))

    # Accent bar left
    _accent_bar(img, x1, y1 + 10, y2 - 10, accent_color, w=4)

    # Icon + title row  — dùng bold font cho icon để tránh bị vuông
    ty = y1 + V_TOP
    fe  = _f(ICON_SZ, "bold")
    ft2 = _f(TITLE_SZ, "bold")

    iw = _tw(d, icon, fe)
    d.text((x1 + IL + 10, ty), icon, font=fe, fill=(*accent_color, 255))

    # Title glow
    glow_s = Image.new("RGBA", (W, 60), (0, 0, 0, 0))
    ImageDraw.Draw(glow_s).text(
        (x1 + IL + 10 + iw + 14, ty), title,
        font=ft2, fill=(*accent_color, 60)
    )
    img.alpha_composite(glow_s.filter(ImageFilter.GaussianBlur(8)), (0, y1 + V_TOP - 10))
    d.text((x1 + IL + 10 + iw + 14, ty), title,
           font=ft2, fill=(*accent_color, 255))

    # Items
    fc  = _f(CMD_SZ, "bold")
    fd  = _f(CMD_SZ, "regular")
    iy  = ty + ICON_SZ + 18

    for cmd_part, desc_part in items:
        # Bullet dot with glow
        bx = x1 + IL + 22
        by = iy + LINE_H // 2 - 8

        dot_g = Image.new("RGBA", (24, 24), (0, 0, 0, 0))
        ImageDraw.Draw(dot_g).ellipse((0, 0, 23, 23), fill=(*C_BULLET, 50))
        img.alpha_composite(dot_g.filter(ImageFilter.GaussianBlur(4)),
                            (bx - 4, by - 4))
        dot = Image.new("RGBA", (14, 14), (0, 0, 0, 0))
        ImageDraw.Draw(dot).ellipse((0, 0, 13, 13), fill=(*C_BULLET, 255))
        img.alpha_composite(dot, (bx, by))

        # "> cmd: desc" — styled
        text_x = bx + 26
        text_y = iy + (LINE_H - CMD_SZ) // 2

        full = f"> {cmd_part}: {desc_part}"
        # Measure to split colour zones
        arrow_txt = "> "
        cmd_txt   = cmd_part + ":"
        sp_txt    = " "
        desc_txt  = desc_part

        fw_a  = _tw(d, arrow_txt, fc)
        fw_c  = _tw(d, cmd_txt, fc)
        fw_sp = _tw(d, sp_txt, fd)

        d.text((text_x,            text_y), arrow_txt, font=fc, fill=(100, 200, 255, 200))
        d.text((text_x + fw_a,     text_y), cmd_txt,   font=fc, fill=(*C_CMD, 240))
        d.text((text_x + fw_a + fw_c + fw_sp, text_y),
               desc_txt, font=fd, fill=(*C_DESC, 210))

        iy += LINE_H

    return y2 + 22

# ── Footer ────────────────────────────────────────────────────────────────────

def _draw_footer(img: Image.Image, d: ImageDraw.ImageDraw, y: int):
    PAD = 52
    h   = img.height
    fy  = max(y + 20, h - 55)
    div = Image.new("RGBA", (W - PAD * 2, 1), (0, 0, 0, 0))
    ImageDraw.Draw(div).line([(0, 0), (W - PAD * 2 - 1, 0)],
                              fill=(255, 255, 255, 22))
    img.alpha_composite(div, (PAD, fy - 16))

    fe = _f(24, "regular")
    ft = _f(24, "regular")
    txt_star  = "* "
    txt_main  = "MyBot VIP Panel"
    txt_star2 = " *"

    ws1 = _tw(d, txt_star, fe)
    wm  = _tw(d, txt_main, ft)
    ws2 = _tw(d, txt_star2, fe)
    total_w = ws1 + wm + ws2
    tx = (W - total_w) // 2

    d.text((tx,              fy), txt_star,  font=fe, fill=(*C_FOOTER, 200))
    d.text((tx + ws1,        fy), txt_main,  font=ft, fill=(*C_FOOTER, 200))
    d.text((tx + ws1 + wm,   fy), txt_star2, font=fe, fill=(*C_FOOTER, 200))

# ── Canvas factory ────────────────────────────────────────────────────────────

def _calc_height(n_sections: list[int]) -> int:
    """Tính chiều cao canvas dựa vào số items mỗi section."""
    HEADER_H = 230 + 32        # hy2 + 32
    LINE_H   = 54
    V_TOP    = 22
    V_BOT    = 18
    ICON_SZ  = 34
    GAP      = 22              # khoảng cách giữa các card
    FOOTER_H = 80
    PAD_BOT  = 30

    total = HEADER_H
    for n_items in n_sections:
        card_h = V_TOP + ICON_SZ + 18 + n_items * LINE_H + V_BOT
        total += card_h + GAP
    total += FOOTER_H + PAD_BOT
    return max(total, 600)

def _new_canvas(n_sections: list[int] | None = None):
    h = _calc_height(n_sections) if n_sections else H
    img = _make_bg(h)
    _rainbow_bar(img)
    d = ImageDraw.Draw(img, "RGBA")
    return img, d

def _save(img: Image.Image, out_path: str) -> tuple:
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=95, optimize=False)
    return img.width, img.height

# ── Public screens ────────────────────────────────────────────────────────────

def draw_mybot_panel(out_path: str, cmdb: str = "?mybot") -> tuple:
    """Menu chính khi gọi ?mybot (không có sub-lệnh)."""
    img, d = _new_canvas([2, 3])

    y = _draw_header(img, d,
                     title="MyBot Panel",
                     subtitle="🤖 Hệ thống quản lý bot đa năng")

    y = _draw_section(img, d, y,
                      icon=">>", title="Tạo / Đăng nhập Bot",
                      items=[
                          (f"{cmdb} qrlogin",           "Đăng nhập bằng mã QR"),
                          (f"{cmdb} login imei cookie", "Đăng nhập bằng data thủ công"),
                      ],
                      accent_key="cyan")

    y = _draw_section(img, d, y,
                      icon=">>", title="Trợ giúp & Hướng dẫn",
                      items=[
                          (f"{cmdb} help",    "Hướng dẫn căn bản"),
                          (f"{cmdb} qtv",     "Lệnh dành cho QTV"),
                          (f"{cmdb} manager", "Quản lý hệ thống (Main Bot)"),
                      ],
                      accent_key="purple")

    _draw_footer(img, d, y)
    return _save(img, out_path)


def draw_mybot_help(out_path: str, cmdb: str = "?mybot") -> tuple:
    """Canvas hướng dẫn căn bản (?mybot help)."""
    img, d = _new_canvas([5, 4])

    y = _draw_header(img, d,
                     title="MyBot Help",
                     subtitle="📘 Hướng dẫn sử dụng lệnh cơ bản")

    y = _draw_section(img, d, y,
                      icon=">>", title="Lệnh Cơ Bản",
                      items=[
                          (f"{cmdb} list",              "Xem danh sách bot"),
                          (f"{cmdb} detail [index]",    "Xem chi tiết bot"),
                          (f"{cmdb} start [index]",     "Khởi động bot"),
                          (f"{cmdb} restart [index]",   "Khởi động lại bot"),
                          (f"{cmdb} shutdown [index]",  "Tắt bot"),
                      ],
                      accent_key="blue")

    y = _draw_section(img, d, y,
                      icon=">>", title="Cài Đặt Bot",
                      items=[
                          (f"{cmdb} prefix [bot] [prefix]", "Đổi prefix lệnh"),
                          (f"{cmdb} nameserver [tên]",      "Đổi tên server"),
                          (f"{cmdb} login web|pc",          "Đổi loại đăng nhập"),
                          (f"{cmdb} server",                "Xem URL server"),
                      ],
                      accent_key="orange")

    _draw_footer(img, d, y)
    return _save(img, out_path)


def draw_mybot_qtv(out_path: str, cmdb: str = "?mybot") -> tuple:
    """Canvas lệnh dành cho QTV (?mybot qtv)."""
    img, d = _new_canvas([4, 4])

    y = _draw_header(img, d,
                     title="MyBot QTV",
                     subtitle="⚙️ Lệnh dành cho Quản Trị Viên")

    y = _draw_section(img, d, y,
                      icon=">>", title="Trạng Thái Bot",
                      items=[
                          (f"{cmdb} detail [index]",   "Xem chi tiết bot"),
                          (f"{cmdb} start [index]",    "Khởi động bot"),
                          (f"{cmdb} stop [index]",     "Dừng bot"),
                          (f"{cmdb} restart [index]",  "Khởi động lại bot"),
                      ],
                      accent_key="pink")

    y = _draw_section(img, d, y,
                      icon=">>", title="Quản Lý Credentials",
                      items=[
                          (f"{cmdb} update [imei] [cookie]", "Cập nhật data đăng nhập"),
                          (f"{cmdb} getupdate",              "Cập nhật bằng mã QR"),
                          (f"{cmdb} nameserver [tên mới]",   "Đổi tên server"),
                          (f"{cmdb} delete",                 "Xóa bot"),
                      ],
                      accent_key="cyan")

    _draw_footer(img, d, y)
    return _save(img, out_path)


def draw_mybot_manager(out_path: str, server_name: str = "Server", cmdb: str = "?mybot") -> tuple:
    """Canvas quản trị nâng cao (?mybot manager – Main Bot only)."""
    img, d = _new_canvas([4, 2, 2])

    y = _draw_header(img, d,
                     title="Bot Manager",
                     subtitle=f"🏠 Quản lý hệ thống · {server_name}")

    y = _draw_section(img, d, y,
                      icon=">>", title="Quyền Quản Trị",
                      items=[
                          (f"{cmdb} delete [index/@bot]",      "Xóa bot khỏi hệ thống"),
                          (f"{cmdb} changeowner [index/@bot]", "Đổi chủ sở hữu bot"),
                          (f"{cmdb} update [index] [imei]",    "Cập nhật credentials"),
                          (f"{cmdb} start [index] 1h",         "Kích hoạt bot + thời hạn"),
                      ],
                      accent_key="pink")

    y = _draw_section(img, d, y,
                      icon=">>", title="Quản Lý Nhóm",
                      items=[
                          (f"{cmdb} group set",    "Đặt nhóm nhận thông báo"),
                          (f"{cmdb} group notify", "Bật / tắt thông báo login"),
                      ],
                      accent_key="purple")

    y = _draw_section(img, d, y,
                      icon=">>", title="Danh Sách & Thông Tin",
                      items=[
                          (f"{cmdb} list",           "Danh sách tất cả bot"),
                          (f"{cmdb} detail [index]", "Chi tiết bot cụ thể"),
                      ],
                      accent_key="orange")

    _draw_footer(img, d, y)
    return _save(img, out_path)


# ── Bot List Canvas (style: blue gradient như ảnh) ───────────────────────────

_BL_W       = 800
_AV_SIZE    = 80
_CARD_H     = 110
_CARD_PAD   = 30
_CARD_GAP   = 12

# Palette blue
_BL_TOP     = (52,  120, 220)
_BL_BOT     = (30,  80,  200)
_BL_CARD_BG = (50,  90,  180, 60)
_BL_CARD_ED = (255, 255, 255, 30)
_BL_TITLE   = (100, 240, 210)   # cyan
_BL_SUB     = (255, 210, 50)    # vàng
_BL_NAME    = (255, 255, 255)
_BL_INF_COLOR = (80, 220, 140)  # xanh lá (∞ / Vô thời hạn)


def _bl_make_bg(h: int) -> Image.Image:
    img = Image.new("RGBA", (_BL_W, h), (0, 0, 0, 255))
    px  = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        r = int(_BL_TOP[0] + (_BL_BOT[0] - _BL_TOP[0]) * t)
        g = int(_BL_TOP[1] + (_BL_BOT[1] - _BL_TOP[1]) * t)
        b = int(_BL_TOP[2] + (_BL_BOT[2] - _BL_TOP[2]) * t)
        for x in range(_BL_W):
            px[x, y] = (r, g, b, 255)
    return img


def _fetch_avatar_circle(url: str, size: int, cookies: dict | None = None) -> "Image.Image | None":
    if not url:
        return None
    try:
        resp = requests.get(url.strip(), timeout=6,
                            headers={"User-Agent": "Mozilla/5.0"},
                            cookies=cookies or {})
        resp.raise_for_status()
        raw = Image.open(BytesIO(resp.content)).convert("RGBA")
        iw, ih = raw.size
        s   = min(iw, ih)
        raw = raw.crop(((iw-s)//2, (ih-s)//2, (iw+s)//2, (ih+s)//2))
        raw = raw.resize((size, size), Image.LANCZOS)
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size-1, size-1), fill=255)
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        out.paste(raw, mask=mask)
        return out
    except Exception:
        return None


def _bl_default_avatar(size: int, idx: int) -> Image.Image:
    colors = [(180,80,40),(60,160,200),(200,160,60),(80,160,80),(160,60,160)]
    c = colors[idx % len(colors)]
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(img).ellipse((0, 0, size-1, size-1), fill=(*c, 200))
    return img


def _bl_status_color(bot: dict, src: str) -> tuple:
    from datetime import datetime
    if src == "MAIN" and (bot.get("is_main_bot") or bot.get("mainBot")):
        return (80, 200, 255)
    exp_str = bot.get("expiredTime")
    if exp_str:
        try:
            if datetime.now() > datetime.strptime(str(exp_str), "%H:%M:%S-%d/%m/%Y"):
                return (255, 80, 80)
        except Exception:
            pass
    if not bot.get("status"):
        return (160, 160, 160)
    return (50, 210, 130)


def _bl_status_text(bot: dict, src: str) -> str:
    from datetime import datetime
    if src == "MAIN" and (bot.get("is_main_bot") or bot.get("mainBot")):
        return "Main Bot"
    exp_str = bot.get("expiredTime")
    if exp_str:
        try:
            if datetime.now() > datetime.strptime(str(exp_str), "%H:%M:%S-%d/%m/%Y"):
                return f"Hết hạn"
        except Exception:
            pass
        return "Vô thời hạn"
    if not bot.get("status"):
        return "Đã dừng"
    return "Vô thời hạn"


def _bl_avatar_with_ring(av_img: Image.Image, ring_color: tuple, size: int,
                          dot_color: tuple) -> Image.Image:
    """Avatar + viền cam + dot status góc dưới trái."""
    RING = 3
    DOT  = 16
    canvas_size = size + RING * 2 + 4
    canvas = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))

    # Viền tròn cam
    ring_layer = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
    ImageDraw.Draw(ring_layer).ellipse(
        (0, 0, canvas_size - 1, canvas_size - 1),
        outline=(220, 120, 40, 255), width=RING
    )
    canvas.alpha_composite(av_img, (RING + 2, RING + 2))
    canvas.alpha_composite(ring_layer)

    # Dot status — góc dưới trái
    dot_layer = Image.new("RGBA", (DOT, DOT), (0, 0, 0, 0))
    ImageDraw.Draw(dot_layer).ellipse((0, 0, DOT-1, DOT-1), fill=(*dot_color, 255))
    dx = 2
    dy = canvas_size - DOT - 2
    canvas.alpha_composite(dot_layer, (dx, dy))

    return canvas


def _bl_draw_card(img: Image.Image, d: ImageDraw.ImageDraw,
                  y: int, index: int, bot: dict, src: str,
                  av_img: "Image.Image | None") -> int:
    PAD  = _CARD_PAD
    x1, x2 = PAD, _BL_W - PAD
    y1, y2 = y, y + _CARD_H

    # Card background (semi-transparent)
    card = Image.new("RGBA", (x2 - x1, y2 - y1), (0, 0, 0, 0))
    ImageDraw.Draw(card).rounded_rectangle(
        (0, 0, x2-x1-1, y2-y1-1), 14,
        fill=_BL_CARD_BG, outline=_BL_CARD_ED, width=1
    )
    img.alpha_composite(card, (x1, y1))

    # Divider vertical line
    div = Image.new("RGBA", (2, _CARD_H - 20), (0, 0, 0, 0))
    ImageDraw.Draw(div).rectangle((0, 0, 1, _CARD_H - 21), fill=(255, 255, 255, 50))
    img.alpha_composite(div, (x1 + _AV_SIZE + 28, y1 + 10))

    # Avatar
    if av_img is None:
        av_img = _bl_default_avatar(_AV_SIZE, index)
    sc  = _bl_status_color(bot, src)
    ringed = _bl_avatar_with_ring(av_img, (220, 120, 40), _AV_SIZE, sc)
    av_x = x1 + 12
    av_y = y1 + (_CARD_H - ringed.height) // 2
    img.alpha_composite(ringed, (av_x, av_y))

    # Text area
    tx   = av_x + ringed.width + 16
    fn   = _f(28, "bold")
    fst  = _f(22, "regular")
    fe2  = _f(22, "bold")

    name = _sanitize_text(bot.get("username") or "Unknown", "bold")
    name_y = y1 + 18
    d.text((tx, name_y), f"{index}. {name}", font=fn, fill=(*_BL_NAME, 255))

    # Status row: ∞ icon + text
    st_txt = _bl_status_text(bot, src)
    st_color = sc  # màu theo trạng thái (xanh dương Main Bot, xanh lá active, đỏ hết hạn, xám đã dừng)
    inf_y  = name_y + 38
    # ∞ symbol — to hơn để gần sát mép khung
    fe_inf = _f(30, "bold")
    inf_sym = "∞"
    # Badge ∞
    bb_inf  = d.textbbox((0, 0), inf_sym, font=fe_inf)
    inf_w   = bb_inf[2] - bb_inf[0]
    inf_h   = bb_inf[3] - bb_inf[1]
    badge_w = inf_w + 12
    badge_h = 32
    badge_layer = Image.new("RGBA", (badge_w, badge_h), (0, 0, 0, 0))
    ImageDraw.Draw(badge_layer).rounded_rectangle(
        (0, 0, badge_w-1, badge_h-1), 7,
        outline=(*st_color, 200), width=1
    )
    img.alpha_composite(badge_layer, (tx, inf_y))
    # Center ∞ symbol inside badge (cả ngang và đứng)
    inf_x = tx + (badge_w - inf_w) // 2 - bb_inf[0]
    inf_ty = inf_y + (badge_h - inf_h) // 2 - bb_inf[1]
    d.text((inf_x, inf_ty), inf_sym, font=fe_inf, fill=(*st_color, 245))

    # Căn "Vô thời hạn" theo chiều cao của badge ∞
    bb_st = d.textbbox((0, 0), st_txt, font=fst)
    st_h  = bb_st[3] - bb_st[1]
    st_ty = inf_y + (badge_h - st_h) // 2 - bb_st[1]
    d.text((tx + badge_w + 8, st_ty), st_txt, font=fst, fill=(*st_color, 230))

    return y2 + _CARD_GAP


def draw_bot_list(out_path: str, bots: list, cmdb: str = "?mybot", cookies: dict | None = None) -> tuple:
    """
    Canvas danh sách bot — style xanh dương như ảnh CHILDBOT MANAGER.
    bots: list of (index, bot_dict, src, avatar_url)
    """
    n = len(bots)
    HEADER_H  = 160
    CONTENT_H = n * (_CARD_H + _CARD_GAP) + 30
    h_total   = max(HEADER_H + CONTENT_H + 40, 400)

    img = _bl_make_bg(h_total)
    d   = ImageDraw.Draw(img, "RGBA")

    # ── Header ──────────────────────────────────────────────────────────
    ft_title = _f(54, "title")
    ft_sub   = _f(28, "bold")

    title = "CHILDBOT MANAGER"
    tw_t  = _tw(d, title, ft_title)
    # Glow
    glow = Image.new("RGBA", (_BL_W, 80), (0, 0, 0, 0))
    ImageDraw.Draw(glow).text(((_BL_W - tw_t) // 2, 5), title,
                               font=ft_title, fill=(*_BL_TITLE, 80))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(10)), (0, 20))
    # Text
    d.text(((_BL_W - tw_t) // 2, 25), title, font=ft_title, fill=(*_BL_TITLE, 255))

    subtitle = "Danh Sách Quản Lý Bot"
    tw_s     = _tw(d, subtitle, ft_sub)
    d.text(((_BL_W - tw_s) // 2, 95), subtitle, font=ft_sub, fill=(*_BL_SUB, 240))

    # ── Cards ────────────────────────────────────────────────────────────
    y = HEADER_H
    for idx, bot, src, av_url in bots:
        av_img = _fetch_avatar_circle(av_url, _AV_SIZE, cookies=cookies)
        y = _bl_draw_card(img, d, y, idx, bot, src, av_img)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=95)
    return img.width, img.height


# ── Bot Detail Canvas (?mybot detail) ────────────────────────────────────────

_DT_AV_SIZE  = 200
_DT_ROW_H    = 80
_DT_ROW_GAP  = 12
_DT_CARD_PAD = 30


def _wrap_text(d, text, font, max_width):
    words = str(text).split()
    if not words:
        return [""]
    lines, cur = [], words[0]
    for w in words[1:]:
        test = cur + " " + w
        if _tw(d, test, font) <= max_width:
            cur = test
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines


def _default_bot_avatar(size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((0, 0, size - 1, size - 1), fill=(55, 70, 130, 255),
              outline=(255, 255, 255, 90), width=3)
    fe = _f(int(size * 0.45), "emoji")
    sym = "🤖"
    bb = d.textbbox((0, 0), sym, font=fe)
    tw_, th_ = bb[2] - bb[0], bb[3] - bb[1]
    d.text(((size - tw_) // 2 - bb[0], (size - th_) // 2 - bb[1]),
           sym, font=fe, fill=(255, 255, 255, 235))
    return img


def _dt_section_badge(img: Image.Image, d: ImageDraw.ImageDraw, y: int, icon: str, text: str) -> int:
    f  = _f(30, "bold")
    fe = _f(30, "emoji")
    iw = _tw(d, icon, fe)
    tw_ = _tw(d, text, f)
    th_ = _th(d, text, f)
    gap = 12
    pad_x, h = 36, 60
    w = iw + gap + tw_ + pad_x * 2
    x = (W - w) // 2
    _glass(img, x, y, x + w, y + h, r=h // 2,
           fill=(18, 20, 36, 235), edge=(255, 255, 255, 45), shadow=False)
    d.text((x + pad_x, y + (h - th_) // 2 - 2), icon, font=fe, fill=(*C_WHITE, 250))
    d.text((x + pad_x + iw + gap, y + (h - th_) // 2 - 2), text, font=f, fill=(*C_WHITE, 250))
    return y + h + 26


def _dt_field(img: Image.Image, d: ImageDraw.ImageDraw,
              x: int, y: int, w: int, h: int,
              icon: str, label: str, value, accent_key: str = "cyan",
              wrap: bool = False):
    accent = ACCENT.get(accent_key, ACCENT["cyan"])
    _glass(img, x, y, x + w, y + h, r=14,
           fill=(255, 255, 255, 12), edge=(255, 255, 255, 28), shadow=False)
    _accent_bar(img, x, y + 10, y + h - 10, accent, w=4)

    PAD_L = 26
    PAD_R = 34
    avail_w = w - PAD_L - PAD_R

    fe_icon = _f(22, "emoji")
    iw = _tw(d, icon, fe_icon)
    d.text((x + PAD_L, y + 14), icon, font=fe_icon, fill=(*accent, 235))

    fe_lbl = _f(22, "bold")
    lbl_max_w = avail_w - iw - 8
    while _tw(d, label, fe_lbl) > lbl_max_w and fe_lbl.size > 14:
        fe_lbl = _f(fe_lbl.size - 2, "bold")
    d.text((x + PAD_L + iw + 8, y + 14), label, font=fe_lbl, fill=(*accent, 235))

    val_txt = str(value) if value not in (None, "") else "Chưa cập nhật"
    # max_w tính sát mép phải của ô (trừ PAD_L bên trái + 8px an toàn bên phải)
    max_w = w - PAD_L - 8

    if wrap:
        fe_val = _f(24, "regular")
        lines = _wrap_text(d, val_txt, fe_val, max_w)
        max_lines = max(1, (h - 50) // 30)
        lines = lines[:max_lines]
        ly = y + 50
        for ln in lines:
            d.text((x + PAD_L, ly), ln, font=fe_val, fill=(*C_WHITE, 235))
            ly += 30
    else:
        fe_val = _f(28, "bold")
        while _tw(d, val_txt, fe_val) > max_w and fe_val.size > 14:
            fe_val = _f(fe_val.size - 1, "bold")
        d.text((x + PAD_L, y + 50), val_txt, font=fe_val, fill=(*C_WHITE, 245))


def draw_bot_detail(out_path: str, bot: dict, cmdb: str = "?mybot",
                     avatar_url: str | None = None, cookies: dict | None = None,
                     creator_name: str = "N/A", server_running: str = "N/A") -> tuple:
    """Canvas chi tiết bot (?mybot detail)."""
    from datetime import datetime as _dt

    username   = bot.get("username") or "Unknown"
    server_name = bot.get("serverName") or bot.get("nameServer") or "Chưa cập nhật"
    owner_id   = str(bot.get("author_id") or bot.get("botIntId") or "N/A")
    is_active  = bool(bot.get("status"))
    status_txt = "ACTIVE" if is_active else "INACTIVE"
    running_txt = "Có" if is_active else "Không"

    exp_str = bot.get("expiredTime") or ""
    exp_display = exp_str or "Chưa kích hoạt"
    remain_txt  = "Vô thời hạn"
    if exp_str:
        try:
            exp_dt = _dt.strptime(str(exp_str), "%H:%M:%S-%d/%m/%Y")
            now = _dt.now()
            if exp_dt > now:
                delta = exp_dt - now
                days = delta.days
                hours, rem = divmod(delta.seconds, 3600)
                minutes, seconds = divmod(rem, 60)
                remain_txt = f"{days}d {hours}h {minutes}p {seconds}s"
            else:
                remain_txt = "Đã hết hạn"
        except Exception:
            remain_txt = "N/A"

    created_txt   = bot.get("activedTime") or bot.get("createdTime") or "Chưa cập nhật"
    reviewed_txt  = bot.get("reviewedTime") or "Chưa cập nhật"
    approved_txt  = bot.get("approvedBy") or "Hệ thống"
    login_v       = bot.get("login")
    platform_txt  = "web" if login_v == 30 else ("pc" if login_v else "Chưa cập nhật")
    description   = bot.get("description") or "Chưa cập nhật"
    bot_info      = bot.get("botInfo") or "Chưa cập nhật"

    # ── Heights ──────────────────────────────────────────────────────────
    HEADER_H  = 230 + 32
    BADGE_H   = 60 + 26
    GAP       = 30
    FOOTER_H  = 80 + 30

    card1_grid_h = 4 * _DT_ROW_H + 3 * _DT_ROW_GAP
    card1_h = max(_DT_AV_SIZE, card1_grid_h) + _DT_CARD_PAD * 2

    card2_grid_h = 3 * _DT_ROW_H + 2 * _DT_ROW_GAP
    card2_h = card2_grid_h + _DT_CARD_PAD * 2

    card3_h = _DT_ROW_H + 60 + _DT_CARD_PAD * 2

    h_total = (HEADER_H
               + BADGE_H + card1_h + GAP
               + BADGE_H + card2_h + GAP
               + BADGE_H + card3_h + GAP
               + FOOTER_H)

    img = _make_bg(h_total)
    _rainbow_bar(img)
    d = ImageDraw.Draw(img, "RGBA")

    y = _draw_header(img, d, title="Bot Detail",
                      subtitle=f"Thông Tin Chi Tiết Bot · {username}")

    PAD = 52

    # ── Card 1: Tổng quan bot ────────────────────────────────────────────
    y = _dt_section_badge(img, d, y, "📊", "Tổng quan bot")
    x1, y1 = PAD, y
    x2, y2 = W - PAD, y1 + card1_h
    _glass(img, x1, y1, x2, y2, r=20)

    av_img = _fetch_avatar_circle(avatar_url, _DT_AV_SIZE, cookies=cookies) if avatar_url else None
    if av_img is None:
        av_img = _default_bot_avatar(_DT_AV_SIZE)
    av_x = x1 + _DT_CARD_PAD
    av_y = y1 + (card1_h - _DT_AV_SIZE) // 2
    img.alpha_composite(av_img, (av_x, av_y))

    grid_x = av_x + _DT_AV_SIZE + 40
    grid_w = (x2 - _DT_CARD_PAD) - grid_x
    col_w  = (grid_w - _DT_ROW_GAP) // 2

    fields1 = [
        ("👑", "TÊN",              username,       "cyan"),
        ("🔁", "BOT ĐANG CHẠY",    server_running, "blue"),
        ("🏷️", "TÊN ĐẠI DIỆN BOT", server_name,    "pink"),
        ("👤", "ID OWNER",         owner_id,       "purple"),
        ("📊", "TRẠNG THÁI BOT",   status_txt,     "cyan"),
        ("🔁", "ĐANG CHẠY",        running_txt,    "blue"),
        ("⏳", "THỜI HẠN CÒN",     remain_txt,      "orange"),
        ("📅", "NGÀY HẾT HẠN",     exp_display,     "pink"),
    ]
    fy = y1 + _DT_CARD_PAD
    for i, (icon, label, value, acc) in enumerate(fields1):
        col, row = i % 2, i // 2
        fx  = grid_x + col * (col_w + _DT_ROW_GAP)
        fyy = fy + row * (_DT_ROW_H + _DT_ROW_GAP)
        _dt_field(img, d, fx, fyy, col_w, _DT_ROW_H, icon, label, value, acc)

    y = y2 + GAP

    # ── Card 2: Thông tin đăng ký ─────────────────────────────────────────
    y = _dt_section_badge(img, d, y, "📝", "Thông tin đăng ký")
    x1, y1 = PAD, y
    x2, y2 = W - PAD, y1 + card2_h
    _glass(img, x1, y1, x2, y2, r=20)

    grid_x = x1 + _DT_CARD_PAD
    grid_w = (x2 - _DT_CARD_PAD) - grid_x
    col_w  = (grid_w - _DT_ROW_GAP) // 2
    fy = y1 + _DT_CARD_PAD

    _dt_field(img, d, grid_x, fy, grid_w, _DT_ROW_H, "👤", "NGƯỜI TẠO", creator_name, "cyan")
    fy += _DT_ROW_H + _DT_ROW_GAP

    _dt_field(img, d, grid_x, fy, col_w, _DT_ROW_H, "📅", "NGÀY TẠO", created_txt, "cyan")
    _dt_field(img, d, grid_x + col_w + _DT_ROW_GAP, fy, col_w, _DT_ROW_H,
              "✅", "THỜI GIAN XEM XÉT", reviewed_txt, "pink")
    fy += _DT_ROW_H + _DT_ROW_GAP

    _dt_field(img, d, grid_x, fy, col_w, _DT_ROW_H, "🛡️", "PHÊ DUYỆT BỞI", approved_txt, "pink")
    _dt_field(img, d, grid_x + col_w + _DT_ROW_GAP, fy, col_w, _DT_ROW_H,
              "🌐", "NỀN TẢNG ĐĂNG NHẬP", platform_txt, "cyan")

    y = y2 + GAP

    # ── Card 3: Giới thiệu và Thông tin bot ──────────────────────────────
    y = _dt_section_badge(img, d, y, "📖", "Giới thiệu và Thông tin bot")
    x1, y1 = PAD, y
    x2, y2 = W - PAD, y1 + card3_h
    _glass(img, x1, y1, x2, y2, r=20)

    grid_x = x1 + _DT_CARD_PAD
    grid_w = (x2 - _DT_CARD_PAD) - grid_x
    col_w  = (grid_w - _DT_ROW_GAP) // 2
    box_h  = card3_h - 2 * _DT_CARD_PAD

    _dt_field(img, d, grid_x, y1 + _DT_CARD_PAD, col_w, box_h,
              "📖", "GIỚI THIỆU", description, "cyan", wrap=True)
    _dt_field(img, d, grid_x + col_w + _DT_ROW_GAP, y1 + _DT_CARD_PAD, col_w, box_h,
              "ℹ️", "THÔNG TIN BOT", bot_info, "pink", wrap=True)

    y = y2 + GAP

    _draw_footer(img, d, y)
    return _save(img, out_path)
