import qrcode
from PIL import Image, ImageDraw, ImageFilter
from io import BytesIO
import requests
import os
import time
import math

CACHE_DIR = "src/cache_qr"
os.makedirs(CACHE_DIR, exist_ok=True)


class QRDrawer:

    def create_background(self, size):
        bg   = Image.new("RGB", (size, size), (14, 14, 20))
        glow = Image.new("RGB", (size, size), (0, 0, 0))
        draw = ImageDraw.Draw(glow)

        for i in range(300, 0, -1):
            draw.ellipse(
                (-180 - i // 2, size // 2 - i, 180 + i // 2, size // 2 + i),
                fill=(0, int(120 + i * 0.15), 200)
            )
            draw.ellipse(
                (size - 180 - i // 2, size // 2 - i, size + 180 + i // 2, size // 2 + i),
                fill=(180, int(80 + i * 0.2), 160)
            )

        glow = glow.filter(ImageFilter.GaussianBlur(160))
        return Image.blend(bg, glow, 0.35)

    def _fetch_avatar(self, avatar_url: str, size: int) -> Image.Image | None:
        """Tải avatar từ URL, resize + bo tròn, trả về RGBA image hoặc None nếu lỗi."""
        try:
            resp = requests.get(avatar_url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
            resp.raise_for_status()
            raw  = Image.open(BytesIO(resp.content)).convert("RGBA")

            # Crop vuông từ giữa
            w, h  = raw.size
            side  = min(w, h)
            left  = (w - side) // 2
            top   = (h - side) // 2
            raw   = raw.crop((left, top, left + side, top + side))

            # Resize về kích thước cần
            av = raw.resize((size, size), Image.LANCZOS)

            # Mask bo tròn hoàn toàn (circle)
            mask = Image.new("L", (size, size), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)

            result = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            result.paste(av, mask=mask)
            return result
        except Exception:
            return None

    def _draw_avatar_area(self, qr_layer: Image.Image, center_x: int, center_y: int,
                          av_size: int, avatar_url: str | None) -> None:
        """
        Vẽ vùng avatar ở giữa QR:
        - Nền trắng bo tròn (để QR module không đè lên)
        - Border gradient mờ
        - Avatar bo tròn (hoặc placeholder nếu không có URL)
        """
        PAD        = int(av_size * 0.06)   # khoảng trắng giữa avatar và viền ngoài
        outer_r    = av_size // 2 + PAD
        outer_size = outer_r * 2

        # ── 1. Xóa vùng giữa (trong suốt) để nền QR hiện ra ──────────────────
        clear = Image.new("RGBA", (outer_size, outer_size), (0, 0, 0, 0))
        clear_mask = Image.new("L", (outer_size, outer_size), 0)
        ImageDraw.Draw(clear_mask).ellipse((0, 0, outer_size - 1, outer_size - 1), fill=255)
        ox = center_x - outer_r
        oy = center_y - outer_r
        qr_layer.paste(clear, (ox, oy), mask=clear_mask)

        # ── 2. Vòng nền trắng mờ (viền ngoài) ────────────────────────────────
        ring_img  = Image.new("RGBA", (outer_size, outer_size), (0, 0, 0, 0))
        ring_draw = ImageDraw.Draw(ring_img)
        ring_draw.ellipse((0, 0, outer_size - 1, outer_size - 1), fill=(255, 255, 255, 230))
        qr_layer.alpha_composite(ring_img, (ox, oy))

        # ── 3. Gradient ring ──────────────────────────────────────────────────
        RING_W = max(1, int(av_size * 0.02))
        for i in range(RING_W, 0, -1):
            alpha = int(200 * (i / RING_W))
            # gradient xanh→tím giống Zalo
            t = i / RING_W
            r = int(0   + 120 * t)
            g = int(120 - 60  * t)
            b = int(200 + 55  * t)
            ring_draw2 = ImageDraw.Draw(ring_img)
            inset = RING_W - i
            ring_draw2.ellipse(
                (inset, inset, outer_size - 1 - inset, outer_size - 1 - inset),
                outline=(r, g, b, alpha), width=1
            )

        # ── 4. Avatar hoặc placeholder ────────────────────────────────────────
        av_img = None
        if avatar_url:
            av_img = self._fetch_avatar(avatar_url, av_size)

        if av_img is None:
            # Placeholder: vòng tròn màu gradient + icon người
            av_img = Image.new("RGBA", (av_size, av_size), (0, 0, 0, 0))
            av_draw = ImageDraw.Draw(av_img)
            av_draw.ellipse((0, 0, av_size - 1, av_size - 1), fill=(30, 30, 50, 255))
            # Icon người đơn giản
            head_r = av_size // 6
            cx, cy = av_size // 2, av_size // 2
            av_draw.ellipse(
                (cx - head_r, cy - av_size // 3, cx + head_r, cy - av_size // 3 + head_r * 2),
                fill=(140, 140, 180, 255)
            )
            av_draw.ellipse(
                (cx - av_size // 3, cy + head_r // 2, cx + av_size // 3, cy + av_size // 2),
                fill=(140, 140, 180, 255)
            )

        # Đặt avatar vào giữa
        av_x = center_x - av_size // 2
        av_y = center_y - av_size // 2
        qr_layer.alpha_composite(av_img, (av_x, av_y))

    def create_gradient_qr(self, data: str, avatar_url: str | None = None) -> str:
        """
        Tạo QR gradient. Nếu truyền avatar_url thì chèn avatar bo tròn vào giữa.
        Trả về đường dẫn file PNG đã lưu trong cache_qr/.
        """
        qr = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=20,
            border=1,
        )
        qr.add_data(data)
        qr.make(fit=True)

        matrix   = qr.get_matrix()
        size     = len(matrix)
        box      = 20
        img_size = size * box

        base     = self.create_background(img_size).convert("RGBA")
        qr_layer = Image.new("RGBA", (img_size, img_size), (0, 0, 0, 0))
        draw     = ImageDraw.Draw(qr_layer)

        def smooth_color(t):
            r = int(110 + 80 * math.sin(2 * math.pi * (t + 0.0)))
            g = int(110 + 80 * math.sin(2 * math.pi * (t + 0.33)))
            b = int(110 + 80 * math.sin(2 * math.pi * (t + 0.66)))
            return (r, g, b, 255)

        # Tính vùng trung tâm cần giữ trống cho avatar (30% kích thước QR)
        av_size   = int(img_size * 0.22)        # kích thước avatar
        PAD       = int(av_size * 0.06)
        outer_r   = av_size // 2 + PAD
        cx        = img_size // 2
        cy        = img_size // 2

        for y in range(size):
            for x in range(size):
                if matrix[y][x]:
                    cx_px = x * box + box // 2
                    cy_px = y * box + box // 2

                    # Bỏ qua module nằm trong vùng avatar
                    dist = math.hypot(cx_px - cx, cy_px - cy)
                    if dist < outer_r + box * 0.5:
                        continue

                    t = ((x / size) + (y / size)) * 0.5
                    t += math.sin((x / size) * math.pi * 2) * 0.08
                    t += math.cos((y / size) * math.pi * 2) * 0.08
                    t = t % 1.0

                    color = smooth_color(t)

                    x1 = x * box
                    y1 = y * box
                    x2 = x1 + box
                    y2 = y1 + box

                    draw.rounded_rectangle(
                        (x1, y1, x2, y2),
                        radius=box * 0.35,
                        fill=color
                    )

        qr_layer = qr_layer.filter(ImageFilter.GaussianBlur(0.6))

        # Vẽ avatar ở giữa
        self._draw_avatar_area(qr_layer, cx, cy, av_size, avatar_url)

        final = Image.alpha_composite(base, qr_layer)

        path = os.path.join(CACHE_DIR, f"qr_{int(time.time() * 1000)}.png")
        final.save(path)
        return path
