"""
search_canvas.py  –  Vẽ ảnh kết quả tìm kiếm nhạc (port search-canvas.js → Pillow)
Đặt tại: src/services/pillow/search_canvas.py

Hỗ trợ platform: spotify, youtube, tiktok, capcut, nhaccuatui, zingmp3 (default)
Dùng trong lệnh music để hiển thị danh sách bài tìm được.

Usage:
  from src.services.pillow.search_canvas import draw_search_result
  path = draw_search_result(songs, platform="zingmp3", keyword="chu de")
"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import os, requests as _req, uuid, math

FONT_DIR = Path("data/assets/font")

# ── Platform config ───────────────────────────────────────────────────────────
PLATFORM_CONFIG = {
    "default": {
        "name": "Music Search",
        "primary": (139, 92, 246),
        "secondary": (99, 102, 241),
        "bg_top": (10, 10, 26),
        "bg_bot": (17, 24, 48),
        "platform_icon": None,
    },
    "zingmp3": {
        "name": "ZingMP3",
        "primary": (13, 188, 121),
        "secondary": (9, 147, 96),
        "bg_top": (5, 20, 10),
        "bg_bot": (10, 30, 18),
        "platform_icon": None,
    },
    "spotify": {
        "name": "Spotify",
        "primary": (29, 185, 84),
        "secondary": (30, 215, 96),
        "bg_top": (10, 26, 10),
        "bg_bot": (16, 30, 16),
        "platform_icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Spotify_icon.svg/1200px-Spotify_icon.svg.png",
    },
    "youtube": {
        "name": "YouTube",
        "primary": (255, 0, 0),
        "secondary": (204, 0, 0),
        "bg_top": (26, 10, 10),
        "bg_bot": (24, 8, 8),
        "platform_icon": None,
    },
    "tiktok": {
        "name": "TikTok",
        "primary": (0, 242, 234),
        "secondary": (255, 0, 80),
        "bg_top": (10, 14, 20),
        "bg_bot": (16, 16, 26),
        "platform_icon": None,
    },
    "soundcloud": {
        "name": "SoundCloud",
        "primary": (255, 90, 0),
        "secondary": (255, 140, 0),
        "bg_top": (20, 10, 5),
        "bg_bot": (26, 14, 8),
        "platform_icon": None,
    },
    "nhaccuatui": {
        "name": "NhacCuaTui",
        "primary": (230, 50, 50),
        "secondary": (200, 30, 30),
        "bg_top": (20, 8, 8),
        "bg_bot": (26, 10, 10),
        "platform_icon": None,
    },
}

def _cfg(platform):
    return PLATFORM_CONFIG.get(platform, PLATFORM_CONFIG["default"])

# ── Font helpers ──────────────────────────────────────────────────────────────
def _load_font(size, bold=False):
    names = ["Goldman-Bold.ttf","Sarabun-Bold.ttf","OpenSans-Bold.ttf"] if bold \
        else ["Goldman-Regular.ttf","Sarabun-Regular.ttf","OpenSans-Regular.ttf"]
    dirs = [FONT_DIR/"Goldman", FONT_DIR/"Sarabun",
            FONT_DIR/"Opensans"/"static"/"Opensans", FONT_DIR]
    for name in names:
        for d in dirs:
            p = d / name
            if p.exists():
                try: return ImageFont.truetype(str(p), size)
                except: pass
    for p in FONT_DIR.rglob("*.ttf"):
        try: return ImageFont.truetype(str(p), size)
        except: pass
    return ImageFont.load_default()

def _measure(font, text):
    bb = font.getbbox(text)
    return bb[2]-bb[0], bb[3]-bb[1]

def _clamp(font, text, max_w):
    if not text:
        return ""
    text = str(text)
    while text and _measure(font, text + "...")[0] > max_w:
        text = text[:-1]
    return text + "..." if _measure(font, text)[0] > max_w else text

def _wrap(font, text, max_w, max_lines=2):
    words = str(text or "").split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if _measure(font, test)[0] <= max_w:
            cur = test
        else:
            if cur: lines.append(cur)
            if len(lines) >= max_lines: break
            cur = w
    if cur and len(lines) < max_lines:
        lines.append(cur)
    while len(lines) < max_lines:
        lines.append("")
    return lines[:max_lines]

def _fmt_count(v):
    try:
        n = int(v)
    except Exception:
        return None
    if n >= 1_000_000: return f"{n/1_000_000:.1f}M".rstrip("0").rstrip(".")+"M" if "." in f"{n/1_000_000:.1f}" else f"{n//1_000_000}M"
    if n >= 1_000:     return f"{n/1_000:.1f}K".rstrip("0").rstrip(".")+"K" if "." in f"{n/1_000:.1f}" else f"{n//1_000}K"
    return str(n)

# ── Thumbnail loader ──────────────────────────────────────────────────────────
def _load_thumb(url, size):
    if url:
        try:
            r = _req.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
            img = Image.open(BytesIO(r.content)).convert("RGBA")
            img = img.resize((size, size), Image.LANCZOS)
            mask = Image.new("L", (size*4, size*4), 0)
            ImageDraw.Draw(mask).ellipse([0,0,size*4-1,size*4-1], fill=255)
            mask = mask.resize((size, size), Image.LANCZOS)
            out = Image.new("RGBA", (size, size), (0,0,0,0))
            out.paste(img, mask=mask)
            return out
        except: pass
    return None

def _default_thumb(size, primary):
    img = Image.new("RGBA", (size, size), (0,0,0,0))
    d = ImageDraw.Draw(img)
    d.ellipse([0,0,size-1,size-1], fill=(*primary, 60))
    # Play icon
    cx, cy = size//2, size//2
    s = size // 3
    pts = [(cx-s//2, cy-s//2), (cx+s//2, cy), (cx-s//2, cy+s//2)]
    d.polygon(pts, fill=(*primary, 180))
    return img

# ── Draw ──────────────────────────────────────────────────────────────────────
CARD_H    = 130
PADDING   = 20
THUMB_SZ  = 100
NUM_W     = 52
SEP_W     = 28
ROW_GAP   = 18
MAX_ROWS  = 10
HEADER_H  = 70
FOOTER_H  = 26

def draw_search_result(songs, platform="default", keyword="", out_dir="data/assets/cache/cards"):
    """
    songs: list of dict với các key: title, artistsNames|channelName, thumbnailM|thumbnail,
           rankChart, view, listen, playback_count, likes_count, comment, publishedTime
    Trả về đường dẫn file ảnh đã tạo.
    """
    songs = (songs or [])[:30]
    if not songs:
        return _draw_empty(platform, out_dir)

    cfg = _cfg(platform)
    primary   = cfg["primary"]
    secondary = cfg["secondary"]

    f_header = _load_font(22, bold=True)
    f_title  = _load_font(22, bold=True)
    f_artist = _load_font(19)
    f_stats  = _load_font(17)
    f_num    = _load_font(22, bold=True)
    f_footer = _load_font(14)

    # Tính số cột và chiều rộng
    MAX_TITLE_W = 340
    COL_W = NUM_W + THUMB_SZ + SEP_W + MAX_TITLE_W + PADDING * 3
    n_cols = min(math.ceil(len(songs) / MAX_ROWS), 3)
    COL_GAP = 36
    W = COL_W * n_cols + COL_GAP * max(0, n_cols - 1) + PADDING * 2

    n_rows = math.ceil(len(songs) / n_cols)
    H = HEADER_H + n_rows * (CARD_H + ROW_GAP) + FOOTER_H + 20

    canvas = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(canvas)

    # Nền gradient
    bg_top = cfg["bg_top"]
    bg_bot = cfg["bg_bot"]
    for y in range(H):
        t = y / H
        r = int(bg_top[0]*(1-t) + bg_bot[0]*t)
        g = int(bg_top[1]*(1-t) + bg_bot[1]*t)
        b = int(bg_top[2]*(1-t) + bg_bot[2]*t)
        d.line([(0,y),(W,y)], fill=(r,g,b,255))

    # Grid lines
    for gx in range(0, W, 40):
        d.line([(gx,0),(gx,H)], fill=(255,255,255,4))
    for gy in range(0, H, 40):
        d.line([(0,gy),(W,gy)], fill=(255,255,255,4))

    # Header bar
    hx, hy, hw, hh = PADDING, 8, W - PADDING*2, 50
    # Panel header
    hp = Image.new("RGBA", (hw, hh), (255,255,255,10))
    mask = Image.new("L",(hw*4,hh*4),0)
    ImageDraw.Draw(mask).rounded_rectangle([0,0,hw*4-1,hh*4-1],radius=48,fill=255)
    mask = mask.resize((hw,hh),Image.LANCZOS)
    out_h = Image.new("RGBA",(hw,hh),(0,0,0,0))
    out_h.paste(hp, mask=mask)
    canvas.alpha_composite(out_h,(hx,hy))
    # Top bar gradient
    for x in range(hw):
        t = x / hw
        r = int(primary[0]*(1-t) + secondary[0]*t)
        g = int(primary[1]*(1-t) + secondary[1]*t)
        b = int(primary[2]*(1-t) + secondary[2]*t)
        canvas.putpixel((hx+x, hy), (r,g,b,200))
        canvas.putpixel((hx+x, hy+1), (r,g,b,150))
        canvas.putpixel((hx+x, hy+2), (r,g,b,80))

    d = ImageDraw.Draw(canvas)
    platform_label = f"♪ {cfg['name']}"
    d.text((hx+16, hy+14), platform_label, font=f_header, fill=(255,255,255,230))
    right_text = f"{len(songs)} bai hat  •  Go so de chon  •  Go 0 de huy"
    rw, _ = _measure(f_footer, right_text)
    d.text((hx + hw - rw - 16, hy+18), right_text, font=f_footer, fill=(255,255,255,130))

    # Tải thumbnails
    thumbs = []
    for song in songs:
        url = song.get("thumbnailM") or song.get("thumbnail") or song.get("artwork_url") or ""
        thumbs.append(_load_thumb(url, THUMB_SZ))

    # Chia cột
    columns = [songs[i:i+MAX_ROWS] for i in range(0, len(songs), MAX_ROWS)]

    for col_idx, col_songs in enumerate(columns):
        start_x = PADDING + col_idx * (COL_W + COL_GAP)
        y_pos = HEADER_H + 14

        for row_idx, song in enumerate(col_songs):
            global_i = col_idx * MAX_ROWS + row_idx
            num = global_i + 1

            card_w = COL_W - PADDING
            # Card background
            cb = Image.new("RGBA", (card_w, CARD_H), (255,255,255,20))
            cmask = Image.new("L",(card_w*4,CARD_H*4),0)
            ImageDraw.Draw(cmask).rounded_rectangle([0,0,card_w*4-1,CARD_H*4-1],radius=40,fill=255)
            cmask = cmask.resize((card_w,CARD_H),Image.LANCZOS)
            cout = Image.new("RGBA",(card_w,CARD_H),(0,0,0,0))
            cout.paste(cb, mask=cmask)
            canvas.alpha_composite(cout,(start_x, y_pos))

            d = ImageDraw.Draw(canvas)

            # Top accent line
            for x in range(card_w):
                t = x / card_w
                r = int(primary[0]*(1-t) + secondary[0]*t)
                g = int(primary[1]*(1-t) + secondary[1]*t)
                b = int(primary[2]*(1-t) + secondary[2]*t)
                canvas.putpixel((start_x+x, y_pos+2), (r,g,b,200))
                canvas.putpixel((start_x+x, y_pos+3), (r,g,b,120))

            d = ImageDraw.Draw(canvas)

            # Số thứ tự
            num_bg = Image.new("RGBA",(NUM_W,40),(0,0,0,0))
            ImageDraw.Draw(num_bg).rounded_rectangle([0,0,NUM_W-1,39],radius=[10,0,10,0],fill=(*primary,220))
            canvas.alpha_composite(num_bg,(start_x, y_pos))
            d = ImageDraw.Draw(canvas)
            nw, nh = _measure(f_num, str(num))
            d.text((start_x + NUM_W//2 - nw//2, y_pos + 20 - nh//2), str(num), font=f_num, fill=(255,255,255,255))

            # Thumbnail
            tx = start_x + NUM_W + 10
            ty = y_pos + 10
            thumb = thumbs[global_i] if global_i < len(thumbs) else None
            if thumb is None:
                thumb = _default_thumb(THUMB_SZ, primary)
            # Vòng viền ngoài thumb
            ring = Image.new("RGBA", canvas.size, (0,0,0,0))
            tc = tx + THUMB_SZ//2; tcy = ty + THUMB_SZ//2
            ImageDraw.Draw(ring).ellipse([tc-THUMB_SZ//2-3, tcy-THUMB_SZ//2-3,
                                          tc+THUMB_SZ//2+3, tcy+THUMB_SZ//2+3],
                                         fill=(255,255,255,50))
            canvas.alpha_composite(ring)
            canvas.alpha_composite(thumb, (tx, ty))

            # Separator
            sx = tx + THUMB_SZ + 10
            d = ImageDraw.Draw(canvas)
            d.rectangle([sx, ty+10, sx+2, ty+THUMB_SZ-10], fill=(255,255,255,50))

            # Text
            text_x = sx + 18
            max_txt_w = COL_W - PADDING - (text_x - start_x) - 10

            title   = song.get("title") or "Unknown"
            artist  = song.get("artistsNames") or song.get("channelName") or "Unknown Artist"

            t_lines = _wrap(f_title, title, max_txt_w, 2)
            ty2 = ty + 8
            for line in t_lines:
                if line:
                    d.text((text_x, ty2), line, font=f_title, fill=(255,255,255,240))
                ty2 += 26

            a_text = _clamp(f_artist, str(artist), max_txt_w)
            d.text((text_x, ty2 + 2), a_text, font=f_artist, fill=(255,255,255,170))

            # Stats
            stats = []
            if song.get("rankChart") or song.get("rank"):
                stats.append(f"Top {song.get('rankChart') or song.get('rank')}")
            if song.get("view"):
                n = _fmt_count(song["view"])
                if n: stats.append(f"{n} view")
            if song.get("listen"):
                n = _fmt_count(song["listen"])
                if n: stats.append(f"{n} listen")
            if song.get("playback_count"):
                n = _fmt_count(song["playback_count"])
                if n: stats.append(f"{n} play")
            if song.get("publishedTime"):
                stats.append(str(song["publishedTime"]))
            stats_str = _clamp(f_stats, "  ".join(stats), max_txt_w) if stats else ""
            if stats_str:
                d.text((text_x, ty2 + 26), stats_str, font=f_stats, fill=(*primary, 200))

            y_pos += CARD_H + ROW_GAP

    # Footer
    d = ImageDraw.Draw(canvas)
    footer_text = "♪ Music Bot  –  Tim kiem & Nghe nhac chat luong cao ♪"
    fw, _ = _measure(f_footer, footer_text)
    d.text((W//2 - fw//2, H - FOOTER_H + 6), footer_text, font=f_footer, fill=(255,255,255,70))

    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"search_{uuid.uuid4().hex[:8]}.jpg")
    canvas.convert("RGB").save(out_path, quality=90)
    return out_path


def _draw_empty(platform="default", out_dir="data/assets/cache/cards"):
    cfg = _cfg(platform)
    W, H = 560, 300
    canvas = Image.new("RGBA",(W,H))
    d = ImageDraw.Draw(canvas)
    primary = cfg["primary"]
    for y in range(H):
        t = y/H
        d.line([(0,y),(W,y)], fill=(
            int(10*(1-t)+primary[0]*0.3*t),
            int(6*(1-t)+primary[1]*0.3*t),
            int(30*(1-t)+primary[2]*0.3*t), 255))

    f32 = _load_font(32, bold=True)
    f18 = _load_font(18)
    d.text((W//2 - 170, H//2 - 30), "Khong tim thay bai hat nao", font=f32, fill=(255,255,255,230))
    d.text((W//2 - 90,  H//2 + 20), "Thu tu khoa khac nhe!", font=f18, fill=(255,255,255,130))

    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"search_empty_{uuid.uuid4().hex[:6]}.jpg")
    canvas.convert("RGB").save(out_path, quality=88)
    return out_path
