"""
tiktokCard.py – card danh sách video TikTok
Style: gradient tím tối (giống nhaccuatui)
Output: JPEG 2560×1440
"""
import os, threading
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 2560, 1440
PAD  = 60

_ASSET_FONT = Path(__file__).resolve().parents[3] / "assets" / "font"
FONT_BOLD   = str(_ASSET_FONT / "Opensans" / "static" / "Opensans" / "OpenSans-Bold.ttf")
FONT_REG    = str(_ASSET_FONT / "Opensans" / "static" / "Opensans" / "OpenSans-Regular.ttf")

# ── Màu tím tối như nhaccuatui ──
GRAD_TL = ( 22,  20,  52)
GRAD_TR = ( 38,  22,  58)
GRAD_BL = ( 30,  42,  75)
GRAD_BR = ( 52,  32,  72)

ACCENT       = (254,  44,  85)   # TikTok red
TEXT_TITLE   = (255, 255, 255)
TEXT_ARTIST  = (180, 185, 220)
TEXT_STATS   = (140, 155, 200)
TEXT_NUM     = (254,  44,  85)
CARD_BG      = (255, 255, 255, 18)
CARD_BORDER  = (255, 255, 255, 40)
BADGE_BG     = (254,  44,  85, 230)

def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_BOLD if bold else FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()

def _make_bg() -> Image.Image:
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), GRAD_TL)
    c.putpixel((1, 0), GRAD_TR)
    c.putpixel((0, 1), GRAD_BL)
    c.putpixel((1, 1), GRAD_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")

def _rounded_mask(w, h, r, aa=4):
    mw, mh = w * aa, h * aa
    mr = int(min(r, w // 2, h // 2) * aa)
    m  = Image.new("L", (mw, mh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, mw - 1, mh - 1), radius=mr, fill=255)
    return m.resize((w, h), Image.LANCZOS)

def _draw_card_bg(canvas, x1, y1, x2, y2, radius=18):
    bw, bh = x2 - x1, y2 - y1
    layer = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    mask  = _rounded_mask(bw, bh, radius)
    fill  = Image.new("RGBA", (bw, bh), CARD_BG)
    layer.paste(fill, (0, 0), mask)
    ImageDraw.Draw(layer).rounded_rectangle(
        (0, 0, bw - 1, bh - 1), radius, outline=CARD_BORDER, width=2
    )
    canvas.alpha_composite(layer, (x1, y1))

def _fetch_thumb(url: str, size: tuple) -> Image.Image:
    blank = Image.new("RGBA", size, (30, 28, 55, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r = requests.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        # Crop giữa hình vuông
        s = min(w0, h0)
        img = img.crop(((w0-s)//2, (h0-s)//2, (w0+s)//2, (h0+s)//2))
        return img.resize(size, Image.LANCZOS)
    except:
        return blank

def _truncate(draw, text: str, font, max_w: int) -> str:
    if not text:
        return ""
    if draw.textlength(text, font=font) <= max_w:
        return text
    ell  = "…"
    room = max_w - draw.textlength(ell, font=font)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=font) > room:
            break
        out += ch
    return out + ell

def _fmt_num(n):
    try:
        n = int(n)
    except:
        return "0"
    if n >= 1_000_000_000:
        return f"{n/1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)

def draw_tiktok_list(items: list, out_path: str,
                     title: str = "Kết quả TikTok",
                     subtitle: str = "Reply số hoặc: 1 audio") -> str:
    n = min(len(items), 10)
    if n == 0:
        return out_path

    ROWS      = 5
    COLS      = 2
    GAP_X     = 40
    GAP_Y     = 20
    HEADER_H  = 130
    THUMB_SZ  = 110
    IP        = 20   # inner padding

    grid_y1 = PAD + HEADER_H + 10
    grid_h  = H - grid_y1 - PAD
    row_h   = (grid_h - GAP_Y * (ROWS - 1)) // ROWS
    col_w   = (W - PAD * 2 - GAP_X) // COLS

    # Tải thumbnail song song
    thumbs = [None] * n
    def _fetch(i, url):
        thumbs[i] = _fetch_thumb(url, (THUMB_SZ, THUMB_SZ))
    threads = []
    for i, it in enumerate(items[:n]):
        url = (it.get("video") or {}).get("cover") or it.get("cover") or ""
        t = threading.Thread(target=_fetch, args=(i, url), daemon=True)
        threads.append(t); t.start()
    for t in threads:
        t.join(timeout=10)

    canvas = _make_bg()
    d = ImageDraw.Draw(canvas)

    # ── Header ──
    f_header = _font(80, bold=True)
    f_sub    = _font(44)
    d.text((PAD, PAD - 8),       title,    font=f_header, fill=TEXT_TITLE)
    d.text((PAD, PAD + 86),      subtitle, font=f_sub,    fill=TEXT_ARTIST)
    # Divider đỏ
    div_y = grid_y1 - 8
    d.rectangle([PAD, div_y, W - PAD, div_y + 3], fill=ACCENT)

    # ── Fonts cho row ──
    # Tính toán cẩn thận để text không đè nhau
    f_num    = _font(56, bold=True)
    f_title  = _font(44, bold=True)
    f_author = _font(36)
    f_stats  = _font(32)

    # chiều cao thực tế của 3 dòng text
    # num badge: 56, title: 44, author: 36, stats: 32
    # tổng text block = ~56 + 8 + 44 + 8 + 36 + 8 + 32 = ~192px
    # row_h cần >= THUMB_SZ + 2*IP và >= 192 + 2*IP

    for i, item in enumerate(items[:n]):
        col = i % COLS
        row = i // COLS
        x1  = PAD + col * (col_w + GAP_X)
        y1  = grid_y1 + row * (row_h + GAP_Y)
        x2  = x1 + col_w
        y2  = y1 + row_h

        _draw_card_bg(canvas, x1, y1, x2, y2, radius=18)
        d = ImageDraw.Draw(canvas)

        # Số thứ tự (góc trái)
        num_txt = f"{i+1:02d}"
        num_w   = int(d.textlength(num_txt, font=f_num))
        num_x   = x1 + IP
        num_cy  = y1 + (row_h) // 2
        bb      = f_num.getbbox(num_txt)
        num_h   = bb[3] - bb[1]
        d.text((num_x, num_cy - num_h // 2 - bb[1]), num_txt, font=f_num, fill=TEXT_NUM)

        # Thumbnail
        th_x = num_x + num_w + IP
        th_y = y1 + (row_h - THUMB_SZ) // 2
        if thumbs[i]:
            mask = _rounded_mask(THUMB_SZ, THUMB_SZ, 12)
            canvas.paste(thumbs[i], (th_x, th_y), mask)
        else:
            d.rounded_rectangle([th_x, th_y, th_x + THUMB_SZ - 1, th_y + THUMB_SZ - 1],
                                 radius=12, fill=(40, 35, 70, 200))
        d = ImageDraw.Draw(canvas)

        # Text area
        tx   = th_x + THUMB_SZ + IP
        t_mw = x2 - tx - IP   # max width cho text

        desc   = item.get("desc") or "TikTok"
        author = ""
        a = item.get("author") or {}
        if isinstance(a, dict):
            author = a.get("nickname") or a.get("uniqueId") or a.get("unique_id") or ""
        stat = item.get("stat") or {}
        plays    = _fmt_num(stat.get("playCount") or stat.get("play_count") or 0)
        likes    = _fmt_num(stat.get("diggCount")  or stat.get("digg_count") or 0)
        comments = _fmt_num(stat.get("commentCount") or stat.get("comment_count") or 0)

        # Tính vị trí dọc: chia đều theo row_h
        # 3 dòng: title, author, stats — căn giữa theo row
        lh_title  = _font(44, bold=True).getbbox("Ay")[3] - _font(44, bold=True).getbbox("Ay")[1]
        lh_author = f_author.getbbox("Ay")[3] - f_author.getbbox("Ay")[1]
        lh_stats  = f_stats.getbbox("Ay")[3]  - f_stats.getbbox("Ay")[1]
        gap_ln    = 10
        total_h   = lh_title + gap_ln + lh_author + gap_ln + lh_stats
        ty_start  = y1 + (row_h - total_h) // 2

        line1 = _truncate(d, desc,            f_title,  t_mw)
        line2 = _truncate(d, "@" + author if author else "", f_author, t_mw)
        line3 = f"▶ {plays}  ❤ {likes}  💬 {comments}"

        d.text((tx, ty_start),                               line1, font=f_title,  fill=TEXT_TITLE)
        d.text((tx, ty_start + lh_title  + gap_ln),          line2, font=f_author, fill=TEXT_ARTIST)
        d.text((tx, ty_start + lh_title  + gap_ln
                              + lh_author + gap_ln),         line3, font=f_stats,  fill=TEXT_STATS)

    # ── Badge TikTok (góc phải dưới) ──
    f_badge = _font(40, bold=True)
    badge_txt = "TikTok"
    bw2 = int(ImageDraw.Draw(canvas).textlength(badge_txt, font=f_badge)) + 36
    bx  = W - PAD - bw2
    by  = H - PAD - 56
    d = ImageDraw.Draw(canvas)
    d.rounded_rectangle([bx, by, bx + bw2, by + 56], radius=14, fill=BADGE_BG)
    d.text((bx + 18, by + 8), badge_txt, font=f_badge, fill=TEXT_TITLE)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=92)
    return out_path
