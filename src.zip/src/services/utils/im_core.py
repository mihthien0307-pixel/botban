"""
im_core.py  –  Helper cho lệnh im-set trong zBot
Đặt tại: src/services/utils/im_core.py
"""

import json
import threading
import time

from src.services.utils.jsonio import read_settings, write_settings


# ── Lấy danh sách uid đang chờ kết bạn ───────────────────────────────────────

def viewFriend(self):
    """Trả về list uid đang gửi lời mời kết bạn cho bot."""
    try:
        raw = self.listFriendRequests()

        # listFriendRequests() trả về data.get("data") từ response JSON.
        # Tuỳ phiên bản API, đây có thể là:
        #   - dict đã decode   → dùng thẳng
        #   - string encoded   → cần _decode rồi parse
        #   - string JSON thuần → json.loads
        if isinstance(raw, str):
            try:
                decoded = self._decode({"data": raw})
                data = decoded if isinstance(decoded, dict) else {}
            except Exception:
                try:
                    data = json.loads(raw)
                except Exception:
                    data = {}
        elif isinstance(raw, dict):
            data = raw
        else:
            data = {}

        items = data.get("recommItems") or []
        return [
            str(info.get("userId") or "")
            for i in items
            if isinstance(i, dict)
            for info in [i.get("dataInfo") or {}]
            if info.get("userId")
        ]
    except Exception:
        return []


# ── Vòng lặp nền tự động chấp nhận lời mời kết bạn ──────────────────────────

def initCheckFriendRequests(self):
    """Khởi động thread nền tự chấp nhận kết bạn (chỉ chạy 1 lần / bot)."""
    if getattr(self, "friendLoop", False):
        return
    self.friendLoop = True
    self.friendSeen = set()

    def loop():
        while True:
            time.sleep(30)
            s = read_settings(self.uid)
            if not bool(s.get("autoAcceptFriend", False)):
                continue
            ids = viewFriend(self)
            for uid in ids:
                if not uid or uid in self.friendSeen:
                    continue
                self.friendSeen.add(uid)
                try:
                    self.acceptFriendRequest(uid)
                except Exception:
                    pass

    threading.Thread(target=loop, daemon=True).start()


# ── Tự động xoá tin nhắn của uid trong danh sách dontCare ────────────────────

def DontcareMessage(self, message, data, userId, threadId, type):
    """
    Gọi từ onMessage. Nếu userId trong dontCare → xoá tin nhắn của họ.
    """
    try:
        uid = str(userId or "").strip()
        if not uid:
            return

        s  = read_settings(self.uid) or {}
        dc = s.get("dontCare") or []
        if uid not in {str(x) for x in dc if x}:
            return

        msgId    = getattr(data, "msgId",    None)
        cliMsgId = getattr(data, "cliMsgId", None)
        if not msgId or not cliMsgId:
            return

        self.deleteMessage(msgId, uid, cliMsgId, threadId)

    except Exception:
        return
