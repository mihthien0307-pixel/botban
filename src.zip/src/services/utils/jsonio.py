from app.library.packages import *
import threading
from threading import Lock, RLock

sf = 'Data'
luong = 10
sm = threading.Semaphore(luong)
file_lock = Lock()

# ── Settings cache — tránh đọc file disk mỗi message ─────────────────────────
_settings_cache: dict[str, dict] = {}
_cache_lock = RLock()
_CACHE_TTL = 5.0   # giây — hết TTL mới đọc lại file (write_settings reset cache ngay)

_cache_ts: dict[str, float] = {}   # uid -> timestamp lần đọc cuối

def read_settings(uid: str) -> dict:
    now = time.time()
    with _cache_lock:
        ts = _cache_ts.get(uid, 0)
        if uid in _settings_cache and (now - ts) < _CACHE_TTL:
            return dict(_settings_cache[uid])   # trả bản copy để tránh mutate

    # Cache miss hoặc TTL hết → đọc file
    data_file_path = f"data/config/bot/{sf}-{uid}.json"
    try:
        with file_lock:
            with open(data_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    with _cache_lock:
        _settings_cache[uid] = data
        _cache_ts[uid] = time.time()

    return dict(data)

def write_settings(uid: str, settings: dict):
    # Cập nhật cache ngay lập tức để các lệnh tiếp theo thấy dữ liệu mới
    with _cache_lock:
        _settings_cache[uid] = dict(settings)
        _cache_ts[uid] = time.time()

    def write_task():
        try:
            data_file_path = f"data/config/bot/{sf}-{uid}.json"
            with file_lock:
                with open(data_file_path, 'w', encoding='utf-8') as f:
                    json.dump(settings, f, ensure_ascii=False, indent=4)
        finally:
            sm.release()
    sm.acquire()
    thread = threading.Thread(target=write_task)
    thread.start()
    time.sleep(0.4)

def invalidate_settings_cache(uid: str):
    """Gọi khi cần force reload settings từ file (ví dụ sau restart)."""
    with _cache_lock:
        _settings_cache.pop(uid, None)
        _cache_ts.pop(uid, None)

# ─────────────────────────────────────────────────────────────────────────────

def load_json(path, default=None):
    if not os.path.exists(path):
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}

def save_json(path, data):
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)
