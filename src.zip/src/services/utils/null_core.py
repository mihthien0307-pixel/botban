import time
from api.util.object import MessageObject
StickerUrl = "https://f37-zfcloud.zdn.vn/33d23811283f8861d12e/1471286756158048095?stickerCreatedBy=TUANN.NHIM"

def UnknownCommand(this, message, data, userId, threadId, type):
    def sendSticker(n):
        for _ in range(n):
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)
            sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)

    def react(code, n):
        for _ in range(n):
            sendMultiReaction(data, code, threadId, type, 300000, 100)

    def undoDel(n):
        for _ in range(n):
            undoMessage(msgId, cliMsgId, threadId, type)
            deleteMessage(msgId, uid, cliMsgId, threadId)
            undoMessage(msgId, cliMsgId, threadId, type)
            deleteMessage(msgId, uid, cliMsgId, threadId)
            undoMessage(msgId, cliMsgId, threadId, type)
            deleteMessage(msgId, uid, cliMsgId, threadId)
            undoMessage(msgId, cliMsgId, threadId, type)
            deleteMessage(msgId, uid, cliMsgId, threadId)

    parts = message.text.strip().split()
    if len(parts) < 2:
        return this.replyMessageStyle(f"Dùng: --flood | --ws", data, threadId, type)

    msgId = getattr(data, "msgId", None)
    cliMsgId = getattr(data, "cliMsgId", None)
    if msgId is None or cliMsgId is None:
        return

    sendCustomSticker = this.sendCustomSticker
    sendMultiReaction = this.sendMultiReaction
    undoMessage = this.undoMessage
    deleteMessage = this.deleteMessage
    uid = this.uid

    action = parts[1].lower()
    if action == "--flood":
        n = 500000
        warn = this.replyMessageStyle("...", data, threadId, type)
        # warn là dict, replyMessageStyle inject "clientId" (= cliMsgId của warn msg)
        # globalMsgId của warn msg nằm ở key "msgId" trong response
        warn_cliMsgId = (warn or {}).get("clientId")
        warn_msgId = (warn or {}).get("msgId")
        if warn_cliMsgId:
            obj = MessageObject(msgId=warn_msgId or warn_cliMsgId, cliMsgId=warn_cliMsgId, msgType="webchat")
            for i in range(10, 0, -1):
                this.sendMultiReaction(obj, "🕑", threadId, type, 102229, numreact=i)
                time.sleep(1)
                this.sendMultiReaction(obj, "", threadId, type, -1, numreact=i)
            this.deleteMessage(warn_msgId or warn_cliMsgId, this.uid, warn_cliMsgId, threadId)
        sendSticker(n)

    elif action == "--ws":
        n = 500000
        warn = this.replyMessageStyle("...", data, threadId, type)
        warn_cliMsgId = (warn or {}).get("clientId")
        warn_msgId = (warn or {}).get("msgId")
        if warn_cliMsgId:
            obj = MessageObject(msgId=warn_msgId or warn_cliMsgId, cliMsgId=warn_cliMsgId, msgType="webchat")
            for i in range(10, 0, -1):
                this.sendMultiReaction(obj, "🕑", threadId, type, 102229, numreact=i)
                time.sleep(1)
                this.sendMultiReaction(obj, "", threadId, type, -1, numreact=i)
        undoDel(n)
        react("/-ok", n)
