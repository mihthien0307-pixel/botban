from google import genai
import os
from dotenv import load_dotenv
load_dotenv()
client = genai.Client(api_key="AIzaSyD8x_gI9AOTeWBC0ii5uxE5mftSg9hrRVw")

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents="Explain how AI works in a few words",
)

print(response.text)