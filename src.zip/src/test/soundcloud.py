import os
import re
import requests
from bs4 import BeautifulSoup

# ================= CONFIG =================

BASE_API = "https://api-v2.soundcloud.com"
BASE_WEB = "https://soundcloud.com"
DOWNLOAD_DIR = "downloads"

os.makedirs(DOWNLOAD_DIR, exist_ok=True)
_client_id_cache = None

# ================= HELPERS =================

def headers():
    return {
        "User-Agent": "Mozilla/5.0",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://soundcloud.com/",
    }

def is_client_id_valid(client_id: str) -> bool:
    try:
        r = requests.get(
            f"{BASE_API}/search/tracks",
            params={"q": "test", "client_id": client_id, "limit": 1},
            headers=headers(),
            timeout=5
        )
        return r.status_code == 200
    except requests.RequestException:
        return False

def get_client_id() -> str:
    global _client_id_cache

    if _client_id_cache:
        return _client_id_cache

    fallback = "vjvE4M9RytEg9W09NH1ge2VyrZPUSKo5"
    if is_client_id_valid(fallback):
        _client_id_cache = fallback
        return fallback

    r = requests.get(BASE_WEB, headers=headers(), timeout=10)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    scripts = soup.find_all("script", crossorigin=True)

    for tag in reversed(scripts):
        src = tag.get("src")
        if not src:
            continue

        js = requests.get(src, headers=headers(), timeout=10).text
        match = re.search(r'client_id:"(.*?)"', js)
        if match:
            _client_id_cache = match.group(1)
            return _client_id_cache

    raise RuntimeError("Không lấy được client_id SoundCloud")

def resolve_track(link: str) -> dict:
    cid = get_client_id()
    r = requests.get(
        f"{BASE_API}/resolve",
        params={"url": link, "client_id": cid},
        headers=headers(),
        timeout=10
    )
    r.raise_for_status()
    return r.json()

def search_tracks(query: str, limit=10) -> list:
    cid = get_client_id()
    r = requests.get(
        f"{BASE_API}/search/tracks",
        params={
            "q": query,
            "client_id": cid,
            "limit": limit,
            "linked_partitioning": 1,
        },
        headers=headers(),
        timeout=10
    )
    r.raise_for_status()
    return r.json().get("collection", [])

def get_stream_url(track_link: str) -> str | None:
    cid = get_client_id()
    data = resolve_track(track_link)

    for t in data.get("media", {}).get("transcodings", []):
        if t["format"]["protocol"] == "progressive":
            r = requests.get(
                t["url"],
                params={"client_id": cid},
                headers=headers(),
                timeout=10
            )
            return r.json().get("url")
    return None

def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name)
    return name.strip().replace(" ", "_")

def download_file(url: str, filename: str):
    path = os.path.join(DOWNLOAD_DIR, filename)
    with requests.get(url, stream=True, timeout=30) as r:
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
    return path
def main():
    query = input("Nhập tên bài hát: ").strip()
    if not query:
        print("❌ Query rỗng")
        return

    print("🔎 Đang tìm kiếm...")
    tracks = search_tracks(query)

    if not tracks:
        print("❌ Không tìm thấy bài hát")
        return

    for i, t in enumerate(tracks, 1):
        mins, secs = divmod(t.get("duration", 0) // 1000, 60)
        print(f"{i}. {t.get('title')} - {t['user']['username']} [{mins}:{secs:02d}]")

    choice = input("Chọn số bài hát: ").strip()
    if not choice.isdigit():
        print("❌ Lựa chọn không hợp lệ")
        return

    idx = int(choice) - 1
    if idx < 0 or idx >= len(tracks):
        print("❌ Ngoài phạm vi")
        return

    track = tracks[idx]
    print("⬇️ Đang lấy link stream...")

    stream_url = get_stream_url(track["permalink_url"])
    if not stream_url:
        print("❌ Không tải được bài này")
        return

    filename = safe_filename(track["title"]) + ".mp3"
    path = download_file(stream_url, filename)

    print(f"✅ Đã tải xong: {path}")

if __name__ == "__main__":
    main()